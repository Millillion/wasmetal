#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__32(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__32\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128059___O;
    wasmetal_core__DOT____Vcellout___128059___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___000140_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000139_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000136_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000135_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000134_)))))))));
    vlSelf->__VdfgTmp_h0db23397__0 = (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))));
    vlSelf->__VdfgTmp_h3f696fc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013705_));
    vlSelf->wasmetal_core__DOT___017871_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___057987_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___057189_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012440_)))));
    vlSelf->__VdfgTmp_heaf10b4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012440_));
    vlSelf->wasmetal_core__DOT___010082_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056292_)))));
    vlSelf->__VdfgTmp_h2c387a2e__0 = ((4U & ((0x10000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056292_)));
    vlSelf->wasmetal_core__DOT___065207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057306_))));
    vlSelf->wasmetal_core__DOT___050097_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006058_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023497_));
    vlSelf->wasmetal_core__DOT___013783_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013737_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023618_));
    vlSelf->wasmetal_core__DOT___053836_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051834_))));
    vlSelf->wasmetal_core__DOT___053832_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051817_))));
    vlSelf->wasmetal_core__DOT___053848_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051866_))));
    vlSelf->wasmetal_core__DOT___053822_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051795_))));
    vlSelf->wasmetal_core__DOT___053840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051849_))));
    vlSelf->wasmetal_core__DOT___053800_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051742_))));
    vlSelf->wasmetal_core__DOT___059111_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059107_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h83434591__0))))))));
    vlSelf->wasmetal_core__DOT___059158_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059154_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059153_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059152_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006144_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006015_))))))))))));
    vlSelf->wasmetal_core__DOT___059157_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005928_)))))))));
    vlSelf->wasmetal_core__DOT___059135_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059117_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059116_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059115_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) {
        vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d;
        vlSelf->wasmetal_core__DOT___022885_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022885_ = vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___055415_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051920_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051907_))))))));
    vlSelf->wasmetal_core__DOT___053114_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053108_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xaaccf0f0U 
                                                                      >> 
                                                                      ((4U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x5555ccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049204_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049113_))))))));
    vlSelf->wasmetal_core__DOT___049754_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049752_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049751_))));
    vlSelf->wasmetal_core__DOT___051593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051403_))));
    vlSelf->wasmetal_core__DOT___049733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049732_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049731_))));
    vlSelf->wasmetal_core__DOT___049861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049372_))));
    vlSelf->wasmetal_core__DOT___049710_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049708_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049707_))));
    vlSelf->wasmetal_core__DOT___049847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049045_))));
    vlSelf->wasmetal_core__DOT___049691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049690_))));
    vlSelf->wasmetal_core__DOT___053220_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053216_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053215_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051833_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))))));
    vlSelf->wasmetal_core__DOT___049628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049626_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049625_))));
    vlSelf->wasmetal_core__DOT___052629_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049001_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052624_))))))));
    vlSelf->wasmetal_core__DOT___049667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049659_))));
    vlSelf->wasmetal_core__DOT___049509_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049495_))));
    vlSelf->wasmetal_core__DOT___052000_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050610_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051995_))))))));
    vlSelf->wasmetal_core__DOT___049478_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049463_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049462_))));
    vlSelf->wasmetal_core__DOT___049149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049113_))));
    vlSelf->wasmetal_core__DOT___066105_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051412_))))))));
    vlSelf->wasmetal_core__DOT___051419_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051415_)))))));
    vlSelf->wasmetal_core__DOT___049290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049287_))));
    vlSelf->wasmetal_core__DOT___050871_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050696_))));
    vlSelf->wasmetal_core__DOT___053374_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051474_))))))));
    vlSelf->wasmetal_core__DOT___065164_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051485_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051484_)))))));
    vlSelf->wasmetal_core__DOT___050876_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050712_))));
    vlSelf->wasmetal_core__DOT___050821_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049889_))));
    vlSelf->wasmetal_core__DOT___053219_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050529_))))))));
    vlSelf->wasmetal_core__DOT___050834_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049870_))));
    vlSelf->wasmetal_core__DOT___065828_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050731_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050678_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f4141b2__0)))))))))))));
    vlSelf->wasmetal_core__DOT___050862_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049804_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049800_))));
    vlSelf->wasmetal_core__DOT___051012_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050632_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050637_))))))));
    vlSelf->wasmetal_core__DOT___050814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049776_))));
    vlSelf->wasmetal_core__DOT___051927_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0077U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049574_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050475_))))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                              << 2U) 
                                                                             | ((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051920_))))))));
    vlSelf->wasmetal_core__DOT___065729_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x55330f0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051424_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051429_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051461_))))))));
    vlSelf->wasmetal_core__DOT___050802_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049756_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049752_))));
    vlSelf->wasmetal_core__DOT___050807_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049735_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049732_))));
    vlSelf->wasmetal_core__DOT___053121_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053117_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049859_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049387_))))))));
    vlSelf->wasmetal_core__DOT___050635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049708_))));
    vlSelf->wasmetal_core__DOT___049686_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049602_))));
    vlSelf->wasmetal_core__DOT___050979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049626_))));
    vlSelf->wasmetal_core__DOT___050784_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049664_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049660_))));
    vlSelf->wasmetal_core__DOT___051865_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xccaaf000U 
                                                         >> 
                                                         ((4U 
                                                           & ((0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))))))));
    vlSelf->wasmetal_core__DOT___050065_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049496_))));
    vlSelf->wasmetal_core__DOT___051101_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049463_))));
    vlSelf->wasmetal_core__DOT___051060_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049208_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049114_))));
    vlSelf->wasmetal_core__DOT___051045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049288_))));
    vlSelf->wasmetal_core__DOT___051766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049522_))))));
    vlSelf->wasmetal_core__DOT___049523_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049521_))));
    vlSelf->wasmetal_core__DOT___049806_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049804_))));
    vlSelf->wasmetal_core__DOT___050863_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> 
                                                            (1U 
                                                             & (0x35U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049805_))));
    vlSelf->wasmetal_core__DOT___050872_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049714_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050701_))));
    vlSelf->wasmetal_core__DOT___050702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050700_))));
    vlSelf->wasmetal_core__DOT___050822_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049630_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049893_))));
    vlSelf->wasmetal_core__DOT___049894_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049893_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049892_))));
    vlSelf->wasmetal_core__DOT___050717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050715_))));
    vlSelf->wasmetal_core__DOT___050877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049684_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050716_))));
    vlSelf->wasmetal_core__DOT___049781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049779_))));
    vlSelf->wasmetal_core__DOT___050815_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049780_))));
    vlSelf->wasmetal_core__DOT___051771_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049476_))))));
    vlSelf->wasmetal_core__DOT___049479_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049475_))));
    vlSelf->wasmetal_core__DOT___049874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049873_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049872_))));
    vlSelf->wasmetal_core__DOT___050835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049545_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049873_))));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028118_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 5U)));
    vlSelf->wasmetal_core__DOT___052612_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___051797_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049716_))))));
    vlSelf->wasmetal_core__DOT___049717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049715_))));
    vlSelf->wasmetal_core__DOT___051422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049209_))))));
    vlSelf->wasmetal_core__DOT___049210_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049209_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049208_))));
    vlSelf->wasmetal_core__DOT___049759_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049756_))));
    vlSelf->wasmetal_core__DOT___050803_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))))));
    vlSelf->wasmetal_core__DOT___065049_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050554_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050550_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049545_))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050548_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050514_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050530_))))))))))))))));
    vlSelf->wasmetal_core__DOT___051782_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049634_))))));
    vlSelf->wasmetal_core__DOT___049635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049633_))));
    vlSelf->wasmetal_core__DOT___049692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049685_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049603_))));
    vlSelf->wasmetal_core__DOT___049668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049664_))));
    vlSelf->wasmetal_core__DOT___049738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049735_))));
    vlSelf->wasmetal_core__DOT___050808_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))))));
    vlSelf->wasmetal_core__DOT___051408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049326_))))));
    vlSelf->wasmetal_core__DOT___049327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049325_))));
    vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001537_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT____Vcellout___128078___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028463_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028462_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028492_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028491_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028458_)))));
    vlSelf->wasmetal_core__DOT___028430_ = ((IData)(vlSelf->wasmetal_core__DOT___028463_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003558_));
    wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028638_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003484_));
    vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029081_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028950_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128436___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128436___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032287_)))));
    vlSelf->wasmetal_core__DOT___032260_ = ((IData)(vlSelf->wasmetal_core__DOT___001425_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001425_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026484_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026451_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d));
    vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026726_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___070682_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070687_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027196_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026591_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026590_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026589_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026588_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026529_)))));
    vlSelf->wasmetal_core__DOT___026559_ = ((IData)(vlSelf->wasmetal_core__DOT___026591_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001488_));
    vlSelf->wasmetal_core__DOT___070785_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070790_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026996_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5011624a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT____Vcellout___128664___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128436___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034569_)))));
    vlSelf->wasmetal_core__DOT___034510_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001425_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030120_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030276_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    wasmetal_core__DOT____Vcellout___128059___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028314_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028313_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028312_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028311_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028278_)))));
    vlSelf->wasmetal_core__DOT___028282_ = ((IData)(vlSelf->wasmetal_core__DOT___028314_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028249_));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036899_)
            ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036636_));
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027471_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127952___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027394_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027393_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027377_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027301_)))));
    vlSelf->wasmetal_core__DOT___027330_ = ((IData)(vlSelf->wasmetal_core__DOT___027394_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b7__05d));
    vlSelf->wasmetal_core__DOT___023234_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfaf781e7__0))));
    vlSelf->wasmetal_core__DOT___023233_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005921_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))));
    vlSelf->wasmetal_core__DOT___023232_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc23424b0__0))));
    vlSelf->wasmetal_core__DOT___023231_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005875_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128142___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029126_)))));
    vlSelf->wasmetal_core__DOT___029130_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128325___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031048_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031047_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031046_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031045_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031012_)))));
    vlSelf->wasmetal_core__DOT___031016_ = ((IData)(vlSelf->wasmetal_core__DOT___031048_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    if (vlSelf->wasmetal_core__DOT___010722_) {
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011595_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))))))));
        vlSelf->wasmetal_core__DOT___012826_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf1343531__0))));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (0x10fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h52908d38__0)))));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h74563738__0))));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011853_)));
    } else {
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf0f0000aaccULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0faacc00000000ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))));
        vlSelf->wasmetal_core__DOT___012826_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012794_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011939_)))));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011854_));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0xaaaaccccf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013099_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (0x5300U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0))))))));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (0xf0f033aaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011889_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h23ac912c__0))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011887_)))))));
    }
    vlSelf->wasmetal_core__DOT___011352_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011359_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011358_)))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(
                                                                 (0xf0f0553300000000ULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(
                                                                  (0xf0f000005533ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0)))))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011361_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011360_)))));
    vlSelf->wasmetal_core__DOT___057560_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___012610_ = ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011566_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h033744d0__0))))))));
    vlSelf->__VdfgTmp_hdcc00e41__0 = (((IData)(vlSelf->wasmetal_core__DOT___011300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011299_));
    vlSelf->__VdfgTmp_ha9c6ec44__0 = (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011785_));
    vlSelf->__VdfgTmp_h358fed79__0 = (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012219_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012218_)));
    vlSelf->wasmetal_core__DOT___057161_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011045_)))));
    vlSelf->__VdfgTmp_h417b846d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011793_));
    vlSelf->__VdfgTmp_hde352602__0 = (((IData)(vlSelf->wasmetal_core__DOT___011045_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011044_));
    vlSelf->wasmetal_core__DOT___011799_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010791_)))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___011301_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011306_)));
            vlSelf->wasmetal_core__DOT___012072_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011304_)));
        } else {
            vlSelf->wasmetal_core__DOT___011301_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011304_)));
            vlSelf->wasmetal_core__DOT___012072_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011798_));
        }
    } else if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___011301_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011305_)));
        vlSelf->wasmetal_core__DOT___012072_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011799_));
    } else {
        vlSelf->wasmetal_core__DOT___011301_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010423_)))));
        vlSelf->wasmetal_core__DOT___012072_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010789_)))));
    }
    vlSelf->wasmetal_core__DOT___010794_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010790_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010788_))))));
    vlSelf->wasmetal_core__DOT___011315_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010789_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010818_))))));
    vlSelf->wasmetal_core__DOT___011804_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010788_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010817_))))));
    vlSelf->wasmetal_core__DOT___010822_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010818_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010816_))))));
    vlSelf->wasmetal_core__DOT___010821_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010817_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010815_))))));
    vlSelf->wasmetal_core__DOT___011790_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010816_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010666_))))))));
    vlSelf->wasmetal_core__DOT___010671_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010665_))))));
    vlSelf->wasmetal_core__DOT___010670_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010664_))))));
    vlSelf->wasmetal_core__DOT___011323_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010692_))))));
    vlSelf->wasmetal_core__DOT___011812_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010664_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010691_))))));
    vlSelf->wasmetal_core__DOT___010696_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010692_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010690_))))));
    vlSelf->wasmetal_core__DOT___010695_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010691_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010689_))))));
    vlSelf->wasmetal_core__DOT___012781_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010690_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010421_))))))));
    vlSelf->wasmetal_core__DOT___010428_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010420_))))));
    vlSelf->wasmetal_core__DOT___010427_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010419_))))));
    vlSelf->wasmetal_core__DOT___011339_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010420_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010452_))))));
    vlSelf->wasmetal_core__DOT___011820_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010451_))))));
    vlSelf->wasmetal_core__DOT___010456_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010452_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010450_))))));
    vlSelf->wasmetal_core__DOT___010455_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010451_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010449_))))));
    vlSelf->wasmetal_core__DOT___011343_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010450_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010480_))))));
    vlSelf->wasmetal_core__DOT___011824_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010449_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010479_))))));
    vlSelf->wasmetal_core__DOT___010484_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010480_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010478_))))));
    vlSelf->wasmetal_core__DOT___010483_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010479_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010477_))))));
    vlSelf->wasmetal_core__DOT___011347_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010478_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010507_))))));
    vlSelf->wasmetal_core__DOT___011828_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010477_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010506_))))));
    vlSelf->__VdfgTmp_hb5646ca1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->__VdfgTmp_h025488dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010506_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->wasmetal_core__DOT___010512_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010507_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010505_))))));
    vlSelf->wasmetal_core__DOT___056716_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010395_)) 
                                                  & (IData)(
                                                            (0xccccccccddcfcfcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010505_))))))))));
    vlSelf->wasmetal_core__DOT___012559_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->__VdfgTmp_hb8dc7649__0 = (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010508_)));
    vlSelf->wasmetal_core__DOT___057174_ = ((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012456_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056445_))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))));
    vlSelf->wasmetal_core__DOT___056962_ = (1U & (IData)(
                                                         (0xf5f300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056961_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012631_)))))))));
    vlSelf->wasmetal_core__DOT___011558_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012630_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h796615cc__0))))))));
    vlSelf->wasmetal_core__DOT___011788_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))))))));
    vlSelf->wasmetal_core__DOT___012809_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x1111111100ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0110000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011912_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011913_)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h519cda3a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057162_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h519cda3a__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0)))))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))));
        vlSelf->wasmetal_core__DOT___011792_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011305_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_))));
    } else {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xf1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h033744d0__0)))));
        vlSelf->wasmetal_core__DOT___011792_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011799_)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___011798_)));
    }
    vlSelf->wasmetal_core__DOT___012221_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))))))));
    vlSelf->wasmetal_core__DOT___056461_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056443_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                          ? 
                                                                         (0x32U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010950_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010948_))))
                                                                          : 
                                                                         (0xeef0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010949_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___012052_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))))))))));
    vlSelf->__VdfgTmp_hf2cfe231__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056825_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056826_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134220___A 
        = ((0x3fffe000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039092_))) 
                           << 0xdU)) | ((0x1000U & 
                                         ((0xf8U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___039092_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))) 
                                          << 0xcU)) 
                                        | ((0x800U 
                                            & ((IData)(
                                                       (0xfffffff8ffff8888ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055308_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                               << 0xbU)) 
                                           | ((0x400U 
                                               & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055307_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((IData)(
                                                             (0xfffffff8ffff8888ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055306_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((IData)(
                                                                (0xfffffff8ffff8888ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055305_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((IData)(
                                                                   (0xfffffff8ffff8888ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055304_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((IData)(
                                                                      (0xfffffff8ffff8888ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055303_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                              << 6U)) 
                                                          | ((0x20U 
                                                              & ((IData)(
                                                                         (0xfffffff8ffff8888ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055302_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                 << 5U)) 
                                                             | ((0x10U 
                                                                 & ((IData)(
                                                                            (0xfffffff8ffff8888ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                    << 4U)) 
                                                                | ((8U 
                                                                    & ((IData)(
                                                                               (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055300_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                       << 3U)) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055299_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055298_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055297_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___012928_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? (IData)(
                                                                (0xf0f0fcfcf0fff0faULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012934_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012933_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012804_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___012931_))))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___012933_)))));
    vlSelf->wasmetal_core__DOT___011427_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056600_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056599_))))))) 
                                                  & (IData)(
                                                            (0xff55ff33ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                ? 
                                                                               (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011441_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45f38dff__0))))
                                                                                : 
                                                                               (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h39b11875__0))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011445_))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011444_))))))))))))));
    vlSelf->wasmetal_core__DOT___057320_ = ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012616_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xcaU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___011441_)))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf011U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45f38dff__0)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0553300000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___012459_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057169_)))));
    vlSelf->wasmetal_core__DOT___065290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065289_))));
    vlSelf->wasmetal_core__DOT___012001_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3816fa33__0))));
    vlSelf->wasmetal_core__DOT___013184_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3478584b__0))))));
    vlSelf->wasmetal_core__DOT___013168_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3478584b__0))));
    vlSelf->wasmetal_core__DOT___056903_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013139_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h758d714e__0))))))));
    vlSelf->__VdfgTmp_h10754ee4__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   (4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0))))))));
    vlSelf->__VdfgTmp_h9816e297__0 = ((0x10U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                << 4U)) 
                                      | ((8U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                << 3U)) 
                                         | ((4U & (
                                                   (0x17U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                   << 2U)) 
                                            | ((2U 
                                                & ((0x69U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (0x17U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)))))));
    vlSelf->wasmetal_core__DOT___072181_ = (1U & (0x6996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x96U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072175_))))));
    vlSelf->wasmetal_core__DOT___072193_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x96U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134228___A 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055296_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055295_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffff8ffff8888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055294_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffff8ffff8888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055293_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffff8ffff8888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055292_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffff8ffff8888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055291_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055290_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055289_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055288_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffff8ffff8888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055287_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffff8ffff8888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055285_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055284_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055282_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055281_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055280_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___057012_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->wasmetal_core__DOT___057026_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->__VdfgTmp_h3af565ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___057547_) 
                                       << 1U) | (1U 
                                                 & (0xf011U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057009_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056921_)))))));
    vlSelf->__VdfgTmp_h7487032b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010396_));
    vlSelf->wasmetal_core__DOT___011764_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT___056648_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___033416_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012002_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfdfU 
                                                           >> 
                                                           ((0x10U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056787_)))));
    vlSelf->__VdfgTmp_he1977acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___056787_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3816fa33__0));
    vlSelf->wasmetal_core__DOT___053533_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050719_))));
    vlSelf->wasmetal_core__DOT___072180_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))))));
    vlSelf->wasmetal_core__DOT___057538_ = (1U & (IData)(
                                                         (0xaf0fbbffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057536_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))))));
    if (vlSelf->wasmetal_core__DOT___011103_) {
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0xf030f05U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011098_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (0xf011U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51371d7f__0))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011109_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0)))))))))))))));
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xf0accccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00aaccccf0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057438_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012805_)))))));
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))))))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011954_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011099_))))));
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012804_)))));
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                  ? 
                                                                 (2U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x55330fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0))))
                                                                  : 
                                                                 (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h39b11875__0)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___011407_))))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011955_))))));
    }
    vlSelf->__VdfgTmp_hedaab00c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011098_));
    vlSelf->wasmetal_core__DOT___057172_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7c3586c1__0))))));
    vlSelf->wasmetal_core__DOT___057100_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaf0fbbffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012474_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))))))))))));
    vlSelf->wasmetal_core__DOT___011129_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056335_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056336_))))))) 
                                                  & (IData)(
                                                            (0xff33ff55ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011136_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011135_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h23c0a543__0))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011109_)))))))))))))));
    vlSelf->wasmetal_core__DOT___056388_ = (1U & (IData)(
                                                         (0xff00fff8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056374_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056371_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056372_)))))))));
    vlSelf->wasmetal_core__DOT___056480_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011103_)))));
    vlSelf->wasmetal_core__DOT___012053_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))));
    vlSelf->__VdfgTmp_hb67239de__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057468_));
    vlSelf->wasmetal_core__DOT___012599_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))));
    vlSelf->__VdfgTmp_hdb922d45__0 = (((IData)(vlSelf->wasmetal_core__DOT___057025_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x30303030000ffaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057050_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057049_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010182_))))))))));
    vlSelf->__VdfgTmp_h3514b323__0 = (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057547_));
    vlSelf->__VdfgTmp_h224cdee6__0 = (((IData)(vlSelf->wasmetal_core__DOT___012393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012392_));
    if (vlSelf->wasmetal_core__DOT___011101_) {
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011748_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___011749_)))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5fb0de62__0))))))));
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8ae31ec8__0))))))));
        vlSelf->wasmetal_core__DOT___012448_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012394_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___012395_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___012714_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012721_))
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012718_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012717_))))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012720_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012719_)))
                                                                    : 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012722_)))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00aaccccf0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h77847496__0)))))))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                    ? 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h77847496__0))))))) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                               ? 
                                                              (0xee0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011631_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xf0faacc00000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))))))))
                                                               : 
                                                              (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011632_)))))))))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011576_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011574_))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xf0f0aaccU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013103_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h74563738__0))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xaaccf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057630_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))))))))))))))));
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (0xccaafff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfffff0f0ff001111ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012721_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((0xffaaccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012717_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012718_)))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0x11f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012722_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012719_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___012720_)))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011593_))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012642_)))))));
        vlSelf->wasmetal_core__DOT___012448_ = (1U 
                                                & (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xcaU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h224cdee6__0))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xaaaaf0f000ffccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h30784950__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010949_)))))))))))))));
    }
    vlSelf->wasmetal_core__DOT___057455_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057449_))))))) 
                                                  & (IData)(
                                                            (0xffccffaaff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012915_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0xf0f000eeU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057438_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010721_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccf0f0ff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012800_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___057386_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        & (IData)(
                                                                  (0xff00ff0f33335555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011939_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012793_))))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                ? 
                                                               (0xfeeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h03a652de__0))))
                                                                : 
                                                               (0x35U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012799_)))))))))));
    vlSelf->__VdfgTmp_he499e9e8__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056900_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___056899_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056901_));
    vlSelf->wasmetal_core__DOT___013108_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057571_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0xf11U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xac00U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x55330000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hefe0e1be__0))))))))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___013139_)) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                              ? 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___012131_))
                                                                               : 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011868_)))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011869_))
                                                                               : 
                                                                              (0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013144_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013145_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013041_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013038_))))))));
    vlSelf->wasmetal_core__DOT___057504_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012879_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c1422ca__0))));
    vlSelf->wasmetal_core__DOT___066145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012941_))));
    vlSelf->wasmetal_core__DOT___011731_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011253_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057256_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012597_))));
    vlSelf->wasmetal_core__DOT___057028_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012240_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->__VdfgTmp_hca77b771__0 = (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012240_));
    vlSelf->__VdfgTmp_h638ad0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013166_));
    vlSelf->__VdfgTmp_h839fe08c__0 = ((4U & ((0x177eU 
                                              >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                             << 2U)) 
                                      | ((2U & ((0xe81717e8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___072145_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072143_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___072146_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x17U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x115577f577f0115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x96U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x6996U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___072182_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))))));
    vlSelf->wasmetal_core__DOT___072195_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0))))))));
    vlSelf->wasmetal_core__DOT___072196_ = (1U & (IData)(
                                                         (0xe81717e817e8e817ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x6996U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))));
    vlSelf->wasmetal_core__DOT___067171_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012023_)))));
    vlSelf->wasmetal_core__DOT___056835_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xdddd000f000fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056803_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056703_)))));
    vlSelf->__VdfgTmp_h4364218e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012023_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xccccaaaa00f000ffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xf011U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012983_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))))))));
    vlSelf->wasmetal_core__DOT___057118_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057114_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeee0000fff00000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf00eeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010392_)))))))))))))));
    vlSelf->__VdfgTmp_hef87eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012425_));
    vlSelf->wasmetal_core__DOT___068285_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012441_))))));
    vlSelf->__VdfgTmp_hd6fa80fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010896_));
    vlSelf->wasmetal_core__DOT___056479_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056478_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x11f00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___056780_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056774_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1343531__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011853_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056775_))))));
    vlSelf->__VdfgTmp_he54a047f__0 = ((4U & ((0xca000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056730_)))))) 
                                             << 2U)) 
                                      | ((2U & ((1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xfafcULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4aad360c__0))))))) 
                                                << 1U)) 
                                         | ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ffaaff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011853_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012798_))))))))))))))));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022737_));
    vlSelf->__VdfgTmp_hd6365363__0 = (((IData)(vlSelf->wasmetal_core__DOT___012261_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012184_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc49b4927__0))))
                                                     : 
                                                    (0x53U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaaccccf0f0ff00ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012185_)))))));
    vlSelf->__VdfgTmp_h2163f181__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___012582_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcdbca8e0__0))));
    vlSelf->__VdfgTmp_ha0e20209__0 = (((IData)(vlSelf->wasmetal_core__DOT___012644_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2994a26e__0))))
                                                     : 
                                                    (0x32U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 2U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                           & (IData)(
                                                                     (0xcc00fff0f0aaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hcd2c6110__0))))))) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011441_)))))));
    vlSelf->wasmetal_core__DOT___011461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf000ffccccaaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011586_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056607_)))));
    vlSelf->wasmetal_core__DOT___011683_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_h6b93e166__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012598_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012597_)));
    vlSelf->wasmetal_core__DOT___017453_ = (1U & (IData)(
                                                         (0xf351000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___017452_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058852_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127618___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___024031_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127602___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023904_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050147_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006632_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050145_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003806_)))))))));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059074_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000140_)))))));
    vlSelf->wasmetal_core__DOT___000131_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000140_));
    vlSelf->wasmetal_core__DOT___057105_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heaf10b4b__0))));
    vlSelf->__VdfgTmp_h4448f15c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010082_));
    if (vlSelf->wasmetal_core__DOT___010085_) {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xfa330000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfff00000eeeeULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8262dffe__0)))))))))))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xeef0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012597_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012596_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0xc5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010081_)))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012598_))));
    }
    vlSelf->__VdfgTmp_h9167c706__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010081_)));
    vlSelf->__VdfgTmp_heef7d961__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h2c387a2e__0));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013775_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___013783_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___013778_))))))))));
    vlSelf->wasmetal_core__DOT___057757_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013783_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013740_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059134_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___059162_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127487___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022948_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127479___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___067403_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053116_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___049760_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049753_)))));
    vlSelf->wasmetal_core__DOT___051900_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xff00ff0f0f1111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050514_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050631_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051895_)))))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051898_))))))));
    vlSelf->wasmetal_core__DOT___055082_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x5cU 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((0xf0f5533U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___050629_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xfbbU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053117_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049861_))))))));
    vlSelf->wasmetal_core__DOT___009508_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049861_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049860_))))))));
    vlSelf->wasmetal_core__DOT___051655_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009538_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051647_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051646_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049710_))))))));
    vlSelf->wasmetal_core__DOT___049718_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049710_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049709_)))));
    vlSelf->wasmetal_core__DOT___055081_ = (1U & (IData)(
                                                         (0x7fff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff00f0f01111ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051895_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049151_))))) 
                                                                                << 2U)) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___050632_) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051485_))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))));
    vlSelf->wasmetal_core__DOT___049636_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049628_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049627_)))));
    vlSelf->wasmetal_core__DOT___049524_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049508_)))));
    vlSelf->wasmetal_core__DOT___049211_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049148_)))));
    vlSelf->wasmetal_core__DOT___050873_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050870_)))));
    vlSelf->wasmetal_core__DOT___065172_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x3fff20003fff3fffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___065166_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051841_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xfdf0000U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065165_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065164_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0fff4400000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051468_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051467_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051466_)))))))))))))));
    vlSelf->wasmetal_core__DOT___050823_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050820_)))));
    vlSelf->wasmetal_core__DOT___050864_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050862_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050861_)))));
    vlSelf->wasmetal_core__DOT___064888_ = (1U & (IData)(
                                                         (0xff0f0000bbbb0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051008_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049464_))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051006_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050978_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050904_))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050896_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050731_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050804_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050802_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050801_)))));
    vlSelf->wasmetal_core__DOT___051796_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051329_)))));
    vlSelf->wasmetal_core__DOT___050641_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049716_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050635_)))));
    vlSelf->__VdfgTmp_h36c85254__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049686_) 
                                          << 1U) | 
                                         (1U & (1U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049690_)))));
    vlSelf->wasmetal_core__DOT___049772_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049685_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049686_)))));
    vlSelf->wasmetal_core__DOT___051781_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050997_)))));
    vlSelf->wasmetal_core__DOT___050981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049634_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050979_)))));
    vlSelf->__VdfgTmp_hd9ae5f1a__0 = ((4U & ((4U >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050784_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051295_)));
    vlSelf->wasmetal_core__DOT___051297_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049665_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050784_)))));
    vlSelf->wasmetal_core__DOT___051867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051865_))));
    vlSelf->wasmetal_core__DOT___053193_ = (1U & (0xac00U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051865_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xaaccf0f0U 
                                                            >> 
                                                            ((4U 
                                                              & ((IData)(
                                                                         (0x5555cccc0f0fff00ULL 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049483_)))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((0xf0faaccU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xaaaaccccf0f0ff00ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051765_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051116_)))));
    vlSelf->wasmetal_core__DOT___050067_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049522_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050065_)))));
    vlSelf->wasmetal_core__DOT___051104_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049476_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051101_)))));
    vlSelf->wasmetal_core__DOT___051753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051059_)))));
    vlSelf->wasmetal_core__DOT___051063_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049209_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051060_)))));
    vlSelf->wasmetal_core__DOT___051048_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049326_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051045_)))));
    vlSelf->wasmetal_core__DOT___051619_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049523_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049509_))))));
    vlSelf->wasmetal_core__DOT___051709_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049806_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049802_)))));
    vlSelf->wasmetal_core__DOT___049809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> 
                                                                   (1U 
                                                                    & (0x35U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049806_)))));
    vlSelf->wasmetal_core__DOT___050865_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050863_))));
    vlSelf->wasmetal_core__DOT___051370_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050862_)))));
    vlSelf->wasmetal_core__DOT___051554_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050872_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050871_))))));
    vlSelf->wasmetal_core__DOT___050874_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050872_))));
    vlSelf->wasmetal_core__DOT___051743_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050702_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050698_)))));
    vlSelf->wasmetal_core__DOT___050705_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049714_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050702_)))));
    vlSelf->wasmetal_core__DOT___051527_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050821_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))));
    vlSelf->wasmetal_core__DOT___053657_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050822_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050821_)))));
    vlSelf->wasmetal_core__DOT___051722_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049894_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049891_)))));
    vlSelf->wasmetal_core__DOT___049896_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049630_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049894_)))));
    vlSelf->__VdfgTmp_h07886821__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (4U 
                                                >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___050717_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050713_)));
    vlSelf->wasmetal_core__DOT___050720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050717_)))));
    vlSelf->wasmetal_core__DOT___053387_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053374_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053373_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050877_))))))))))));
    vlSelf->__VdfgTmp_hd604be0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050876_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051544_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050877_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050876_)))));
    vlSelf->__VdfgTmp_h32fdaf9b__0 = ((4U & ((8U >> 
                                              (1U & 
                                               (8U 
                                                >> 
                                                (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___049781_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049777_)));
    vlSelf->wasmetal_core__DOT___049784_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049781_)))));
    vlSelf->wasmetal_core__DOT___050817_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050815_))));
    vlSelf->wasmetal_core__DOT___051359_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050814_)))));
    vlSelf->wasmetal_core__DOT___065400_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___051992_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051991_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052000_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051999_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->__VdfgTmp_hc485c507__0 = (((IData)(vlSelf->wasmetal_core__DOT___051771_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051101_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051100_))))));
    vlSelf->__VdfgTmp_h8235f0ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049478_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051605_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049479_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049478_)))));
    vlSelf->wasmetal_core__DOT___053724_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049874_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049871_))))));
    vlSelf->wasmetal_core__DOT___049877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049545_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049874_)))));
    vlSelf->wasmetal_core__DOT___050837_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050835_))));
    vlSelf->wasmetal_core__DOT___051513_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050835_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050834_)))));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028119_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 6U)));
    vlSelf->wasmetal_core__DOT___053129_ = (1U & (IData)(
                                                         (0x7f7f7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053121_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053120_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))));
    vlSelf->wasmetal_core__DOT___009537_ = (1U & (0x5300U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049717_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049710_)))));
    vlSelf->wasmetal_core__DOT___049719_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049717_))));
    vlSelf->wasmetal_core__DOT___051438_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051423_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))));
    vlSelf->wasmetal_core__DOT___051587_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049210_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049149_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049148_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051583_))))))));
    vlSelf->wasmetal_core__DOT___049212_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049210_))));
    vlSelf->wasmetal_core__DOT___051693_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049754_)))));
    vlSelf->wasmetal_core__DOT___049761_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049759_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))))))))))));
    vlSelf->wasmetal_core__DOT___051350_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050803_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050802_)))));
    vlSelf->wasmetal_core__DOT___050805_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050803_))));
    vlSelf->wasmetal_core__DOT___065506_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x30f0200030f030fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052623_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049578_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049577_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049576_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050542_)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050899_))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051782_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051789_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x7f7f7fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052629_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052628_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049665_))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0)))))))))))));
    vlSelf->wasmetal_core__DOT___051634_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049628_)))));
    vlSelf->wasmetal_core__DOT___049637_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049635_))));
    vlSelf->wasmetal_core__DOT___051641_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->wasmetal_core__DOT___049694_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049692_))));
    vlSelf->wasmetal_core__DOT___009497_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xbfff0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055066_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049668_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xff55ccf0U 
                                                               >> 
                                                               ((0x10U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                    << 4U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052624_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3784db21__0))))))))));
    vlSelf->__VdfgTmp_h0f76403b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___049667_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 (2U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                       << 1U)) 
                                                                     << 1U))) 
                                                                << 1U))) 
                                                           << 1U))))));
    vlSelf->wasmetal_core__DOT___051623_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049668_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049667_)))));
    vlSelf->__VdfgTmp_ha03a7afa__0 = ((2U & ((0xacU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051696_));
    vlSelf->wasmetal_core__DOT___049740_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049738_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (1U 
                                                                     & (8U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049321_)))))))))))));
    vlSelf->__VdfgTmp_h45934da4__0 = (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___050807_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (1U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___049731_)))));
    vlSelf->wasmetal_core__DOT___051339_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050807_)))));
    vlSelf->wasmetal_core__DOT___051420_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051407_)))))))));
    vlSelf->__VdfgTmp_hd506ed16__0 = (((IData)(vlSelf->wasmetal_core__DOT___051408_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051045_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___051044_))))));
    vlSelf->wasmetal_core__DOT___049329_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049327_))));
    vlSelf->wasmetal_core__DOT___051574_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049327_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049290_)))));
    vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001569_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128113___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028874_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028873_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028872_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028839_)))));
    vlSelf->wasmetal_core__DOT___028843_ = ((IData)(vlSelf->wasmetal_core__DOT___028875_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___028848_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___028847_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___028877_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___028876_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028464_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028430_)
            : (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->wasmetal_core__DOT____Vcellout___128096___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028639_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028638_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028668_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028667_)))) 
           ^ (((IData)(wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028634_)))));
    vlSelf->wasmetal_core__DOT___028606_ = ((IData)(vlSelf->wasmetal_core__DOT___028639_)
                                             ? (IData)(wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003558_));
    vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029082_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT____Vcellout___128123___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028951_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028950_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028980_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028979_)))) 
           ^ (((IData)(wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028946_)))));
    vlSelf->wasmetal_core__DOT___028918_ = ((IData)(vlSelf->wasmetal_core__DOT___028951_)
                                             ? (IData)(wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001524_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001524_)
            : (IData)(vlSelf->wasmetal_core__DOT___032260_));
    vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028742_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026485_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d));
    vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026664_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___070684_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070683_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070689_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070688_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027134_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d));
    vlSelf->wasmetal_core__DOT___045492_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071347_))))))));
    vlSelf->wasmetal_core__DOT___045516_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071347_)))))))));
    vlSelf->wasmetal_core__DOT___045489_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045513_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045288_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071410_))))))));
    vlSelf->wasmetal_core__DOT___045312_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071410_)))))))));
    vlSelf->wasmetal_core__DOT___045285_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___045309_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026592_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026559_)
            : (IData)(vlSelf->wasmetal_core__DOT___001370_));
    vlSelf->wasmetal_core__DOT___070787_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070786_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070792_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070791_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026934_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___040007_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040008_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___040014_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___040024_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d)))))))));
    vlSelf->__VdfgTmp_h3b36f4b3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->__VdfgTmp_hf4f36877__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->__VdfgTmp_h0642a572__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->__VdfgTmp_h25bc616c__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001524_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034510_));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030121_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030281_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___063120_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063126_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063132_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063138_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128059___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028315_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028282_)
            : (IData)(vlSelf->wasmetal_core__DOT___028250_));
    vlSelf->wasmetal_core__DOT___036894_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036900_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134172___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036900_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036899_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036898_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036897_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT____Vcellout___127961___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027472_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027471_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027470_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027469_)))) 
           ^ (((IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027436_ = ((IData)(vlSelf->wasmetal_core__DOT___027472_)
                                             ? (IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d));
    vlSelf->wasmetal_core__DOT___027473_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d))));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027395_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027330_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b8__05d));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029130_));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031049_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031016_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___011460_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056618_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011538_))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011539_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011540_))
                                                                                 : 
                                                                                (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h06746976__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeeeeeee00000fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056616_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056615_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                & (IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f5f0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : 
                                                                                (0xfff01111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010332_)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha8472195__0))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010722_)))))))));
    vlSelf->wasmetal_core__DOT___012608_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff3355550f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___057381_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h417b846d__0))))))));
    vlSelf->wasmetal_core__DOT___011093_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->wasmetal_core__DOT___011296_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___011088_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010789_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010794_))));
    vlSelf->wasmetal_core__DOT___011432_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010794_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011315_)));
    vlSelf->wasmetal_core__DOT___011791_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011315_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011804_)));
    vlSelf->wasmetal_core__DOT___012071_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011804_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010822_)));
    vlSelf->wasmetal_core__DOT___011431_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010821_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010816_))))))));
    vlSelf->wasmetal_core__DOT___011087_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010822_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010821_)));
    vlSelf->wasmetal_core__DOT___012070_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010671_))));
    vlSelf->wasmetal_core__DOT___056366_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010671_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010670_)));
    vlSelf->wasmetal_core__DOT___056592_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011323_)));
    vlSelf->wasmetal_core__DOT___056715_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011323_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011812_)));
    vlSelf->wasmetal_core__DOT___056890_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011812_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010696_)));
    vlSelf->wasmetal_core__DOT___056591_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010695_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010690_))))))));
    vlSelf->wasmetal_core__DOT___056365_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010696_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010695_)));
    vlSelf->wasmetal_core__DOT___013057_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010428_))));
    vlSelf->wasmetal_core__DOT___010406_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010427_)));
    vlSelf->wasmetal_core__DOT___011332_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010427_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011339_)));
    vlSelf->wasmetal_core__DOT___012780_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011339_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011820_)));
    vlSelf->wasmetal_core__DOT___013056_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011820_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010456_)));
    vlSelf->wasmetal_core__DOT___010405_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010456_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010455_)));
    vlSelf->wasmetal_core__DOT___011331_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010455_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011343_)));
    vlSelf->wasmetal_core__DOT___012779_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011343_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011824_)));
    vlSelf->wasmetal_core__DOT___013055_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011824_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010484_)));
    vlSelf->wasmetal_core__DOT___010404_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010483_)));
    vlSelf->wasmetal_core__DOT___011330_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010483_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011347_)));
    vlSelf->wasmetal_core__DOT___012778_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011347_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011828_)));
    vlSelf->wasmetal_core__DOT___057389_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xefffffffecccccccULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))))))));
    vlSelf->__VdfgTmp_hfce8a752__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))));
    vlSelf->wasmetal_core__DOT___012531_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? (IData)(
                                                                (0xfcfcfafafff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010423_))))));
    vlSelf->wasmetal_core__DOT___011329_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xffccffaafff0fff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))));
    vlSelf->wasmetal_core__DOT___010403_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010512_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010506_))))))));
    vlSelf->wasmetal_core__DOT___012105_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010512_)));
    vlSelf->wasmetal_core__DOT___069249_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___011743_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___012106_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010604_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010407_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___011783_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___011910_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056744_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))));
    vlSelf->wasmetal_core__DOT___011081_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011084_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011046_)))))))));
    vlSelf->__VdfgTmp_he19177ad__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011045_)))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011044_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf110000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf000f33335555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056447_) 
                                                                              << 3U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                & (IData)(
                                                                                (0x333355550f0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011084_))))))));
    vlSelf->wasmetal_core__DOT___012216_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h358fed79__0)))))));
    vlSelf->__VdfgTmp_h95aabd6f__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011301_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf10000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011557_))))))));
    vlSelf->__VdfgTmp_ha5e2ba13__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0))));
    vlSelf->__VdfgTmp_h187b70d7__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012392_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___012474_));
    vlSelf->wasmetal_core__DOT___065320_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065290_))));
    vlSelf->wasmetal_core__DOT___057559_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___056985_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056903_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f555500ff3333ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0)) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0)))))))))))));
    vlSelf->wasmetal_core__DOT___072167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072148_))));
    vlSelf->wasmetal_core__DOT___072165_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072148_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0))))));
    vlSelf->__VdfgTmp_h39564552__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x69969669U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x96U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072175_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))));
    vlSelf->wasmetal_core__DOT___072198_ = (1U & (IData)(
                                                         (0x7117177117717117ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072181_)))))))));
    vlSelf->wasmetal_core__DOT___072208_ = (1U & (IData)(
                                                         (0x22aabbfabbf022aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072177_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072193_)))))))));
    vlSelf->wasmetal_core__DOT___072194_ = (1U & (IData)(
                                                         (0x17e8e817e81717e8ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072177_)))))))));
    vlSelf->wasmetal_core__DOT___057030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaaff0f0c0f0cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057025_))))))))))));
    vlSelf->wasmetal_core__DOT___057587_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3af565ab__0))));
    vlSelf->wasmetal_core__DOT___057553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h3af565ab__0)))))))))));
    vlSelf->wasmetal_core__DOT___012602_ = (1U & (0xccaa0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057306_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7487032b__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012685_)))))));
    vlSelf->wasmetal_core__DOT___057257_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xf00eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7487032b__0))))))));
    vlSelf->wasmetal_core__DOT___067676_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011764_))))));
    vlSelf->wasmetal_core__DOT___011732_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011764_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056645_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056647_)))))))));
    vlSelf->wasmetal_core__DOT___011684_ = (1U & (IData)(
                                                         (0xccccaaaa00f000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056648_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056647_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056635_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056634_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056645_)))))))));
    vlSelf->wasmetal_core__DOT___056689_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056647_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056648_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128548___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010044_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010022_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033452_)))));
    vlSelf->wasmetal_core__DOT___033480_ = ((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___056790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf077U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))))));
    vlSelf->wasmetal_core__DOT___012054_ = (1U & (0xf0088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))));
    vlSelf->wasmetal_core__DOT___056384_ = (1U & (IData)(
                                                         (0xccaa0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056382_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))))));
    vlSelf->wasmetal_core__DOT___056462_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))));
    vlSelf->wasmetal_core__DOT___012449_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057172_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaa33f0f0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012400_)))))))))))))));
    vlSelf->__VdfgTmp_h7a970221__0 = (((IData)(vlSelf->wasmetal_core__DOT___012941_) 
                                       << 2U) | ((2U 
                                                  & ((0xf400U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfff00000eeeeULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb67239de__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff1ff00ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                                          << 3U)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0)))))))));
    vlSelf->__VdfgTmp_hb6e1260e__0 = ((4U & ((IData)(
                                                     (0xf0fff4400000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((IData)(
                                                                         (0xfff00000eeeeULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                                 << 3U)) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                                            ? 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (0xbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012990_)))
                                                                            : 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012992_))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012991_))))))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012983_))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb67239de__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___012969_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010084_)));
    vlSelf->wasmetal_core__DOT___012315_ = (1U & (IData)(
                                                         (0xaaaacccc000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___012329_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___013076_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))));
    vlSelf->wasmetal_core__DOT___012895_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057445_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011101_))))));
    vlSelf->wasmetal_core__DOT___012811_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057390_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               & (IData)(
                                                                         (0xf0f3333ff005555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011889_))))))))) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h03a652de__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012799_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012845_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012828_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012826_))))))));
    vlSelf->__VdfgTmp_h2ddf0adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 2U) | ((2U 
                                                  & ((0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011954_)))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011103_)));
    vlSelf->__VdfgTmp_h5b3d01ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he499e9e8__0))));
    vlSelf->wasmetal_core__DOT___057660_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x10U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057540_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___011102_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x33550f0f00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013103_)))))))))))))));
    vlSelf->wasmetal_core__DOT___057633_ = (1U & (IData)(
                                                         (0xff00f8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1100f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013144_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013142_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013143_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057630_)))))))));
    vlSelf->wasmetal_core__DOT___066100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057343_))));
    vlSelf->wasmetal_core__DOT___065917_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___057031_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___012316_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___056947_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca77b771__0))));
    vlSelf->wasmetal_core__DOT___012330_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___057552_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))));
    vlSelf->wasmetal_core__DOT___013159_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & (IData)(
                                                      (0xff00ff33f5f5f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))))))));
    vlSelf->wasmetal_core__DOT___072201_ = (1U & (IData)(
                                                         (0xb22b2bb22bb2b22bULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072180_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->__VdfgTmp_h1399f995__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x9669699669969669ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___072180_)))))))))));
    vlSelf->wasmetal_core__DOT___072202_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072180_))))));
    vlSelf->wasmetal_core__DOT___067824_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hef87eb38__0))));
    vlSelf->wasmetal_core__DOT___068071_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6fa80fa__0))));
    vlSelf->__VdfgTmp_hf72e2656__0 = (((IData)(vlSelf->wasmetal_core__DOT___056481_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056480_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056479_)));
    vlSelf->__VdfgTmp_hbeb24dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___056779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056780_));
    vlSelf->wasmetal_core__DOT___056747_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x1f00U 
                                                                 >> 
                                                                 ((8U 
                                                                   & (((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                                       & (IData)(
                                                                                (0xfffff8f8ffffff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011900_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011898_))))))))) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h1d24e3fc__0)))))))))));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___012165_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33aa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6365363__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056914_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5550fff003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056964_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056968_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012262_)))))))));
    vlSelf->wasmetal_core__DOT___012620_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057288_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcf5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012642_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   (0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___011631_))))
                                                                    : 
                                                                   (0xfeeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011632_) 
                                                                         << 2U) 
                                                                        | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                             & (IData)(
                                                                                (0xccccaaaaf0f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf0faf0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056425_)))))))))))))))))))
                                                      : 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_ha0e20209__0)))))));
    vlSelf->__VdfgTmp_hde86d559__0 = ((2U & ((IData)(
                                                     (0xa0a0f0f00ff00ccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeeeULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xaaaacccc00f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012991_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057264_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (IData)(vlSelf->__VdfgTmp_h6b93e166__0))));
}
