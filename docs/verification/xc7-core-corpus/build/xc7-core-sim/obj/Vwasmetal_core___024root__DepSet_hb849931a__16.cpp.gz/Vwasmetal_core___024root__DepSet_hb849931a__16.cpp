#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__22(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__22\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___053577_;
    wasmetal_core__DOT___053577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063458_;
    wasmetal_core__DOT___063458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063583_;
    wasmetal_core__DOT___063583_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063591_;
    wasmetal_core__DOT___063591_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063599_;
    wasmetal_core__DOT___063599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063607_;
    wasmetal_core__DOT___063607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070648_;
    wasmetal_core__DOT___070648_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__ = 0;
    // Body
    if (vlSelf->wasmetal_core__DOT___010396_) {
        vlSelf->wasmetal_core__DOT___012867_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011962_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011772_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011771_))))));
        if (vlSelf->wasmetal_core__DOT___010395_) {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011960_))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010402_));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011192_));
        } else {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011962_)));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_he0f8989d__0)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
        }
        vlSelf->wasmetal_core__DOT___011252_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011186_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011185_)))));
        vlSelf->wasmetal_core__DOT___012597_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011185_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___012867_ = (1U 
                                                & (0x32U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeee0000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011770_)))));
        if (vlSelf->wasmetal_core__DOT___010395_) {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> ((4U & ((IData)((0xfff00000eeeeULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_h9edc9904__0))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010394_)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
        } else {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> (1U & (IData)((0xfff00000eeeeULL 
                                            >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010393_)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011185_)));
        }
        vlSelf->wasmetal_core__DOT___011252_ = (1U 
                                                & (0x10fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))));
        vlSelf->wasmetal_core__DOT___012597_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeee0000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011205_)))));
    }
    vlSelf->__VdfgTmp_h3b3aaa80__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011770_));
    vlSelf->wasmetal_core__DOT___056970_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056931_))));
    vlSelf->__VdfgTmp_h0b76dd71__0 = (((IData)(vlSelf->wasmetal_core__DOT___056931_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056930_));
    vlSelf->wasmetal_core__DOT___056828_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h86de1fc0__0)))))));
    vlSelf->__VdfgTmp_hca116eb2__0 = ((2U & ((IData)(
                                                     (0xfff4ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012287_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h86de1fc0__0)))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf4f400ff00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3a025ab3__0)))))));
    vlSelf->__VdfgTmp_hd485d8e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___057011_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057010_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057009_)));
    vlSelf->wasmetal_core__DOT___013169_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056921_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057009_)))))));
    vlSelf->wasmetal_core__DOT___072143_ = (1U & (0xb2U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab99f676__0))));
    vlSelf->wasmetal_core__DOT___056497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055199_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d 
        = (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___055309_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT___012805_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056717_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056723_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056722_)))))));
    vlSelf->__VdfgTmp_hf1343531__0 = (((IData)(vlSelf->wasmetal_core__DOT___011936_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011937_));
    vlSelf->__VdfgTmp_h52908d38__0 = (((IData)(vlSelf->wasmetal_core__DOT___011937_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011936_));
    vlSelf->__VdfgTmp_h7f7a7923__0 = (((IData)(vlSelf->wasmetal_core__DOT___012979_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012978_));
    vlSelf->__VdfgTmp_h00c406e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056634_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056635_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056638_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056639_))))));
    vlSelf->__VdfgTmp_h4e50e0f7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)))));
    vlSelf->wasmetal_core__DOT___012616_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056618_))))));
    vlSelf->__VdfgTmp_h1d24e3fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012845_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012799_));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        vlSelf->wasmetal_core__DOT___011631_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011649_));
        vlSelf->wasmetal_core__DOT___013144_ = vlSelf->wasmetal_core__DOT___011636_;
        vlSelf->wasmetal_core__DOT___011940_ = (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha12381c3__0)));
    } else {
        vlSelf->wasmetal_core__DOT___011631_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011529_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011530_))));
        vlSelf->wasmetal_core__DOT___013144_ = vlSelf->wasmetal_core__DOT___011649_;
        vlSelf->wasmetal_core__DOT___011940_ = (1U 
                                                & (0x32U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h53b21008__0)));
    }
    vlSelf->wasmetal_core__DOT___056803_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011960_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011962_)))))));
    vlSelf->__VdfgTmp_h703b59c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011960_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf4d8b80a__0)))));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        vlSelf->wasmetal_core__DOT___012425_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012384_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)))));
        if (vlSelf->wasmetal_core__DOT___010396_) {
            vlSelf->wasmetal_core__DOT___012441_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010393_)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012548_)));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012362_)));
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
        } else {
            vlSelf->wasmetal_core__DOT___012441_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h8262dffe__0)));
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011185_)));
        }
        vlSelf->wasmetal_core__DOT___012426_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010393_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he0f8989d__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___012425_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012373_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012383_)))));
        if (vlSelf->wasmetal_core__DOT___010396_) {
            vlSelf->wasmetal_core__DOT___012441_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___012377_));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011192_));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010402_));
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
        } else {
            vlSelf->wasmetal_core__DOT___012441_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012373_)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010394_)));
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)));
        }
        vlSelf->wasmetal_core__DOT___012426_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010394_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012377_)))));
    }
    vlSelf->wasmetal_core__DOT___056293_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012373_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012384_)))));
    vlSelf->wasmetal_core__DOT___056932_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056924_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056923_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___055308_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055307_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055306_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055305_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055304_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055303_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055302_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055301_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055300_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055299_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055298_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055297_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055296_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055295_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055294_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055293_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055292_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055291_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055290_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055289_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055288_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055287_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055286_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055285_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055284_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055283_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055282_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055281_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055280_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055279_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055278_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->wasmetal_core__DOT___055273_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00fff4ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055271_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055112_)))));
    vlSelf->wasmetal_core__DOT___055270_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009781_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009780_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___055241_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054806_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054805_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___055221_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d2a78cf__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___055219_ = (1U & (IData)(
                                                         (0xff00ff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haef445c6__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___057169_ = (1U & (0xf0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010948_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0)))));
    vlSelf->wasmetal_core__DOT___057630_ = (1U & (0xeU 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     & (IData)(
                                                               (0xfff0fff0ffff4444ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011603_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011602_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013095_))))))))) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056910_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010721_)))));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030094_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___065180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___065052_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->__VdfgTmp_h48aaf6cb__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h60159710__0))));
    vlSelf->__VdfgTmp_hc8f262c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h60159710__0)))));
    vlSelf->wasmetal_core__DOT___068814_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051121_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff00ff1fffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050040_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))));
    vlSelf->wasmetal_core__DOT___069202_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051621_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbf00bfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051618_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051617_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___068960_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051357_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051353_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051352_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))));
    vlSelf->wasmetal_core__DOT___069252_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051640_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051637_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___069058_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051529_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051527_)))))))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___019770_ = (1U & (0xffffff70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051277_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->reset) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051276_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048483_)))))));
    vlSelf->wasmetal_core__DOT___019771_ = (1U & (IData)(
                                                         (0xffffeaffffffc0c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050463_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050362_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0023997__0))))))));
    vlSelf->wasmetal_core__DOT___019772_ = (1U & (IData)(
                                                         (0xffffeaffffffc0c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050463_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050362_)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb0023997__0))))))));
    vlSelf->wasmetal_core__DOT___053254_ = (1U & (IData)(
                                                         (0xd000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052863_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051219_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053007_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053006_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052949_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053005_)))))))));
    vlSelf->wasmetal_core__DOT___052689_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052684_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052683_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0)))));
    vlSelf->wasmetal_core__DOT___053431_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053345_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048483_))))));
    vlSelf->wasmetal_core__DOT___053570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xe0c0c0cU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___053437_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052864_) 
                                                             << 3U) 
                                                            | ((4U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                   << 2U)) 
                                                               | (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___053364_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053259_))));
    vlSelf->wasmetal_core__DOT___052688_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052657_))));
    vlSelf->wasmetal_core__DOT___019793_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x10000U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053587_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___052694_)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053590_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053589_)))));
    vlSelf->wasmetal_core__DOT___039855_ = (1U & (0xea2a2a2aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053260_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    wasmetal_core__DOT___053577_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___053576_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052658_))));
    vlSelf->wasmetal_core__DOT___053103_ = (1U & (IData)(
                                                         (0x7f007f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053097_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053095_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h461b3fd9__0))))))));
    vlSelf->wasmetal_core__DOT___053504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053493_))));
    vlSelf->wasmetal_core__DOT___053362_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050382_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050371_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    vlSelf->wasmetal_core__DOT___051222_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050382_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057949_))));
    vlSelf->wasmetal_core__DOT___013505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057706_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057702_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015781_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015696_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015695_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015707_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015708_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015717_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013558_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013559_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013548_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015612_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015750_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015621_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015622_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015630_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015629_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015638_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015651_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013589_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013565_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013581_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013602_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013605_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013599_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057729_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057730_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057728_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015650_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023431_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023430_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023429_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023428_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_ha9e2ef67__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___051502_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051504_));
    vlSelf->wasmetal_core__DOT___058693_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051504_))))));
    vlSelf->wasmetal_core__DOT___051508_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051504_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006238_)))))));
    vlSelf->wasmetal_core__DOT___050253_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006114_))));
    vlSelf->wasmetal_core__DOT___050175_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050260_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050141_))));
    vlSelf->wasmetal_core__DOT___050138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050153_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050142_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___018281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005738_))));
    vlSelf->wasmetal_core__DOT___018334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    vlSelf->__VdfgTmp_hcdf58d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_hcf2773b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hc8e63fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hffde1553__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hcf316312__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)))))));
    vlSelf->__VdfgTmp_hba4cc4c7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_h9fccfed0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022537_));
    vlSelf->wasmetal_core__DOT___051509_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005663_)))))));
    vlSelf->wasmetal_core__DOT___016296_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___059074_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000140_)))))));
    vlSelf->wasmetal_core__DOT___000131_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000140_));
    vlSelf->wasmetal_core__DOT____Vcellout___127569___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013780_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023601_ = ((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127478___O 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005989_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                | (IData)(vlSelf->wasmetal_core__DOT___022853_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022853_)));
    vlSelf->wasmetal_core__DOT___049867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (3U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O)))))));
    vlSelf->wasmetal_core__DOT___050485_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->__VdfgTmp_h1ac2f982__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022737_));
    vlSelf->wasmetal_core__DOT___059205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059201_))));
    vlSelf->wasmetal_core__DOT___060006_ = (1U & (IData)(
                                                         (0xf00ff8800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127552___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005823_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023480_ = ((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006633_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___006632_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022667_));
    vlSelf->wasmetal_core__DOT___017494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide))));
    vlSelf->wasmetal_core__DOT___063467_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063465_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063475_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063474_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063473_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063483_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063482_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063481_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    wasmetal_core__DOT___063458_ = (1U & (IData)((0x153fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & (vlSelf->cmd_index 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0xf38f2779U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009510_)))))))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026455_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036763_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036730_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h959d8796__0))));
    vlSelf->wasmetal_core__DOT___063147_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063144_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063143_)))))));
    vlSelf->wasmetal_core__DOT___063153_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063150_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063149_)))))));
    vlSelf->wasmetal_core__DOT___063159_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063156_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063155_)))))));
    vlSelf->wasmetal_core__DOT___063165_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063162_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063161_)))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028289_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028224_));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026563_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001414_));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034324_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034323_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034322_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034321_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034384_)))));
    vlSelf->wasmetal_core__DOT___034388_ = ((IData)(vlSelf->wasmetal_core__DOT___034324_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128658___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034491_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034490_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034489_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034488_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034545_)))));
    vlSelf->wasmetal_core__DOT___034549_ = ((IData)(vlSelf->wasmetal_core__DOT___034491_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044870_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027473_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027436_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027396_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b9__05d));
    wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x16U) & (IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x400000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x16U)
                  : (IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032878_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032844_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___062793_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x10U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062785_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O))))))));
    vlSelf->wasmetal_core__DOT___062804_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x11U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062796_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062815_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x12U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062807_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062826_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128014___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x13U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062818_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128167___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128022___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027813_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027779_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d));
    wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x16U) & (IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028099_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x11U)));
    wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x16U)) & (IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___070649_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032686_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032652_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    wasmetal_core__DOT___070648_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070646_)))))))));
    vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037196_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037163_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0817f177__0))));
    vlSelf->wasmetal_core__DOT___054509_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054511_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054513_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054515_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128597___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127838___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    wasmetal_core__DOT___063583_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063591_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063599_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063607_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___044380_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127845___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127846___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026335_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128404___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031964_)))));
    vlSelf->wasmetal_core__DOT___031937_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029506_));
    vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030691_));
    if (vlSelf->wasmetal_core__DOT__sp__05b13__05d) {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b13__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031937_));
    vlSelf->wasmetal_core__DOT___011798_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010790_)))));
    vlSelf->__VdfgTmp_h033744d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011564_));
    vlSelf->wasmetal_core__DOT___012218_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056450_)))))))));
    vlSelf->wasmetal_core__DOT___011047_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056449_)))))))));
    vlSelf->wasmetal_core__DOT___011300_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056455_)))))))));
    vlSelf->wasmetal_core__DOT___011786_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056454_)))))))));
    vlSelf->wasmetal_core__DOT___012220_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056453_)))))))));
    vlSelf->wasmetal_core__DOT___011046_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056452_)))))))));
    vlSelf->wasmetal_core__DOT___011299_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056459_)))))))));
    vlSelf->wasmetal_core__DOT___011785_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056458_)))))))));
    vlSelf->wasmetal_core__DOT___012219_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056457_)))))))));
    vlSelf->wasmetal_core__DOT___011045_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056456_)))))))));
    vlSelf->wasmetal_core__DOT___011302_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056460_)))))))));
    vlSelf->wasmetal_core__DOT___011793_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011306_)))))))));
    vlSelf->wasmetal_core__DOT___011044_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011306_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011305_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011304_)))))))));
    vlSelf->wasmetal_core__DOT___012073_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011306_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011305_)))))))));
    vlSelf->wasmetal_core__DOT___010791_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010173_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010789_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010805_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010788_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010810_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010818_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010152_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010817_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010142_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010816_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010831_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010815_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010836_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010667_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010672_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010666_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010103_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010665_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010091_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010664_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010123_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011478_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010692_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010113_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010691_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010132_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010690_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010705_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010689_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010710_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010422_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010429_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010421_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010434_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010420_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010439_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010419_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010444_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010452_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010457_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010451_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010462_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010450_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010467_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010449_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010472_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010480_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010479_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010490_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010478_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010495_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010477_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010500_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010507_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010513_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010506_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010518_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010505_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010523_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010508_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010414_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___056625_ = (1U & (IData)(
                                                         (0xff00f1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012632_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012631_)))))))));
    vlSelf->wasmetal_core__DOT___012456_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011914_))));
    vlSelf->wasmetal_core__DOT___056744_ = ((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                            & (IData)(
                                                      (0xff55fffcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011915_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011912_)))))))));
    vlSelf->__VdfgTmp_h52f234fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___012630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012629_));
    vlSelf->wasmetal_core__DOT___011085_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056444_)))))))));
    vlSelf->__VdfgTmp_h796615cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012627_));
    vlSelf->__VdfgTmp_h519cda3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011035_));
    vlSelf->__VdfgTmp_hfe0435c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___011035_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011034_));
    vlSelf->wasmetal_core__DOT___011787_ = (1U & (IData)(
                                                         (0xff00f0ccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011033_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056451_)))))))));
    vlSelf->__VdfgTmp_h8f2fdb1c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011033_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011032_)));
    vlSelf->__VdfgTmp_hc511e40f__0 = (((IData)(vlSelf->wasmetal_core__DOT___011566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011565_));
    vlSelf->wasmetal_core__DOT____Vcellinp___134222___A 
        = ((0x10000U & ((0xffe0ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___055203_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xff00ff00ff00e0ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055200_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055199_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___055112_)))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffff010ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___055198_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xbbbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055196_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009651_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009649_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009650_)))))))))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffffffffff444ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055188_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xdU)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffff010ffffffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055179_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xbbb00000bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055177_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd7e7c41d__0))))))))))))) 
                                                                          << 1U)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffff010ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___055157_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xbbb00000bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055155_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e4b209e__0))))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffffffffff444ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___055149_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & (vlSelf->insn_x 
                                                                                >> 0xaU)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffffffffff444ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055134_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 9U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffffffffff444ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___055126_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffff010ffffffffULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055113_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055106_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055105_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x33330f0f00ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054720_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hffdded68__0))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054714_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffffffffff444ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___055063_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 6U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffffffffff888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055016_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055015_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027490_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027489_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0fcc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054973_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___033411_))))))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((0xbU 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027488_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xf0fccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054929_))))))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054892_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054891_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027487_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054846_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054845_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((0xbU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027485_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & vlSelf->insn_x) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0fcc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054799_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010338_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xbU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027478_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054748_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011042_))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056914_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013139_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056910_)))))))));
    vlSelf->wasmetal_core__DOT___012959_ = (1U & (IData)(
                                                         (0xaf0fbbffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___072009_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9d4acb63__0))));
    vlSelf->wasmetal_core__DOT___056903_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013139_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h758d714e__0))))))));
    vlSelf->__VdfgTmp_h77847496__0 = (((IData)(vlSelf->wasmetal_core__DOT___011595_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xaaaaccccf0f0ff00ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011593_)));
    vlSelf->__VdfgTmp_ha438982a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011441_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x555533330f0f00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0)))));
    vlSelf->__VdfgTmp_h2c387a2e__0 = ((4U & ((0x10000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056292_)));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___033416_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___010083_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010394_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012377_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010393_)))))))));
    vlSelf->wasmetal_core__DOT___011853_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012793_)))));
    vlSelf->__VdfgTmp_h0bb40096__0 = (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                       << 1U) | (1U 
                                                 & (0xf0fccaaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h30784950__0)))))));
    vlSelf->wasmetal_core__DOT___057538_ = (1U & (IData)(
                                                         (0xaf0fbbffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057536_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))))));
    vlSelf->__VdfgTmp_hbb125bb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___012868_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012866_)));
    vlSelf->wasmetal_core__DOT___056864_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056863_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012978_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012979_))))));
    vlSelf->wasmetal_core__DOT___057468_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056827_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056863_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->__VdfgTmp_hbde6c7ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___056281_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012362_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056280_)));
    vlSelf->wasmetal_core__DOT___056645_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056640_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056639_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056638_))))));
    vlSelf->__VdfgTmp_h86a3b3a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___056640_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056643_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056642_)));
    vlSelf->wasmetal_core__DOT___057025_ = (1U & (0xf0f000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057024_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057023_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc88b842e__0))))));
    vlSelf->wasmetal_core__DOT___057548_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057050_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057023_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057049_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    if (vlSelf->wasmetal_core__DOT___010721_) {
        vlSelf->wasmetal_core__DOT___012392_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012400_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c39d480__0)))));
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___056607_ = 
                (1U & (1U >> (1U & (0xffaaccf0U >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)))));
            vlSelf->wasmetal_core__DOT___011352_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011359_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011358_))));
        } else {
            vlSelf->wasmetal_core__DOT___056607_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h39b11875__0)));
            vlSelf->wasmetal_core__DOT___011352_ = 
                (1U & (1U >> ((2U & ((IData)((0xf0f0553300000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xf0f000005533ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0)))))));
        }
        vlSelf->wasmetal_core__DOT___011098_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010720_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0x555533330f0f00ffULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))));
        vlSelf->wasmetal_core__DOT___057441_ = (1U 
                                                & (IData)(
                                                          (0x55553333ff00ff0fULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1632b282__0))));
        vlSelf->wasmetal_core__DOT___012794_ = (1U 
                                                & (IData)(
                                                          (0xaaaacccc00ff00f0ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1632b282__0))));
    } else {
        vlSelf->wasmetal_core__DOT___012392_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012402_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))));
        vlSelf->wasmetal_core__DOT___056607_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011407_));
        vlSelf->wasmetal_core__DOT___011352_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011361_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011360_))));
        vlSelf->wasmetal_core__DOT___011098_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010719_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h23c0a543__0)))));
        vlSelf->wasmetal_core__DOT___057441_ = 0U;
        vlSelf->wasmetal_core__DOT___012794_ = 0U;
    }
    vlSelf->__VdfgTmp_h4aad360c__0 = (((IData)(vlSelf->wasmetal_core__DOT___056728_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x1fU 
                                                            >> 
                                                            ((8U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                   ? 
                                                                  (0x53U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_ha12381c3__0))
                                                                   : 
                                                                  (0xcdU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h53b21008__0))) 
                                                                 << 3U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056718_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___056717_))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x1111000fU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056723_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056722_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf19e2482__0))))))))));
    vlSelf->wasmetal_core__DOT___056900_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012185_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056896_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056895_))))));
    vlSelf->__VdfgTmp_h74563738__0 = (((IData)(vlSelf->wasmetal_core__DOT___013100_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012185_));
    if (vlSelf->wasmetal_core__DOT___010722_) {
        if (vlSelf->wasmetal_core__DOT___010721_) {
            vlSelf->wasmetal_core__DOT___011135_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hdeb472fa__0)));
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011403_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011404_))));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012177_))));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011135_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010727_));
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hc49b4927__0)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf1343531__0)));
        }
        vlSelf->wasmetal_core__DOT___012261_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012179_)));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011853_)));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (0x10fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h52908d38__0)))));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h74563738__0))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010721_) {
            vlSelf->wasmetal_core__DOT___011135_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010720_)));
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___011586_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011445_))));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012185_)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012794_)));
        } else {
            vlSelf->wasmetal_core__DOT___011135_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010719_)));
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011586_)));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012184_)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011939_))));
        }
        vlSelf->wasmetal_core__DOT___012261_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012180_));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (0xf0f033aaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011889_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h23ac912c__0))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011887_)))))));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011854_));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0xaaaaccccf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013099_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (0x5300U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0))))))));
    }
    if (vlSelf->wasmetal_core__DOT___011101_) {
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h8ae31ec8__0))))))));
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011748_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___011749_)))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5fb0de62__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___012753_ = (1U 
                                                & (0xccaafff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfffff0f0ff001111ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012721_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((0xffaaccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012717_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012718_)))))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0x11f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012722_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012719_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___012720_)))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011593_))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012642_)))))));
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___012714_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012721_))
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012718_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012717_))))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012720_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012719_)))
                                                                    : 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012722_)))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00aaccccf0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h77847496__0)))))))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                    ? 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h77847496__0))))))) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                               ? 
                                                              (0xee0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011631_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xf0faacc00000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))))))))
                                                               : 
                                                              (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011632_)))))))))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011576_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011574_))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xf0f0aaccU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013103_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h74563738__0))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xaaccf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057630_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))))))))))))))));
    }
    vlSelf->__VdfgTmp_h10754ee4__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   (4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0))))))));
    vlSelf->wasmetal_core__DOT___072181_ = (1U & (0x6996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x96U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072175_))))));
    vlSelf->wasmetal_core__DOT___072193_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x96U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0)))))));
    vlSelf->wasmetal_core__DOT___057189_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012440_)))));
    vlSelf->wasmetal_core__DOT___012240_ = (1U & (IData)(
                                                         (0xf000ffccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056929_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056928_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056552_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h98e4ab16__0)))))))))));
    vlSelf->wasmetal_core__DOT___013166_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056929_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056924_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056928_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___072159_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x17U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0))))));
    vlSelf->__VdfgTmp_ha1c57cb3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0)))));
    vlSelf->wasmetal_core__DOT___057220_ = (1U & (IData)(
                                                         (0x3355f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x33550f0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057096_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___012420_)
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___012422_)
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___010720_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010849_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010850_)))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011110_))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057094_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057095_)))))))));
    vlSelf->__VdfgTmp_h7c3586c1__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___012420_)
                                               : ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___012422_)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012402_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011102_));
    vlSelf->wasmetal_core__DOT___012474_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011102_))));
    vlSelf->wasmetal_core__DOT___011136_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h62b744ad__0))))));
    vlSelf->__VdfgTmp_hcdbca8e0__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___011407_)
                                               : ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h39b11875__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011445_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011102_));
    vlSelf->wasmetal_core__DOT___012644_ = (1U & (IData)(
                                                         (0xf0f000ff1111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xffaaccf0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011405_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h39b11875__0))))))));
    vlSelf->__VdfgTmp_h3af565ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___057547_) 
                                       << 1U) | (1U 
                                                 & (0xf011U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057009_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056921_)))))));
    vlSelf->wasmetal_core__DOT___072025_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057658_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x550fff33U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xf0f0aaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072002_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9d4acb63__0))))))) 
                                                                          << 2U)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h56d07f21__0)))))))))));
    vlSelf->wasmetal_core__DOT___072012_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072001_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x3030303000055ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056595_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056593_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056594_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010530_)))))))))))));
    vlSelf->__VdfgTmp_h45f38dff__0 = (((IData)(vlSelf->wasmetal_core__DOT___011358_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011359_));
    vlSelf->wasmetal_core__DOT___056478_ = (1U & (IData)(
                                                         (0x5555f0f000ff00ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010948_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))))))));
    vlSelf->wasmetal_core__DOT___057168_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056475_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e559da9__0))))));
    vlSelf->wasmetal_core__DOT___065207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057306_))));
    vlSelf->wasmetal_core__DOT___064004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010904_))));
    vlSelf->wasmetal_core__DOT___065289_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057399_)))));
    vlSelf->wasmetal_core__DOT___057401_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057399_)))))));
    vlSelf->wasmetal_core__DOT___056706_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056703_))));
    vlSelf->wasmetal_core__DOT___012941_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012867_))));
    vlSelf->wasmetal_core__DOT___056755_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))));
    vlSelf->wasmetal_core__DOT___012879_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0))))));
    vlSelf->__VdfgTmp_h3816fa33__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0))));
    vlSelf->wasmetal_core__DOT___057014_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056970_)))));
    vlSelf->wasmetal_core__DOT___056972_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056970_)))))))));
    vlSelf->wasmetal_core__DOT___057617_ = (1U & (IData)(
                                                         (0xf100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056970_)))))))));
    vlSelf->wasmetal_core__DOT___056948_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0))))));
    vlSelf->wasmetal_core__DOT___012241_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0)))));
    vlSelf->__VdfgTmp_h3478584b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0)));
    vlSelf->wasmetal_core__DOT___056832_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056829_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056828_)))))));
    vlSelf->__VdfgTmp_h2ec4fb80__0 = (((IData)(vlSelf->wasmetal_core__DOT___056828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056829_));
    vlSelf->wasmetal_core__DOT___012596_ = (1U & (IData)(
                                                         (0xff0f11111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca116eb2__0))))))));
    vlSelf->__VdfgTmp_hc8ed07a2__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hca116eb2__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___012548_));
    vlSelf->wasmetal_core__DOT___057012_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->wasmetal_core__DOT___057026_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->wasmetal_core__DOT___057560_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___072148_ = (1U & (0xaf8e8e0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072145_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x17U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___072143_)))))));
    vlSelf->wasmetal_core__DOT___039092_ = (1U & (IData)(
                                                         (0xffffffffff000e00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053772_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055201_)))))))));
    vlSelf->wasmetal_core__DOT___056372_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011135_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h62b744ad__0))))))));
    vlSelf->wasmetal_core__DOT___012931_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011920_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011919_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h52908d38__0))))));
    vlSelf->wasmetal_core__DOT___072203_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x96U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))));
    vlSelf->__VdfgTmp_h9816e297__0 = ((0x10U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                << 4U)) 
                                      | ((8U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                << 3U)) 
                                         | ((4U & (
                                                   (0x17U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                   << 2U)) 
                                            | ((2U 
                                                & ((0x69U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (0x17U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)))))));
    vlSelf->__VdfgTmp_h24dd6e03__0 = ((2U & ((0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)) 
                                             << 1U)) 
                                      | (1U & (0x96U 
                                               >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0))));
    vlSelf->wasmetal_core__DOT___011855_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d24e3fc__0)))));
    vlSelf->__VdfgTmp_hc3a80e12__0 = (((IData)(vlSelf->wasmetal_core__DOT___013145_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013144_));
    vlSelf->wasmetal_core__DOT___012023_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x11fff0fff0ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011770_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9edc9904__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056803_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfff00000eeee0000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0)))))))));
    vlSelf->__VdfgTmp_h18f44539__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012878_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff00000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))))));
    vlSelf->__VdfgTmp_h5c1422ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012878_)));
    vlSelf->wasmetal_core__DOT___012969_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                   ? 
                                                  (0xfefU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(
                                                                (0xeeee0000fff0ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012868_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012866_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012867_))));
    vlSelf->wasmetal_core__DOT___057114_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012506_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_heaf10b4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012440_));
    vlSelf->wasmetal_core__DOT___010082_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056292_)))));
    vlSelf->wasmetal_core__DOT___010896_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056293_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012377_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134228___A 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055296_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055295_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffff8ffff8888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055294_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffff8ffff8888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055293_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffff8ffff8888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055292_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffff8ffff8888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055291_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055290_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055289_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055288_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffff8ffff8888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055287_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffff8ffff8888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055285_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055284_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055282_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055281_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055280_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134225___A 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055279_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055278_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffffffffff444ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055273_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x1eU)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffffffffff444ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055270_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & (vlSelf->insn_x 
                                                                          >> 0x1dU)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffff010ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___055268_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xbbbU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x11f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010164_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009814_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009815_))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffff010ffffffffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___055265_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf222e899__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffff010ffffffffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055262_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009794_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffff010ffffffffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___055259_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff00e000ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h910334c5__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffff010ffffffffULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055256_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xee000f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15c467ca__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xffe0ffffU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055253_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff00ff00ff00e0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055251_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055199_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055112_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffff010ffffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055250_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054854_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055247_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h034bd5a0__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055244_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054852_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054850_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054851_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055241_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x13U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x12U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055219_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x11U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055217_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd610ba85__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128233___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030095_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030094_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030124_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030123_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030090_)))));
    vlSelf->wasmetal_core__DOT___030063_ = ((IData)(vlSelf->wasmetal_core__DOT___030095_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128247___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030223_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030222_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030284_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030283_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030218_)))));
    vlSelf->wasmetal_core__DOT___030159_ = ((IData)(vlSelf->wasmetal_core__DOT___030223_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->__VdfgTmp_hca11f007__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0))));
    vlSelf->__VdfgTmp_h19390f5d__0 = ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    vlSelf->__VdfgTmp_h0341114f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___019787_ = (1U & (IData)(
                                                         (0x770f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)))))))))));
    vlSelf->wasmetal_core__DOT___053571_ = (1U & (IData)(
                                                         (0x1f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))));
    vlSelf->wasmetal_core__DOT___019803_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbbbU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___052988_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT___039820_ = (1U & (IData)(
                                                         (0xeaea2aea2a2a2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfdf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050451_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__check_type)))))))));
    vlSelf->wasmetal_core__DOT___072262_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052690_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052689_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT___019775_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___053577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053475_))));
    vlSelf->wasmetal_core__DOT___039856_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039854_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039857_ = (1U & (0xaea2a2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128179___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053475_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___053577_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___051229_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050365_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff100000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___058683_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057949_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015651_))));
    vlSelf->wasmetal_core__DOT___058931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058693_))));
    vlSelf->wasmetal_core__DOT___050254_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050253_))));
    vlSelf->wasmetal_core__DOT___051301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050253_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050175_))));
    vlSelf->wasmetal_core__DOT___051303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050175_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050261_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050260_))));
    vlSelf->wasmetal_core__DOT___051309_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050138_))));
    vlSelf->wasmetal_core__DOT___050139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050275_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050164_))));
    vlSelf->wasmetal_core__DOT___050165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050164_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050277_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050153_))));
    vlSelf->wasmetal_core__DOT___050154_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050153_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051284_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050167_))));
    vlSelf->wasmetal_core__DOT___050168_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050142_))));
    vlSelf->wasmetal_core__DOT___050143_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050142_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___023238_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffde1553__0))));
    vlSelf->wasmetal_core__DOT___023239_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005731_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))));
    vlSelf->wasmetal_core__DOT___023237_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hba4cc4c7__0))));
    vlSelf->wasmetal_core__DOT___023236_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fccfed0__0))));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059206_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051509_))));
    vlSelf->__VdfgTmp_h9e4ff193__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016296_));
    vlSelf->wasmetal_core__DOT___018857_ = (1U & (IData)(
                                                         (0xfffeffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5565504__0))))))));
    vlSelf->wasmetal_core__DOT___017414_ = ((0x80000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___048930_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048929_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x80000000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0x8000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed5eddc9__0))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000131_));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___014037_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023601_));
    vlSelf->wasmetal_core__DOT___050493_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049867_))));
    vlSelf->wasmetal_core__DOT___049868_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049867_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051271_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050485_))));
    vlSelf->wasmetal_core__DOT___050487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049917_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049865_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049944_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___050484_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049924_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049921_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013652_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h76242b02__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005823_));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006274_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023480_));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063462_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063458_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063457_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127852___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026456_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026455_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026451_)))));
    vlSelf->wasmetal_core__DOT___026423_ = ((IData)(vlSelf->wasmetal_core__DOT___026456_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d));
    vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036764_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hb0a19382__0))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028290_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028225_));
    vlSelf->wasmetal_core__DOT____Vcellout___127868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026564_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026563_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026593_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026592_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026559_)))));
    vlSelf->wasmetal_core__DOT___026498_ = ((IData)(vlSelf->wasmetal_core__DOT___026564_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001426_));
    vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031335_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034325_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034388_));
    vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034492_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034549_));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128031___O 
        = (0xfU & ((vlSelf->insn_z >> 0x14U) ^ (((IData)(wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128031___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027939_))))));
    vlSelf->wasmetal_core__DOT___027944_ = ((vlSelf->insn_z 
                                             >> 0x17U) 
                                            & (IData)(wasmetal_core__DOT___128031___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128271___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x17U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x16U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x15U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x14U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128271___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030474_)))));
    vlSelf->wasmetal_core__DOT___030479_ = (1U & ((0x800000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x17U)
                                                   : (IData)(wasmetal_core__DOT___128271___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032879_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027814_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128055___O 
        = (0xfU & ((vlSelf->insn_x >> 0x14U) ^ (((IData)(wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128055___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028165_))))));
    vlSelf->wasmetal_core__DOT___028170_ = ((vlSelf->insn_x 
                                             >> 0x17U) 
                                            & (IData)(wasmetal_core__DOT___128055___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028100_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x12U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128319___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x17U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x16U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x15U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x14U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128319___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030956_)))));
    vlSelf->wasmetal_core__DOT___030961_ = ((~ (vlSelf->function_params 
                                                >> 0x17U)) 
                                            & (IData)(wasmetal_core__DOT___128319___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070651_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070649_)))))))));
    vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032687_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___044809_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070648_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___044797_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070648_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070646_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037197_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h092cd911__0))));
    vlSelf->wasmetal_core__DOT___054510_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054509_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xeU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054512_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054511_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054514_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054513_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054516_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054515_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127830___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063584_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063583_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063592_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063591_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063600_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063599_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063608_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026370_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d));
    vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___012610_ = ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011566_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h033744d0__0))))))));
    vlSelf->__VdfgTmp_hdcc00e41__0 = (((IData)(vlSelf->wasmetal_core__DOT___011300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011299_));
    vlSelf->__VdfgTmp_ha9c6ec44__0 = (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011785_));
    vlSelf->__VdfgTmp_h358fed79__0 = (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012219_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012218_)));
    vlSelf->wasmetal_core__DOT___057161_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011045_)))));
    vlSelf->__VdfgTmp_h417b846d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011793_));
    vlSelf->__VdfgTmp_hde352602__0 = (((IData)(vlSelf->wasmetal_core__DOT___011045_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011044_));
    vlSelf->wasmetal_core__DOT___011301_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011306_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011305_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010423_)))))));
    vlSelf->wasmetal_core__DOT___011799_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010791_)))));
    vlSelf->wasmetal_core__DOT___010794_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010790_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010788_))))));
    vlSelf->wasmetal_core__DOT___011315_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010789_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010818_))))));
    vlSelf->wasmetal_core__DOT___011804_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010788_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010817_))))));
    vlSelf->wasmetal_core__DOT___010822_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010818_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010816_))))));
    vlSelf->wasmetal_core__DOT___010821_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010817_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010815_))))));
    vlSelf->wasmetal_core__DOT___011790_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010816_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010666_))))))));
    vlSelf->wasmetal_core__DOT___010671_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010665_))))));
    vlSelf->wasmetal_core__DOT___010670_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010664_))))));
    vlSelf->wasmetal_core__DOT___011323_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010692_))))));
    vlSelf->wasmetal_core__DOT___011812_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010664_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010691_))))));
    vlSelf->wasmetal_core__DOT___010696_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010692_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010690_))))));
    vlSelf->wasmetal_core__DOT___010695_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010691_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010689_))))));
    vlSelf->wasmetal_core__DOT___012781_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010690_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010421_))))))));
    vlSelf->wasmetal_core__DOT___010428_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010420_))))));
    vlSelf->wasmetal_core__DOT___010427_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010419_))))));
    vlSelf->wasmetal_core__DOT___011339_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010420_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010452_))))));
    vlSelf->wasmetal_core__DOT___011820_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010451_))))));
    vlSelf->wasmetal_core__DOT___010456_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010452_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010450_))))));
    vlSelf->wasmetal_core__DOT___010455_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010451_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010449_))))));
    vlSelf->wasmetal_core__DOT___011343_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010450_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010480_))))));
    vlSelf->wasmetal_core__DOT___011824_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010449_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010479_))))));
    vlSelf->wasmetal_core__DOT___010484_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010480_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010478_))))));
    vlSelf->wasmetal_core__DOT___010483_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010479_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010477_))))));
    vlSelf->wasmetal_core__DOT___011347_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010478_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010507_))))));
    vlSelf->wasmetal_core__DOT___011828_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010477_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010506_))))));
    vlSelf->__VdfgTmp_hb5646ca1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->__VdfgTmp_h025488dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010506_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->wasmetal_core__DOT___010512_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010507_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010505_))))));
    vlSelf->wasmetal_core__DOT___056716_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010395_)) 
                                                  & (IData)(
                                                            (0xccccccccddcfcfcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010505_))))))))));
    vlSelf->wasmetal_core__DOT___012559_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->__VdfgTmp_hb8dc7649__0 = (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010508_)));
    vlSelf->wasmetal_core__DOT___057174_ = ((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012456_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056445_))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))));
    vlSelf->wasmetal_core__DOT___056962_ = (1U & (IData)(
                                                         (0xf5f300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056961_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012631_)))))))));
    vlSelf->wasmetal_core__DOT___011558_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012630_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h796615cc__0))))))));
    vlSelf->wasmetal_core__DOT___011788_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))))))));
    vlSelf->wasmetal_core__DOT___012809_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x1111111100ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0110000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011912_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011913_)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h519cda3a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057162_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h519cda3a__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0)))))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))));
    } else {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xf1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h033744d0__0)))));
    }
    vlSelf->wasmetal_core__DOT___012221_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))))))));
    vlSelf->__VdfgTmp_heef7d961__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h2c387a2e__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128548___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010044_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010022_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033452_)))));
    vlSelf->wasmetal_core__DOT___033480_ = ((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hef87eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012425_));
    vlSelf->wasmetal_core__DOT___056461_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056443_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                          ? 
                                                                         (0x32U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010950_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010948_))))
                                                                          : 
                                                                         (0xeef0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010949_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___012053_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))));
    vlSelf->__VdfgTmp_hb67239de__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057468_));
    vlSelf->wasmetal_core__DOT___068285_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012441_))))));
    vlSelf->wasmetal_core__DOT___012599_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))));
    vlSelf->__VdfgTmp_hdb922d45__0 = (((IData)(vlSelf->wasmetal_core__DOT___057025_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x30303030000ffaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057050_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057049_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010182_))))))))));
    vlSelf->__VdfgTmp_h3514b323__0 = (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057547_));
    vlSelf->__VdfgTmp_h224cdee6__0 = (((IData)(vlSelf->wasmetal_core__DOT___012393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012392_));
    vlSelf->wasmetal_core__DOT___057455_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057449_))))))) 
                                                  & (IData)(
                                                            (0xffccffaaff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012915_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0xf0f000eeU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057438_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010721_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccf0f0ff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012800_))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___011103_) {
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xf0accccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00aaccccf0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057438_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012805_)))))));
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012804_)))));
        vlSelf->wasmetal_core__DOT___011295_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011353_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                  ? 
                                                                 (2U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x55330fU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0))))
                                                                  : 
                                                                 (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h39b11875__0)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___011407_))))))));
    }
    vlSelf->wasmetal_core__DOT___057386_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        & (IData)(
                                                                  (0xff00ff0f33335555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011939_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012793_))))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                ? 
                                                               (0xfeeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h03a652de__0))))
                                                                : 
                                                               (0x35U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012799_)))))))))));
    vlSelf->wasmetal_core__DOT___056780_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056774_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1343531__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011853_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056775_))))));
    vlSelf->__VdfgTmp_he499e9e8__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056900_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___056899_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056901_));
    vlSelf->wasmetal_core__DOT___013108_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057571_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0xf11U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xac00U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x55330000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hefe0e1be__0))))))))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___013139_)) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                              ? 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___012131_))
                                                                               : 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011868_)))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011869_))
                                                                               : 
                                                                              (0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013144_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013145_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013041_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013038_))))))));
    vlSelf->wasmetal_core__DOT___072208_ = (1U & (IData)(
                                                         (0x22aabbfabbf022aULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___072177_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072193_)))))))));
    vlSelf->wasmetal_core__DOT___072194_ = (1U & (IData)(
                                                         (0x17e8e817e81717e8ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x17U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072193_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hab99f676__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072177_)))))))));
    vlSelf->wasmetal_core__DOT___011731_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011253_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___011683_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057256_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012597_))));
    vlSelf->__VdfgTmp_h6b93e166__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012598_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012597_)));
    vlSelf->__VdfgTmp_hca77b771__0 = (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012240_));
    vlSelf->__VdfgTmp_h638ad0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013166_));
    vlSelf->__VdfgTmp_h839fe08c__0 = ((4U & ((0x177eU 
                                              >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                             << 2U)) 
                                      | ((2U & ((0xe81717e8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___072145_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072143_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___072146_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x17U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x115577f577f0115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x96U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x6996U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___072198_ = (1U & (IData)(
                                                         (0x7117177117717117ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___072181_)))))))));
    vlSelf->wasmetal_core__DOT___072182_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))))));
    vlSelf->wasmetal_core__DOT___072195_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0))))))));
    vlSelf->wasmetal_core__DOT___072196_ = (1U & (IData)(
                                                         (0xe81717e817e8e817ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x6996U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))));
    vlSelf->wasmetal_core__DOT___057172_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7c3586c1__0))))));
    vlSelf->wasmetal_core__DOT___057100_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaf0fbbffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012474_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))))))))))));
    vlSelf->wasmetal_core__DOT___011129_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056335_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056336_))))))) 
                                                  & (IData)(
                                                            (0xff33ff55ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011136_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011135_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h23c0a543__0))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011109_)))))))))))))));
    vlSelf->__VdfgTmp_hd6365363__0 = (((IData)(vlSelf->wasmetal_core__DOT___012261_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012184_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc49b4927__0))))
                                                     : 
                                                    (0x53U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaaccccf0f0ff00ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012185_)))))));
    vlSelf->__VdfgTmp_h2163f181__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___012582_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcdbca8e0__0))));
    vlSelf->__VdfgTmp_ha0e20209__0 = (((IData)(vlSelf->wasmetal_core__DOT___012644_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2994a26e__0))))
                                                     : 
                                                    (0x32U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 2U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                           & (IData)(
                                                                     (0xcc00fff0f0aaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hcd2c6110__0))))))) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011441_)))))));
    vlSelf->wasmetal_core__DOT___011461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf000ffccccaaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011586_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056607_)))));
    vlSelf->wasmetal_core__DOT___057587_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3af565ab__0))));
    vlSelf->wasmetal_core__DOT___057553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h3af565ab__0)))))))))));
    vlSelf->wasmetal_core__DOT___011427_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056600_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056599_))))))) 
                                                  & (IData)(
                                                            (0xff55ff33ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                ? 
                                                                               (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011441_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45f38dff__0))))
                                                                                : 
                                                                               (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h39b11875__0))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011445_))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011444_))))))))))))));
    vlSelf->wasmetal_core__DOT___057320_ = ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012616_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xcaU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___011441_)))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf011U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45f38dff__0)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0553300000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___011460_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011352_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056618_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011538_))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011539_)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011540_))
                                                                                 : 
                                                                                (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h06746976__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeeeeeee00000fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056616_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056615_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                & (IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f5f0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : 
                                                                                (0xfff01111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010331_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010333_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010332_)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha8472195__0))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010722_)))))))));
}
