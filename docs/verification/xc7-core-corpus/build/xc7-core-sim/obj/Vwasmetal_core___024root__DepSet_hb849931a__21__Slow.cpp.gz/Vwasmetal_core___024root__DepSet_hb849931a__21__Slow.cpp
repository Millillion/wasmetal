#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__27(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__27\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___050631_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049311_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049313_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049311_))));
    vlSelf->wasmetal_core__DOT___065709_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065200_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065708_)))));
    vlSelf->wasmetal_core__DOT___061838_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061837_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hb587b232__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce304a5b__0))))))))))))));
    vlSelf->wasmetal_core__DOT___050446_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050394_))));
    vlSelf->wasmetal_core__DOT___050402_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048518_))));
    vlSelf->wasmetal_core__DOT___011719_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___049158_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003221_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h534a5d27__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001902_)))))))));
    vlSelf->wasmetal_core__DOT___065075_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064734_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065074_)))));
    vlSelf->wasmetal_core__DOT___064735_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042140_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064734_)))));
    if (vlSelf->wasmetal_core__DOT___042176_) {
        if (vlSelf->wasmetal_core__DOT___042174_) {
            if (vlSelf->wasmetal_core__DOT___042173_) {
                if (vlSelf->wasmetal_core__DOT___042172_) {
                    if (vlSelf->wasmetal_core__DOT___042171_) {
                        if (vlSelf->wasmetal_core__DOT___042170_) {
                            if (vlSelf->wasmetal_core__DOT___042169_) {
                                if (vlSelf->wasmetal_core__DOT___042168_) {
                                    if (vlSelf->wasmetal_core__DOT___042167_) {
                                        if (vlSelf->wasmetal_core__DOT___042166_) {
                                            if (vlSelf->wasmetal_core__DOT___042165_) {
                                                if (vlSelf->wasmetal_core__DOT___042185_) {
                                                    if (vlSelf->wasmetal_core__DOT___042184_) {
                                                        if (vlSelf->wasmetal_core__DOT___042183_) {
                                                            if (vlSelf->wasmetal_core__DOT___042182_) {
                                                                if (vlSelf->wasmetal_core__DOT___042181_) {
                                                                    if (vlSelf->wasmetal_core__DOT___042180_) {
                                                                        if (vlSelf->wasmetal_core__DOT___042179_) {
                                                                            if (vlSelf->wasmetal_core__DOT___042178_) {
                                                                                if (vlSelf->wasmetal_core__DOT___042175_) {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042140_)));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                ((~ 
                                                                                (9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0))) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042140_));
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd7e24a1__0)));
                                                                                } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042151_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042151_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042352_));
                                                                                }
                                                                            } else {
                                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042154_));
                                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042154_;
                                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042355_));
                                                                            }
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042155_));
                                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                                = vlSelf->wasmetal_core__DOT___042155_;
                                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                                = 
                                                                                (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___042356_));
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042156_));
                                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                            = vlSelf->wasmetal_core__DOT___042156_;
                                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                            = 
                                                                            (1U 
                                                                             & (IData)(vlSelf->wasmetal_core__DOT___042357_));
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042157_));
                                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                        = vlSelf->wasmetal_core__DOT___042157_;
                                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                        = 
                                                                        (1U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___042358_));
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042158_));
                                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                    = vlSelf->wasmetal_core__DOT___042158_;
                                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                    = 
                                                                    (1U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT___042359_));
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042159_));
                                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                                = vlSelf->wasmetal_core__DOT___042159_;
                                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                                = 
                                                                (1U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT___042360_));
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042160_));
                                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                            = vlSelf->wasmetal_core__DOT___042160_;
                                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                            = 
                                                            (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT___042361_));
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042161_));
                                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                        = vlSelf->wasmetal_core__DOT___042161_;
                                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                        = 
                                                        (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___042362_));
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042141_));
                                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                    = vlSelf->wasmetal_core__DOT___042141_;
                                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                    = 
                                                    (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT___042342_));
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042142_));
                                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                                = vlSelf->wasmetal_core__DOT___042142_;
                                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                                = (1U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___042343_));
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042143_));
                                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042143_;
                                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042344_));
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042144_));
                                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042144_;
                                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042345_));
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042145_));
                                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042145_;
                                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042346_));
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042146_));
                            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                                = vlSelf->wasmetal_core__DOT___042146_;
                            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042347_));
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042147_));
                        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                            = vlSelf->wasmetal_core__DOT___042147_;
                        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042348_));
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                    vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042148_));
                    vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                        = vlSelf->wasmetal_core__DOT___042148_;
                    vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                        = (1U & (IData)(vlSelf->wasmetal_core__DOT___042349_));
                }
            } else {
                vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
                vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042149_));
                vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                    = vlSelf->wasmetal_core__DOT___042149_;
                vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___042350_));
            }
        } else {
            vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
            vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042150_));
            vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
                = vlSelf->wasmetal_core__DOT___042150_;
            vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT___042351_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
        vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042152_));
        vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___042152_;
        vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___042353_));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128647___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001488_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001476_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001444_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001438_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034380_)))));
    vlSelf->wasmetal_core__DOT___034408_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001488_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028846_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028488_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->wasmetal_core__DOT___053993_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054040_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054044_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054048_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054047_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128094___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028663_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028630_)
            : (IData)(vlSelf->wasmetal_core__DOT___004522_));
    vlSelf->wasmetal_core__DOT___029079_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___029076_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___029065_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029054_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128121___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028975_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028942_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001443_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001443_)
            : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128103___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028766_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028752_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028741_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028734_ = ((IData)(vlSelf->wasmetal_core__DOT___028766_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026476_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127876___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026696_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026685_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026674_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026663_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127876___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026631_ = ((IData)(vlSelf->wasmetal_core__DOT___026696_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___127927___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027166_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027155_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027144_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027133_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027101_ = ((IData)(vlSelf->wasmetal_core__DOT___027166_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026573_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003269_));
    vlSelf->wasmetal_core__DOT____Vcellout___127910___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026966_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026955_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026944_) 
                                   << 1U) | (1U & (~ 
                                                   (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc01d1a00__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026901_ = ((IData)(vlSelf->wasmetal_core__DOT___026966_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT____Vcellout___127893___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)) 
                   << 3U)) | (IData)(vlSelf->__VdfgTmp_h0d1a9c72__0)) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127893___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026766_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___061511_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha1796962__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134219___O 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___001437_))) 
           ^ (4U | (((IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__) 
                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001443_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___064503_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064502_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064501_)))));
    vlSelf->wasmetal_core__DOT___063988_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063984_)))));
    vlSelf->wasmetal_core__DOT___064928_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064501_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064506_)))));
    vlSelf->wasmetal_core__DOT___064756_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063990_)))));
    vlSelf->wasmetal_core__DOT___064510_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064506_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064505_)))));
    vlSelf->wasmetal_core__DOT___063994_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063989_)))));
    vlSelf->wasmetal_core__DOT___064926_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064505_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064508_)))));
    vlSelf->wasmetal_core__DOT___064758_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063992_)))));
    vlSelf->wasmetal_core__DOT___064509_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064507_)))));
    vlSelf->wasmetal_core__DOT___063993_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063992_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063991_)))));
    vlSelf->wasmetal_core__DOT___064925_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064507_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064493_)))));
    vlSelf->wasmetal_core__DOT___064757_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063977_)))));
    vlSelf->wasmetal_core__DOT___064497_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064493_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064492_)))));
    vlSelf->wasmetal_core__DOT___063981_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063976_)))));
    vlSelf->wasmetal_core__DOT___064922_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064495_)))));
    vlSelf->wasmetal_core__DOT___064753_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063976_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063979_)))));
    vlSelf->wasmetal_core__DOT___064496_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064495_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064494_)))));
    vlSelf->wasmetal_core__DOT___063980_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063978_)))));
    vlSelf->wasmetal_core__DOT___064921_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064494_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064489_)))));
    vlSelf->wasmetal_core__DOT___064752_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063978_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063973_)))));
    vlSelf->wasmetal_core__DOT___064490_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064489_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064488_)))));
    vlSelf->wasmetal_core__DOT___063974_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063973_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063972_)))));
    vlSelf->wasmetal_core__DOT___064750_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063972_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___064919_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064488_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___064751_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063971_))));
    vlSelf->wasmetal_core__DOT___063975_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063971_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063970_)))));
    vlSelf->wasmetal_core__DOT___064920_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___064491_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064486_)))));
    vlSelf->wasmetal_core__DOT___030118_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc07dc041__0)))));
    vlSelf->wasmetal_core__DOT___030254_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc07dc041__0)))));
    vlSelf->wasmetal_core__DOT___030115_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d93b5b__0)))));
    vlSelf->wasmetal_core__DOT___030243_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d93b5b__0)))));
    vlSelf->wasmetal_core__DOT___030104_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___030232_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0817566b__0))));
    vlSelf->wasmetal_core__DOT___030093_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___030221_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30dbdcaa__0))));
    vlSelf->wasmetal_core__DOT___069154_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8025ed93__0))));
    vlSelf->wasmetal_core__DOT___069034_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068961_)))));
    vlSelf->wasmetal_core__DOT___068962_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068961_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068935_)))));
    vlSelf->wasmetal_core__DOT___068892_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068844_)))));
    vlSelf->wasmetal_core__DOT___068790_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068789_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068745_)))));
    vlSelf->wasmetal_core__DOT___068936_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068891_)))));
    vlSelf->wasmetal_core__DOT___068697_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068696_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068648_)))));
    vlSelf->wasmetal_core__DOT___068845_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068789_)))));
    vlSelf->wasmetal_core__DOT___068599_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068546_)))));
    vlSelf->wasmetal_core__DOT___068746_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068745_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068696_)))));
    vlSelf->wasmetal_core__DOT___068649_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068598_)))));
    vlSelf->wasmetal_core__DOT___068473_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068472_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068419_)))));
    vlSelf->wasmetal_core__DOT___068547_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068546_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068472_)))));
    vlSelf->wasmetal_core__DOT___068396_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068395_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068340_)))));
    vlSelf->wasmetal_core__DOT___068287_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068286_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068233_)))));
    vlSelf->wasmetal_core__DOT___068420_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068419_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068395_)))));
    vlSelf->wasmetal_core__DOT___068149_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068097_)))));
    vlSelf->wasmetal_core__DOT___068341_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068286_)))));
    vlSelf->wasmetal_core__DOT___068073_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068024_)))));
    vlSelf->wasmetal_core__DOT___068234_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068148_)))));
    vlSelf->wasmetal_core__DOT___067968_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067901_)))));
    vlSelf->wasmetal_core__DOT___068098_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068097_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068072_)))));
    vlSelf->wasmetal_core__DOT___068025_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068024_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067967_)))));
    vlSelf->wasmetal_core__DOT___067815_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067814_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067753_)))));
    vlSelf->wasmetal_core__DOT___067902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067901_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067814_)))));
    vlSelf->wasmetal_core__DOT___067754_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067729_)))));
    vlSelf->wasmetal_core__DOT___067592_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067591_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___067447_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))));
    vlSelf->wasmetal_core__DOT___067496_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha04cce4c__0))));
    vlSelf->wasmetal_core__DOT___067300_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had26118d__0))));
    vlSelf->wasmetal_core__DOT___067145_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4e6deac__0))));
    vlSelf->wasmetal_core__DOT___066962_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4438b1a5__0))));
    vlSelf->wasmetal_core__DOT___066843_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a3dbf89__0))));
    vlSelf->wasmetal_core__DOT___066638_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h898e287a__0))));
    vlSelf->wasmetal_core__DOT___066516_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9e6b526c__0))));
    vlSelf->wasmetal_core__DOT___067330_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h717e9861__0))));
    vlSelf->wasmetal_core__DOT___066304_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h238b010e__0))));
    vlSelf->wasmetal_core__DOT___067186_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdba97a87__0))));
    vlSelf->wasmetal_core__DOT___066116_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9040377d__0))));
    vlSelf->wasmetal_core__DOT___067067_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cb2731d__0))));
    vlSelf->wasmetal_core__DOT___066884_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf22a37d9__0))));
    vlSelf->wasmetal_core__DOT___065925_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd9104ee__0))));
    vlSelf->wasmetal_core__DOT___066760_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b010904__0))));
    vlSelf->wasmetal_core__DOT___066593_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3613bfb2__0))));
    vlSelf->wasmetal_core__DOT___065793_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h06dc5af9__0))));
    vlSelf->wasmetal_core__DOT___066390_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he924c244__0))));
    vlSelf->wasmetal_core__DOT___065595_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h61294ca4__0))));
    vlSelf->wasmetal_core__DOT___066260_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7dd7d539__0))));
    vlSelf->wasmetal_core__DOT___066070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb5d0a138__0))));
    vlSelf->wasmetal_core__DOT___065291_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbfd77ec1__0))));
    vlSelf->wasmetal_core__DOT___065070_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc4a801d__0))));
    vlSelf->wasmetal_core__DOT___065889_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9d768121__0))));
    vlSelf->wasmetal_core__DOT___065691_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa154e86__0))));
    vlSelf->wasmetal_core__DOT___065404_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h03893f91__0))));
    vlSelf->wasmetal_core__DOT___065175_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h776ad714__0))));
    vlSelf->wasmetal_core__DOT___064723_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___064890_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4328824__0))));
    vlSelf->wasmetal_core__DOT___064482_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))));
    vlSelf->wasmetal_core__DOT___063827_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063826_))));
    vlSelf->wasmetal_core__DOT___052841_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044240_))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028296_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028231_));
    vlSelf->wasmetal_core__DOT___049151_ = (1U & (IData)(
                                                         (0xf000f0ff00ffddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003135_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001811_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___003133_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003134_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000157_)))))))));
    vlSelf->wasmetal_core__DOT___064470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064469_))));
    vlSelf->wasmetal_core__DOT___064902_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064469_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064901_)))));
    vlSelf->wasmetal_core__DOT___063834_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___063965_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___042099_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042101_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042097_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063945_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((9U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca681a3f__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042103_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___042098_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042095_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x8000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___063935_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063934_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7da480c4__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___042094_))))))))))))));
    if (vlSelf->wasmetal_core__DOT___042104_) {
        if (vlSelf->wasmetal_core__DOT___042103_) {
            if (vlSelf->wasmetal_core__DOT___042102_) {
                if (vlSelf->wasmetal_core__DOT___042101_) {
                    if (vlSelf->wasmetal_core__DOT___042100_) {
                        if (vlSelf->wasmetal_core__DOT___042099_) {
                            if (vlSelf->wasmetal_core__DOT___042098_) {
                                if (vlSelf->wasmetal_core__DOT___042097_) {
                                    if (vlSelf->wasmetal_core__DOT___042096_) {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = ((IData)(vlSelf->wasmetal_core__DOT___042094_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042294_));
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = ((~ (IData)(vlSelf->wasmetal_core__DOT___042094_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___042082_));
                                    } else {
                                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042296_;
                                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                            = vlSelf->wasmetal_core__DOT___042084_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042297_;
                                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                        = vlSelf->wasmetal_core__DOT___042085_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042298_;
                                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                    = vlSelf->wasmetal_core__DOT___042086_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042299_;
                            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                                = vlSelf->wasmetal_core__DOT___042087_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042300_;
                        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                            = vlSelf->wasmetal_core__DOT___042088_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                    vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042301_;
                    vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                        = vlSelf->wasmetal_core__DOT___042089_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
                vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042302_;
                vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                    = vlSelf->wasmetal_core__DOT___042090_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
            vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042303_;
            vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
                = vlSelf->wasmetal_core__DOT___042091_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
        vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042304_;
        vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___042092_;
    }
    vlSelf->wasmetal_core__DOT___064015_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048341_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063728_))));
    vlSelf->wasmetal_core__DOT___064524_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064522_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf4328824__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e505808__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___064768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))));
    vlSelf->wasmetal_core__DOT___064523_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063867_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdba97a87__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h717e9861__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6cb2731d__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hf22a37d9__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b010904__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he924c244__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb776b144__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7dd7d539__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb5d0a138__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9d768121__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h03893f91__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa154e86__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h776ad714__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h0791be06__0 = (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hb39b7a55__0))));
    vlSelf->__VdfgTmp_h563f0a85__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072045_))))));
    vlSelf->__VdfgTmp_h21594217__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x96U 
                                                 >> 
                                                 ((4U 
                                                   & ((6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h144113a8__0)) 
                                                      << 2U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072046_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___072045_)))) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->__VdfgTmp_ha753d377__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h66324e1d__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h982d8c02__0)))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127427___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h76ba8332__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022537_ = ((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031073_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___049032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049279_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049027_))));
    vlSelf->wasmetal_core__DOT___049354_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049075_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049077_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049075_))));
    vlSelf->__VdfgTmp_hb57f307c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010090_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010089_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007798_))));
    vlSelf->__VdfgTmp_he4fe919e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010760_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___007798_)) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010089_)))));
    vlSelf->wasmetal_core__DOT___049031_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049030_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049282_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049030_))));
    vlSelf->wasmetal_core__DOT___049353_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049079_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049079_))));
    vlSelf->wasmetal_core__DOT___009783_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0)))
                                                    : 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h161030dd__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                   | (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007718_))))));
    vlSelf->__VdfgTmp_he89f377b__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc98b4d16__0))))
                                                : (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h161030dd__0)))))));
    vlSelf->__VdfgTmp_h87c0b1ab__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h82899d97__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0))))));
    vlSelf->wasmetal_core__DOT___054902_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51b5ea87__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054806_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054805_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_h496bba40__0))))))))));
    vlSelf->wasmetal_core__DOT___056196_ = (1U & (IData)(
                                                         (0xfff88888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010139_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007731_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___049014_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049009_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049247_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049009_))));
    vlSelf->wasmetal_core__DOT___049358_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049123_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049124_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049123_))));
    vlSelf->wasmetal_core__DOT___062090_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062084_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hacafe368__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))));
    vlSelf->__VdfgTmp_hf1d7bcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010754_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010753_));
    vlSelf->__VdfgTmp_h304fb1ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___010753_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010754_));
    vlSelf->wasmetal_core__DOT___054786_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))));
    vlSelf->wasmetal_core__DOT___049013_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049012_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049249_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049012_))));
    vlSelf->wasmetal_core__DOT___049357_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049126_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049131_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049126_))));
    vlSelf->wasmetal_core__DOT___062157_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062150_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf07ddd26__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfe0abeab__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hea36c42a__0)))))))))))));
    vlSelf->__VdfgTmp_h842b3020__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010310_))));
    vlSelf->wasmetal_core__DOT___010044_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010310_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h42c557be__0))))));
    vlSelf->wasmetal_core__DOT___062035_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))));
    vlSelf->wasmetal_core__DOT___062031_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062025_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h70e31548__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0286ce7d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054973_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb315704__0))))))))))))));
    vlSelf->wasmetal_core__DOT___051613_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051548_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051612_))));
    vlSelf->wasmetal_core__DOT___049529_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce73595f__0))))));
    vlSelf->wasmetal_core__DOT___051581_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051519_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h36154466__0))))));
    vlSelf->wasmetal_core__DOT___010756_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->wasmetal_core__DOT___010241_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h627ddd53__0)))));
    vlSelf->wasmetal_core__DOT___051549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051365_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051548_))));
    vlSelf->wasmetal_core__DOT___051520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051519_))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010976_)));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010886_)));
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010880_)));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010868_)));
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010874_)));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011014_)));
        vlSelf->wasmetal_core__DOT___011540_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010932_)));
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011011_)));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))));
        vlSelf->wasmetal_core__DOT___011869_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011004_)));
    } else {
        vlSelf->wasmetal_core__DOT___011604_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0))))));
        vlSelf->wasmetal_core__DOT___056379_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
        vlSelf->wasmetal_core__DOT___056380_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
        vlSelf->wasmetal_core__DOT___011660_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010374_)));
        vlSelf->wasmetal_core__DOT___056376_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
        vlSelf->wasmetal_core__DOT___012742_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
        vlSelf->wasmetal_core__DOT___056375_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
        vlSelf->wasmetal_core__DOT___012178_ = (1U 
                                                & (0xa0cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
        vlSelf->wasmetal_core__DOT___012131_ = (1U 
                                                & (0xffffffe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h831e3e64__0))))));
        if (vlSelf->wasmetal_core__DOT___007693_) {
            vlSelf->wasmetal_core__DOT___011540_ = 
                (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0))));
            vlSelf->wasmetal_core__DOT___011869_ = 
                (1U & (0xff35U >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hdea69a06__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___011540_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h00532677__0))));
            vlSelf->wasmetal_core__DOT___011869_ = 
                (1U & (0xdU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011003_))));
        }
        vlSelf->wasmetal_core__DOT___011868_ = (1U 
                                                & (0xffeeff0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010215_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
        vlSelf->wasmetal_core__DOT___056552_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010336_)));
    }
    vlSelf->__VdfgTmp_hc16275c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010977_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6a47c3d1__0)));
    vlSelf->wasmetal_core__DOT___010750_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    vlSelf->wasmetal_core__DOT___009651_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he68aaf0c__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010887_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h25286e3d__0))))));
    vlSelf->__VdfgTmp_h1d2a78cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010987_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010986_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010988_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010986_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010987_)))))));
    vlSelf->wasmetal_core__DOT___057047_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0))))))));
    vlSelf->__VdfgTmp_hb37e0c87__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha8fd39d5__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010881_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41c2ec0e__0))))));
    vlSelf->__VdfgTmp_haef445c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010981_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010980_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010982_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010980_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010981_)))))));
    vlSelf->wasmetal_core__DOT___010342_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010374_)));
    vlSelf->__VdfgTmp_ha8472195__0 = (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056425_));
    vlSelf->__VdfgTmp_hddfbd8d3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h499272d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010172_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(vlSelf->wasmetal_core__DOT___009806_)) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf00001111ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                             << 2U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0)))))))))));
    vlSelf->wasmetal_core__DOT___011042_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007507_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdeccdd32__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_heab1a15e__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009806_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055276_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                     << 2U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         & (IData)(
                                                                   (0xf0f0aaaaff00ccccULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hd5b4e54d__0)))) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hbc09f2bb__0))))))))))));
    vlSelf->wasmetal_core__DOT___053084_ = (1U & (IData)(
                                                         (0x7fff7fff7fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053027_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053073_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053063_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053061_)))))))));
    vlSelf->wasmetal_core__DOT___053082_ = (1U & (IData)(
                                                         (0xff11fff0ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053044_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053047_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053069_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053071_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053070_)))))))));
    vlSelf->wasmetal_core__DOT___071983_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012123_)))));
    vlSelf->wasmetal_core__DOT___013047_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012123_))))));
    vlSelf->__VdfgTmp_h7b0cb704__0 = (((IData)(vlSelf->wasmetal_core__DOT___012124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012123_));
    vlSelf->__VdfgTmp_hfe9a1cba__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d));
    vlSelf->wasmetal_core__DOT___061727_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___011154_ = (1U & (IData)(
                                                         (0xfcfaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054782_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->__VdfgTmp_h743eef07__0 = ((2U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))) 
                                             << 1U)) 
                                      | (1U & (0xa0cU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0))))));
    vlSelf->wasmetal_core__DOT___054771_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hab146f1e__0)))));
    vlSelf->__VdfgTmp_h724ed7d2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007254_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007776_))));
    vlSelf->__VdfgTmp_hde094a0f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h860ce20a__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___007776_)
                                                     : 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)))));
    vlSelf->wasmetal_core__DOT___010338_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054797_) 
                                                       << 3U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           & (IData)(
                                                                     (0xf0f0aaaaff00ccccULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                                  ? 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))
                                                                  : 
                                                                 (0xc0aU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0))) 
                                                                << 1U)) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               & (IData)(vlSelf->wasmetal_core__DOT___007250_))))))));
    vlSelf->wasmetal_core__DOT___056186_ = (1U & (IData)(
                                                         (0xdddd000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056183_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056182_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                      & (IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7b1353df__0)))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007250_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007235_)))))))));
    vlSelf->__VdfgTmp_h86da9f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___054278_) 
                                       << 3U) | ((4U 
                                                  & ((0xf00eeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007677_)))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                          ? 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0))
                                                          : 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       & (IData)(
                                                                 (0xf0f333300ff5555ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___007246_))))))))))));
    vlSelf->__VdfgTmp_he96324c1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d));
    vlSelf->__VdfgTmp_hedc6bc1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h3c2b613a__0)))));
    vlSelf->__VdfgTmp_h18547ac4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->__VdfgTmp_hd610ba85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010191_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010192_)));
    vlSelf->__VdfgTmp_h1b8b64b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010193_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010192_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010191_))));
    vlSelf->wasmetal_core__DOT___049566_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049087_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049089_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049087_))));
    vlSelf->wasmetal_core__DOT___048978_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048974_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049264_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048974_))));
    vlSelf->wasmetal_core__DOT___049853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049096_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049096_))));
    vlSelf->wasmetal_core__DOT___049839_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049262_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049260_))));
    vlSelf->wasmetal_core__DOT___061491_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061488_))));
    vlSelf->wasmetal_core__DOT___061965_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))));
    vlSelf->wasmetal_core__DOT___054931_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054924_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061063_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___054903_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h988afe01__0)))));
    vlSelf->wasmetal_core__DOT___049852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049064_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049066_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049064_))));
    vlSelf->wasmetal_core__DOT___049838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049271_))));
    vlSelf->wasmetal_core__DOT___055979_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055809_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055808_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055807_)))))))));
    vlSelf->wasmetal_core__DOT___062016_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019255_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___049854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049065_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049061_))));
    vlSelf->wasmetal_core__DOT___049841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049270_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049270_))));
    vlSelf->wasmetal_core__DOT___061984_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061975_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac54b2bd__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd03398e3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7208d2a5__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061979_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ffde934__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___009840_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xaaf0ccU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         & (IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007341_))))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010110_)))))))));
    vlSelf->__VdfgTmp_h8d891945__0 = ((8U & ((0xff550f33U 
                                              >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                          << 2U) | 
                                         ((2U & ((IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))) 
                                                 << 1U)) 
                                          | (IData)(vlSelf->wasmetal_core__DOT___010110_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010269_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2cfd74cc__0))))))))))));
    vlSelf->wasmetal_core__DOT___056615_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___011513_)))
                                                         : 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                         & (0x1111000fU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010351_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010350_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010348_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___010349_)))))))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                          ? 
                                                         (1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011508_))
                                                          : 
                                                         (0x1111000fU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010358_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010359_)))))))))));
    vlSelf->__VdfgTmp_hbd75f801__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff00000eeee0000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))))));
    vlSelf->__VdfgTmp_ha7c061ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___010151_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010150_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0)))))));
    vlSelf->__VdfgTmp_h25073b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h249314f5__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h249314f5__0))))));
    vlSelf->__VdfgTmp_h143507db__0 = (((IData)(vlSelf->wasmetal_core__DOT___010131_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xff00aaaaf0f0ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007367_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                           ? 
                                                          (0xc0aU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___007786_))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010250_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010251_)))))))));
    vlSelf->wasmetal_core__DOT___019319_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054955_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054952_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054963_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0))))))))))));
    vlSelf->__VdfgTmp_hfba46556__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))));
    vlSelf->__VdfgTmp_h53247725__0 = (((IData)(vlSelf->wasmetal_core__DOT___010141_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010140_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010139_))));
    vlSelf->__VdfgTmp_hb7b9c3d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010321_))));
    vlSelf->wasmetal_core__DOT___070513_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010322_)))));
    vlSelf->wasmetal_core__DOT___033411_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010322_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010321_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95b8e055__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010869_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6bbf4d1__0))))));
    vlSelf->__VdfgTmp_h034bd5a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010956_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010955_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010957_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___010955_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010956_)))))));
    vlSelf->wasmetal_core__DOT___055467_ = (1U & (IData)(
                                                         (0x553300000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055433_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055420_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff55ff33f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055434_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007962_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___054843_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054814_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054813_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054812_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054811_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054825_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hafe0013c__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000f33335555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054829_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054828_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054835_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054834_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054833_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054832_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___009831_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd544aedd__0))))));
    vlSelf->__VdfgTmp_h97dd8594__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hd544aedd__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h20b0bc38__0))))));
    vlSelf->wasmetal_core__DOT___061882_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019243_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___054884_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff33330f0f5555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054856_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xff33330f0f5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054870_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))));
    vlSelf->__VdfgTmp_hc09bd195__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc5fe5af8__0))))));
    vlSelf->wasmetal_core__DOT___010122_ = (1U & (0xf0ee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
    vlSelf->wasmetal_core__DOT___010281_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9e2ff648__0)))));
    vlSelf->wasmetal_core__DOT___061778_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->wasmetal_core__DOT___061773_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061767_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h422a580d__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054793_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))));
    vlSelf->__VdfgTmp_hc1ae2972__0 = ((4U & ((0xa0cU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5e3b944f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xa0cU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h5ce4c910__0)))) 
                                                << 1U)) 
                                         | (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))))));
    vlSelf->__VdfgTmp_h5e28409c__0 = ((4U & ((0xc0aU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hff6b6a1f__0)))) 
                                             << 2U)) 
                                      | ((2U & ((0xc0aU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h028c74de__0)))) 
                                                << 1U)) 
                                         | (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd184a96b__0)))))));
    vlSelf->wasmetal_core__DOT___012029_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010490_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h63abc8ec__0))))));
    vlSelf->wasmetal_core__DOT___061504_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061496_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010875_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5ffe6cff__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054855_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___054854_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054853_)))))));
    vlSelf->wasmetal_core__DOT___055122_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011520_))));
    vlSelf->wasmetal_core__DOT___055972_ = (1U & (IData)(
                                                         (0xff0000f8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055792_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055791_)))))))));
    vlSelf->wasmetal_core__DOT___061956_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___056634_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___056308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d)))));
    vlSelf->wasmetal_core__DOT___012039_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010457_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d))))));
    vlSelf->__VdfgTmp_hcf7af3c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2e0905c__0)))));
    vlSelf->__VdfgTmp_h929b802f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_))))));
    vlSelf->wasmetal_core__DOT___056173_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009796_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? (IData)(
                                                              (0xf0f0f0f0f0f0fffeULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___009795_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009794_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h831e3e64__0)))))))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___008974_))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d 
        = (1U & (0x1fU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                            << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h910334c5__0)))));
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1f90c42a__0))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xf0f0f0feU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h047929cf__0))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h047929cf__0))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0xf0f0f0eU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcdc85607__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___010259_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010291_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h00532677__0))))));
        vlSelf->wasmetal_core__DOT___010966_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010964_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___010166_ = (1U 
                                                & (0xcccdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010165_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010164_))))));
        vlSelf->wasmetal_core__DOT___009807_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x10U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007729_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5812bf47__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0f0aaaaff00ccccULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007731_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007484_))))))))))))));
        vlSelf->wasmetal_core__DOT___010196_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010216_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010215_))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h0549af28__0))))));
    vlSelf->wasmetal_core__DOT___011122_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0))))));
    vlSelf->__VdfgTmp_hf939f2bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9bd5098e__0));
    vlSelf->__VdfgTmp_h9c968075__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h35b20f8b__0));
    vlSelf->__VdfgTmp_hc43f9106__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8e4b209e__0));
    vlSelf->__VdfgTmp_h882f8f15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010164_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h047929cf__0)));
    vlSelf->__VdfgTmp_h3820fb89__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011125_));
    vlSelf->wasmetal_core__DOT___010186_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d))))));
    vlSelf->__VdfgTmp_h7edccd87__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd7e7c41d__0));
    vlSelf->wasmetal_core__DOT___011115_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0))))));
    vlSelf->__VdfgTmp_hcc63a86c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009784_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h0b52da3e__0));
    vlSelf->__VdfgTmp_ha620249b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d 
        = (1U & (0x1100f0U >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15c467ca__0)))));
    vlSelf->wasmetal_core__DOT___012717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010529_)))))))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010597_)));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010781_)));
    } else {
        vlSelf->wasmetal_core__DOT___056621_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))));
        vlSelf->wasmetal_core__DOT___010573_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
        vlSelf->wasmetal_core__DOT___056368_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010781_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hd25df3ae__0))))));
    vlSelf->wasmetal_core__DOT___055106_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h4e8951c3__0))))));
    vlSelf->wasmetal_core__DOT___055031_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055026_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055019_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___055022_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055021_))))))))));
    vlSelf->wasmetal_core__DOT___051689_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051629_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___051630_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h36154466__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051629_))));
    vlSelf->wasmetal_core__DOT___053680_ = (1U & (0xaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb6137419__0))));
    vlSelf->wasmetal_core__DOT___053689_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (1U 
                                                                   & (0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051612_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))));
    vlSelf->wasmetal_core__DOT___048673_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))));
    vlSelf->__VdfgTmp_h951148c2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0))))));
    vlSelf->__VdfgTmp_h6a1d65be__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce73595f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha9985ff6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)))))));
    vlSelf->wasmetal_core__DOT___049644_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0))))));
    vlSelf->__VdfgTmp_h79a3c79a__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0))))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                          << 1U)))))));
    vlSelf->__VdfgTmp_h35851421__0 = ((4U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xacU 
                                                 >> 
                                                 ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h309182ec__0))))) 
                                                << 1U)) 
                                         | (1U & (4U 
                                                  >> 
                                                  (2U 
                                                   & ((4U 
                                                       >> 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                        << 1U)) 
                                                      << 1U))))));
    vlSelf->wasmetal_core__DOT___049238_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                         << 1U)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h309182ec__0))))));
    vlSelf->wasmetal_core__DOT___062103_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062094_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7b1ed1fb__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h99d3b9a6__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1e1103c4__0))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x3333555500ff0f0fULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062098_) 
                                                                               << 3U) 
                                                                              | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1f51ea8e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056637_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)))))
                                                   : 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___056313_ = (1U & (0x3300faU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xbU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010462_)))))));
    vlSelf->wasmetal_core__DOT___012980_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___010717_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2f9ca2ed__0))))))));
    vlSelf->__VdfgTmp_hafd3f22a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d));
    vlSelf->__VdfgTmp_h0adc7ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT___010299_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010336_)));
    vlSelf->wasmetal_core__DOT___070139_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___070137_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_imm[3U] 
                                                                                >> 6U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h350dca3c__0))))))));
    vlSelf->wasmetal_core__DOT___061506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061483_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061468_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061460_)))))));
    vlSelf->wasmetal_core__DOT___061505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061502_))));
    vlSelf->wasmetal_core__DOT___062158_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062139_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he0ff0f52__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28180847__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1dd2f13b__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h703df812__0))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))))))))))))))));
    vlSelf->wasmetal_core__DOT___019337_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055037_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff33330f0f5555ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055051_) 
                                                                               << 3U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))));
    vlSelf->wasmetal_core__DOT___056312_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc9e45bda__0)))))));
    vlSelf->wasmetal_core__DOT___056897_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                   ? 
                                                  (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)))))
                                                   : 
                                                  (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0))))));
    vlSelf->wasmetal_core__DOT___069138_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048850_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___054966_ = (1U & (0xeeeefff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054947_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((4U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054940_))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___054943_))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054942_))))))))));
    vlSelf->wasmetal_core__DOT___059202_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051505_))))));
    vlSelf->wasmetal_core__DOT___059159_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051506_))));
    vlSelf->__VdfgTmp_h22ba1a50__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h170507c4__0)));
    vlSelf->wasmetal_core__DOT___048832_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h170507c4__0))))));
    vlSelf->__VdfgTmp_h5b64371c__0 = ((2U & ((IData)(
                                                     (0x330f5500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001781_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___001850_))));
    if (vlSelf->wasmetal_core__DOT___000182_) {
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h73960028__0)))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73960028__0))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001784_)))));
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___001849_;
    } else {
        vlSelf->wasmetal_core__DOT___002811_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___001785_)))))));
        vlSelf->wasmetal_core__DOT___002564_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                    ? 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___001785_)))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___001783_))))));
        vlSelf->wasmetal_core__DOT___002893_ = vlSelf->wasmetal_core__DOT___002111_;
    }
    vlSelf->wasmetal_core__DOT___048771_ = ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                            & (IData)(
                                                      (0x3300f00055ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))));
    vlSelf->__VdfgTmp_hb4d5b900__0 = ((2U & ((IData)(
                                                     (0x33f05500000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h804cf86b__0)))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                ? (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000923_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000921_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___000924_))));
    vlSelf->wasmetal_core__DOT___016197_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006898_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006899_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051557_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016206_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006918_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006919_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006933_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006951_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006959_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006966_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___006969_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051542_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___051541_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___016297_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022643_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022630_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022629_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057706_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057702_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015781_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015696_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015695_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015707_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015708_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015717_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013558_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013559_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013548_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015612_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015750_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015621_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015622_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015630_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015629_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015638_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015651_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013589_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013565_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013581_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013602_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013605_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013599_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057729_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057730_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057728_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___015650_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023445_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023431_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023430_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006159_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023429_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023428_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___068897_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048861_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048862_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___009833_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfc864313__0))))));
    vlSelf->__VdfgTmp_h2544c7bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011003_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hdea69a06__0)));
    vlSelf->__VdfgTmp_ha9e2ef67__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___051502_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___051504_));
    vlSelf->wasmetal_core__DOT___058693_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051504_))))));
    vlSelf->wasmetal_core__DOT___051508_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051504_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051502_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___006238_)))))));
    vlSelf->__VdfgTmp_h6dac888a__0 = (((IData)(vlSelf->wasmetal_core__DOT___002933_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0));
    vlSelf->wasmetal_core__DOT___049528_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb043089c__0))))));
    vlSelf->wasmetal_core__DOT___049814_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb043089c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0))))));
    vlSelf->wasmetal_core__DOT___051366_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051365_))));
    vlSelf->wasmetal_core__DOT___050253_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006114_))));
    vlSelf->wasmetal_core__DOT___050175_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050260_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050141_))));
    vlSelf->wasmetal_core__DOT___050138_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0))))));
    vlSelf->wasmetal_core__DOT___050164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006114_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050153_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3500bf27__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT___050142_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127453___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003805_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005855_) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005770_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022667_ = ((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___001898_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002271_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb0eb761__0))))))));
    vlSelf->__VdfgTmp_h9934c93f__0 = (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002510_));
    vlSelf->wasmetal_core__DOT___002475_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xffff4444fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002510_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002509_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h703a7a56__0)))))))));
    vlSelf->wasmetal_core__DOT___050848_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0))))));
    vlSelf->__VdfgTmp_hbd292e75__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1dedb610__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)))))));
    vlSelf->wasmetal_core__DOT___051346_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051345_))));
    vlSelf->__VdfgTmp_hb62f452d__0 = (((IData)(vlSelf->wasmetal_core__DOT___002324_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0));
    vlSelf->__VdfgTmp_h81d9e1ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___002730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002729_));
    vlSelf->__VdfgTmp_hfd6c95b6__0 = ((4U & ((IData)(
                                                     (0xfff00000eeeeULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0));
    vlSelf->__VdfgTmp_h5a517e30__0 = ((4U & ((IData)(
                                                     (0x33000f0055ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h89619cd0__0)))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h5e317429__0));
    vlSelf->__VdfgTmp_h0da24f1d__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                          ? (IData)(vlSelf->wasmetal_core__DOT___001850_)
                                          : (IData)(vlSelf->wasmetal_core__DOT___001849_)));
    vlSelf->__VdfgTmp_h0073f5c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_he9e11b30__0));
    vlSelf->wasmetal_core__DOT___010022_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010361_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3d308cc6__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he9e11b30__0))))));
    vlSelf->wasmetal_core__DOT___049382_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb043089c__0))))));
    vlSelf->wasmetal_core__DOT___051326_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051325_))));
    vlSelf->wasmetal_core__DOT___058694_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058692_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)))));
    vlSelf->wasmetal_core__DOT___017220_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017324_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017226_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017333_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017318_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017312_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017241_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___057889_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023566_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023552_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023551_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___023549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___002113_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048816_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))))));
    vlSelf->wasmetal_core__DOT___018281_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005738_))));
    vlSelf->wasmetal_core__DOT___018334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    vlSelf->__VdfgTmp_hf09b90d7__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h58306e5b__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5d9fd2de__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)))))));
    vlSelf->wasmetal_core__DOT___049440_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc673eb53__0))))));
    vlSelf->wasmetal_core__DOT___051288_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127552___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005823_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023480_ = ((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127552___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___049526_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___049815_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))));
    vlSelf->wasmetal_core__DOT___051113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051112_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127569___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013780_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023601_ = ((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050849_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->wasmetal_core__DOT___049227_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcfd16dec__0))))));
    vlSelf->wasmetal_core__DOT___051056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049884_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))));
    vlSelf->wasmetal_core__DOT___061507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061496_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061469_)))));
    vlSelf->wasmetal_core__DOT___061477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061474_))));
    vlSelf->wasmetal_core__DOT___054747_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccaaaaf0f0ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054727_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha89e6386__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbbe663c1__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xffff3355fffff0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3265141f__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hffdded68__0))))))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xfcfaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054717_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xc000aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h014e1215__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054714_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054713_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054721_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054720_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061639_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061627_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061620_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52d73039__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))))))));
    vlSelf->wasmetal_core__DOT___009842_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056201_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007509_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae0eb281__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010229_)))))))));
    vlSelf->__VdfgTmp_h02606b30__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hd163f969__0))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010229_));
    vlSelf->wasmetal_core__DOT___011992_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hdc4dab2d__0))))));
    vlSelf->__VdfgTmp_h249647a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0));
    vlSelf->__VdfgTmp_h73f89ba5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___047949_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0))))));
    vlSelf->wasmetal_core__DOT___050692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050691_))));
    vlSelf->wasmetal_core__DOT___063925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063909_))));
    vlSelf->wasmetal_core__DOT___019240_ = (1U & (IData)(
                                                         (0xf000000eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060712_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))))));
    vlSelf->wasmetal_core__DOT___055997_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h12bbe12d__0))));
    vlSelf->wasmetal_core__DOT___019201_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055863_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048284_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055864_)))))))));
    vlSelf->wasmetal_core__DOT___019277_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055864_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055863_))))));
    vlSelf->__VdfgTmp_hce2b20fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___047872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047871_));
    vlSelf->__VdfgTmp_hb4c65051__0 = (((IData)(vlSelf->wasmetal_core__DOT___047871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___047946_));
    vlSelf->wasmetal_core__DOT___049747_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049697_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049746_))));
    vlSelf->wasmetal_core__DOT___049698_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049697_))));
    vlSelf->wasmetal_core__DOT___055992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055990_))));
    vlSelf->wasmetal_core__DOT___062075_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___002393_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he278c168__0)))))));
    vlSelf->wasmetal_core__DOT___050827_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___049055_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049116_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0))))));
    vlSelf->wasmetal_core__DOT___019232_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffff000000bf00bfULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055958_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055957_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055428_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055319_))))))))))));
    vlSelf->wasmetal_core__DOT___050047_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___050790_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0))))));
    vlSelf->wasmetal_core__DOT___049499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049498_))));
    vlSelf->wasmetal_core__DOT___050851_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0))))));
    vlSelf->wasmetal_core__DOT___051906_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfac3f09e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049116_))));
    vlSelf->wasmetal_core__DOT___061712_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055732_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___047951_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0))))));
    vlSelf->wasmetal_core__DOT___048589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048581_))));
    vlSelf->wasmetal_core__DOT___049056_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6896023__0))))));
    vlSelf->wasmetal_core__DOT___049616_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049117_))));
    vlSelf->wasmetal_core__DOT___055013_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054986_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054976_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc326eb38__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054977_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054978_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054991_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___050046_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___050787_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0))))));
    vlSelf->wasmetal_core__DOT___049500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048582_))));
    vlSelf->wasmetal_core__DOT___051433_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))));
    vlSelf->wasmetal_core__DOT___051905_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049121_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049119_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))));
    vlSelf->wasmetal_core__DOT___047952_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0))))));
    vlSelf->wasmetal_core__DOT___048590_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048587_))));
    vlSelf->__VdfgTmp_h36cbed8c__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hd6896023__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha333b59f__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)))))));
    vlSelf->wasmetal_core__DOT___049057_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2956b7c1__0))))));
    vlSelf->wasmetal_core__DOT___049617_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049119_))));
    vlSelf->wasmetal_core__DOT___050058_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___050788_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___049504_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___051426_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha4843895__0))))));
    vlSelf->wasmetal_core__DOT___051904_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha4843895__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___049144_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049142_))));
    vlSelf->wasmetal_core__DOT___049370_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))));
    vlSelf->wasmetal_core__DOT___049700_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049503_))));
    vlSelf->wasmetal_core__DOT___063926_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063923_))));
    vlSelf->__VdfgTmp_h5a2cc5a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0))));
    vlSelf->wasmetal_core__DOT___002759_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hcf8aa4a8__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9be80f53__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0)))))));
    vlSelf->wasmetal_core__DOT___002112_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048815_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002143_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002142_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1e7febb9__0))))))));
    vlSelf->wasmetal_core__DOT___063011_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052687_)))));
    vlSelf->wasmetal_core__DOT___052690_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052687_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f45eb21__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050365_))))));
    vlSelf->wasmetal_core__DOT___052703_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h568bee24__0))));
    vlSelf->wasmetal_core__DOT___049024_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049021_))));
    vlSelf->wasmetal_core__DOT___049450_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049281_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049248_))));
    vlSelf->__VdfgTmp_h94c83f35__0 = (((IData)(vlSelf->wasmetal_core__DOT___049360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049359_));
    vlSelf->__VdfgTmp_h3b672e02__0 = (((IData)(vlSelf->wasmetal_core__DOT___049081_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049125_));
    vlSelf->wasmetal_core__DOT___002075_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048831_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002106_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002105_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf798121__0))))))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_he2ba16db__0))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h95b0aa6a__0))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hc6bfb5bb__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002841_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))));
            vlSelf->wasmetal_core__DOT___002680_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002689_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002688_)))));
            vlSelf->wasmetal_core__DOT___002641_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002650_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002649_)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002841_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002853_))));
        vlSelf->wasmetal_core__DOT___002680_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hd0a40acf__0))))))));
        vlSelf->wasmetal_core__DOT___002641_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (2U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xfff00000eeeeULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hcd5a09ca__0))))))));
    }
    vlSelf->wasmetal_core__DOT___002352_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048778_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002142_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002382_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hea3488cd__0))))))));
    vlSelf->wasmetal_core__DOT___002430_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048786_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002105_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002460_)) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hae207145__0))))))));
    vlSelf->wasmetal_core__DOT___002392_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048770_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002382_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002225_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002689_)))))))));
    vlSelf->wasmetal_core__DOT___049042_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049040_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049039_))));
    vlSelf->wasmetal_core__DOT___049452_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049280_))));
    vlSelf->__VdfgTmp_hdfb5cdf6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049352_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049351_));
    vlSelf->wasmetal_core__DOT___049491_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049071_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049078_))));
    vlSelf->wasmetal_core__DOT___002515_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048742_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? (IData)(vlSelf->wasmetal_core__DOT___002460_)
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___001770_)) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002649_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002650_)))))))));
    vlSelf->wasmetal_core__DOT___069651_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069647_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069645_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))))))));
    vlSelf->wasmetal_core__DOT___069718_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069714_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069713_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069712_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))))))));
    vlSelf->wasmetal_core__DOT___069740_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069735_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069734_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))))));
    vlSelf->wasmetal_core__DOT___069762_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069758_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069757_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069756_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))))))));
    vlSelf->wasmetal_core__DOT___069783_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069779_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069778_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069777_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))))))));
    vlSelf->wasmetal_core__DOT___069805_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069801_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069799_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))))))));
    vlSelf->wasmetal_core__DOT___069827_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069823_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069822_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069821_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))))))));
    vlSelf->wasmetal_core__DOT___069972_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069968_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069967_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069966_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d)))))))));
    vlSelf->wasmetal_core__DOT___069992_ = (1U & (IData)(
                                                         (0xfdf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069988_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069986_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))))))));
    vlSelf->wasmetal_core__DOT___069411_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069407_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x70U 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0x7077000070777077ULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & vlSelf->insn_imm[2U]) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 5U))))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048278_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))));
    vlSelf->wasmetal_core__DOT___069556_ = (1U & (0xff4f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069552_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x70U 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(
                                                                           (0x7077000070777077ULL 
                                                                            >> 
                                                                            ((0x20U 
                                                                              & (vlSelf->insn_imm[2U] 
                                                                                >> 6U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 8U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU))))))))) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___048278_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))));
    vlSelf->wasmetal_core__DOT___070097_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070093_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 3U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d)))))))));
    vlSelf->wasmetal_core__DOT___070157_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070153_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d)))))))));
    vlSelf->wasmetal_core__DOT___070170_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070165_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d)))))))));
    vlSelf->wasmetal_core__DOT___070184_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070180_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070179_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d)))))))));
    vlSelf->wasmetal_core__DOT___070245_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070241_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070240_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d)))))))));
    vlSelf->wasmetal_core__DOT___070274_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070270_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070269_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d)))))))));
    vlSelf->wasmetal_core__DOT___070286_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070282_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070281_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d)))))))));
    vlSelf->wasmetal_core__DOT___070298_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070294_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070293_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d)))))))));
    vlSelf->wasmetal_core__DOT___070324_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070320_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070319_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d)))))))));
    vlSelf->wasmetal_core__DOT___070336_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x14U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d)))))))));
    vlSelf->wasmetal_core__DOT___070348_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d)))))))));
    vlSelf->wasmetal_core__DOT___070376_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070372_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070371_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x17U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d)))))))));
    vlSelf->wasmetal_core__DOT___070388_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070384_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070383_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x18U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d)))))))));
    vlSelf->wasmetal_core__DOT___070400_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x19U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___070413_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070409_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070408_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d)))))))));
    vlSelf->wasmetal_core__DOT___070425_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070421_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070420_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d)))))))));
    vlSelf->wasmetal_core__DOT___070438_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070434_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070433_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1cU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d)))))))));
    vlSelf->wasmetal_core__DOT___070450_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070446_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070445_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___053365_ = (1U & (IData)(
                                                         (0x10ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053354_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052849_)))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)))))))))));
    vlSelf->wasmetal_core__DOT___040040_ = (1U & (0xbfb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071471_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__divider__02ebusy))))));
    vlSelf->wasmetal_core__DOT___040039_ = (1U & (0xa2aeaea2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q)))))));
    vlSelf->wasmetal_core__DOT___040030_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___039983_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___039978_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___039997_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d)))))))));
    vlSelf->__VdfgTmp_h364b73f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052804_));
    vlSelf->wasmetal_core__DOT___063469_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063464_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063477_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063472_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063485_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063480_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063493_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063488_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O))))))));
    vlSelf->wasmetal_core__DOT___063501_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063496_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063509_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063504_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063517_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063512_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128491___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063460_ = (1U & (IData)(
                                                         (0xf3f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063452_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O))))))))));
    vlSelf->wasmetal_core__DOT___063369_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063822_ = (1U & (IData)(
                                                         (0x33305550fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052902_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3cb924f__0))))))));
    vlSelf->wasmetal_core__DOT___050448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063398_ = (1U & (0x3050000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052906_)))))));
    vlSelf->__VdfgTmp_h3eb9c9bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->wasmetal_core__DOT___063364_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___063525_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063520_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O))))))));
    vlSelf->wasmetal_core__DOT___063533_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063528_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063541_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063549_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063544_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                  >> 3U))))))));
    vlSelf->__VdfgTmp_h0f244854__0 = (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->__VdfgTmp_hb0023997__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___050435_))) 
                                             << 1U)) 
                                      | (1U & (0xfeU 
                                               >> (
                                                   ((IData)(vlSelf->reset) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)))))))));
    vlSelf->wasmetal_core__DOT___063557_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063552_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O))))))));
    vlSelf->wasmetal_core__DOT___063565_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063560_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b13__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063573_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063568_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b14__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063581_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063576_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___019789_ = (1U & (IData)(
                                                         (0x23a0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052835_)))))))));
    vlSelf->wasmetal_core__DOT___063589_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063584_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))))))));
    vlSelf->wasmetal_core__DOT___063597_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063605_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063600_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063613_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063608_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063621_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063616_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))))))));
    vlSelf->wasmetal_core__DOT___063629_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063624_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063637_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063632_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063645_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063653_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))))))));
    vlSelf->wasmetal_core__DOT___063661_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063669_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063677_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___063685_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))))))));
    vlSelf->wasmetal_core__DOT___063693_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063701_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063709_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 3U))))))));
}
