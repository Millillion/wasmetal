#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__45(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__45\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___008826_;
    wasmetal_core__DOT___008826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008882_;
    wasmetal_core__DOT___008882_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008884_;
    wasmetal_core__DOT___008884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008941_;
    wasmetal_core__DOT___008941_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008972_;
    wasmetal_core__DOT___008972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___008973_;
    wasmetal_core__DOT___008973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009020_;
    wasmetal_core__DOT___009020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009024_;
    wasmetal_core__DOT___009024_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009025_;
    wasmetal_core__DOT___009025_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009026_;
    wasmetal_core__DOT___009026_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009049_;
    wasmetal_core__DOT___009049_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009096_;
    wasmetal_core__DOT___009096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009132_;
    wasmetal_core__DOT___009132_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009133_;
    wasmetal_core__DOT___009133_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009134_;
    wasmetal_core__DOT___009134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009140_;
    wasmetal_core__DOT___009140_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009141_;
    wasmetal_core__DOT___009141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009150_;
    wasmetal_core__DOT___009150_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009151_;
    wasmetal_core__DOT___009151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009152_;
    wasmetal_core__DOT___009152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009168_;
    wasmetal_core__DOT___009168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009243_;
    wasmetal_core__DOT___009243_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009274_;
    wasmetal_core__DOT___009274_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009387_;
    wasmetal_core__DOT___009387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009414_;
    wasmetal_core__DOT___009414_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009447_;
    wasmetal_core__DOT___009447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009699_;
    wasmetal_core__DOT___009699_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009700_;
    wasmetal_core__DOT___009700_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009716_;
    wasmetal_core__DOT___009716_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009725_;
    wasmetal_core__DOT___009725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009886_;
    wasmetal_core__DOT___009886_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009915_;
    wasmetal_core__DOT___009915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013207_;
    wasmetal_core__DOT___013207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013208_;
    wasmetal_core__DOT___013208_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014355_;
    wasmetal_core__DOT___014355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014375_;
    wasmetal_core__DOT___014375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014381_;
    wasmetal_core__DOT___014381_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014382_;
    wasmetal_core__DOT___014382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014383_;
    wasmetal_core__DOT___014383_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014440_;
    wasmetal_core__DOT___014440_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014447_;
    wasmetal_core__DOT___014447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014454_;
    wasmetal_core__DOT___014454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019677_;
    wasmetal_core__DOT___019677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019684_;
    wasmetal_core__DOT___019684_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019760_;
    wasmetal_core__DOT___019760_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051265_;
    wasmetal_core__DOT___051265_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056103_;
    wasmetal_core__DOT___056103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056218_;
    wasmetal_core__DOT___056218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056268_;
    wasmetal_core__DOT___056268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056270_;
    wasmetal_core__DOT___056270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057713_;
    wasmetal_core__DOT___057713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057915_;
    wasmetal_core__DOT___057915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057936_;
    wasmetal_core__DOT___057936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057950_;
    wasmetal_core__DOT___057950_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057970_;
    wasmetal_core__DOT___057970_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057977_;
    wasmetal_core__DOT___057977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057979_;
    wasmetal_core__DOT___057979_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058023_;
    wasmetal_core__DOT___058023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058027_;
    wasmetal_core__DOT___058027_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058032_;
    wasmetal_core__DOT___058032_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058042_;
    wasmetal_core__DOT___058042_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058054_;
    wasmetal_core__DOT___058054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058055_;
    wasmetal_core__DOT___058055_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058056_;
    wasmetal_core__DOT___058056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058981_;
    wasmetal_core__DOT___058981_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071733_;
    wasmetal_core__DOT___071733_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h3c5f3431__0;
    __VdfgTmp_h3c5f3431__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha336bc52__0;
    __VdfgTmp_ha336bc52__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2b908e25__0;
    __VdfgTmp_h2b908e25__0 = 0;
    CData/*1:0*/ __VdfgTmp_h74811752__0;
    __VdfgTmp_h74811752__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2c715ba9__0;
    __VdfgTmp_h2c715ba9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29905bdd__0;
    __VdfgTmp_h29905bdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8ed306e0__0;
    __VdfgTmp_h8ed306e0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h44cf3d5c__0;
    __VdfgTmp_h44cf3d5c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5c89e2df__0;
    __VdfgTmp_h5c89e2df__0 = 0;
    CData/*3:0*/ __VdfgTmp_h0fbdc802__0;
    __VdfgTmp_h0fbdc802__0 = 0;
    CData/*1:0*/ __VdfgTmp_hca62a78c__0;
    __VdfgTmp_hca62a78c__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcb32e64d__0;
    __VdfgTmp_hcb32e64d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3ae7f513__0;
    __VdfgTmp_h3ae7f513__0 = 0;
    CData/*2:0*/ __VdfgTmp_h115316d8__0;
    __VdfgTmp_h115316d8__0 = 0;
    CData/*1:0*/ __VdfgTmp_h351522cb__0;
    __VdfgTmp_h351522cb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd28f0b72__0;
    __VdfgTmp_hd28f0b72__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb4d0429b__0;
    __VdfgTmp_hb4d0429b__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb9a1e459__0;
    __VdfgTmp_hb9a1e459__0 = 0;
    CData/*1:0*/ __VdfgTmp_hce268e24__0;
    __VdfgTmp_hce268e24__0 = 0;
    CData/*2:0*/ __VdfgTmp_h4bae57cc__0;
    __VdfgTmp_h4bae57cc__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha28c8f63__0;
    __VdfgTmp_ha28c8f63__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e20e5e3__0;
    __VdfgTmp_h0e20e5e3__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8170c8be__0;
    __VdfgTmp_h8170c8be__0 = 0;
    CData/*3:0*/ __VdfgTmp_h8f2e1370__0;
    __VdfgTmp_h8f2e1370__0 = 0;
    CData/*2:0*/ __VdfgTmp_h738ad7cb__0;
    __VdfgTmp_h738ad7cb__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6f023739__0;
    __VdfgTmp_h6f023739__0 = 0;
    CData/*1:0*/ __VdfgTmp_h41d7b504__0;
    __VdfgTmp_h41d7b504__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9dc510af__0;
    __VdfgTmp_h9dc510af__0 = 0;
    CData/*1:0*/ __VdfgTmp_hba696de2__0;
    __VdfgTmp_hba696de2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8453cf34__0;
    __VdfgTmp_h8453cf34__0 = 0;
    CData/*1:0*/ __VdfgTmp_hbb8e97f6__0;
    __VdfgTmp_hbb8e97f6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3fbd9b9f__0;
    __VdfgTmp_h3fbd9b9f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h98614ec5__0;
    __VdfgTmp_h98614ec5__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6ff3b264__0;
    __VdfgTmp_h6ff3b264__0 = 0;
    CData/*3:0*/ __VdfgTmp_h63472758__0;
    __VdfgTmp_h63472758__0 = 0;
    CData/*2:0*/ __VdfgTmp_h0c9bc85d__0;
    __VdfgTmp_h0c9bc85d__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf656a041__0;
    __VdfgTmp_hf656a041__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a1a10ae__0;
    __VdfgTmp_h7a1a10ae__0 = 0;
    CData/*4:0*/ __VdfgTmp_hb2511b98__0;
    __VdfgTmp_hb2511b98__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf3511969__0;
    __VdfgTmp_hf3511969__0 = 0;
    CData/*1:0*/ __VdfgTmp_h78b7c78d__0;
    __VdfgTmp_h78b7c78d__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf87abe5d__0;
    __VdfgTmp_hf87abe5d__0 = 0;
    CData/*3:0*/ __VdfgTmp_h32a58059__0;
    __VdfgTmp_h32a58059__0 = 0;
    CData/*4:0*/ __VdfgTmp_h836204cc__0;
    __VdfgTmp_h836204cc__0 = 0;
    // Body
    wasmetal_core__DOT___058981_ = (1U & (0xeeeef0ffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013519_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))));
    vlSelf->wasmetal_core__DOT___017483_ = (1U & ((
                                                   (0xf70000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013319_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___013549_)))))) 
                                                   & (IData)(
                                                             (0x4000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___013540_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013539_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013538_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (((IData)(vlSelf->wasmetal_core__DOT___013549_)
                                                                              ? (IData)(
                                                                                (0xeee0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013546_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013545_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9b65f112__0)))))))
                                                                              : 
                                                                             (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___013547_)))) 
                                                                            << 2U)) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x8fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013335_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013503_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf3f5f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017531_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he3b69f57__0))))))))))))) 
                                                  & ((0x8000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___017385_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017427_))))) 
                                                     & (IData)(
                                                               (0xe000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___013524_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013523_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013522_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057732_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015635_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8523194f__0))))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___013519_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128848___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___036315_) 
                               << 2U) | ((2U & ((7U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h60102cdd__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (8U >> (IData)(vlSelf->__VdfgTmp_h8fcc0329__0))) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___036342_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h0bc68a5e__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128848___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___013208_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057703_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he3b69f57__0)))));
    wasmetal_core__DOT___013207_ = (1U & (IData)((0xf3f5f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057707_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9cde2904__0)))));
    wasmetal_core__DOT___057950_ = (1U & (IData)((0xff00aaaaccccf0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    __VdfgTmp_h7a1a10ae__0 = ((4U & ((0x53U >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0));
    wasmetal_core__DOT___058056_ = (1U & (IData)((0xf0f0aaaaff00ccccULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    wasmetal_core__DOT___058042_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014360_))));
    vlSelf->__VdfgTmp_hb0772ee2__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013631_));
    vlSelf->wasmetal_core__DOT___058037_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014357_))));
    vlSelf->__VdfgTmp_hd09be45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014358_));
    vlSelf->wasmetal_core__DOT___014372_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))));
    __VdfgTmp_hb2511b98__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___014453_) 
                                           << 2U) | 
                                          ((2U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                  << 1U)) 
                                           | (1U & 
                                              (0x53U 
                                               >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)))))));
    vlSelf->wasmetal_core__DOT___014371_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057935_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    vlSelf->wasmetal_core__DOT___014461_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057934_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057935_)))));
    vlSelf->wasmetal_core__DOT___014374_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___014383_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014460_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he122bc0f__0))))));
    wasmetal_core__DOT___014447_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)))))))));
    __VdfgTmp_hba696de2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057914_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057913_));
    wasmetal_core__DOT___014382_ = (1U & (0xaaccf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057929_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hdb52a936__0))))));
    wasmetal_core__DOT___019684_ = (1U & (0xf011U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057913_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057911_))))));
    wasmetal_core__DOT___057915_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057912_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057911_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057910_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___057909_)))))));
    vlSelf->wasmetal_core__DOT___019683_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057928_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057909_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057910_))))));
    __VdfgTmp_h9dc510af__0 = (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057928_));
    vlSelf->wasmetal_core__DOT___014373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057929_)))));
    vlSelf->wasmetal_core__DOT___019676_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057931_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h98614ec5__0 = (((IData)(vlSelf->wasmetal_core__DOT___057930_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057931_));
    wasmetal_core__DOT___057936_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h91cdf6cd__0))))));
    __VdfgTmp_h8453cf34__0 = (((IData)(vlSelf->wasmetal_core__DOT___057933_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057932_));
    wasmetal_core__DOT___014381_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057932_))));
    vlSelf->wasmetal_core__DOT___071749_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014446_))));
    vlSelf->__VdfgTmp_h51e83899__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___005668_ = (1U & (IData)(
                                                         (0xdf2f20d00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))));
    wasmetal_core__DOT___014454_ = (1U & (0xccaaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x53U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)))))))));
    vlSelf->wasmetal_core__DOT___019668_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014453_)))));
    vlSelf->wasmetal_core__DOT___035645_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b33__05d))));
    vlSelf->wasmetal_core__DOT___057927_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)))))))))));
    wasmetal_core__DOT___058054_ = (1U & (IData)((0xaaaaccccff00f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)))))))))));
    wasmetal_core__DOT___058027_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)))))))))));
    wasmetal_core__DOT___058032_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (0x53U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)))))))))));
    vlSelf->wasmetal_core__DOT___057940_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057926_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x53U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057939_)))))))));
    wasmetal_core__DOT___058023_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058019_)))))))));
    vlSelf->wasmetal_core__DOT___035634_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d))));
    vlSelf->wasmetal_core__DOT___058041_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x53U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7297059c__0))))))));
    wasmetal_core__DOT___058055_ = (1U & (IData)((0xaaaaccccf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058010_)))))))));
    vlSelf->wasmetal_core__DOT___058028_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)))))))))));
    vlSelf->wasmetal_core__DOT___058033_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058019_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___058024_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058010_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hff1952b3__0))))))));
    vlSelf->wasmetal_core__DOT___035633_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d))));
    vlSelf->wasmetal_core__DOT___035622_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d))));
    vlSelf->wasmetal_core__DOT___058059_ = (1U & (0xf0f000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057978_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x53U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014455_)))))));
    vlSelf->wasmetal_core__DOT___057971_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057957_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057956_)))));
    vlSelf->wasmetal_core__DOT___058026_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hed9f0c33__0))))));
    vlSelf->wasmetal_core__DOT___035621_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d))));
    wasmetal_core__DOT___057979_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057969_)))));
    vlSelf->wasmetal_core__DOT___035671_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d))));
    __VdfgTmp_h63472758__0 = (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                               << 3U) | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0));
    vlSelf->wasmetal_core__DOT___035670_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d))));
    wasmetal_core__DOT___057977_ = (1U & (0xf0f000bbU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___057968_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7dbcfedb__0))))));
    vlSelf->wasmetal_core__DOT___035669_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))));
    wasmetal_core__DOT___014440_ = (1U & (0x8000U >> 
                                          ((8U & ((0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0x53U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057962_))))));
    vlSelf->wasmetal_core__DOT___058061_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha3ec838c__0)))))));
    wasmetal_core__DOT___057970_ = (1U & (0xacU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057962_)))));
    vlSelf->wasmetal_core__DOT___035664_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d))));
    vlSelf->wasmetal_core__DOT___035667_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d))));
    vlSelf->wasmetal_core__DOT___035666_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d))));
    vlSelf->wasmetal_core__DOT___035665_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d))));
    vlSelf->wasmetal_core__DOT___035663_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035662_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d))));
    vlSelf->wasmetal_core__DOT___035661_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d))));
    vlSelf->wasmetal_core__DOT___035660_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___035658_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___035657_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___035656_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___035655_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035654_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b41__05d))));
    vlSelf->wasmetal_core__DOT___035652_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b40__05d))));
    vlSelf->wasmetal_core__DOT___035651_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b39__05d))));
    vlSelf->wasmetal_core__DOT___035650_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035649_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b37__05d))));
    vlSelf->wasmetal_core__DOT___035648_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b36__05d))));
    vlSelf->wasmetal_core__DOT___035647_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b35__05d))));
    vlSelf->wasmetal_core__DOT___035646_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b34__05d))));
    vlSelf->wasmetal_core__DOT___035644_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b32__05d))));
    vlSelf->wasmetal_core__DOT___035643_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b31__05d))));
    vlSelf->wasmetal_core__DOT___035641_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b30__05d))));
    vlSelf->wasmetal_core__DOT___035640_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b29__05d))));
    vlSelf->wasmetal_core__DOT___035639_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d))));
    vlSelf->wasmetal_core__DOT___035638_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d))));
    vlSelf->wasmetal_core__DOT___035637_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d))));
    vlSelf->wasmetal_core__DOT___035635_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d))));
    vlSelf->wasmetal_core__DOT___035632_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d))));
    vlSelf->wasmetal_core__DOT___035620_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d))));
    vlSelf->wasmetal_core__DOT___009359_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009358_)))));
    vlSelf->wasmetal_core__DOT___062342_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h890a41f9__0))));
    vlSelf->wasmetal_core__DOT___010627_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h890a41f9__0)))));
    vlSelf->wasmetal_core__DOT___009349_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009348_)))));
    vlSelf->wasmetal_core__DOT___062422_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009757_))));
    vlSelf->wasmetal_core__DOT___055555_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009267_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009757_)))));
    vlSelf->wasmetal_core__DOT___009336_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009335_)))));
    vlSelf->wasmetal_core__DOT___062356_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h792a3800__0))));
    vlSelf->__VdfgTmp_heedd871e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h792a3800__0)));
    vlSelf->wasmetal_core__DOT___062327_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0))));
    vlSelf->wasmetal_core__DOT___056271_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b5a0ff3__0)))));
    vlSelf->wasmetal_core__DOT___062347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32990406__0))));
    vlSelf->wasmetal_core__DOT___056227_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h32990406__0)))));
    vlSelf->wasmetal_core__DOT___062432_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009308_))));
    vlSelf->wasmetal_core__DOT___008808_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009309_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009308_))))));
    vlSelf->wasmetal_core__DOT___062369_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h41d1df16__0))));
    vlSelf->wasmetal_core__DOT___062413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009225_))));
    vlSelf->wasmetal_core__DOT___009364_ = (1U & (2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009363_)))));
    vlSelf->wasmetal_core__DOT___062367_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062324_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he74af19b__0)))));
    vlSelf->wasmetal_core__DOT___013087_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he74af19b__0))))));
    vlSelf->wasmetal_core__DOT___062353_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))));
    vlSelf->wasmetal_core__DOT___009868_ = (1U & (0xfafcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb864fb42__0))))));
    vlSelf->wasmetal_core__DOT___062350_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h27200c45__0))));
    vlSelf->__VdfgTmp_h5cf792c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h27200c45__0)));
    vlSelf->wasmetal_core__DOT___062337_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0))));
    vlSelf->wasmetal_core__DOT___010626_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha3cb0627__0)))));
    vlSelf->wasmetal_core__DOT___009739_ = (1U & (IData)(
                                                         (0xf0f0ff0011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0x555533330f0f00ffULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hae568380__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007866_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007941_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007940_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4bfa77b1__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3aac618__0))))))));
    vlSelf->wasmetal_core__DOT___008547_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055458_))));
    vlSelf->wasmetal_core__DOT___008844_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055546_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055545_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055549_)))))));
    vlSelf->wasmetal_core__DOT___008971_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055353_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha33784b5__0))))));
    wasmetal_core__DOT___056268_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055744_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055742_)))))));
    vlSelf->wasmetal_core__DOT___009001_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055395_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h63940f3b__0))))));
    wasmetal_core__DOT___009024_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055458_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055459_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___009047_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055897_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hddf47e90__0))))));
    vlSelf->wasmetal_core__DOT___055490_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055474_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055472_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055481_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008824_)))))))));
    vlSelf->wasmetal_core__DOT___009698_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb6e33d53__0))))));
    vlSelf->wasmetal_core__DOT___009081_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055550_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055549_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055547_)))))));
    vlSelf->wasmetal_core__DOT___009094_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055817_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h16df2209__0))))));
    wasmetal_core__DOT___009150_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055945_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf618fe17__0)))) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055396_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055395_)))))));
    vlSelf->wasmetal_core__DOT___009107_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055924_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e3623a6__0))))));
    vlSelf->wasmetal_core__DOT___010622_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf1111U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055631_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055630_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa157860__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008920_)))))))));
    wasmetal_core__DOT___009132_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055845_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))));
    vlSelf->wasmetal_core__DOT___008758_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055704_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                               ? 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h04ff5b07__0))
                                                               : 
                                                              (0xa0cU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbb21088e__0))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055701_)))))));
    vlSelf->wasmetal_core__DOT___055717_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051313_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051934_)))))));
    vlSelf->wasmetal_core__DOT___009139_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055354_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055353_)))))));
    vlSelf->wasmetal_core__DOT___055748_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055742_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055391_)))))));
    wasmetal_core__DOT___008882_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055576_))));
    vlSelf->wasmetal_core__DOT___009167_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055884_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h33e7f237__0))))));
    vlSelf->wasmetal_core__DOT___008917_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055626_))));
    vlSelf->wasmetal_core__DOT___009178_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055899_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055897_)))))));
    vlSelf->wasmetal_core__DOT___009197_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055548_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055547_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055530_)))))));
    wasmetal_core__DOT___008972_ = (1U & (0x1111fff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055358_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055357_)))))));
    vlSelf->wasmetal_core__DOT___009002_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055392_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055391_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055389_)))))));
    wasmetal_core__DOT___009025_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055886_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055885_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055884_)))))));
    __VdfgTmp_hcb32e64d__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055452_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                              & (IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd89c9b51__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                   ? 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hfdc2660a__0))
                                                                   : 
                                                                  (0xa0cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h6a6364aa__0))))))))) 
                                     << 1U)) | (1U 
                                                & (0x110fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                ? 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4c1297e6__0))
                                                                : 
                                                               (0xa0cU 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd9a5d9eb__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa0c0000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)))))))));
    vlSelf->wasmetal_core__DOT___009048_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055900_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055899_)))))));
    wasmetal_core__DOT___009699_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055804_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055803_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008856_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___008857_)))))));
    __VdfgTmp_h2c715ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009338_));
    wasmetal_core__DOT___009274_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009353_)))))));
    vlSelf->wasmetal_core__DOT___009095_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055576_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055577_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
    vlSelf->wasmetal_core__DOT___009108_ = (1U & (0xfff01111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009861_)))))));
    wasmetal_core__DOT___009133_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))));
    vlSelf->wasmetal_core__DOT___008757_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055699_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009368_)))))));
    vlSelf->wasmetal_core__DOT___009307_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009381_)))))));
    wasmetal_core__DOT___009140_ = (1U & (0xfff01111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051932_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
    __VdfgTmp_ha336bc52__0 = (((IData)(vlSelf->wasmetal_core__DOT___009391_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009392_));
    wasmetal_core__DOT___009151_ = (1U & (0xf1111U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055947_) 
                                                  << 3U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                      & (IData)(
                                                                (0x555533330f0f00ffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h91b07825__0)))) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    wasmetal_core__DOT___009168_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055887_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055886_)))))));
    __VdfgTmp_h351522cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___009066_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009067_));
    __VdfgTmp_h8170c8be__0 = (((IData)(vlSelf->wasmetal_core__DOT___009067_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009066_));
    wasmetal_core__DOT___009886_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009017_))))));
    __VdfgTmp_hca62a78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009016_));
    wasmetal_core__DOT___009020_ = (1U & (0x1111000fU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h37c9f429__0))))));
    __VdfgTmp_h3ae7f513__0 = (((IData)(vlSelf->wasmetal_core__DOT___008859_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008858_));
    __VdfgTmp_hd28f0b72__0 = (((IData)(vlSelf->wasmetal_core__DOT___009089_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009090_));
    __VdfgTmp_h29905bdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009352_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009351_));
    __VdfgTmp_h0e20e5e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008899_));
    vlSelf->__VdfgTmp_h9f78711b__0 = (((IData)(vlSelf->wasmetal_core__DOT___009123_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009124_));
    __VdfgTmp_h115316d8__0 = ((4U & ((IData)((0xf0f0f050f0f0f03ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___009124_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___009123_)));
    __VdfgTmp_h8ed306e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008929_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008928_));
    wasmetal_core__DOT___009447_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xf5f30000U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009034_))))));
    wasmetal_core__DOT___009243_ = (1U & (0xeeeefff0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0xf5f30000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009031_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009032_)))))));
    vlSelf->wasmetal_core__DOT___061181_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056124_))));
    vlSelf->__VdfgTmp_h2275929a__0 = (((IData)(vlSelf->wasmetal_core__DOT___056124_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    wasmetal_core__DOT___009414_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x35U 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009351_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___009352_)))))))));
    vlSelf->wasmetal_core__DOT___009180_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008835_)))))))));
    vlSelf->wasmetal_core__DOT___056114_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd3ee6e40__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0x33ffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009449_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___008835_))))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009449_)))));
    __VdfgTmp_h2b908e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___008836_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008831_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008832_)));
    wasmetal_core__DOT___009134_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008959_)))))))));
    wasmetal_core__DOT___008941_ = (1U & ((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                               ? (0xfeffU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                               : (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                          & (IData)(
                                                    (0x1111ffff000fffffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h12f500a7__0)))))))));
    vlSelf->wasmetal_core__DOT___009424_ = (1U & (IData)(
                                                         (0x1f1fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x35U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he25b62bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009367_)))))))));
    __VdfgTmp_h44cf3d5c__0 = (((IData)(vlSelf->wasmetal_core__DOT___009367_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009366_));
    vlSelf->wasmetal_core__DOT___019284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056133_))));
    vlSelf->wasmetal_core__DOT___056134_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    __VdfgTmp_hb9a1e459__0 = (((IData)(vlSelf->wasmetal_core__DOT___009218_) 
                               << 2U) | ((2U & ((0xf1111U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055702_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055701_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055700_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055699_)))))) 
                                                << 1U)) 
                                         | (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008958_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h12f500a7__0))))))));
    __VdfgTmp_h3c5f3431__0 = ((2U & ((0xf1111U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051935_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051934_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051933_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051932_)))))) 
                                     << 1U)) | (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009379_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009380_))))))));
    __VdfgTmp_h5c89e2df__0 = (((IData)(vlSelf->wasmetal_core__DOT___009380_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009379_));
    __VdfgTmp_hb4d0429b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008932_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009471_));
    __VdfgTmp_ha28c8f63__0 = (((IData)(vlSelf->wasmetal_core__DOT___009459_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008860_)));
    wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023189_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053611_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       << 2U)) 
                                                   | (3U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___053598_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035966_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035909_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d));
    vlSelf->wasmetal_core__DOT___059355_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hba6f19f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h69683dae__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                ? 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0))))
                                                                : 
                                                               (0xc0c5U 
                                                                >> 
                                                                ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hadae8e7b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h647a213f__0)))))))))));
    vlSelf->wasmetal_core__DOT___059254_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had1ad578__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h42022071__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                   ? 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))
                                                                   : 
                                                                  (0xc0c5U 
                                                                   >> 
                                                                   ((8U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h15403f4f__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h632fa2db__0))))))))))));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017485_ = ((1U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017601_))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013380_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xefef00efU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057719_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017610_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h219534f4__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xefef00efU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017576_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ce496ce__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h310e5162__0)))))))))))));
    vlSelf->wasmetal_core__DOT___017591_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058982_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058981_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058980_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___017601_)) 
                                                                         & (IData)(
                                                                                (0xb0bbb0bb0000b0bbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015828_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017600_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017599_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015681_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___057726_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057711_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xefefef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057725_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017782_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017589_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d32f603__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9110e1f3__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036342_));
    wasmetal_core__DOT___057713_ = (1U & ((IData)((0xef0000ffffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___057697_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057696_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hfacd537a__0))))))) 
                                          & (IData)(
                                                    (0xcc000000f5ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                       << 5U) 
                                                      | (((IData)(wasmetal_core__DOT___013208_) 
                                                          << 4U) 
                                                         | (((IData)(wasmetal_core__DOT___013207_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013205_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___013204_))))))))));
    vlSelf->wasmetal_core__DOT___057985_ = (1U & (0xfefeff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___057950_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))))))));
    vlSelf->wasmetal_core__DOT___058030_ = (1U & (IData)(
                                                         (0xccccaaaaf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x53U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->wasmetal_core__DOT___058035_ = (1U & (IData)(
                                                         (0xff00ccaaaaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058031_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a1a10ae__0)))))));
    vlSelf->__VdfgTmp_ha0dc9087__0 = (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058056_));
    vlSelf->wasmetal_core__DOT___058045_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014358_))));
    vlSelf->wasmetal_core__DOT___058040_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccccc0c0f000aa00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058068_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56cb633a__0))))))));
    vlSelf->wasmetal_core__DOT___057906_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0))))));
    vlSelf->wasmetal_core__DOT___057907_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xa0c0f0f0f0f0f0fULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((0x53U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0)) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057787_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha1f1e621__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xe000000000000000ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((0x53U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((0x53U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb875033__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h04659776__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014358_)))))))))))));
    vlSelf->wasmetal_core__DOT___019685_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hb2511b98__0)))));
    vlSelf->__VdfgTmp_h5970a25a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    vlSelf->__VdfgTmp_he15aac2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014371_));
    if (vlSelf->wasmetal_core__DOT___014357_) {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014461_)));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___014454_)));
    } else {
        vlSelf->wasmetal_core__DOT___019697_ = (1U 
                                                & (IData)(wasmetal_core__DOT___014383_));
        vlSelf->wasmetal_core__DOT___014448_ = (1U 
                                                & (0xf0f0aaccU 
                                                   >> (IData)(__VdfgTmp_hb2511b98__0)));
    }
    vlSelf->wasmetal_core__DOT___019669_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hba696de2__0))));
    vlSelf->__VdfgTmp_hd4b4ff41__0 = (((IData)(wasmetal_core__DOT___014383_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014382_));
    __VdfgTmp_h32a58059__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___019684_))));
    vlSelf->wasmetal_core__DOT___019688_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___014447_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019684_)))));
    vlSelf->wasmetal_core__DOT___014356_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057915_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hba696de2__0))))));
    __VdfgTmp_h836204cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 3U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 2U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019683_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___014447_)))));
    vlSelf->wasmetal_core__DOT___071762_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019683_))))));
    vlSelf->wasmetal_core__DOT___071742_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014447_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___019684_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014446_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019683_)))))))));
    vlSelf->__VdfgTmp_h06185798__0 = (((IData)(wasmetal_core__DOT___019684_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019683_));
    vlSelf->wasmetal_core__DOT___019670_ = (1U & (0xf077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___057915_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9dc510af__0)))));
    wasmetal_core__DOT___014355_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 2U) 
                                           | (IData)(__VdfgTmp_h9dc510af__0))));
    __VdfgTmp_hbb8e97f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014373_));
    __VdfgTmp_hf87abe5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019676_));
    vlSelf->wasmetal_core__DOT___019696_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014382_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    vlSelf->wasmetal_core__DOT___014384_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057936_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h98614ec5__0))))));
    wasmetal_core__DOT___019677_ = (1U & (0x3500U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                               << 2U) 
                                              | (IData)(__VdfgTmp_h8453cf34__0)))));
    wasmetal_core__DOT___014375_ = (1U & (0xf0f0ccaaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019676_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h8453cf34__0))))));
    vlSelf->wasmetal_core__DOT___019758_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___014381_))))));
    __VdfgTmp_h3fbd9b9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    __VdfgTmp_h78b7c78d__0 = (((IData)(wasmetal_core__DOT___057936_) 
                               << 1U) | (IData)(wasmetal_core__DOT___014381_));
    wasmetal_core__DOT___051265_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005668_))));
    vlSelf->__VdfgTmp_h51855551__0 = (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019668_));
    vlSelf->wasmetal_core__DOT___014359_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057927_))))));
    vlSelf->wasmetal_core__DOT___071751_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___014454_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058054_))))));
    vlSelf->wasmetal_core__DOT___019710_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058027_))))));
    vlSelf->wasmetal_core__DOT___019706_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058032_))))));
    vlSelf->wasmetal_core__DOT___014385_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014461_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057940_))))));
    vlSelf->wasmetal_core__DOT___019698_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___058023_))))));
    vlSelf->wasmetal_core__DOT___058050_ = (1U & (0xfafcffffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058042_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058041_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058043_)))))));
    __VdfgTmp_hf3511969__0 = (((IData)(wasmetal_core__DOT___058055_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058054_));
    vlSelf->__VdfgTmp_h17641de8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058028_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058027_));
    vlSelf->__VdfgTmp_hb21fd03f__0 = (((IData)(vlSelf->wasmetal_core__DOT___058033_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058032_));
    vlSelf->__VdfgTmp_h3ea29050__0 = (((IData)(vlSelf->wasmetal_core__DOT___058024_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058023_));
    vlSelf->wasmetal_core__DOT___071750_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058059_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058056_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___058055_)))))))));
    vlSelf->wasmetal_core__DOT___057980_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057979_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057978_)))));
    vlSelf->wasmetal_core__DOT___057972_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h63472758__0))))));
    vlSelf->__VdfgTmp_hfa4aa235__0 = ((2U & ((IData)(
                                                     (0xf4f400ff00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                           << 4U) 
                                                          | (IData)(__VdfgTmp_h63472758__0))))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___057957_)))));
    vlSelf->wasmetal_core__DOT___058060_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057977_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057979_)))));
    vlSelf->wasmetal_core__DOT___057981_ = (1U & (0xaaccf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___057977_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057962_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)))))))));
    vlSelf->wasmetal_core__DOT___058051_ = (1U & ((1U 
                                                   & (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))
                                                   ? (IData)(
                                                             (0xfeccaa00c0c00000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((0x53U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                      << 4U)) 
                                                                  | (((IData)(wasmetal_core__DOT___014440_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xb00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057969_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057963_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1cc8027__0))))))))))))))
                                                   : 
                                                  (0x80U 
                                                   >> 
                                                   ((4U 
                                                     & ((8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                        << 2U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd09be45d__0)))));
    vlSelf->__VdfgTmp_h625062d0__0 = (((IData)(wasmetal_core__DOT___057970_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014456_));
    vlSelf->wasmetal_core__DOT___057975_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057970_))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035620_) 
           | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b1__05d));
    vlSelf->wasmetal_core__DOT___009866_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heedd871e__0))));
    vlSelf->wasmetal_core__DOT___011268_ = (1U & (0xf3f5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cf792c3__0))));
    vlSelf->wasmetal_core__DOT___010624_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))))));
    vlSelf->wasmetal_core__DOT___056269_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056268_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055747_)))))))));
    vlSelf->wasmetal_core__DOT___056160_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009024_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                               & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7737ac68__0)))) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d366d59__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056157_)))))))));
    vlSelf->wasmetal_core__DOT___009724_ = (1U & (IData)(
                                                         (0x55330f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009132_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008938_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3068c687__0))) 
                                                                                << 1U)) 
                                                                              | ((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85f1be24__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___008806_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055717_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___007856_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051315_))))))))))));
    vlSelf->wasmetal_core__DOT___008813_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055747_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055745_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055744_))))))))))));
    vlSelf->wasmetal_core__DOT___009709_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (IData)(
                                                          (0xff55ffccff0fff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009204_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0x1111000fU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))) 
                                                                         << 2U)) 
                                                                     | (((IData)(wasmetal_core__DOT___008882_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))))))
                                                : (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009204_))));
    vlSelf->__VdfgTmp_h9005ae64__0 = (((IData)(vlSelf->wasmetal_core__DOT___008917_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055925_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___055924_)))));
    vlSelf->__VdfgTmp_h51a98e86__0 = (((IData)(wasmetal_core__DOT___008972_) 
                                       << 1U) | (1U 
                                                 & (0x1111000fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd77eff94__0)))))));
    vlSelf->wasmetal_core__DOT___010058_ = (1U & (IData)(
                                                         (0xfef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x305U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009323_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009322_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x33550f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf1111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055457_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055456_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055454_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008548_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008547_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x305U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hcb32e64d__0)))))))))))));
    vlSelf->__VdfgTmp_hc9a6e3e5__0 = (((IData)(wasmetal_core__DOT___009699_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009698_));
    vlSelf->__VdfgTmp_hc1f2eefb__0 = ((2U & ((0x11f0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008858_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___008859_))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009699_));
    vlSelf->wasmetal_core__DOT___009080_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055530_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h2c715ba9__0))))));
    vlSelf->__VdfgTmp_h01bf79b3__0 = (((IData)(wasmetal_core__DOT___009133_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055932_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008959_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008958_)))))));
    vlSelf->wasmetal_core__DOT___061317_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008758_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008757_))))));
    vlSelf->__VdfgTmp_hcfb95646__0 = (((IData)(wasmetal_core__DOT___009140_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008990_)))))));
    vlSelf->__VdfgTmp_hc115db5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (1U 
                                                 & (0x1111fff0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 2U) 
                                                           | (IData)(__VdfgTmp_ha336bc52__0)))))));
    vlSelf->wasmetal_core__DOT___009316_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055390_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055389_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_ha336bc52__0))))));
    vlSelf->__VdfgTmp_hea7ff6d4__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009167_));
    vlSelf->__VdfgTmp_hde712649__0 = (((IData)(vlSelf->wasmetal_core__DOT___009048_) 
                                       << 1U) | (1U 
                                                 & (0x11f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))));
    vlSelf->__VdfgTmp_hc3f8840b__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009877_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h351522cb__0))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009178_));
    vlSelf->__VdfgTmp_h6b05f1fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___009068_) 
                                       << 2U) | (IData)(__VdfgTmp_h8170c8be__0));
    vlSelf->wasmetal_core__DOT___056249_ = (1U & ((IData)(
                                                          (0xf3faf0f0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h243a5897__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xccffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xa3U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055738_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009886_)))))))))));
    wasmetal_core__DOT___009387_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                           ? (0x1111fff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009392_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009391_))))))
                                           : (2U >> 
                                              (1U & 
                                               (0x35U 
                                                >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0))))));
    vlSelf->wasmetal_core__DOT___060834_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060828_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(wasmetal_core__DOT___056268_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009002_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009387_)))))))));
    vlSelf->__VdfgTmp_hb35f8ae6__0 = (((IData)(wasmetal_core__DOT___009387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009386_));
    wasmetal_core__DOT___009152_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                           ? (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009016_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009017_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009163_))))))
                                           : (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0xcaU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)))))));
    vlSelf->wasmetal_core__DOT___011169_ = (1U & ((IData)(
                                                          (0xff0fff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009434_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3eec0328__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009152_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009151_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009150_)))))))))));
    vlSelf->wasmetal_core__DOT___009436_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0x1111f0f000ff00ffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 4U) 
                                                           | ((8U 
                                                               & ((0x35U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hca62a78c__0))))))));
    if (vlSelf->wasmetal_core__DOT___007846_) {
        wasmetal_core__DOT___008884_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008900_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008899_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h900f682d__0))))));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (0xfc55U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf5f30000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009174_)))))));
        wasmetal_core__DOT___009026_ = (1U & (0xeeeefff0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009034_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((0xf5f30000U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h637d46f1__0)) 
                                                            << 2U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009032_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009031_)))))));
        if (vlSelf->wasmetal_core__DOT___007858_) {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hb6a6380e__0)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___009878_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009877_))));
        } else {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008831_))));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h8170c8be__0)));
        }
        wasmetal_core__DOT___009141_ = (1U & (0xfc55U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009146_)))))));
        wasmetal_core__DOT___008973_ = (1U & (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___008991_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd77eff94__0))))));
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (IData)(wasmetal_core__DOT___009020_));
    } else {
        wasmetal_core__DOT___008884_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008901_)));
        vlSelf->wasmetal_core__DOT___009169_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___009175_))));
        wasmetal_core__DOT___009026_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009035_)));
        if (vlSelf->wasmetal_core__DOT___007858_) {
            wasmetal_core__DOT___008826_ = (1U & (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008836_)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009068_)));
        } else {
            wasmetal_core__DOT___008826_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008835_)));
            vlSelf->wasmetal_core__DOT___009872_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008835_)));
        }
        wasmetal_core__DOT___009141_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009147_))));
        wasmetal_core__DOT___008973_ = (1U & (2U >> 
                                              (1U & 
                                               (0xcaU 
                                                >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
        vlSelf->wasmetal_core__DOT___009003_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0xcaU 
                                                       >> (IData)(vlSelf->__VdfgTmp_hecc250a9__0)))));
    }
    vlSelf->__VdfgTmp_hde083b18__0 = ((2U & ((0xeU 
                                              >> (IData)(__VdfgTmp_hca62a78c__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009163_));
    vlSelf->__VdfgTmp_h2fbb9566__0 = (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009020_));
    vlSelf->__VdfgTmp_hc9ff0a4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h3ae7f513__0)));
    vlSelf->__VdfgTmp_h2a535782__0 = ((4U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h8b31618a__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___009197_) 
                                          << 1U) | 
                                         (1U & (0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009338_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hd28f0b72__0))))))));
    vlSelf->__VdfgTmp_hc69ce2b6__0 = (((IData)(wasmetal_core__DOT___009274_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055575_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h29905bdd__0))))));
    vlSelf->__VdfgTmp_hcd20ba92__0 = (((IData)(vlSelf->wasmetal_core__DOT___009095_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h0e20e5e3__0))))));
    vlSelf->__VdfgTmp_hafe541cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009101_) 
                                       << 2U) | (IData)(__VdfgTmp_h0e20e5e3__0));
    if (vlSelf->wasmetal_core__DOT___007846_) {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008857_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008856_))));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2c715ba9__0)));
        } else {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h3ae7f513__0)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hd28f0b72__0)));
        }
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009861_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (0xfef0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | (IData)(__VdfgTmp_h115316d8__0)))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008930_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h8ed306e0__0))))));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009382_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009381_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h5c89e2df__0))))));
        wasmetal_core__DOT___009049_ = (1U & (0xee0fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6b05f1fa__0)))));
        wasmetal_core__DOT___009700_ = (1U & (0xee0fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_hc9ff0a4b__0))));
        wasmetal_core__DOT___009096_ = (1U & (0xfef0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hafe541cd__0)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007858_) {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008861_)));
        } else {
            vlSelf->wasmetal_core__DOT___008845_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
            vlSelf->wasmetal_core__DOT___009334_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___008860_)));
        }
        vlSelf->wasmetal_core__DOT___009853_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009109_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (0xcaU 
                                                          >> (IData)(vlSelf->__VdfgTmp_h7d874977__0))))));
        vlSelf->wasmetal_core__DOT___008921_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008932_)));
        vlSelf->wasmetal_core__DOT___009376_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6b0a05f6__0)))));
        wasmetal_core__DOT___009049_ = (1U & (2U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009069_))));
        wasmetal_core__DOT___009700_ = (1U & (2U >> (IData)(vlSelf->__VdfgTmp_heeb9424e__0)));
        wasmetal_core__DOT___009096_ = (1U & (1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                << 1U) 
                                               | (1U 
                                                  & (0xcaU 
                                                     >> (IData)(vlSelf->__VdfgTmp_ha295f108__0))))));
    }
    vlSelf->__VdfgTmp_hf2dd18ce__0 = (((IData)(wasmetal_core__DOT___008884_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009979_));
    vlSelf->__VdfgTmp_h8f3860df__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc3aac618__0)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h16df2209__0))))))
                                                   : 
                                                  (0xa3U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___008882_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___055818_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___055817_))))))))
                                               : (2U 
                                                  >> (IData)(wasmetal_core__DOT___008884_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_));
    vlSelf->__VdfgTmp_h39a6e1f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009108_) 
                                       << 1U) | (1U 
                                                 & (0x1fU 
                                                    >> 
                                                    ((8U 
                                                      & ((IData)(
                                                                 (0xf0f0f050f0f0f03ULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))));
    vlSelf->__VdfgTmp_h9555d936__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009419_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      & (IData)(
                                                                (0xfefef0f000ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | ((8U 
                                                                         & ((0xcaU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                            << 3U)) 
                                                                        | (IData)(__VdfgTmp_h115316d8__0))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (1U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055921_)))))));
    vlSelf->wasmetal_core__DOT___010650_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                   ? 
                                                  (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1f1fff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(
                                                                                (0xa0000000cULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7d874977__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008929_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009417_))))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009419_))))));
    vlSelf->__VdfgTmp_h6abc2452__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010650_));
    vlSelf->__VdfgTmp_h68679bcf__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055627_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055626_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008931_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___008930_)))))) 
                                             << 1U)) 
                                      | (1U & (0x1fU 
                                               >> (
                                                   (8U 
                                                    & ((IData)(
                                                               (0xa0000000cULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hca6b58ac__0))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h8ed306e0__0))))));
    vlSelf->__VdfgTmp_ha87cf846__0 = (((IData)(wasmetal_core__DOT___009168_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009447_));
    vlSelf->__VdfgTmp_hb37ea0c9__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009396_));
    vlSelf->__VdfgTmp_he49a3989__0 = (((IData)(wasmetal_core__DOT___009026_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009025_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___009024_)));
    vlSelf->__VdfgTmp_h5aef5382__0 = (((IData)(wasmetal_core__DOT___009243_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009025_));
    vlSelf->__VdfgTmp_h3b033656__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055455_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055454_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055453_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___055452_)))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___009243_));
    vlSelf->__VdfgTmp_h78ee927d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2275929a__0))));
    vlSelf->wasmetal_core__DOT___061171_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061165_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xccaaf0f0U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(wasmetal_core__DOT___009274_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1eb86efd__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(wasmetal_core__DOT___009414_)))))))));
    vlSelf->wasmetal_core__DOT___069049_ = (1U & (IData)(
                                                         (0xaaff00f0bbbb3030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012329_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012330_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056114_)))))))));
    vlSelf->wasmetal_core__DOT___061015_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056114_))));
    vlSelf->__VdfgTmp_hab523f16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056114_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___060982_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___008826_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h792a3800__0))))))));
    vlSelf->wasmetal_core__DOT___010069_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xf1111U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055473_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055472_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055470_)))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008824_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055475_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___055474_)))))))))
                                                : (1U 
                                                   >> (IData)(wasmetal_core__DOT___008826_))));
    vlSelf->__VdfgTmp_haa33114f__0 = ((2U & ((0xf1111U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055471_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055470_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb6a6380e__0))))) 
                                             << 1U)) 
                                      | (1U & (0x11f0U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h2b908e25__0)))));
    vlSelf->__VdfgTmp_h05b3fc84__0 = (((IData)(vlSelf->wasmetal_core__DOT___009920_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009134_));
    vlSelf->wasmetal_core__DOT___013181_ = (1U & ((IData)(
                                                          (0xff0fff44ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009422_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h584d0366__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xaaffccfff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(wasmetal_core__DOT___009134_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009133_) 
                                                                              << 1U) 
                                                                             | (IData)(wasmetal_core__DOT___009132_)))))))))));
    vlSelf->__VdfgTmp_he19f1ef5__0 = ((2U & (((~ ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  (0x100U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h08b4abe6__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h315e9115__0)))) 
                                              & (IData)(
                                                        (0xfffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009369_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009368_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h44cf3d5c__0)))))))) 
                                             << 1U)) 
                                      | (1U & (0xf0f03355U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009478_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2fcb0063__0)))))));
    vlSelf->wasmetal_core__DOT___008756_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055709_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h44cf3d5c__0)))));
    vlSelf->__VdfgTmp_haa7da8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056134_));
    vlSelf->wasmetal_core__DOT___061327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xcc55f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_hb9a1e459__0))))))))));
    vlSelf->wasmetal_core__DOT___009711_ = ((IData)(vlSelf->wasmetal_core__DOT___009219_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0x33ffaaff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hb9a1e459__0))))))));
    vlSelf->wasmetal_core__DOT___010035_ = (1U & ((~ (IData)(
                                                             (0xf0f00003355ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009224_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h6b56eebb__0)))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? 
                                                     (0x3f3bU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            & (IData)(
                                                                      (0xffff1111fff0fff0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007857_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007856_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007853_))))))))) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051316_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___051315_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051314_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051313_)))))))))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h3c5f3431__0)))))));
    vlSelf->wasmetal_core__DOT___009306_ = (1U & (0x110fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h5c89e2df__0)))));
    wasmetal_core__DOT___056103_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                               ? (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008990_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008991_)))))
                                               : (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009147_)))
                                           : (2U >> (IData)(vlSelf->wasmetal_core__DOT___009427_))));
    vlSelf->wasmetal_core__DOT___060766_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_heabab031__0)) 
                                                             << 1U)) 
                                                         | (IData)(wasmetal_core__DOT___056103_))))));
    vlSelf->wasmetal_core__DOT___056104_ = (1U & (IData)(
                                                         (0xf000000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heabab031__0))))))));
    vlSelf->wasmetal_core__DOT___055938_ = (1U & ((IData)(
                                                          (0xfff0ff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009427_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf516e409__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009141_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(wasmetal_core__DOT___009140_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009139_)))))))))));
    vlSelf->__VdfgTmp_hb80b9598__0 = (((IData)(wasmetal_core__DOT___008973_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___008972_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___008971_)));
    vlSelf->__VdfgTmp_ha0fb8243__0 = (((IData)(vlSelf->wasmetal_core__DOT___009472_) 
                                       << 2U) | (IData)(__VdfgTmp_hb4d0429b__0));
    vlSelf->wasmetal_core__DOT___009211_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_hb4d0429b__0)))));
    vlSelf->wasmetal_core__DOT___056168_ = (1U & ((IData)(
                                                          (0xffff8000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h4ad8a46a__0)))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? (IData)(
                                                                (0xccffaaff0fff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009762_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_ha28c8f63__0))))))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009762_)))));
    vlSelf->wasmetal_core__DOT___056121_ = (1U & (IData)(
                                                         (0xf00000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                          ? 
                                                                         (0x3355f0f0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 3U) 
                                                                              | (IData)(__VdfgTmp_ha28c8f63__0))))
                                                                          : 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___009460_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h18926335__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127529___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023190_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023187_)))) 
           ^ (((IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127529___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023250_)))));
    vlSelf->wasmetal_core__DOT___023254_ = ((IData)(vlSelf->wasmetal_core__DOT___023190_) 
                                            & (IData)(wasmetal_core__DOT___127529___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035967_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d));
    vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h3d32f603__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___017590_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xefefef00efefefefULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017640_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017652_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h6a49916d__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057713_)))));
    vlSelf->wasmetal_core__DOT___017484_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057713_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057712_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057711_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057710_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015657_)))))))));
    vlSelf->wasmetal_core__DOT___071723_ = (1U & (0xccaafff0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057950_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057971_)))))));
    vlSelf->wasmetal_core__DOT___019690_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014446_)))));
    vlSelf->__VdfgTmp_h2a7b33bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___019669_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014353_));
    vlSelf->wasmetal_core__DOT___035375_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h885d0717__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((1U 
                                                          & (0xdf2f20dU 
                                                             >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0x50003000U 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0x4000U 
                                                           >> (IData)(__VdfgTmp_h32a58059__0)))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                           ? 
                                                          (0xafffcfffU 
                                                           >> (IData)(__VdfgTmp_h836204cc__0))
                                                           : 
                                                          (0xbfffU 
                                                           >> (IData)(__VdfgTmp_h32a58059__0))))))));
    vlSelf->wasmetal_core__DOT___035384_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04659776__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071762_))))));
    vlSelf->__VdfgTmp_h74456d25__0 = (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071742_)));
    vlSelf->wasmetal_core__DOT___035379_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x3500000000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h06185798__0))))))))))));
    vlSelf->wasmetal_core__DOT___071753_ = (1U & (0xf0aaccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___014447_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h06185798__0))))));
    vlSelf->wasmetal_core__DOT___071758_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019670_))));
    vlSelf->wasmetal_core__DOT___071763_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    if (vlSelf->wasmetal_core__DOT___014358_) {
        vlSelf->wasmetal_core__DOT___071735_ = (1U 
                                                & (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___014355_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))));
        vlSelf->wasmetal_core__DOT___071728_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___019690_)
                                                    : 
                                                   (0xbU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___019683_)))));
    } else {
        vlSelf->wasmetal_core__DOT___071735_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014356_))));
        vlSelf->wasmetal_core__DOT___071728_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014360_)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019688_)));
    }
    vlSelf->wasmetal_core__DOT___014363_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014356_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___014355_)))));
    vlSelf->__VdfgTmp_h42589940__0 = (((IData)(vlSelf->wasmetal_core__DOT___019697_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019696_));
    vlSelf->__VdfgTmp_h09be8eb6__0 = (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                     ? 
                                                    (0xf0cc55ffU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___014383_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___014382_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___014381_))))))
                                                     : 
                                                    (0xbU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014384_))))));
    vlSelf->wasmetal_core__DOT___071760_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___019677_)))));
    if (vlSelf->wasmetal_core__DOT___014360_) {
        if (vlSelf->wasmetal_core__DOT___014358_) {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_he15aac2f__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5970a25a__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014385_)));
            vlSelf->wasmetal_core__DOT___071721_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h51855551__0))));
        } else {
            vlSelf->wasmetal_core__DOT___071725_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hf87abe5d__0))));
            vlSelf->wasmetal_core__DOT___013628_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(__VdfgTmp_hbb8e97f6__0))));
            vlSelf->wasmetal_core__DOT___013629_ = 
                (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014385_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))));
            vlSelf->wasmetal_core__DOT___071721_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h2a7b33bb__0))));
        }
        vlSelf->wasmetal_core__DOT___013627_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014359_)) 
                                                   & (0xffcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___071725_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (1U 
                                                      >> (IData)(wasmetal_core__DOT___019677_))));
        vlSelf->wasmetal_core__DOT___013628_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (2U 
                                                      >> (IData)(wasmetal_core__DOT___014375_))));
        vlSelf->wasmetal_core__DOT___013629_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___014384_))
                                                    : 
                                                   (7U 
                                                    >> (IData)(__VdfgTmp_h3fbd9b9f__0))));
        vlSelf->wasmetal_core__DOT___071721_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___014358_)) 
                                                   | (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___019670_))));
        vlSelf->wasmetal_core__DOT___013627_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___014363_));
    }
    vlSelf->__VdfgTmp_hd8777223__0 = (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___019677_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hf87abe5d__0)));
    vlSelf->wasmetal_core__DOT___019724_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___014375_))));
    vlSelf->__VdfgTmp_h929e6874__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___014375_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hbb8e97f6__0))));
    vlSelf->wasmetal_core__DOT___035385_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019758_))))));
    vlSelf->wasmetal_core__DOT___019713_ = (1U & (0xf880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014384_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3fbd9b9f__0))))));
    vlSelf->wasmetal_core__DOT___035372_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f33aa00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019696_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h78b7c78d__0)))))))))))));
    vlSelf->wasmetal_core__DOT___019695_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h78b7c78d__0))));
    vlSelf->wasmetal_core__DOT___035703_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___035702_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd339b1da__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___035712_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058087_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___035711_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    vlSelf->wasmetal_core__DOT___035710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7cb02621__0))));
    vlSelf->wasmetal_core__DOT___035709_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc2af737a__0))));
    vlSelf->wasmetal_core__DOT___035683_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___035682_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___035681_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d)))));
    vlSelf->wasmetal_core__DOT___035680_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___035679_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___035676_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051265_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)))));
    vlSelf->__VdfgTmp_h4eafc8bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014448_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___014447_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014446_)));
    vlSelf->wasmetal_core__DOT___019751_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___014454_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058056_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hf3511969__0))))))));
    vlSelf->wasmetal_core__DOT___058058_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf3511969__0))));
    vlSelf->wasmetal_core__DOT___071737_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014371_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17641de8__0))))))));
    __VdfgTmp_hf656a041__0 = (((IData)(vlSelf->wasmetal_core__DOT___058029_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h17641de8__0));
    wasmetal_core__DOT___071733_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hb21fd03f__0))))))));
    __VdfgTmp_h6ff3b264__0 = (((IData)(vlSelf->wasmetal_core__DOT___058034_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb21fd03f__0));
    wasmetal_core__DOT___019760_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014461_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h3ea29050__0))))))));
    __VdfgTmp_h0c9bc85d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058025_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h3ea29050__0));
    vlSelf->wasmetal_core__DOT___071720_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057980_))))));
    vlSelf->wasmetal_core__DOT___058067_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa4aa235__0)))));
    vlSelf->wasmetal_core__DOT___058064_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058060_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058059_)))));
    vlSelf->wasmetal_core__DOT___071719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057981_))));
    vlSelf->wasmetal_core__DOT___057984_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057980_)))));
    vlSelf->wasmetal_core__DOT___057982_ = (1U & (0xddf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057972_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057971_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h625062d0__0))))));
    vlSelf->wasmetal_core__DOT___057983_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057976_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057975_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfa4aa235__0))))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035631_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b2__05d));
    vlSelf->wasmetal_core__DOT___019261_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009709_))));
    vlSelf->__VdfgTmp_h8b57d846__0 = (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009709_)));
    vlSelf->wasmetal_core__DOT___056242_ = (1U & ((0xf8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___055359_))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xccffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009967_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h51a98e86__0))))))))));
    vlSelf->wasmetal_core__DOT___055363_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055362_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xcc550f0f00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008971_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007854_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055355_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x305U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h51a98e86__0)))))))))));
    vlSelf->wasmetal_core__DOT___056048_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_hcb32e64d__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009322_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009323_))))));
    vlSelf->wasmetal_core__DOT___060893_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056048_))));
    vlSelf->__VdfgTmp_h4cbaee21__0 = (((IData)(vlSelf->wasmetal_core__DOT___056048_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->__VdfgTmp_hef18707b__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010058_));
    vlSelf->wasmetal_core__DOT___009758_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1f2eefb__0))));
    vlSelf->wasmetal_core__DOT___056237_ = ((IData)(vlSelf->wasmetal_core__DOT___009935_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xaaffccff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009267_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc1f2eefb__0)))))))));
    vlSelf->wasmetal_core__DOT___010055_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                      ? (IData)(
                                                                (0xfff3fff5fff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009083_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                                                 ? 
                                                                                (0xfcaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009090_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009089_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008861_))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heeb9424e__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009081_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009080_))))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009083_)))));
    __VdfgTmp_h74811752__0 = (((IData)(vlSelf->wasmetal_core__DOT___009080_) 
                               << 1U) | (1U & (0x110fU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009090_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009089_)))))));
    if (vlSelf->wasmetal_core__DOT___007847_) {
        if (vlSelf->wasmetal_core__DOT___007846_) {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h63940f3b__0)) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___009659_)))));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                  << 2U) | ((2U & (
                                                   (1U 
                                                    >> 
                                                    ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                       & (IData)(
                                                                 (0x555533330f0f00ffULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hae568380__0)))) 
                                                      << 1U) 
                                                     | (1U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                            ? 
                                                           (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hd4d63a34__0))
                                                            : 
                                                           (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2567a16a__0)))))) 
                                                   << 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___009659_)))));
            vlSelf->wasmetal_core__DOT___056111_ = 
                (1U & (IData)(wasmetal_core__DOT___009447_));
            wasmetal_core__DOT___056218_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5e3623a6__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009851_)))));
        } else {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009150_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009001_)));
            vlSelf->wasmetal_core__DOT___056111_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009175_)));
            wasmetal_core__DOT___056218_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9005ae64__0))));
        }
        vlSelf->wasmetal_core__DOT___056052_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008826_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009329_)))))));
        vlSelf->wasmetal_core__DOT___055849_ = (1U 
                                                & (0xaaccf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x1111000fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055843_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h7e1fafed__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055846_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___055845_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___008938_)))))));
        if (vlSelf->wasmetal_core__DOT___007844_) {
            vlSelf->wasmetal_core__DOT___056026_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_hc69ce2b6__0)))));
            vlSelf->wasmetal_core__DOT___056021_ = 
                (1U & (0x35U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_h74811752__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___056026_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009275_))));
            vlSelf->wasmetal_core__DOT___056021_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055538_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h6ca56fa1__0))))))))));
        }
        vlSelf->wasmetal_core__DOT___056074_ = (1U 
                                                & (0x3000aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009376_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009374_)))))));
    } else {
        if (vlSelf->wasmetal_core__DOT___007846_) {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009151_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___009002_)));
        } else {
            vlSelf->wasmetal_core__DOT___011267_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009886_)));
            vlSelf->wasmetal_core__DOT___011286_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___009020_)));
        }
        vlSelf->wasmetal_core__DOT___056111_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009441_)));
        vlSelf->wasmetal_core__DOT___056052_ = (1U 
                                                & (0x100U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009330_))))));
        vlSelf->wasmetal_core__DOT___055849_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___008941_)));
        vlSelf->wasmetal_core__DOT___056026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009276_)))));
        wasmetal_core__DOT___056218_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___009853_)));
        vlSelf->wasmetal_core__DOT___056074_ = (1U 
                                                & (0x100U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009375_))))));
        vlSelf->wasmetal_core__DOT___056021_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009267_)))));
    }
    wasmetal_core__DOT___009725_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h01bf79b3__0)))));
    __VdfgTmp_h6f023739__0 = (((IData)(vlSelf->wasmetal_core__DOT___009951_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h01bf79b3__0));
    vlSelf->wasmetal_core__DOT___061323_ = (1U & (IData)(
                                                         (0xff1100000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061317_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061316_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009424_)))))))));
    vlSelf->__VdfgTmp_hcb50dc13__0 = (((IData)(vlSelf->wasmetal_core__DOT___056227_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0x55330f0f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009139_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha33784b5__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055355_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x305U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcfb95646__0)))))))));
    wasmetal_core__DOT___056270_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_hc115db5a__0)))));
    vlSelf->wasmetal_core__DOT___060927_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hea7ff6d4__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->wasmetal_core__DOT___055954_ = ((IData)(vlSelf->wasmetal_core__DOT___009170_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hea7ff6d4__0)))))))));
    vlSelf->wasmetal_core__DOT___056241_ = ((IData)(vlSelf->wasmetal_core__DOT___009962_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaaff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde712649__0)))))))));
    wasmetal_core__DOT___009716_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hde712649__0))));
    vlSelf->wasmetal_core__DOT___061010_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009181_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009180_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hc3f8840b__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->wasmetal_core__DOT___055964_ = ((IData)(vlSelf->wasmetal_core__DOT___009181_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009180_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc3f8840b__0)))))))));
    vlSelf->wasmetal_core__DOT___009867_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (0x55330f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009178_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hddf47e90__0)) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009870_))))))
                                                : (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009872_))));
    __VdfgTmp_h8f2e1370__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009402_) 
                                          << 2U) | 
                                         ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                            & (IData)(
                                                      (0xeeee0f0fff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6b05f1fa__0))))))) 
                                           << 1U) | 
                                          (1U & (4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___009400_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___007847_)))))));
    vlSelf->__VdfgTmp_h739b8454__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011267_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)));
    vlSelf->wasmetal_core__DOT___060849_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009388_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb35f8ae6__0))))))));
    vlSelf->__VdfgTmp_hedda33f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011169_));
    vlSelf->wasmetal_core__DOT___060853_ = (1U & (IData)(
                                                         (0xf0f50000cc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009436_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3dedcb44__0))))))));
    vlSelf->wasmetal_core__DOT___060846_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060840_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055748_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009316_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xcc55f0f0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h62e050c1__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde083b18__0))))))))))))));
    __VdfgTmp_h0fbdc802__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009316_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_hde083b18__0)));
    vlSelf->__VdfgTmp_h55155be3__0 = ((2U & ((0xcfaf0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___009973_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0x3aU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2fbb9566__0))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009972_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056243_ = ((IData)(vlSelf->wasmetal_core__DOT___009973_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0x33ffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009972_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2fbb9566__0)))))))));
    vlSelf->wasmetal_core__DOT___011249_ = (1U & ((IData)(
                                                          (0xfff0ff88ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009927_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (0xcaU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hfc35c726__0)))))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xaaff33fff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009003_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009002_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009001_)))))))))));
    vlSelf->__VdfgTmp_h2858a73f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010338_)));
    vlSelf->__VdfgTmp_h65ab9fde__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011285_))));
    vlSelf->wasmetal_core__DOT___055410_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    __VdfgTmp_h4bae57cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                               << 2U) | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                   ? 
                                                  (0xee0fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc9ff0a4b__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009091_)))
                                                  : 
                                                 (2U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___009405_))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___056089_)));
    vlSelf->wasmetal_core__DOT___010068_ = (1U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (IData)(
                                                             (0xfff0fff0ffaaffccULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008878_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008877_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbd15e417__0))))))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008810_)) 
                                                     & (IData)(
                                                               (0x33ffaafff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008845_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008844_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055804_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055803_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb6e33d53__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___061051_ = (1U & (IData)(
                                                         (0x335500000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061031_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008844_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009197_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009334_)))))))));
    __VdfgTmp_hce268e24__0 = (((IData)(vlSelf->wasmetal_core__DOT___009334_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009333_));
    vlSelf->wasmetal_core__DOT___061099_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009199_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xccaa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h2a535782__0))))))))));
    vlSelf->wasmetal_core__DOT___009712_ = ((IData)(vlSelf->wasmetal_core__DOT___009199_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0x33ff55fff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2a535782__0))))))));
    vlSelf->wasmetal_core__DOT___056062_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                   ? 
                                                  (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                                   ? 
                                                                  (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009354_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009353_) 
                                                                           << 2U) 
                                                                          | (IData)(__VdfgTmp_h29905bdd__0)))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___008901_))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009346_))))))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___009349_)));
    vlSelf->__VdfgTmp_hc194321c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056062_));
    vlSelf->wasmetal_core__DOT___010625_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc69ce2b6__0)))));
    vlSelf->__VdfgTmp_hd485fb84__0 = ((2U & ((0xcfaf0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___009940_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009939_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056238_ = ((IData)(vlSelf->wasmetal_core__DOT___009940_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009939_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0)))))))));
    vlSelf->wasmetal_core__DOT___009726_ = (1U & ((
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (IData)(
                                                             (0xff33ff55ff0fff0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009275_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h282170d2__0)))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                      ? 
                                                     (0x3fafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009739_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009094_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcd20ba92__0)))))));
    wasmetal_core__DOT___009915_ = ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                    & (IData)((0xfefef0f000ff00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_ha295f108__0)) 
                                                             << 3U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hafe541cd__0)))))));
    if (vlSelf->wasmetal_core__DOT___007844_) {
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (0x3aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009026_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009923_)))))));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009414_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009412_)))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0x1111f0f0ff00ff00ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009069_) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h2b908e25__0)))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009400_)))))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008941_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009984_)))))));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (0x30005U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009424_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009422_)))))));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3c5f3431__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009224_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0xc000aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___008973_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009930_)))))));
        vlSelf->wasmetal_core__DOT___056009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009232_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hc115db5a__0)))))));
        vlSelf->wasmetal_core__DOT___010646_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb35f8ae6__0))))));
        vlSelf->wasmetal_core__DOT___056107_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009436_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009434_)))))));
        vlSelf->wasmetal_core__DOT___009910_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009003_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009927_)))))));
        vlSelf->wasmetal_core__DOT___012944_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008921_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009357_)))))));
        vlSelf->wasmetal_core__DOT___056030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009284_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h68679bcf__0)))))));
        vlSelf->wasmetal_core__DOT___010647_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb37ea0c9__0))))));
        vlSelf->wasmetal_core__DOT___056014_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009245_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3b033656__0)))))));
        vlSelf->wasmetal_core__DOT___056018_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_haa33114f__0)))))));
        vlSelf->wasmetal_core__DOT___009907_ = (1U 
                                                & (0xa000cU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h05b3fc84__0))))));
        vlSelf->wasmetal_core__DOT___056070_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he19f1ef5__0))))));
        vlSelf->wasmetal_core__DOT___056034_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (0x33550f0fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009295_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008757_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___008756_))))))));
        vlSelf->wasmetal_core__DOT___056057_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_hce268e24__0))))));
        vlSelf->wasmetal_core__DOT___009905_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___009915_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009412_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___009908_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009398_));
        vlSelf->wasmetal_core__DOT___010649_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))))))));
        vlSelf->wasmetal_core__DOT___010648_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009402_)))));
        vlSelf->wasmetal_core__DOT___056247_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009364_));
        vlSelf->wasmetal_core__DOT___010651_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009425_));
        vlSelf->wasmetal_core__DOT___056001_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009225_)))));
        vlSelf->wasmetal_core__DOT___009911_ = (1U 
                                                & (0x200U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb294466b__0))))))));
        vlSelf->wasmetal_core__DOT___056009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009233_))));
        vlSelf->wasmetal_core__DOT___010646_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009389_));
        vlSelf->wasmetal_core__DOT___056107_ = (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h20f110d2__0)))));
        vlSelf->wasmetal_core__DOT___009910_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009389_));
        vlSelf->wasmetal_core__DOT___012944_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009359_));
        vlSelf->wasmetal_core__DOT___056030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009285_))));
        vlSelf->wasmetal_core__DOT___010647_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009398_));
        vlSelf->wasmetal_core__DOT___056014_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009246_))));
        vlSelf->wasmetal_core__DOT___056018_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009259_))));
        vlSelf->wasmetal_core__DOT___009907_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009425_));
        vlSelf->wasmetal_core__DOT___056070_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009364_));
        vlSelf->wasmetal_core__DOT___056034_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___009296_))));
        vlSelf->wasmetal_core__DOT___056057_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___009336_));
        vlSelf->wasmetal_core__DOT___009905_ = (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9f90b4cf__0)))));
    }
    vlSelf->wasmetal_core__DOT___061152_ = (1U & (IData)(
                                                         (0xccaa0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009348_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf2dd18ce__0))))))));
    vlSelf->wasmetal_core__DOT___009897_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                         ? 
                                                        (0xcaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf2dd18ce__0)))))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___009349_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                          ? 
                                                         (0xcaU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008845_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___008878_))))))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___009336_))))));
    vlSelf->__VdfgTmp_hbcde5889__0 = (((IData)(vlSelf->wasmetal_core__DOT___055825_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h8f3860df__0)));
    __VdfgTmp_h41d7b504__0 = (((IData)(vlSelf->wasmetal_core__DOT___009357_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009853_));
    vlSelf->__VdfgTmp_h83e89eb3__0 = ((2U & ((0x305U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h39a6e1f8__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xcc550f0f00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009107_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055636_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009851_))))))))));
    __VdfgTmp_h738ad7cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___009945_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h39a6e1f8__0));
    vlSelf->wasmetal_core__DOT___061265_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9555d936__0))));
    vlSelf->wasmetal_core__DOT___009906_ = (1U & (IData)(
                                                         (0x11000000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9555d936__0))))));
    vlSelf->wasmetal_core__DOT___061253_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009110_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009109_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009107_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009108_))))))))))));
    vlSelf->wasmetal_core__DOT___010033_ = ((IData)(vlSelf->wasmetal_core__DOT___009110_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009109_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009108_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009107_))))))))));
    vlSelf->wasmetal_core__DOT___055839_ = (1U & (0x30005U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                                   ? 
                                                                  (0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008920_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hfa157860__0))))))
                                                                   : 
                                                                  (0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___055631_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055630_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008917_)))))
                                                                  : 
                                                                 (2U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___008921_))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055837_)))))));
    vlSelf->wasmetal_core__DOT___010623_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68679bcf__0)))));
    vlSelf->__VdfgTmp_h6c7838ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___009997_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha87cf846__0));
    vlSelf->__VdfgTmp_hf1710ca9__0 = ((2U & ((IData)(
                                                     (0x55cc0f0f00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009167_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008547_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___056157_)))))))) 
                                             << 1U)) 
                                      | (1U & (0x305U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha87cf846__0))))));
    vlSelf->wasmetal_core__DOT___060935_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h52168cf5__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056111_))))));
    vlSelf->wasmetal_core__DOT___010034_ = (1U & (IData)(
                                                         (0xf000000088ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056111_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h52168cf5__0))))))));
    vlSelf->wasmetal_core__DOT___060930_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009397_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb37ea0c9__0))))))));
    vlSelf->wasmetal_core__DOT___060919_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5533f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_he49a3989__0))))))))));
    vlSelf->wasmetal_core__DOT___055888_ = ((IData)(vlSelf->wasmetal_core__DOT___009027_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xaaffccff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he49a3989__0))))))));
    vlSelf->wasmetal_core__DOT___056240_ = (1U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009246_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007844_)))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                                     & (IData)(
                                                               (0xaaff33fff0fff0ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009956_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h5aef5382__0))))))))));
    vlSelf->wasmetal_core__DOT___056161_ = (1U & (0x50cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5aef5382__0)))));
    vlSelf->wasmetal_core__DOT___010042_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                           & (IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008549_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008548_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008547_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055457_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055456_)))))))))))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x305U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3b033656__0)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055464_)))))));
    vlSelf->wasmetal_core__DOT___066788_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061171_))));
    vlSelf->wasmetal_core__DOT___024504_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010649_))));
    vlSelf->wasmetal_core__DOT___010032_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab523f16__0))));
    vlSelf->wasmetal_core__DOT___068251_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057030_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057031_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___060982_)))))));
    vlSelf->__VdfgTmp_h3b65973b__0 = (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056052_));
    vlSelf->wasmetal_core__DOT___055789_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010069_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x305U 
                                                               >> (IData)(vlSelf->__VdfgTmp_heedd871e__0))))))));
    vlSelf->__VdfgTmp_h30bed265__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010648_));
    vlSelf->wasmetal_core__DOT___055489_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haa33114f__0)))));
    vlSelf->wasmetal_core__DOT___061333_ = (1U & (IData)(
                                                         (0xaa00cc00f00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h584d0366__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h05b3fc84__0))))))));
    vlSelf->__VdfgTmp_he07352b1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013181_));
    vlSelf->__VdfgTmp_h69066ba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055849_));
    vlSelf->__VdfgTmp_h284e2fd7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010651_));
    vlSelf->wasmetal_core__DOT___061304_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009363_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he19f1ef5__0))))))));
    vlSelf->wasmetal_core__DOT___010043_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                ? 
                                                               (0xcaU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> 
                                                                         ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                            & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h85f1be24__0)))) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf33cf413__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3068c687__0)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                             & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc229347b__0)))) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc903ec6a__0))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdb0e0153__0))))))))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008757_)))
                                                               : 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                ? 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008758_))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008756_)))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055710_))))));
    vlSelf->wasmetal_core__DOT___061330_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061327_))));
    vlSelf->__VdfgTmp_h04c057c0__0 = ((2U & ((0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009711_));
    vlSelf->wasmetal_core__DOT___056003_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009711_))));
    vlSelf->wasmetal_core__DOT___055239_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010035_))));
    vlSelf->wasmetal_core__DOT___060721_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056001_))));
    vlSelf->__VdfgTmp_h30ace780__0 = (((IData)(vlSelf->wasmetal_core__DOT___056001_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___060759_ = (1U & (IData)(
                                                         (0xf00aa00330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009376_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h41d1df16__0))))))));
    vlSelf->wasmetal_core__DOT___060754_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1111f0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___060752_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf0f03355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009306_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0b92bce8__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055717_))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009307_)))))))))))))));
    vlSelf->__VdfgTmp_h672152ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___009307_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009306_));
    vlSelf->wasmetal_core__DOT___056353_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056351_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056350_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056349_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056178_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056341_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056340_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056179_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))))));
    vlSelf->wasmetal_core__DOT___024507_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056104_))));
    vlSelf->__VdfgTmp_hc7fb8523__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055938_));
    vlSelf->wasmetal_core__DOT___060743_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008975_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x55330f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hb80b9598__0))))))))));
    vlSelf->wasmetal_core__DOT___055869_ = ((IData)(vlSelf->wasmetal_core__DOT___008975_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xaaffccfff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb80b9598__0))))))));
    vlSelf->wasmetal_core__DOT___061264_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009473_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xccaaf0f0U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha0fb8243__0)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056129_ = ((IData)(vlSelf->wasmetal_core__DOT___009473_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0x33ff55ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha0fb8243__0))))))));
    vlSelf->wasmetal_core__DOT___009707_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                ? (IData)(
                                                          (0xff55ffccff0fff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009211_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((0xf1111U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009860_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009861_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9f78711b__0))))) 
                                                                         << 2U)) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9005ae64__0)))))))
                                                : (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009211_))));
    vlSelf->wasmetal_core__DOT___056207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056168_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->__VdfgTmp_ha0636656__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056121_));
    vlSelf->wasmetal_core__DOT___006166_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hde955cd8__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hde955cd8__0)))))));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023192_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023254_));
    vlSelf->wasmetal_core__DOT____Vcellout___128885___O 
        = (((8U & ((0x4bU >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b38__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b37__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128885___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036494_)))));
    vlSelf->wasmetal_core__DOT___036498_ = ((0x4bU 
                                             >> (IData)(vlSelf->__VdfgTmp_h459e7eca__0)) 
                                            & (IData)(wasmetal_core__DOT___128885___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035968_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127496___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h14d2ff5c__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hed92d4b0__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0xf10eU 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha1b196f5__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023013_)))));
    vlSelf->wasmetal_core__DOT___023017_ = ((6U >> (IData)(vlSelf->__VdfgTmp_he7bb7b74__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127496___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h9ce496ce__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017532_ = (1U & (0x7000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017482_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017483_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017484_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017485_))))));
    vlSelf->wasmetal_core__DOT___017533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017485_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017484_))));
    vlSelf->__VdfgTmp_hf1e8a9a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019670_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2a7b33bb__0))));
    vlSelf->wasmetal_core__DOT___035371_ = (1U & (0x40bfbf40U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74456d25__0)))));
    vlSelf->wasmetal_core__DOT___035358_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0fe0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___071751_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019685_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___071749_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071753_)))))))));
    vlSelf->wasmetal_core__DOT___035342_ = (1U & (IData)(
                                                         (0x5530aacfaacf5530ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071753_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff00ff000000f1f1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071751_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071750_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071749_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019685_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___035382_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071758_)))))));
    vlSelf->wasmetal_core__DOT___035386_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_heb875033__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071763_))))));
    vlSelf->wasmetal_core__DOT___035368_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071735_))))));
    vlSelf->wasmetal_core__DOT___035377_ = (1U & (0x40bfbf40U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___014363_)))))));
    vlSelf->wasmetal_core__DOT___058071_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h42589940__0))));
    vlSelf->wasmetal_core__DOT___035367_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09be8eb6__0)))));
    vlSelf->wasmetal_core__DOT___035383_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071760_))))));
    vlSelf->wasmetal_core__DOT___035365_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b33__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071725_))))));
    vlSelf->wasmetal_core__DOT___035357_ = (1U & (0xe01f1fe0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7297059c__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x33550000f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd8777223__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f5f0f300000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019710_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he15aac2f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___071748_ = (1U & (IData)(
                                                         (0x3355f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd8777223__0))))));
    vlSelf->wasmetal_core__DOT___035378_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019724_)))))));
    vlSelf->wasmetal_core__DOT___035361_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013628_))))));
    vlSelf->wasmetal_core__DOT___071739_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h929e6874__0)))));
    vlSelf->wasmetal_core__DOT___035376_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___019713_))))));
    vlSelf->__VdfgTmp_hf6f65f53__0 = (((IData)(vlSelf->wasmetal_core__DOT___019696_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___019695_));
    vlSelf->wasmetal_core__DOT___019734_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019695_))));
    vlSelf->wasmetal_core__DOT___035701_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035676_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005668_)))));
    vlSelf->wasmetal_core__DOT___058065_ = (1U & ((~ 
                                                   (0x3050000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h06185798__0)))))) 
                                                  & (IData)(
                                                            (0xf0fff0ffaaffccffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4eafc8bd__0))))))));
    vlSelf->wasmetal_core__DOT___035359_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b27__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013629_))))));
    vlSelf->wasmetal_core__DOT___035350_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071762_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019751_))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___014358_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___019690_)
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___019688_))))))))));
    vlSelf->__VdfgTmp_hc1e5da71__0 = (((IData)(vlSelf->wasmetal_core__DOT___014448_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058058_));
    vlSelf->wasmetal_core__DOT___019728_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058058_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha0dc9087__0))))));
    vlSelf->wasmetal_core__DOT___035353_ = (1U & (IData)(
                                                         (0x3050cfafcfaf3050ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h105c18f9__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071737_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xccaaf0f0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h929e6874__0)))))))))));
    vlSelf->wasmetal_core__DOT___019744_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014372_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf656a041__0)))))));
    vlSelf->wasmetal_core__DOT___019725_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf656a041__0)))))));
    vlSelf->wasmetal_core__DOT___035352_ = (1U & (IData)(
                                                         (0x3fcfc03aa5555aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xdf2f20dU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((0xcaU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hff1a4828__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___071733_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014356_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51e83899__0))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071763_)))))))));
    vlSelf->wasmetal_core__DOT___019737_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057927_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6ff3b264__0)))))));
    vlSelf->wasmetal_core__DOT___019720_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6ff3b264__0)))))));
    vlSelf->wasmetal_core__DOT___035351_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                   ? 
                                                  (0x35caca35U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 4U)) 
                                                    | ((8U 
                                                        & ((0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                           << 2U) 
                                                          | (((IData)(wasmetal_core__DOT___019760_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xccaaf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014384_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))))))))))
                                                   : 
                                                  (0x96U 
                                                   >> 
                                                   ((4U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((0xcaU 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019758_))))));
    vlSelf->wasmetal_core__DOT___019733_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057940_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h0c9bc85d__0)))))));
    vlSelf->wasmetal_core__DOT___019715_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h0c9bc85d__0)))))));
    vlSelf->wasmetal_core__DOT___035389_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057984_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058034_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(wasmetal_core__DOT___071733_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071735_)))))));
    vlSelf->wasmetal_core__DOT___035388_ = (1U & (0xf10e0ef1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x3500U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057983_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058026_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058025_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(wasmetal_core__DOT___019760_))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h09be8eb6__0))))));
    vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035642_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b3__05d));
    vlSelf->wasmetal_core__DOT___024484_ = (1U & (0x10efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b57d846__0))));
    vlSelf->wasmetal_core__DOT___024493_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4cbaee21__0))));
    vlSelf->wasmetal_core__DOT___061076_ = (1U & (0xcf5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009935_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009758_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009267_)))))));
    vlSelf->__VdfgTmp_h0ff5ee52__0 = (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_));
    vlSelf->wasmetal_core__DOT___010021_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x33550f0f00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009081_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                ((((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT___008639_)) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___007866_)
                                                                                 ? 
                                                                                (0xa0cU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007865_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h422b1f0e__0))))
                                                                                 : 
                                                                                (0xa0cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7c4f884__0)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055546_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055545_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x305U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_h74811752__0)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055555_)))))));
    vlSelf->__VdfgTmp_h885d71fc__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___009952_) 
                                                << 1U) 
                                               | (1U 
                                                  & (IData)(
                                                            (0x33550f0f00000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 3U) 
                                                                    | (IData)(__VdfgTmp_h6f023739__0))))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056239_ = ((IData)(vlSelf->wasmetal_core__DOT___009952_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6f023739__0))))))));
    vlSelf->wasmetal_core__DOT___056228_ = (1U & (IData)(
                                                         (0x1fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hcb50dc13__0)))));
    vlSelf->wasmetal_core__DOT___056352_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056271_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056269_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___056270_)))))));
    vlSelf->wasmetal_core__DOT___010048_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056271_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___056270_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056269_)))))))));
    vlSelf->wasmetal_core__DOT___067677_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067676_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056009_)))))))));
    vlSelf->wasmetal_core__DOT___010653_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056009_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___024481_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055954_))));
    vlSelf->wasmetal_core__DOT___060986_ = (1U & (0xcf5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009962_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___009716_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009258_)))))));
    vlSelf->wasmetal_core__DOT___056213_ = (1U & ((0xf3faU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009258_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xccaaf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((0xcaU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hb1de0cec__0)) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hbf11cfc1__0))))))))))) 
                                                  & (IData)(
                                                            (0xccffaafff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                     << 3U) 
                                                                    | (((IData)(wasmetal_core__DOT___009716_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0x3aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055481_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009870_)))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___009047_))))))))));
    vlSelf->wasmetal_core__DOT___056138_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055938_))))));
    vlSelf->__VdfgTmp_h33ebc999__0 = (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055964_));
    vlSelf->wasmetal_core__DOT___060962_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009867_))));
    vlSelf->wasmetal_core__DOT___061016_ = (1U & (0x1100f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (IData)(__VdfgTmp_h8f2e1370__0))));
    vlSelf->wasmetal_core__DOT___009909_ = (1U & (IData)(
                                                         (0x11000000f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h8f2e1370__0))))));
    vlSelf->wasmetal_core__DOT___061000_ = (1U & (IData)(
                                                         (0xff1fff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009050_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___009049_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009047_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009048_))))))))))));
    vlSelf->wasmetal_core__DOT___010053_ = ((IData)(vlSelf->wasmetal_core__DOT___009050_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___009049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009048_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009047_))))))))));
    vlSelf->__VdfgTmp_h356ffba0__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010646_));
    vlSelf->wasmetal_core__DOT___043264_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedda33f4__0))))))));
    vlSelf->wasmetal_core__DOT___068951_ = (1U & (IData)(
                                                         (0xbbbb3030aaff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011683_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011684_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___060853_)))))))));
    vlSelf->__VdfgTmp_h798d913c__0 = (((IData)(vlSelf->wasmetal_core__DOT___060853_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->__VdfgTmp_h862c0500__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056107_));
    vlSelf->__VdfgTmp_h9fc94011__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 2U) | ((2U 
                                                  & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                       ? 
                                                      (0xf0f0cc55U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 4U) 
                                                        | (IData)(__VdfgTmp_h0fbdc802__0)))
                                                       : 
                                                      (2U 
                                                       >> (IData)(vlSelf->wasmetal_core__DOT___009317_))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056042_)));
    vlSelf->wasmetal_core__DOT___008814_ = (1U & (IData)(
                                                         (0xf0f000033aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h0fbdc802__0))))));
    vlSelf->wasmetal_core__DOT___024472_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011249_))));
    vlSelf->wasmetal_core__DOT___055412_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055410_)))))))));
    vlSelf->wasmetal_core__DOT___061089_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009701_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf5f3f0f000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___009700_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc9a6e3e5__0)))))))))));
    vlSelf->wasmetal_core__DOT___012502_ = ((IData)(vlSelf->wasmetal_core__DOT___009701_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                               & (IData)(
                                                         (0xff00ffafffcfffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___009700_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc9a6e3e5__0)))))))));
    vlSelf->wasmetal_core__DOT___061102_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h4bae57cc__0))));
    vlSelf->wasmetal_core__DOT___009904_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h4bae57cc__0)))));
    vlSelf->wasmetal_core__DOT___056231_ = (1U & (IData)(
                                                         (0xf0f0f0f0f0f0f02ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8f3860df__0))))))));
    vlSelf->__VdfgTmp_h740b215b__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010068_));
    vlSelf->wasmetal_core__DOT___061071_ = (1U & (IData)(
                                                         (0x33550000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009335_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_hce268e24__0))))))));
    vlSelf->__VdfgTmp_h78ac443f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009712_));
    vlSelf->wasmetal_core__DOT___067912_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012602_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056026_))))));
    vlSelf->__VdfgTmp_h9b8fed80__0 = (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___010028_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010626_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010625_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010624_)))))))));
    vlSelf->wasmetal_core__DOT___055607_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010626_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010624_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010625_)))))));
    vlSelf->wasmetal_core__DOT___061182_ = (1U & (IData)(
                                                         (0xf050000cc00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___009915_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h35ac7889__0))))))));
    vlSelf->wasmetal_core__DOT___010054_ = (1U & ((IData)(
                                                          (0xff0fff44ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009412_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h8ad90c85__0))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___008974_)) 
                                                     & (IData)(
                                                               (0xff00ffafffcfffULL 
                                                                >> 
                                                                (((IData)(wasmetal_core__DOT___009096_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009095_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009094_)))))))))));
    vlSelf->wasmetal_core__DOT___068358_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057295_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___061152_))))));
    vlSelf->wasmetal_core__DOT___055826_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbcde5889__0))));
    vlSelf->wasmetal_core__DOT___061213_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056219_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056218_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007844_)))));
    vlSelf->wasmetal_core__DOT___056232_ = (1U & (IData)(
                                                         (0x703300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055849_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056219_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___056218_)))))))));
    vlSelf->wasmetal_core__DOT___061218_ = (1U & (IData)(
                                                         (0xaa330000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009358_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h41d7b504__0))))))));
    vlSelf->wasmetal_core__DOT___009898_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056247_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                          ? 
                                                         (0xa3U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h41d7b504__0)))))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___009359_))))));
    vlSelf->wasmetal_core__DOT___056216_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009728_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009727_)
                                                    ? (IData)(
                                                              (0xeee000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                                    << 4U) 
                                                                   | (((IData)(wasmetal_core__DOT___009725_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009724_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h83e89eb3__0)))))))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h83e89eb3__0)))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___009727_)
                                                    ? 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009726_) 
                                                         << 2U) 
                                                        | (((IData)(wasmetal_core__DOT___009725_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___009724_)))))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___009726_)))));
    vlSelf->wasmetal_core__DOT___061223_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009946_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33550f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h738ad7cb__0))))))))));
    vlSelf->wasmetal_core__DOT___012954_ = ((IData)(vlSelf->wasmetal_core__DOT___009946_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h738ad7cb__0))))))));
}
