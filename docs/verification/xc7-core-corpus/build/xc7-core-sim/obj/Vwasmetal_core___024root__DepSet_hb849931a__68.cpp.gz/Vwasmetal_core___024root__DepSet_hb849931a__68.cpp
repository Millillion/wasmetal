#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__30(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__30\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___019013_;
    wasmetal_core__DOT___019013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022998_;
    wasmetal_core__DOT___022998_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023003_;
    wasmetal_core__DOT___023003_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023007_;
    wasmetal_core__DOT___023007_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023268_;
    wasmetal_core__DOT___023268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023272_;
    wasmetal_core__DOT___023272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023276_;
    wasmetal_core__DOT___023276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024137_;
    wasmetal_core__DOT___024137_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024141_;
    wasmetal_core__DOT___024141_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024145_;
    wasmetal_core__DOT___024145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024268_;
    wasmetal_core__DOT___024268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024272_;
    wasmetal_core__DOT___024272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024276_;
    wasmetal_core__DOT___024276_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024403_;
    wasmetal_core__DOT___024403_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024407_;
    wasmetal_core__DOT___024407_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024411_;
    wasmetal_core__DOT___024411_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024569_;
    wasmetal_core__DOT___024569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024573_;
    wasmetal_core__DOT___024573_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024577_;
    wasmetal_core__DOT___024577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024824_;
    wasmetal_core__DOT___024824_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024828_;
    wasmetal_core__DOT___024828_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024884_;
    wasmetal_core__DOT___024884_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035284_;
    wasmetal_core__DOT___035284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035288_;
    wasmetal_core__DOT___035288_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035336_;
    wasmetal_core__DOT___035336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035455_;
    wasmetal_core__DOT___035455_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035459_;
    wasmetal_core__DOT___035459_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035463_;
    wasmetal_core__DOT___035463_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035571_;
    wasmetal_core__DOT___035571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035575_;
    wasmetal_core__DOT___035575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035580_;
    wasmetal_core__DOT___035580_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036333_;
    wasmetal_core__DOT___036333_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036338_;
    wasmetal_core__DOT___036338_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036373_;
    wasmetal_core__DOT___036373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036374_;
    wasmetal_core__DOT___036374_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036512_;
    wasmetal_core__DOT___036512_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036516_;
    wasmetal_core__DOT___036516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036520_;
    wasmetal_core__DOT___036520_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___038802_;
    wasmetal_core__DOT___038802_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043164_;
    wasmetal_core__DOT___043164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043165_;
    wasmetal_core__DOT___043165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043166_;
    wasmetal_core__DOT___043166_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043168_;
    wasmetal_core__DOT___043168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043173_;
    wasmetal_core__DOT___043173_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043175_;
    wasmetal_core__DOT___043175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043181_;
    wasmetal_core__DOT___043181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043182_;
    wasmetal_core__DOT___043182_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043184_;
    wasmetal_core__DOT___043184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043187_;
    wasmetal_core__DOT___043187_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043188_;
    wasmetal_core__DOT___043188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043189_;
    wasmetal_core__DOT___043189_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043190_;
    wasmetal_core__DOT___043190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043191_;
    wasmetal_core__DOT___043191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043192_;
    wasmetal_core__DOT___043192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043193_;
    wasmetal_core__DOT___043193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043194_;
    wasmetal_core__DOT___043194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043195_;
    wasmetal_core__DOT___043195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043196_;
    wasmetal_core__DOT___043196_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043198_;
    wasmetal_core__DOT___043198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043199_;
    wasmetal_core__DOT___043199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043204_;
    wasmetal_core__DOT___043204_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043205_;
    wasmetal_core__DOT___043205_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043206_;
    wasmetal_core__DOT___043206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043207_;
    wasmetal_core__DOT___043207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043607_;
    wasmetal_core__DOT___043607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043608_;
    wasmetal_core__DOT___043608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043609_;
    wasmetal_core__DOT___043609_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043610_;
    wasmetal_core__DOT___043610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043611_;
    wasmetal_core__DOT___043611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043612_;
    wasmetal_core__DOT___043612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043613_;
    wasmetal_core__DOT___043613_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043614_;
    wasmetal_core__DOT___043614_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043615_;
    wasmetal_core__DOT___043615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043616_;
    wasmetal_core__DOT___043616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043618_;
    wasmetal_core__DOT___043618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043619_;
    wasmetal_core__DOT___043619_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043623_;
    wasmetal_core__DOT___043623_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043624_;
    wasmetal_core__DOT___043624_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043625_;
    wasmetal_core__DOT___043625_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043626_;
    wasmetal_core__DOT___043626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055875_;
    wasmetal_core__DOT___055875_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055880_;
    wasmetal_core__DOT___055880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055893_;
    wasmetal_core__DOT___055893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055905_;
    wasmetal_core__DOT___055905_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055913_;
    wasmetal_core__DOT___055913_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055919_;
    wasmetal_core__DOT___055919_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055930_;
    wasmetal_core__DOT___055930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056020_;
    wasmetal_core__DOT___056020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056051_;
    wasmetal_core__DOT___056051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056260_;
    wasmetal_core__DOT___056260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056261_;
    wasmetal_core__DOT___056261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056907_;
    wasmetal_core__DOT___056907_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070542_;
    wasmetal_core__DOT___070542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070543_;
    wasmetal_core__DOT___070543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070544_;
    wasmetal_core__DOT___070544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070545_;
    wasmetal_core__DOT___070545_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070547_;
    wasmetal_core__DOT___070547_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070548_;
    wasmetal_core__DOT___070548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070549_;
    wasmetal_core__DOT___070549_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070550_;
    wasmetal_core__DOT___070550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070551_;
    wasmetal_core__DOT___070551_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070552_;
    wasmetal_core__DOT___070552_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070553_;
    wasmetal_core__DOT___070553_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070554_;
    wasmetal_core__DOT___070554_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070555_;
    wasmetal_core__DOT___070555_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070556_;
    wasmetal_core__DOT___070556_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070557_;
    wasmetal_core__DOT___070557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070558_;
    wasmetal_core__DOT___070558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070559_;
    wasmetal_core__DOT___070559_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070560_;
    wasmetal_core__DOT___070560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070561_;
    wasmetal_core__DOT___070561_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070562_;
    wasmetal_core__DOT___070562_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070563_;
    wasmetal_core__DOT___070563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070564_;
    wasmetal_core__DOT___070564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d;
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127498___O;
    wasmetal_core__DOT____Vcellout___127498___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127499___O;
    wasmetal_core__DOT____Vcellout___127499___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127500___O;
    wasmetal_core__DOT____Vcellout___127500___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127520___O;
    wasmetal_core__DOT____Vcellout___127520___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127531___O;
    wasmetal_core__DOT____Vcellout___127531___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127532___O;
    wasmetal_core__DOT____Vcellout___127532___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127534___O;
    wasmetal_core__DOT____Vcellout___127534___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128736___O;
    wasmetal_core__DOT____Vcellout___128736___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128854___O;
    wasmetal_core__DOT____Vcellout___128854___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128875___O;
    wasmetal_core__DOT____Vcellout___128875___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ = 0;
    CData/*3:0*/ __VdfgTmp_hf524d067__0;
    __VdfgTmp_hf524d067__0 = 0;
    CData/*2:0*/ __VdfgTmp_h15797db8__0;
    __VdfgTmp_h15797db8__0 = 0;
    CData/*5:0*/ __VdfgTmp_hff06bcdd__0;
    __VdfgTmp_hff06bcdd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4bfbe6f9__0;
    __VdfgTmp_h4bfbe6f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0968f04c__0;
    __VdfgTmp_h0968f04c__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0c3747f4__0;
    __VdfgTmp_h0c3747f4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hffea5a13__0;
    __VdfgTmp_hffea5a13__0 = 0;
    CData/*1:0*/ __VdfgTmp_h01dc1976__0;
    __VdfgTmp_h01dc1976__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb1f3bce1__0;
    __VdfgTmp_hb1f3bce1__0 = 0;
    // Body
    wasmetal_core__DOT___043626_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055942_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055936_)))))))));
    vlSelf->wasmetal_core__DOT___024213_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055929_))));
    wasmetal_core__DOT___055930_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055928_)))))))));
    vlSelf->__VdfgTmp_h89795cd5__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055918_));
    wasmetal_core__DOT___055919_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055918_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055917_)))))))));
    vlSelf->wasmetal_core__DOT___024211_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055911_))));
    wasmetal_core__DOT___055913_ = (1U & (IData)((0xf0f0f0fdULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055912_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055911_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    wasmetal_core__DOT___043625_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055918_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055911_)))))))));
    vlSelf->wasmetal_core__DOT___024210_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055904_))));
    wasmetal_core__DOT___055905_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055903_)))))))));
    vlSelf->__VdfgTmp_h7884e356__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055892_));
    wasmetal_core__DOT___055893_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055892_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055891_)))))))));
    vlSelf->wasmetal_core__DOT___024208_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055879_))));
    wasmetal_core__DOT___055880_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055879_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055878_)))))))));
    wasmetal_core__DOT___043624_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055892_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055879_)))))))));
    vlSelf->wasmetal_core__DOT___024207_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055873_))));
    wasmetal_core__DOT___055875_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019200_)))))))));
    vlSelf->wasmetal_core__DOT___056576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010376_))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___024168_));
        wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010022_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010022_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___024299_));
    }
    vlSelf->wasmetal_core__DOT___056979_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056584_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O))));
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023198_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036503_));
    vlSelf->wasmetal_core__DOT___018538_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0cc55U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f0cc55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))))))))))));
    vlSelf->wasmetal_core__DOT___059619_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0fccaa00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0000ccaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))))))))));
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036325_));
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035672_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035617_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d));
    vlSelf->__VdfgTmp_h4b49f700__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h648a31a7__0)));
    vlSelf->__VdfgTmp_h54798c59__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010378_)));
    wasmetal_core__DOT___043623_ = (1U & (IData)((0xffffffff50f5c0fcULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070541_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___070540_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc8f8c4ae__0))))))));
    vlSelf->wasmetal_core__DOT___043664_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024206_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070540_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)))))));
    wasmetal_core__DOT___070563_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h36d9d765__0))));
    wasmetal_core__DOT___043199_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024256_)))));
    wasmetal_core__DOT___070564_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5b180012__0))))));
    wasmetal_core__DOT___070558_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_heca6da7c__0))));
    wasmetal_core__DOT___070556_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024244_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hed15da38__0))));
    wasmetal_core__DOT___043194_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024244_)))));
    wasmetal_core__DOT___070555_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024244_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h405c6a5f__0))))));
    wasmetal_core__DOT___070554_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024240_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0))));
    wasmetal_core__DOT___043193_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h86dd6551__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024240_)))));
    wasmetal_core__DOT___070553_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024240_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h86dd6551__0))))));
    wasmetal_core__DOT___070552_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024237_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h39529667__0))));
    wasmetal_core__DOT___043192_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he7bd57fe__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h39529667__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024237_)))));
    wasmetal_core__DOT___070551_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h39529667__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024237_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7bd57fe__0))))));
    wasmetal_core__DOT___070548_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024231_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h3d84b27a__0))));
    wasmetal_core__DOT___043190_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h16107c49__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024231_)))));
    wasmetal_core__DOT___070547_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024231_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h16107c49__0))))));
    wasmetal_core__DOT___043165_ = (1U & (IData)((0xfeeaeaeaeaeaeaeaULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055998_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056011_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070524_)))))))));
    wasmetal_core__DOT___043175_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070533_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7b799034__0))));
    wasmetal_core__DOT___070562_ = (1U & (0x4f0000U 
                                          >> ((0x10U 
                                               & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)) 
                                                  << 4U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h5f27695b__0))));
    wasmetal_core__DOT___043198_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))))));
    wasmetal_core__DOT___070561_ = (1U & (0x1000U >> 
                                          ((8U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h546dd473__0)))));
    wasmetal_core__DOT___043173_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070532_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h742ef24c__0))));
    wasmetal_core__DOT___043196_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)))))));
    wasmetal_core__DOT___070559_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                          << 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bc92329__0))))));
    wasmetal_core__DOT___070560_ = (1U & (0x10U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hde45e173__0))));
    wasmetal_core__DOT___043195_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))))));
    wasmetal_core__DOT___070557_ = (1U & (0x1000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134221___B 
        = ((0x3e000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039157_))) 
                        << 0xdU)) | ((0x1000U & ((0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___039157_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))) 
                                                 << 0xcU)) 
                                     | ((0x800U & ((IData)(
                                                           (0xff000e00ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___056132_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdb7f5f3b__0)))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                   << 0xbU)) 
                                        | ((0x400U 
                                            & ((IData)(
                                                       (0xff000e00ffffffffULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056128_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h09d9ebba__0)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                               << 0xaU)) 
                                           | ((0x200U 
                                               & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056123_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 9U)) 
                                              | ((0x100U 
                                                  & ((IData)(
                                                             (0xff000e00ffffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___056118_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2504815__0)))))) 
                                                                               << 1U)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                     << 8U)) 
                                                 | ((0x80U 
                                                     & ((IData)(
                                                                (0xfffffff8ffff8888ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056113_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                        << 7U)) 
                                                    | ((0x40U 
                                                        & ((IData)(
                                                                   (0xfffffff8ffff8888ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056109_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                           << 6U)) 
                                                       | ((0x20U 
                                                           & ((IData)(
                                                                      (0xfffffff8ffff8888ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056106_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                              << 5U)) 
                                                          | ((0x10U 
                                                              & ((IData)(
                                                                         (0xff000e00ffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___056101_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf8fd63d3__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                 << 4U)) 
                                                             | ((8U 
                                                                 & ((IData)(
                                                                            (0xff000e00ffffffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___056098_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5c2c85cd__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                    << 3U)) 
                                                                | ((4U 
                                                                    & ((IData)(
                                                                               (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056095_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he887753f__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056088_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9969096__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_))))))))))))))))))))));
    wasmetal_core__DOT___043166_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070525_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h17e0a363__0))));
    vlSelf->__VdfgTmp_had236f40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056050_));
    wasmetal_core__DOT___056051_ = (1U & (IData)((0xff00fff1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056050_)))))))));
    wasmetal_core__DOT___043609_ = (1U & (0x173f0317U 
                                          >> ((0x10U 
                                               & ((0x4fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056023_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056019_)))))));
    vlSelf->wasmetal_core__DOT___043653_ = (1U & (IData)(
                                                         (0x4fff444f44444444ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x4fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010656_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___024227_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056019_))));
    wasmetal_core__DOT___056020_ = (1U & (IData)((0xff00fff1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056019_)))))))));
    wasmetal_core__DOT___070545_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024225_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h8511e463__0))));
    wasmetal_core__DOT___070544_ = (1U & (8U >> ((2U 
                                                  & ((0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___024225_))));
    wasmetal_core__DOT___043164_ = (1U & (IData)((0xf8ff88f888888888ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009807_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x10U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha26e7faa__0))))))));
    wasmetal_core__DOT___070543_ = (1U & (0x10U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_ha141c58a__0))));
    wasmetal_core__DOT___043187_ = (1U & (0x80U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5230c890__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)))))));
    wasmetal_core__DOT___070542_ = (1U & (0x1000U >> 
                                          ((8U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h5230c890__0)))));
    wasmetal_core__DOT___043184_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070522_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hda2ae911__0))));
    vlSelf->wasmetal_core__DOT___043668_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055951_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055960_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___011020_))))))))))));
    wasmetal_core__DOT___043207_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024216_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024217_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)))))));
    vlSelf->wasmetal_core__DOT___043667_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024215_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055936_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))))))))));
    wasmetal_core__DOT___043206_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024213_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024214_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024215_)))));
    wasmetal_core__DOT___043182_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070520_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h89795cd5__0))));
    vlSelf->wasmetal_core__DOT___043666_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055911_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010054_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d))))))))))));
    wasmetal_core__DOT___043205_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024210_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024211_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)))))));
    wasmetal_core__DOT___043181_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070519_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7884e356__0))));
    vlSelf->wasmetal_core__DOT___043665_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055879_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134223___B 
        = ((0x10000U & ((IData)((0xff000e00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___056013_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf1U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056011_))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xff000e00ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___056007_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha16f0aa3__0)))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((0xffff88f8U 
                                            >> (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___056000_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((0xffff88f8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055993_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((0xffff88f8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055982_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((0xffff88f8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055975_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055969_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055961_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055952_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffff8ffff8888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055943_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffff8ffff8888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055937_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055930_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055919_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((0xffff88f8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055913_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055905_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055893_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055880_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))))))))))))))))))));
    wasmetal_core__DOT___043204_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024207_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024208_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134220___B 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                 << 4U) 
                                                | (((IData)(wasmetal_core__DOT___055875_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffffffffff010ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055867_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xcc550f0fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfadc0d9c__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffff8ffff8888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0xfc00aaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___019266_)))))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffff8ffff8888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((0xfc00aaU 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019255_)))))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffff8ffff8888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xfa00ccU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffff8ffff8888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xfc00aaU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019243_)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xfc00aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055777_)))))) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((0xfc00aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055759_)))))) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((0xffff88f8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055735_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xffff88f8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055713_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xf888fffff888f888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055662_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001475_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055608_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055606_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001443_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055559_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055558_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffff888ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055511_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xffffffffffff8f88ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055469_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f3355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055467_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055467_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055412_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x4fU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x777U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0f5533U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055363_)))))))))))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___010028_) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033411_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033411_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__));
    }
    wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127531___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023197_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023196_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023259_)))));
    vlSelf->wasmetal_core__DOT___023263_ = ((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                            & (IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
           & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128728___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035369_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (1U & 
                                               (0xdf2f20dU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))));
    vlSelf->wasmetal_core__DOT___035315_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035369_)
                                                   ? (IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0))));
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035673_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d));
    vlSelf->wasmetal_core__DOT___012472_ = (1U & (0xbe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056601_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54798c59__0))));
    vlSelf->wasmetal_core__DOT___012015_ = (1U & (0xbe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54798c59__0))));
    wasmetal_core__DOT___043619_ = (1U & (IData)((0xffffffffffffb000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070564_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070563_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056135_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0))))))));
    vlSelf->wasmetal_core__DOT___043662_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070563_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070564_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d))))));
    wasmetal_core__DOT___043614_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070556_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070555_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043658_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070556_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070555_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d))))));
    wasmetal_core__DOT___043613_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070554_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070553_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043657_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070554_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070553_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d))))));
    wasmetal_core__DOT___043612_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070552_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070551_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043656_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070552_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070551_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d))))));
    wasmetal_core__DOT___043610_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070548_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070547_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043654_ = (1U & (0xffffff10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070547_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___070548_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)))))));
    wasmetal_core__DOT___043618_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070562_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070561_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056122_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d))))));
    vlSelf->wasmetal_core__DOT___043661_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070562_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070561_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d))))));
    wasmetal_core__DOT___043616_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070560_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070559_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056108_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d))))));
    vlSelf->wasmetal_core__DOT___043660_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070560_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070559_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d))))));
    wasmetal_core__DOT___043615_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070558_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070557_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043659_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070558_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070557_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))));
    wasmetal_core__DOT___043168_ = (1U & (IData)((0xf8ff88f888888888ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056044_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xb0U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_had236f40__0))))))));
    wasmetal_core__DOT___043191_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h19ff1492__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_had236f40__0)))))));
    wasmetal_core__DOT___070549_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_had236f40__0)) 
                                                          << 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h19ff1492__0))))));
    wasmetal_core__DOT___070550_ = (1U & (0x4f0000U 
                                          >> ((0x10U 
                                               & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_had236f40__0)) 
                                                  << 4U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc3266ade__0))));
    wasmetal_core__DOT___043189_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024227_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134224___B 
        = ((0x10000U & ((IData)((0xff000e00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___056085_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00ff4fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h7fe84144__0)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xff000e00ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___056082_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3971bdc1__0)))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xff000e00ffffffffULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___056077_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xff00ff4fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h373f306d__0)))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xff000e00ffffffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___056073_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2f82e844__0)))))) 
                                                                          << 1U)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xff000e00ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___056069_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc699f06e__0)))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xff000e00ffffffffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___056065_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86e2747e__0)))))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xff000e00ffffffffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___056060_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb788ecb2__0)))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xff000e00ffffffffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056055_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h03f01150__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                             << 4U) 
                                                                            | (((IData)(wasmetal_core__DOT___056051_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xff000e00ffffffffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___056047_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8c718ae9__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xff000e00ffffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___056041_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3300e967__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056037_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde8b5012__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056033_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8684912__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056029_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27272852__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056025_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056023_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___056020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056017_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd2c8a10e__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___043652_ = (1U & (IData)(
                                                         (0xffffffff40ff4040ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070545_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfef0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)))))))))));
    wasmetal_core__DOT___043608_ = (1U & (IData)((0xffffffff101010ffULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070545_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056011_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___070544_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055998_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d)))))))));
    wasmetal_core__DOT___043188_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___024223_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___070544_))));
    wasmetal_core__DOT___043607_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070543_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070542_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055991_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d))))));
    vlSelf->wasmetal_core__DOT___043651_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070543_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070542_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x10U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010972_))))));
    if (vlSelf->wasmetal_core__DOT___010023_) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033416_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033416_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127719___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)))) 
           ^ (((IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___024855_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___005913_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))));
    vlSelf->wasmetal_core__DOT___005847_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0)))));
    vlSelf->wasmetal_core__DOT___005779_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))));
    vlSelf->wasmetal_core__DOT___005778_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023200_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023263_));
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127498___O = (
                                                   ((8U 
                                                     & ((0xf10eU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022990_)))));
    vlSelf->wasmetal_core__DOT___022994_ = ((0xf10eU 
                                             >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                            & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035380_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035315_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128748___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035486_)))));
    vlSelf->wasmetal_core__DOT___035505_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035621_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d));
    wasmetal_core__DOT___043611_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070550_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070549_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056050_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___043655_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070550_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070549_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d))))));
    if (vlSelf->wasmetal_core__DOT___043258_) {
        if (vlSelf->wasmetal_core__DOT___043257_) {
            if (vlSelf->wasmetal_core__DOT___043256_) {
                if (vlSelf->wasmetal_core__DOT___043255_) {
                    if (vlSelf->wasmetal_core__DOT___043254_) {
                        if (vlSelf->wasmetal_core__DOT___010061_) {
                            if (vlSelf->wasmetal_core__DOT___010063_) {
                                if (vlSelf->wasmetal_core__DOT___043253_) {
                                    if (vlSelf->wasmetal_core__DOT___043252_) {
                                        if (vlSelf->wasmetal_core__DOT___043251_) {
                                            if (vlSelf->wasmetal_core__DOT___043250_) {
                                                if (
                                                    (1U 
                                                     & (0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2237a749__0)))) {
                                                    if (vlSelf->wasmetal_core__DOT___043264_) {
                                                        if (vlSelf->wasmetal_core__DOT___043263_) {
                                                            if (vlSelf->wasmetal_core__DOT___043262_) {
                                                                if (vlSelf->wasmetal_core__DOT___043261_) {
                                                                    if (vlSelf->wasmetal_core__DOT___043260_) {
                                                                        if (vlSelf->wasmetal_core__DOT___043259_) {
                                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                                = vlSelf->wasmetal_core__DOT___043156_;
                                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                                = vlSelf->wasmetal_core__DOT___043301_;
                                                                            wasmetal_core__DOT___038802_ 
                                                                                = vlSelf->wasmetal_core__DOT___043599_;
                                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                                = vlSelf->wasmetal_core__DOT___043690_;
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                                = vlSelf->wasmetal_core__DOT___043241_;
                                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                                = vlSelf->wasmetal_core__DOT___043241_;
                                                                            wasmetal_core__DOT___038802_ 
                                                                                = vlSelf->wasmetal_core__DOT___043663_;
                                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                                = vlSelf->wasmetal_core__DOT___043663_;
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___038804_ 
                                                                            = vlSelf->wasmetal_core__DOT___043242_;
                                                                        vlSelf->wasmetal_core__DOT___011171_ 
                                                                            = vlSelf->wasmetal_core__DOT___043242_;
                                                                        wasmetal_core__DOT___038802_ 
                                                                            = vlSelf->wasmetal_core__DOT___043664_;
                                                                        vlSelf->wasmetal_core__DOT___011068_ 
                                                                            = vlSelf->wasmetal_core__DOT___043664_;
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___038804_ 
                                                                        = vlSelf->wasmetal_core__DOT___043243_;
                                                                    vlSelf->wasmetal_core__DOT___011171_ 
                                                                        = vlSelf->wasmetal_core__DOT___043243_;
                                                                    wasmetal_core__DOT___038802_ 
                                                                        = vlSelf->wasmetal_core__DOT___043665_;
                                                                    vlSelf->wasmetal_core__DOT___011068_ 
                                                                        = vlSelf->wasmetal_core__DOT___043665_;
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___038804_ 
                                                                    = vlSelf->wasmetal_core__DOT___043244_;
                                                                vlSelf->wasmetal_core__DOT___011171_ 
                                                                    = vlSelf->wasmetal_core__DOT___043244_;
                                                                wasmetal_core__DOT___038802_ 
                                                                    = vlSelf->wasmetal_core__DOT___043666_;
                                                                vlSelf->wasmetal_core__DOT___011068_ 
                                                                    = vlSelf->wasmetal_core__DOT___043666_;
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                = vlSelf->wasmetal_core__DOT___043245_;
                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                = vlSelf->wasmetal_core__DOT___043245_;
                                                            wasmetal_core__DOT___038802_ 
                                                                = vlSelf->wasmetal_core__DOT___043667_;
                                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                                = vlSelf->wasmetal_core__DOT___043667_;
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___038804_ 
                                                            = vlSelf->wasmetal_core__DOT___043246_;
                                                        vlSelf->wasmetal_core__DOT___011171_ 
                                                            = vlSelf->wasmetal_core__DOT___043246_;
                                                        wasmetal_core__DOT___038802_ 
                                                            = vlSelf->wasmetal_core__DOT___043668_;
                                                        vlSelf->wasmetal_core__DOT___011068_ 
                                                            = vlSelf->wasmetal_core__DOT___043668_;
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___038804_ 
                                                        = vlSelf->wasmetal_core__DOT___043229_;
                                                    vlSelf->wasmetal_core__DOT___011171_ 
                                                        = vlSelf->wasmetal_core__DOT___043229_;
                                                    wasmetal_core__DOT___038802_ 
                                                        = vlSelf->wasmetal_core__DOT___043651_;
                                                    vlSelf->wasmetal_core__DOT___011068_ 
                                                        = vlSelf->wasmetal_core__DOT___043651_;
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___038804_ 
                                                    = vlSelf->wasmetal_core__DOT___043230_;
                                                vlSelf->wasmetal_core__DOT___011171_ 
                                                    = vlSelf->wasmetal_core__DOT___043230_;
                                                wasmetal_core__DOT___038802_ 
                                                    = vlSelf->wasmetal_core__DOT___043652_;
                                                vlSelf->wasmetal_core__DOT___011068_ 
                                                    = vlSelf->wasmetal_core__DOT___043652_;
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                = vlSelf->wasmetal_core__DOT___043231_;
                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                = vlSelf->wasmetal_core__DOT___043231_;
                                            wasmetal_core__DOT___038802_ 
                                                = vlSelf->wasmetal_core__DOT___043653_;
                                            vlSelf->wasmetal_core__DOT___011068_ 
                                                = vlSelf->wasmetal_core__DOT___043653_;
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___038804_ 
                                            = vlSelf->wasmetal_core__DOT___043232_;
                                        vlSelf->wasmetal_core__DOT___011171_ 
                                            = vlSelf->wasmetal_core__DOT___043232_;
                                        wasmetal_core__DOT___038802_ 
                                            = vlSelf->wasmetal_core__DOT___043654_;
                                        vlSelf->wasmetal_core__DOT___011068_ 
                                            = vlSelf->wasmetal_core__DOT___043654_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___038804_ 
                                        = vlSelf->wasmetal_core__DOT___043233_;
                                    vlSelf->wasmetal_core__DOT___011171_ 
                                        = vlSelf->wasmetal_core__DOT___043233_;
                                    wasmetal_core__DOT___038802_ 
                                        = vlSelf->wasmetal_core__DOT___043655_;
                                    vlSelf->wasmetal_core__DOT___011068_ 
                                        = vlSelf->wasmetal_core__DOT___043655_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___038804_ 
                                    = vlSelf->wasmetal_core__DOT___043234_;
                                vlSelf->wasmetal_core__DOT___011171_ 
                                    = vlSelf->wasmetal_core__DOT___043234_;
                                wasmetal_core__DOT___038802_ 
                                    = vlSelf->wasmetal_core__DOT___043656_;
                                vlSelf->wasmetal_core__DOT___011068_ 
                                    = vlSelf->wasmetal_core__DOT___043656_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___038804_ 
                                = vlSelf->wasmetal_core__DOT___043235_;
                            vlSelf->wasmetal_core__DOT___011171_ 
                                = vlSelf->wasmetal_core__DOT___043235_;
                            wasmetal_core__DOT___038802_ 
                                = vlSelf->wasmetal_core__DOT___043657_;
                            vlSelf->wasmetal_core__DOT___011068_ 
                                = vlSelf->wasmetal_core__DOT___043657_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___038804_ 
                            = vlSelf->wasmetal_core__DOT___043236_;
                        vlSelf->wasmetal_core__DOT___011171_ 
                            = vlSelf->wasmetal_core__DOT___043236_;
                        wasmetal_core__DOT___038802_ 
                            = vlSelf->wasmetal_core__DOT___043658_;
                        vlSelf->wasmetal_core__DOT___011068_ 
                            = vlSelf->wasmetal_core__DOT___043658_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___038804_ 
                        = vlSelf->wasmetal_core__DOT___043237_;
                    vlSelf->wasmetal_core__DOT___011171_ 
                        = vlSelf->wasmetal_core__DOT___043237_;
                    wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043659_;
                    vlSelf->wasmetal_core__DOT___011068_ 
                        = vlSelf->wasmetal_core__DOT___043659_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___038804_ 
                    = vlSelf->wasmetal_core__DOT___043238_;
                vlSelf->wasmetal_core__DOT___011171_ 
                    = vlSelf->wasmetal_core__DOT___043238_;
                wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043660_;
                vlSelf->wasmetal_core__DOT___011068_ 
                    = vlSelf->wasmetal_core__DOT___043660_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___038804_ = vlSelf->wasmetal_core__DOT___043239_;
            vlSelf->wasmetal_core__DOT___011171_ = vlSelf->wasmetal_core__DOT___043239_;
            wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043661_;
            vlSelf->wasmetal_core__DOT___011068_ = vlSelf->wasmetal_core__DOT___043661_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___038804_ = vlSelf->wasmetal_core__DOT___043240_;
        vlSelf->wasmetal_core__DOT___011171_ = vlSelf->wasmetal_core__DOT___043240_;
        wasmetal_core__DOT___038802_ = vlSelf->wasmetal_core__DOT___043662_;
        vlSelf->wasmetal_core__DOT___011068_ = vlSelf->wasmetal_core__DOT___043662_;
    }
    if (wasmetal_core__DOT___043199_) {
        if (wasmetal_core__DOT___043198_) {
            if (wasmetal_core__DOT___043196_) {
                if (wasmetal_core__DOT___043195_) {
                    if (wasmetal_core__DOT___043194_) {
                        if (wasmetal_core__DOT___043193_) {
                            if (wasmetal_core__DOT___043192_) {
                                if (wasmetal_core__DOT___043191_) {
                                    if (wasmetal_core__DOT___043190_) {
                                        if (wasmetal_core__DOT___043189_) {
                                            if (wasmetal_core__DOT___043188_) {
                                                if (wasmetal_core__DOT___043187_) {
                                                    if (wasmetal_core__DOT___043207_) {
                                                        if (wasmetal_core__DOT___043206_) {
                                                            if (wasmetal_core__DOT___043205_) {
                                                                if (wasmetal_core__DOT___043204_) {
                                                                    if (vlSelf->wasmetal_core__DOT___043203_) {
                                                                        if (vlSelf->wasmetal_core__DOT___043202_) {
                                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                                = vlSelf->wasmetal_core__DOT___043156_;
                                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                                = vlSelf->wasmetal_core__DOT___043301_;
                                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                                = vlSelf->wasmetal_core__DOT___043599_;
                                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                                = vlSelf->wasmetal_core__DOT___043690_;
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                                = vlSelf->wasmetal_core__DOT___043179_;
                                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                                = vlSelf->wasmetal_core__DOT___043179_;
                                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                                = vlSelf->wasmetal_core__DOT___043622_;
                                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                                = vlSelf->wasmetal_core__DOT___043622_;
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___038803_ 
                                                                            = vlSelf->wasmetal_core__DOT___043180_;
                                                                        vlSelf->wasmetal_core__DOT___011170_ 
                                                                            = vlSelf->wasmetal_core__DOT___043180_;
                                                                        vlSelf->wasmetal_core__DOT___038801_ 
                                                                            = wasmetal_core__DOT___043623_;
                                                                        vlSelf->wasmetal_core__DOT___011246_ 
                                                                            = wasmetal_core__DOT___043623_;
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___038803_ 
                                                                        = wasmetal_core__DOT___043181_;
                                                                    vlSelf->wasmetal_core__DOT___011170_ 
                                                                        = wasmetal_core__DOT___043181_;
                                                                    vlSelf->wasmetal_core__DOT___038801_ 
                                                                        = wasmetal_core__DOT___043624_;
                                                                    vlSelf->wasmetal_core__DOT___011246_ 
                                                                        = wasmetal_core__DOT___043624_;
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___038803_ 
                                                                    = wasmetal_core__DOT___043182_;
                                                                vlSelf->wasmetal_core__DOT___011170_ 
                                                                    = wasmetal_core__DOT___043182_;
                                                                vlSelf->wasmetal_core__DOT___038801_ 
                                                                    = wasmetal_core__DOT___043625_;
                                                                vlSelf->wasmetal_core__DOT___011246_ 
                                                                    = wasmetal_core__DOT___043625_;
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                = vlSelf->wasmetal_core__DOT___043183_;
                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                = vlSelf->wasmetal_core__DOT___043183_;
                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                = wasmetal_core__DOT___043626_;
                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                = wasmetal_core__DOT___043626_;
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___038803_ 
                                                            = wasmetal_core__DOT___043184_;
                                                        vlSelf->wasmetal_core__DOT___011170_ 
                                                            = wasmetal_core__DOT___043184_;
                                                        vlSelf->wasmetal_core__DOT___038801_ 
                                                            = vlSelf->wasmetal_core__DOT___043627_;
                                                        vlSelf->wasmetal_core__DOT___011246_ 
                                                            = vlSelf->wasmetal_core__DOT___043627_;
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___038803_ 
                                                        = wasmetal_core__DOT___043164_;
                                                    vlSelf->wasmetal_core__DOT___011170_ 
                                                        = wasmetal_core__DOT___043164_;
                                                    vlSelf->wasmetal_core__DOT___038801_ 
                                                        = wasmetal_core__DOT___043607_;
                                                    vlSelf->wasmetal_core__DOT___011246_ 
                                                        = wasmetal_core__DOT___043607_;
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___038803_ 
                                                    = wasmetal_core__DOT___043165_;
                                                vlSelf->wasmetal_core__DOT___011170_ 
                                                    = wasmetal_core__DOT___043165_;
                                                vlSelf->wasmetal_core__DOT___038801_ 
                                                    = wasmetal_core__DOT___043608_;
                                                vlSelf->wasmetal_core__DOT___011246_ 
                                                    = wasmetal_core__DOT___043608_;
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                = wasmetal_core__DOT___043166_;
                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                = wasmetal_core__DOT___043166_;
                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                = wasmetal_core__DOT___043609_;
                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                = wasmetal_core__DOT___043609_;
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___038803_ 
                                            = vlSelf->wasmetal_core__DOT___043167_;
                                        vlSelf->wasmetal_core__DOT___011170_ 
                                            = vlSelf->wasmetal_core__DOT___043167_;
                                        vlSelf->wasmetal_core__DOT___038801_ 
                                            = wasmetal_core__DOT___043610_;
                                        vlSelf->wasmetal_core__DOT___011246_ 
                                            = wasmetal_core__DOT___043610_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___038803_ 
                                        = wasmetal_core__DOT___043168_;
                                    vlSelf->wasmetal_core__DOT___011170_ 
                                        = wasmetal_core__DOT___043168_;
                                    vlSelf->wasmetal_core__DOT___038801_ 
                                        = wasmetal_core__DOT___043611_;
                                    vlSelf->wasmetal_core__DOT___011246_ 
                                        = wasmetal_core__DOT___043611_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___038803_ 
                                    = vlSelf->wasmetal_core__DOT___043169_;
                                vlSelf->wasmetal_core__DOT___011170_ 
                                    = vlSelf->wasmetal_core__DOT___043169_;
                                vlSelf->wasmetal_core__DOT___038801_ 
                                    = wasmetal_core__DOT___043612_;
                                vlSelf->wasmetal_core__DOT___011246_ 
                                    = wasmetal_core__DOT___043612_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___038803_ 
                                = vlSelf->wasmetal_core__DOT___043170_;
                            vlSelf->wasmetal_core__DOT___011170_ 
                                = vlSelf->wasmetal_core__DOT___043170_;
                            vlSelf->wasmetal_core__DOT___038801_ 
                                = wasmetal_core__DOT___043613_;
                            vlSelf->wasmetal_core__DOT___011246_ 
                                = wasmetal_core__DOT___043613_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___038803_ 
                            = vlSelf->wasmetal_core__DOT___043171_;
                        vlSelf->wasmetal_core__DOT___011170_ 
                            = vlSelf->wasmetal_core__DOT___043171_;
                        vlSelf->wasmetal_core__DOT___038801_ 
                            = wasmetal_core__DOT___043614_;
                        vlSelf->wasmetal_core__DOT___011246_ 
                            = wasmetal_core__DOT___043614_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___038803_ 
                        = vlSelf->wasmetal_core__DOT___043172_;
                    vlSelf->wasmetal_core__DOT___011170_ 
                        = vlSelf->wasmetal_core__DOT___043172_;
                    vlSelf->wasmetal_core__DOT___038801_ 
                        = wasmetal_core__DOT___043615_;
                    vlSelf->wasmetal_core__DOT___011246_ 
                        = wasmetal_core__DOT___043615_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___038803_ 
                    = wasmetal_core__DOT___043173_;
                vlSelf->wasmetal_core__DOT___011170_ 
                    = wasmetal_core__DOT___043173_;
                vlSelf->wasmetal_core__DOT___038801_ 
                    = wasmetal_core__DOT___043616_;
                vlSelf->wasmetal_core__DOT___011246_ 
                    = wasmetal_core__DOT___043616_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___038803_ = wasmetal_core__DOT___043175_;
            vlSelf->wasmetal_core__DOT___011170_ = wasmetal_core__DOT___043175_;
            vlSelf->wasmetal_core__DOT___038801_ = wasmetal_core__DOT___043618_;
            vlSelf->wasmetal_core__DOT___011246_ = wasmetal_core__DOT___043618_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___038803_ = vlSelf->wasmetal_core__DOT___043176_;
        vlSelf->wasmetal_core__DOT___011170_ = vlSelf->wasmetal_core__DOT___043176_;
        vlSelf->wasmetal_core__DOT___038801_ = wasmetal_core__DOT___043619_;
        vlSelf->wasmetal_core__DOT___011246_ = wasmetal_core__DOT___043619_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127644___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)) 
                   << 3U)) | (IData)(vlSelf->__VdfgTmp_h50ba50d5__0)) 
           ^ (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024168_)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))) {
        vlSelf->wasmetal_core__DOT___024197_ = (1U 
                                                & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___024328_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___010044_)));
    } else {
        vlSelf->wasmetal_core__DOT___024197_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___010044_)));
        vlSelf->wasmetal_core__DOT___024328_ = (1U 
                                                & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127661___O 
        = (((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010023_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010028_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4a210212__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024299_)))));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023201_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128872___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036503_)))));
    vlSelf->wasmetal_core__DOT___036507_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
                                            & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___059797_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf100U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                                                >> 3U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    vlSelf->__VdfgTmp_hc406f1dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h0017edb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_hc4afcee8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127498___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022994_));
    vlSelf->wasmetal_core__DOT____Vcellout___128851___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036325_)))));
    vlSelf->wasmetal_core__DOT___036329_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                                            & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035387_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0))));
    vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035505_));
    vlSelf->wasmetal_core__DOT____Vcellout___128763___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035622_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035621_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035673_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035672_)))) 
           ^ (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035617_)))));
    vlSelf->wasmetal_core__DOT___035567_ = ((IData)(vlSelf->wasmetal_core__DOT___035622_)
                                             ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d));
    vlSelf->wasmetal_core__DOT___057349_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055826_)))))))));
    vlSelf->wasmetal_core__DOT___057332_ = (1U & (0x1d1d0f55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056187_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009726_)))))));
    vlSelf->wasmetal_core__DOT___057143_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056237_)))))))));
    vlSelf->wasmetal_core__DOT___056996_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                   ? 
                                                  (0x77747777U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d))))))
                                                   : 
                                                  (0x77747777U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d))))))));
    vlSelf->wasmetal_core__DOT___056318_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))))));
    vlSelf->wasmetal_core__DOT___056488_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056228_)))))))));
    vlSelf->wasmetal_core__DOT___057569_ = (1U & (IData)(
                                                         (0xee22fa0a00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010651_)))))))));
    vlSelf->wasmetal_core__DOT___043846_ = (1U & (0x1001U 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 2U) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_ha95c81f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                    >> 3U)));
    if (vlSelf->wasmetal_core__DOT___010024_) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024197_;
        wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024328_;
    }
    if (vlSelf->wasmetal_core__DOT___024258_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024197_;
        wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024328_;
    }
    vlSelf->wasmetal_core__DOT___057404_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134165___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___043780_ = (1U & (0x1001U 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 2U) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_hb920cb05__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                    >> 3U)));
    wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024855_));
    wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023203_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036507_));
    vlSelf->wasmetal_core__DOT___059717_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hc406f1dc__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058450_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058449_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059769_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h0017edb5__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058454_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O)) 
                                                                                | ((2U 
                                                                                & ((0x11000fU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hecea8d31__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059744_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                  ? 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))
                                                                  : 
                                                                 (0xc0c5U 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hc4afcee8__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058452_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058451_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036329_));
    wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035388_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035623_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035567_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b13__05d));
    vlSelf->wasmetal_core__DOT___009692_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff33330f0f5555ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___038801_) 
                                                                         << 3U) 
                                                                        | (((IData)(wasmetal_core__DOT___038802_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___038803_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___038804_))))))))))));
    vlSelf->wasmetal_core__DOT___057517_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056129_)))))))));
    vlSelf->wasmetal_core__DOT___057308_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056238_)))))))));
    vlSelf->wasmetal_core__DOT___057263_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)))))))))));
    vlSelf->wasmetal_core__DOT___057187_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))))));
    vlSelf->wasmetal_core__DOT___057109_ = (1U & (IData)(
                                                         (0xee220000fa0aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056121_)))))))));
    vlSelf->wasmetal_core__DOT___056957_ = (1U & (0xee22fa0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055964_)))))));
    __VdfgTmp_h15797db8__0 = ((4U & ((7U >> (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                              << 2U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___011068_)))) 
                                     << 2U)) | ((2U 
                                                 & ((0x70U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011246_)))) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)));
    vlSelf->wasmetal_core__DOT___056812_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))))));
    vlSelf->wasmetal_core__DOT___056675_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056243_)))))))));
    vlSelf->wasmetal_core__DOT___056399_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056242_)))))))));
    vlSelf->wasmetal_core__DOT___057589_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056239_)))))))));
    wasmetal_core__DOT___056260_ = (1U & (IData)((0xff00ccccf0f0aaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___011171_)))))))));
    vlSelf->__VdfgTmp_h786db0b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011068_));
    if (vlSelf->wasmetal_core__DOT___010025_) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024259_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127532___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023201_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023200_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023263_)))));
    wasmetal_core__DOT___023268_ = ((IData)(vlSelf->wasmetal_core__DOT___023204_) 
                                    & (IData)(wasmetal_core__DOT___127532___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128734___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035389_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035388_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035387_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035380_)))) 
           ^ (((IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035315_)))));
    wasmetal_core__DOT___035336_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035389_)
                                           ? (IData)(wasmetal_core__DOT___128734___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h65d009ee__0))));
    wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035624_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b14__05d));
    vlSelf->wasmetal_core__DOT___011074_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009692_))));
    vlSelf->wasmetal_core__DOT___056991_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009866_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (0x54U 
                                                    >> (IData)(__VdfgTmp_h15797db8__0))
                                                    : (IData)(
                                                              (0x5454545454445000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011246_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011068_) 
                                                                       << 3U) 
                                                                      | (IData)(__VdfgTmp_h15797db8__0)))))))
                                                   : 
                                                  (0x54U 
                                                   >> (IData)(__VdfgTmp_h15797db8__0))));
    vlSelf->wasmetal_core__DOT___056272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056260_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010077_))));
    wasmetal_core__DOT___056261_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___056260_))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)))) {
        wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d;
    } else {
        wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d;
        wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024201_) {
        wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d;
    } else {
        wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d;
        wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005914_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6ade5b0__0)))))));
    vlSelf->wasmetal_core__DOT___005848_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h1ea78a97__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h098b01ee__0)))));
    vlSelf->wasmetal_core__DOT___005776_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he6a1153d__0)))))));
    vlSelf->wasmetal_core__DOT___005777_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127532___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he5c4f457__0)))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023205_) 
           & (IData)(wasmetal_core__DOT___023268_));
    wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
           & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127499___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022994_)))));
    wasmetal_core__DOT___022998_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                    & (IData)(wasmetal_core__DOT___127499___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
           & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h96193a8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 3U)))))));
    __VdfgTmp_hff06bcdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                               << 5U) | ((0x10U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                   << 3U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                        >> 2U)))))));
    vlSelf->__VdfgTmp_he5c2d914__0 = (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                       << 5U) | ((0x10U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                     << 4U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014959_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h91abfcdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128728___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128734___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035390_)
            ? (IData)(wasmetal_core__DOT___035336_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128749___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035505_)))));
    wasmetal_core__DOT___035455_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128749___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035625_)
            ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b15__05d));
    vlSelf->wasmetal_core__DOT___012207_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056272_))));
    vlSelf->__VdfgTmp_hf38792bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___056272_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h54798c59__0));
    vlSelf->wasmetal_core__DOT___012497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009693_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___056261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009691_)))));
    vlSelf->wasmetal_core__DOT___012018_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___056261_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127678___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024466_) 
             << 3U) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___010025_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010024_)))) 
           ^ (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127678___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024197_)))));
    if (vlSelf->wasmetal_core__DOT___024466_) {
        wasmetal_core__DOT___024403_ = wasmetal_core__DOT___127678___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024569_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d;
    } else {
        wasmetal_core__DOT___024403_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d;
        wasmetal_core__DOT___024569_ = wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127645___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024202_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024201_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024259_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024258_)))) 
           ^ (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127645___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024197_)))));
    if (vlSelf->wasmetal_core__DOT___024202_) {
        wasmetal_core__DOT___024137_ = wasmetal_core__DOT___127645___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024268_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d;
    } else {
        wasmetal_core__DOT___024137_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d;
        wasmetal_core__DOT___024268_ = wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127727___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
           ^ (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024855_)))));
    wasmetal_core__DOT___024884_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127727___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127662___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024202_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024201_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024259_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024258_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127662___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024328_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127695___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024466_)) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_hef18707b__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010025_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___010024_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127711___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024328_)))));
    vlSelf->wasmetal_core__DOT___048265_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006039_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006038_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005914_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006037_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006035_)))))))))));
    vlSelf->wasmetal_core__DOT___006121_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005848_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005847_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006010_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                                  >> 2U))))))));
    __VdfgTmp_hf524d067__0 = (((IData)(vlSelf->wasmetal_core__DOT___005779_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005776_))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023206_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128873___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036507_)))));
    wasmetal_core__DOT___036512_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___128873___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h312e1166__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___059910_ = (1U & (IData)(
                                                         (0xf0ff11ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xfef00000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf5238d18__0))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f33aa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf552ae6e__0))))))))))))));
    vlSelf->wasmetal_core__DOT___059849_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016441_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 1U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058461_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 1U))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059882_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heb95d931__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127499___O) 
                                                                                >> 2U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058465_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                                                >> 2U))))))))))))))))))))));
    wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
           & (IData)(wasmetal_core__DOT___022998_));
    vlSelf->wasmetal_core__DOT____Vcellout___128852___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_h917221d1__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h25476d0e__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haf20b36b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036329_)))));
    wasmetal_core__DOT___036333_ = ((7U >> (IData)(vlSelf->__VdfgTmp_hafd7ea26__0)) 
                                    & (IData)(wasmetal_core__DOT___128852___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014970_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___014612_)
                                                    ? (IData)(
                                                              (0xf0f0000aa2eaa22ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0)))
                                                    : (IData)(
                                                              (0xaaaaaaaa0f8b0088ULL 
                                                               >> (IData)(__VdfgTmp_hff06bcdd__0))))));
    wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035391_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035455_));
    vlSelf->wasmetal_core__DOT____Vcellout___128764___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035626_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035625_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035624_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035623_)))) 
           ^ (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035567_)))));
    wasmetal_core__DOT___035571_ = ((IData)(vlSelf->wasmetal_core__DOT___035626_)
                                     ? (IData)(wasmetal_core__DOT___128764___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b16__05d));
    vlSelf->wasmetal_core__DOT___056739_ = (1U & (IData)(
                                                         (0x3333bffb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056736_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b49f700__0))))));
    vlSelf->wasmetal_core__DOT___011075_ = (1U & (IData)(
                                                         (0x3333bffb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056483_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4b49f700__0))))));
    vlSelf->wasmetal_core__DOT___057318_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___012559_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___012567_))
                                                                                 : 
                                                                                (1U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0e20209__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057288_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h186e290b__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012582_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012581_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcdbca8e0__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012580_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___057153_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xfafcU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8267970c__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0f3355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012395_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h224cdee6__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012394_))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012407_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h745845c2__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012413_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012412_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c3586c1__0)))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012411_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___011737_ = (1U & (IData)(
                                                         (0xdfdddddf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xd00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                                 ? 
                                                                                (0xf0fdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011550_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc7461e30__0)))))
                                                                                 : 
                                                                                (2U 
                                                                                >> 
                                                                                (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? 
                                                                                (0xf0fff11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011749_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011574_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))))))
                                                                                 : 
                                                                                (0xdU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011748_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f3f0f500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6248a2d__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O)) 
                                                                                & (IData)(
                                                                                (0xff00ff00fff0fff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011753_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011752_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011103_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___010908_ = (1U & (IData)(
                                                         (0xefeeeeef00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056464_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcb4b0ef5__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056272_)))))))));
    wasmetal_core__DOT___056907_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012018_))));
    vlSelf->wasmetal_core__DOT___013031_ = (1U & (IData)(
                                                         (0x7f77777f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (((~ 
                                                                                ((~ (IData)(vlSelf->wasmetal_core__DOT___010376_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011101_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013040_))
                                                                                 : (IData)(
                                                                                (0xfff0fffefff0fff0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013041_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013040_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013038_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011102_))))))))))) 
                                                                                & (IData)(
                                                                                (0xff00fff0fffdffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013035_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4aee2d94__0)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfff011111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___057574_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                                                 ? (IData)(
                                                                                (0xff00ffaafff0ffccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013064_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf11U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6bff4562__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6c83109e__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xfff01111U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc338337f__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013047_))))))))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___013064_))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))))));
    vlSelf->wasmetal_core__DOT___011163_ = (1U & (0x75570000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010077_)))))));
    vlSelf->wasmetal_core__DOT___012242_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)))) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024403_;
        wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024569_;
    }
    vlSelf->wasmetal_core__DOT___043823_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O)))));
    vlSelf->wasmetal_core__DOT___043847_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->wasmetal_core__DOT___043519_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    if ((1U & (0xe1U >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024137_;
        wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024268_;
    }
    vlSelf->wasmetal_core__DOT___043390_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043757_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O)))));
    vlSelf->wasmetal_core__DOT___043781_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->wasmetal_core__DOT___043455_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
           & (IData)(wasmetal_core__DOT___024884_));
    vlSelf->wasmetal_core__DOT___048158_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005783_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005781_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005780_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    vlSelf->wasmetal_core__DOT___006193_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006166_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127529___O) 
                                                        >> 1U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde33bda2__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hde33bda2__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006035_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hf524d067__0))))))));
    wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023207_) 
           & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060449_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bc2f6b9__0))))))));
    wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d) 
           & (IData)(wasmetal_core__DOT___036512_));
    wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)) 
           & (IData)(wasmetal_core__DOT___036333_));
    wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035339_)
            ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
           & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035627_)
            ? (IData)(wasmetal_core__DOT___035571_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b17__05d));
    vlSelf->wasmetal_core__DOT___012063_ = (1U & (IData)(
                                                         (0xfff100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___056907_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056905_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xccf0ff55U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he499e9e8__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011101_)))))))));
    vlSelf->__VdfgTmp_hf0788fad__0 = ((2U & ((0xfe00U 
                                              >> (((IData)(wasmetal_core__DOT___056907_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056916_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0x33000f00000055ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056914_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0aaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056900_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h758d714e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056899_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012179_))))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f000ee00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056909_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012256_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h64128247__0)))) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024204_) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127533___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023208_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023207_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023205_)))) 
           ^ (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023268_)))));
    wasmetal_core__DOT___023272_ = ((IData)(vlSelf->wasmetal_core__DOT___023208_) 
                                    & (IData)(wasmetal_core__DOT___127533___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
           & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128735___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035391_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035390_)))) 
           ^ (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035336_)))));
    wasmetal_core__DOT___035284_ = ((IData)(vlSelf->wasmetal_core__DOT___035340_)
                                     ? (IData)(wasmetal_core__DOT___128735___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d));
    wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035628_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b18__05d));
    if (vlSelf->wasmetal_core__DOT___024469_) {
        wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d;
    } else {
        wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d;
        wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024205_) {
        wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d;
    } else {
        wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d;
        wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006165_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006171_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb48e3438__0))))));
    wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023209_) 
           & (IData)(wasmetal_core__DOT___023272_));
    wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
           & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127500___O = (
                                                   ((8U 
                                                     & ((0xf40bU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022998_)))));
    wasmetal_core__DOT___023003_ = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                    & (IData)(wasmetal_core__DOT___127500___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
           & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hb335ec2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h15de5b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbff92af3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035341_)
                  ? (IData)(wasmetal_core__DOT___035284_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h9195d647__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128750___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035455_)))));
    wasmetal_core__DOT___035459_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128750___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035629_)
            ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127679___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024470_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024469_) 
                        << 2U) | ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_h64128247__0)) 
                                         << 1U)) | 
                                  (1U & (9U >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127679___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024403_)))));
    if (vlSelf->wasmetal_core__DOT___024470_) {
        wasmetal_core__DOT___024407_ = wasmetal_core__DOT___127679___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024573_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d;
    } else {
        wasmetal_core__DOT___024407_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d;
        wasmetal_core__DOT___024573_ = wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127646___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024206_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024205_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024204_) 
                                   << 1U) | (1U & (0xe1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127646___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024137_)))));
    if (vlSelf->wasmetal_core__DOT___024206_) {
        wasmetal_core__DOT___024141_ = wasmetal_core__DOT___127646___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024272_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d;
    } else {
        wasmetal_core__DOT___024141_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d;
        wasmetal_core__DOT___024272_ = wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127663___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024206_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024205_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024204_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (0xe1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127663___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024268_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127728___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
           ^ (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024884_)))));
    wasmetal_core__DOT___024824_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127728___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127696___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024470_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024469_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h64128247__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h740b215b__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127712___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024569_)))));
    wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023210_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128874___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b52__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036512_)))));
    wasmetal_core__DOT___036516_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___128874___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060022_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00aaaafc0cfc0cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf400U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h86dfc376__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                                                >> 3U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h460f8c4e__0))))))))))));
    __VdfgTmp_h4bfbe6f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0c3747f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127500___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_h0968f04c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127500___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__ 
        = ((0xf40bU >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)) 
           & (IData)(wasmetal_core__DOT___023003_));
    vlSelf->wasmetal_core__DOT____Vcellout___128853___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hd5a7b943__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h310e5162__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h513c757b__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036333_)))));
    wasmetal_core__DOT___036338_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h4e8a0148__0)) 
                                    & (IData)(wasmetal_core__DOT___128853___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035342_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b10__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035459_));
    vlSelf->wasmetal_core__DOT____Vcellout___128765___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035630_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035629_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035628_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035627_)))) 
           ^ (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035571_)))));
    wasmetal_core__DOT___035575_ = ((IData)(vlSelf->wasmetal_core__DOT___035630_)
                                     ? (IData)(wasmetal_core__DOT___128765___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b20__05d));
    vlSelf->wasmetal_core__DOT___057606_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127679___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0)))) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024407_;
        wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024573_;
    }
    vlSelf->wasmetal_core__DOT___043824_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043848_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043498_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___043497_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043521_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    vlSelf->wasmetal_core__DOT___043520_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    if (vlSelf->wasmetal_core__DOT___024207_) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024141_;
        wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024272_;
    }
    vlSelf->wasmetal_core__DOT___043369_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___043368_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043758_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043392_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 3U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    vlSelf->wasmetal_core__DOT___043391_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043782_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    vlSelf->wasmetal_core__DOT___043432_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043456_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008810_)))));
    wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
           & (IData)(wasmetal_core__DOT___024824_));
    wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023211_) 
           & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d) 
           & (IData)(wasmetal_core__DOT___036516_));
    vlSelf->wasmetal_core__DOT___018808_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd49dc43__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h4bfbe6f9__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xc5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058471_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059991_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h10d9a2f8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0c3747f4__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058474_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058473_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059963_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he60f6eaf__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h0968f04c__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdd0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058472_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128867___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___016278_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058470_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006819_)))))))))))))))))))))))));
    wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128854___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d) 
                                                      & (IData)(wasmetal_core__DOT___036338_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___036338_)));
    wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035343_)
            ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
           & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035632_)
            ? (IData)(wasmetal_core__DOT___035575_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b21__05d));
    if (vlSelf->wasmetal_core__DOT___024472_) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024208_) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127534___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023211_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023210_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023209_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023272_)))));
    wasmetal_core__DOT___023276_ = ((IData)(vlSelf->wasmetal_core__DOT___023212_) 
                                    & (IData)(wasmetal_core__DOT___127534___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
           & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d 
        = (1U & (4U >> ((2U & (IData)(wasmetal_core__DOT____Vcellout___128854___O)) 
                        | (IData)(vlSelf->wasmetal_core__DOT___017533_))));
    wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry 
        = (1U & (0xb00U >> ((8U & ((IData)(wasmetal_core__DOT____Vcellout___128854___O) 
                                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057694_))))));
    wasmetal_core__DOT____Vcellout___128736___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035344_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035343_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035342_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035341_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035284_)))));
    wasmetal_core__DOT___035288_ = ((IData)(vlSelf->wasmetal_core__DOT___035344_)
                                     ? (IData)(wasmetal_core__DOT___128736___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d));
    wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035633_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b22__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)))) {
        wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d;
    } else {
        wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d;
        wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)))) {
        wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d;
    } else {
        wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d;
        wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005975_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005989_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9937e7c0__0))))));
    vlSelf->wasmetal_core__DOT___006009_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006022_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_ha48aeb8e__0))))));
    vlSelf->wasmetal_core__DOT___006079_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___006099_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h9936ac51__0))))));
    vlSelf->wasmetal_core__DOT___006080_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127534___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___006106_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h97a6ba37__0))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023214_) 
           & (IData)(wasmetal_core__DOT___023276_));
    wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
           & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127501___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h20c89172__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                << 1U)) 
                                         | (1U & (0xf40bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h6df53282__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023003_)))));
    wasmetal_core__DOT___023007_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127501___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___036374_ = (1U & (6U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d))));
    wasmetal_core__DOT___036373_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                     << 1U)) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry))));
    vlSelf->__VdfgTmp_h493bd629__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_haaae3cf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hbca0145a__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128736___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h532df62e__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128735___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035345_)
                  ? (IData)(wasmetal_core__DOT___035288_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128751___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035459_)))));
    wasmetal_core__DOT___035463_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128751___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035634_)
            ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127680___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024472_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127680___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024407_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0)))) {
        wasmetal_core__DOT___024411_ = wasmetal_core__DOT___127680___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024577_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d;
    } else {
        wasmetal_core__DOT___024411_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d;
        wasmetal_core__DOT___024577_ = wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127647___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024210_) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024208_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024207_)))) 
           ^ (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127647___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024141_)))));
    if (vlSelf->wasmetal_core__DOT___024210_) {
        wasmetal_core__DOT___024145_ = wasmetal_core__DOT___127647___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024276_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d;
    } else {
        wasmetal_core__DOT___024145_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d;
        wasmetal_core__DOT___024276_ = wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127664___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024210_)) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h7884e356__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024208_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024207_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127664___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024272_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127729___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
           ^ (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024824_)))));
    wasmetal_core__DOT___024828_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127729___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127697___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h6850d65a__0))) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024472_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hf4167eb1__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127713___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024573_)))));
    vlSelf->wasmetal_core__DOT___006123_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005782_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005781_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006166_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006036_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005778_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005777_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006165_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006080_)))))))))));
    wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023215_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128875___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036516_)))));
    wasmetal_core__DOT___036520_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___128875___DOT__CO__BRA__2__KET__));
    __VdfgTmp_hffea5a13__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_he5a4e99b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127501___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023007_));
    wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036373_)) 
           & (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035346_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035463_));
    vlSelf->wasmetal_core__DOT____Vcellout___128766___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035635_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035634_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035633_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035632_)))) 
           ^ (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035575_)))));
    wasmetal_core__DOT___035580_ = ((IData)(vlSelf->wasmetal_core__DOT___035635_)
                                     ? (IData)(wasmetal_core__DOT___128766___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b24__05d));
    vlSelf->wasmetal_core__DOT___011254_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127680___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024475_) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024411_;
        wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024577_;
    }
    vlSelf->wasmetal_core__DOT___043826_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043825_ = (1U & (0x7f770100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___043850_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043849_ = (1U & (0x90000009U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008810_)))))));
    vlSelf->wasmetal_core__DOT___043499_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)))));
    vlSelf->wasmetal_core__DOT___043522_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    if (vlSelf->wasmetal_core__DOT___024211_) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024145_;
        wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024276_;
    }
    vlSelf->wasmetal_core__DOT___043370_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O)))));
    vlSelf->wasmetal_core__DOT___043760_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043759_ = (1U & (0x7f770100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___043393_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043784_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043783_ = (1U & (0x90000009U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008810_)))))));
    vlSelf->wasmetal_core__DOT___057409_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___056993_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O))))));
    vlSelf->wasmetal_core__DOT___043434_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043433_ = (1U & (0xfee0f000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                          << 2U) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___043458_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043457_ = (1U & (0x14000028U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                       << 2U)) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac22065f__0))))));
    wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
           & (IData)(wasmetal_core__DOT___024828_));
    wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023216_) 
           & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060552_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7cadd68e__0))))))));
    vlSelf->wasmetal_core__DOT___060566_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h49fa4f4c__0))))))));
    vlSelf->wasmetal_core__DOT___060584_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058512_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060598_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016491_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128875___O) 
                                                                  >> 3U))))))));
    wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d) 
           & (IData)(wasmetal_core__DOT___036520_));
    vlSelf->wasmetal_core__DOT___060072_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6712d737__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_hffea5a13__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f000ddU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f000ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h3056fe7c__0))))))))))));
    wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036374_) ? (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02eroundedSig__05b25__05d));
    wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035347_)
                  ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
           & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035636_)
            ? (IData)(wasmetal_core__DOT___035580_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b25__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)))) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)))) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___127520___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023216_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023215_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023214_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023276_)))));
    vlSelf->wasmetal_core__DOT___023281_ = ((IData)(vlSelf->wasmetal_core__DOT___023217_) 
                                            & (IData)(wasmetal_core__DOT___127520___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
           & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
           & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128737___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035348_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035347_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035346_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035345_)))) 
           ^ (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035288_)))));
    vlSelf->wasmetal_core__DOT___035292_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035348_)
                                                   ? (IData)(wasmetal_core__DOT___128737___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0))));
    wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035637_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b26__05d));
    if (vlSelf->wasmetal_core__DOT___024477_) {
        wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d;
    } else {
        wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d;
        wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT___024213_) {
        wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d;
    } else {
        wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d;
        wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___005845_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005868_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb869da0d__0))))));
    vlSelf->wasmetal_core__DOT___005843_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005855_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_haba8fa43__0))))));
    vlSelf->wasmetal_core__DOT___005706_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005770_)
                                                      ? (IData)(
                                                                (0x2aa00000202ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0)))
                                                      : (IData)(
                                                                (0xfffffeaafffffefeULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb86fa734__0))))));
    vlSelf->wasmetal_core__DOT___005705_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127520___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___003806_)
                                                        ? (IData)(
                                                                  (0x2aa00000202ULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0)))
                                                        : (IData)(
                                                                  (0xfffffeaafffffefeULL 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab9caa42__0))))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023218_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023281_));
    vlSelf->wasmetal_core__DOT____Vcellout___128876___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b63__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b60__05d)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                & (IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128876___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036520_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127502___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                              << 2U)) | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023007_)))));
    vlSelf->wasmetal_core__DOT___023077_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(wasmetal_core__DOT___127502___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128855___O 
        = (((0xcU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
            | (((IData)(wasmetal_core__DOT___036374_) 
                << 1U) | (IData)(wasmetal_core__DOT___036373_))) 
           ^ (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036366_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128855___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_he1094429__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h4c1a1db9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h155aafca__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h6827e815__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128736___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128737___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035349_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035292_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h93626d60__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128752___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035463_)))));
    vlSelf->wasmetal_core__DOT___035468_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128752___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035638_)
            ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127681___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024477_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___024475_)))) 
           ^ (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127681___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024411_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0)))) {
        vlSelf->wasmetal_core__DOT___024416_ = wasmetal_core__DOT___127681___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024582_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024416_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d;
        vlSelf->wasmetal_core__DOT___024582_ = wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127648___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024214_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024213_) 
                        << 2U) | ((2U & ((6U >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___024211_)))) 
           ^ (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127648___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024145_)))));
    if (vlSelf->wasmetal_core__DOT___024214_) {
        vlSelf->wasmetal_core__DOT___024150_ = wasmetal_core__DOT___127648___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024281_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024150_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d;
        vlSelf->wasmetal_core__DOT___024281_ = wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127665___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024214_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024213_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024211_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127665___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024276_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127730___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
           ^ (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024828_)))));
    vlSelf->wasmetal_core__DOT___024832_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127730___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127698___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_he07352b1__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024477_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024475_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127714___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024577_)))));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023219_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060614_ = (1U & (IData)(
                                                         (0xff007700ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h307b9eba__0))))))));
    vlSelf->wasmetal_core__DOT___060640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058515_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___060624_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f000003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058514_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 1U)))))))))))));
    __VdfgTmp_h01dc1976__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    __VdfgTmp_hb1f3bce1__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                               << 1U) | (1U & (4U >> 
                                               ((2U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                    >> 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___019013_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058337_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127502___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___127517___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023077_));
    vlSelf->wasmetal_core__DOT___134162___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___128859___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O))));
    vlSelf->wasmetal_core__DOT___043027_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___043030_ = (1U & (0x40U 
                                                  >> 
                                                  ((6U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128855___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___128856___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___036366_));
    vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035350_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128738___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h767f4755__0))));
    vlSelf->wasmetal_core__DOT___128753___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035468_));
    vlSelf->wasmetal_core__DOT____Vcellout___128767___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035639_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035638_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035637_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035636_)))) 
           ^ (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035580_)))));
    vlSelf->wasmetal_core__DOT___035584_ = ((IData)(vlSelf->wasmetal_core__DOT___035639_)
                                             ? (IData)(wasmetal_core__DOT___128767___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b28__05d));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hc7fb8523__0)))) {
        vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024416_;
        vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127682___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d;
        vlSelf->wasmetal_core__DOT___127715___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024582_;
    }
    vlSelf->wasmetal_core__DOT___043827_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O)))));
    vlSelf->wasmetal_core__DOT___043851_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043500_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043523_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    if (vlSelf->wasmetal_core__DOT___024215_) {
        vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024150_;
        vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127649___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d;
        vlSelf->wasmetal_core__DOT___127666___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024281_;
    }
    vlSelf->wasmetal_core__DOT___043371_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___043761_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O)))));
    vlSelf->wasmetal_core__DOT___043394_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xcU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___043785_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___043435_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O)))));
    vlSelf->wasmetal_core__DOT___043459_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008974_))));
    vlSelf->wasmetal_core__DOT___127731___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024832_));
    vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023220_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127521___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060180_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))
                                                                                 : 
                                                                                (0xc0c5U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7041ac57__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h01dc1976__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78bec42d__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___060204_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he2e2fa14__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_hb1f3bce1__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00aaaafc0cfc0cULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xbb0f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058493_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128869___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4af9777a__0)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060234_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                                 ? 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019014_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 1U) 
                                                                                | (IData)(wasmetal_core__DOT___019013_))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060224_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf0f0cc55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h59bf4fdc__0)))))))))))))))));
}
