#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__18(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__18\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___030747_;
    wasmetal_core__DOT___030747_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030751_;
    wasmetal_core__DOT___030751_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030755_;
    wasmetal_core__DOT___030755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030760_;
    wasmetal_core__DOT___030760_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___030769_;
    wasmetal_core__DOT___030769_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031130_;
    wasmetal_core__DOT___031130_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031134_;
    wasmetal_core__DOT___031134_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031138_;
    wasmetal_core__DOT___031138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031143_;
    wasmetal_core__DOT___031143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031147_;
    wasmetal_core__DOT___031147_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031418_;
    wasmetal_core__DOT___031418_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031422_;
    wasmetal_core__DOT___031422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031426_;
    wasmetal_core__DOT___031426_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031431_;
    wasmetal_core__DOT___031431_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031435_;
    wasmetal_core__DOT___031435_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031705_;
    wasmetal_core__DOT___031705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031709_;
    wasmetal_core__DOT___031709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031713_;
    wasmetal_core__DOT___031713_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031718_;
    wasmetal_core__DOT___031718_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___031727_;
    wasmetal_core__DOT___031727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032441_;
    wasmetal_core__DOT___032441_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032445_;
    wasmetal_core__DOT___032445_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032449_;
    wasmetal_core__DOT___032449_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032454_;
    wasmetal_core__DOT___032454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___032458_;
    wasmetal_core__DOT___032458_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034728_;
    wasmetal_core__DOT___034728_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034732_;
    wasmetal_core__DOT___034732_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034737_;
    wasmetal_core__DOT___034737_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034741_;
    wasmetal_core__DOT___034741_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034746_;
    wasmetal_core__DOT___034746_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034924_;
    wasmetal_core__DOT___034924_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034929_;
    wasmetal_core__DOT___034929_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034933_;
    wasmetal_core__DOT___034933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034938_;
    wasmetal_core__DOT___034938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034946_;
    wasmetal_core__DOT___034946_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035052_;
    wasmetal_core__DOT___035052_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035057_;
    wasmetal_core__DOT___035057_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035061_;
    wasmetal_core__DOT___035061_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035066_;
    wasmetal_core__DOT___035066_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035070_;
    wasmetal_core__DOT___035070_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044382_;
    wasmetal_core__DOT___044382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044564_;
    wasmetal_core__DOT___044564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044584_;
    wasmetal_core__DOT___044584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045536_;
    wasmetal_core__DOT___045536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045545_;
    wasmetal_core__DOT___045545_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045548_;
    wasmetal_core__DOT___045548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045557_;
    wasmetal_core__DOT___045557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063242_;
    wasmetal_core__DOT___063242_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063248_;
    wasmetal_core__DOT___063248_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063254_;
    wasmetal_core__DOT___063254_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063260_;
    wasmetal_core__DOT___063260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063266_;
    wasmetal_core__DOT___063266_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063272_;
    wasmetal_core__DOT___063272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063278_;
    wasmetal_core__DOT___063278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063284_;
    wasmetal_core__DOT___063284_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063290_;
    wasmetal_core__DOT___063290_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064043_;
    wasmetal_core__DOT___064043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064044_;
    wasmetal_core__DOT___064044_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064054_;
    wasmetal_core__DOT___064054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064065_;
    wasmetal_core__DOT___064065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064560_;
    wasmetal_core__DOT___064560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064563_;
    wasmetal_core__DOT___064563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064951_;
    wasmetal_core__DOT___064951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064980_;
    wasmetal_core__DOT___064980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065090_;
    wasmetal_core__DOT___065090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065121_;
    wasmetal_core__DOT___065121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065256_;
    wasmetal_core__DOT___065256_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065268_;
    wasmetal_core__DOT___065268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065344_;
    wasmetal_core__DOT___065344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065355_;
    wasmetal_core__DOT___065355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065453_;
    wasmetal_core__DOT___065453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065462_;
    wasmetal_core__DOT___065462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065536_;
    wasmetal_core__DOT___065536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065677_;
    wasmetal_core__DOT___065677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065775_;
    wasmetal_core__DOT___065775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065873_;
    wasmetal_core__DOT___065873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065988_;
    wasmetal_core__DOT___065988_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066054_;
    wasmetal_core__DOT___066054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066151_;
    wasmetal_core__DOT___066151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066250_;
    wasmetal_core__DOT___066250_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128203___O;
    wasmetal_core__DOT____Vcellout___128203___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128367___O;
    wasmetal_core__DOT____Vcellout___128367___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128455___O;
    wasmetal_core__DOT____Vcellout___128455___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128705___O;
    wasmetal_core__DOT____Vcellout___128705___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128706___O;
    wasmetal_core__DOT____Vcellout___128706___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128707___O;
    wasmetal_core__DOT____Vcellout___128707___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128708___O;
    wasmetal_core__DOT____Vcellout___128708___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128709___O;
    wasmetal_core__DOT____Vcellout___128709___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128710___O;
    wasmetal_core__DOT____Vcellout___128710___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128717___O;
    wasmetal_core__DOT____Vcellout___128717___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128718___O;
    wasmetal_core__DOT____Vcellout___128718___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128719___O;
    wasmetal_core__DOT____Vcellout___128719___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___128299___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128299___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128299___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128299___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128299___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128299___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128300___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128300___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128300___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128300___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128300___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128300___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128310___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128310___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128310___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128310___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128311___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128311___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128311___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128311___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128311___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128311___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128312___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128312___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128312___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128312___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128312___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128312___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128313___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128313___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128313___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128313___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128313___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128313___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128331___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128331___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128331___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128331___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128331___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128331___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128332___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128332___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128332___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128332___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128332___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128332___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128333___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128333___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128333___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128333___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128333___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128333___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128344___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128344___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128344___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128344___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128344___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128344___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128345___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128345___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128345___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128345___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128345___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128345___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128355___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128355___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128355___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128355___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128355___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128355___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128356___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128356___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128356___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128356___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128356___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128356___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128357___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128357___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128357___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128357___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128357___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128357___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128368___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128368___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128368___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128368___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128368___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128368___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128369___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128369___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128369___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128369___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128369___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128369___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128379___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128379___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128379___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128379___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128379___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128379___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128380___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128380___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128380___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128380___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128380___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128380___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128390___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128390___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128390___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128390___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128391___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128391___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128391___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128391___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128391___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128391___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128392___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128392___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128392___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128392___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128392___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128392___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128393___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128393___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128393___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128393___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128393___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128393___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128443___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128443___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128443___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128443___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128443___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128443___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128444___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128444___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128444___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128444___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128444___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128444___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128445___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128445___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128445___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128445___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128445___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128445___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128456___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128456___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128456___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128456___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128456___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128456___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128457___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128457___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128457___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128457___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128457___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128457___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128673___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128673___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128673___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128673___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128673___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128673___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128674___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128674___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128674___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128674___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128674___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128674___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128675___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128675___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128675___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128675___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128675___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128675___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128676___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128676___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128676___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128676___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128676___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128676___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128685___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128685___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128685___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128685___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128686___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128686___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128686___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128686___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128686___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128686___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128687___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128687___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128687___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128687___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128687___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128687___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128689___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128689___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128689___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128689___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128689___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128689___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128690___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128690___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128690___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128690___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128690___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128690___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128691___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128691___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128691___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128691___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128691___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128691___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128692___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128692___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128692___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128692___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128692___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128692___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128702___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128702___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128702___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128702___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128703___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128703___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128703___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128703___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128703___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128703___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128705___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128705___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128705___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128705___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128705___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128705___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128706___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128706___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128706___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128706___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128706___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128706___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128707___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128707___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128707___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128707___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128707___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128707___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128708___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128708___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128708___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128708___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128708___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128708___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128709___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128709___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128709___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128709___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128709___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128709___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128718___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128718___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128719___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128719___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128719___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128719___DOT__CO__BRA__1__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___068879_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068878_))));
    vlSelf->wasmetal_core__DOT___068503_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068502_))));
    vlSelf->wasmetal_core__DOT___064948_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064940_))))))));
    vlSelf->wasmetal_core__DOT___065245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065244_))));
    vlSelf->wasmetal_core__DOT___065333_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064796_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065332_))));
    vlSelf->wasmetal_core__DOT___065444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065443_))));
    vlSelf->wasmetal_core__DOT___067291_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067288_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064132_)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                           << 1U))))))))));
    vlSelf->wasmetal_core__DOT___064964_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064963_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___067780_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064606_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064605_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___064812_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064811_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064130_))))));
    vlSelf->wasmetal_core__DOT___067634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067633_))));
    vlSelf->wasmetal_core__DOT___067692_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067414_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067548_))))));
    vlSelf->wasmetal_core__DOT___065668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065244_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065667_))));
    vlSelf->wasmetal_core__DOT___064156_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067274_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067549_))));
    vlSelf->wasmetal_core__DOT___065863_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065862_))));
    vlSelf->wasmetal_core__DOT___065746_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065332_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065745_))));
    vlSelf->wasmetal_core__DOT___065979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065978_))));
    vlSelf->__VdfgTmp_hf24dfeba__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064960_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064963_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067228_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067516_))));
    vlSelf->wasmetal_core__DOT___066042_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065667_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066041_))));
    vlSelf->__VdfgTmp_hedd7926b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064808_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064811_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064130_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067414_))));
    vlSelf->wasmetal_core__DOT___064197_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064177_))));
    vlSelf->wasmetal_core__DOT___066240_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066239_))));
    vlSelf->wasmetal_core__DOT___066171_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066170_))));
    vlSelf->wasmetal_core__DOT___066349_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066348_))));
    vlSelf->__VdfgTmp_ha0b0298a__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064605_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___067373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067372_))));
    vlSelf->wasmetal_core__DOT___064621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___066449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066448_))));
    vlSelf->__VdfgTmp_h0f450401__0 = ((2U & ((0xf0f0aaccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_he8a45048__0))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067228_))));
    vlSelf->wasmetal_core__DOT___067119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066822_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067118_))));
    vlSelf->wasmetal_core__DOT___067275_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067274_))));
    vlSelf->wasmetal_core__DOT___064607_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064598_))));
    vlSelf->wasmetal_core__DOT___065239_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___065438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064966_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064961_))));
    vlSelf->wasmetal_core__DOT___064969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064966_))));
    vlSelf->wasmetal_core__DOT___065327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064814_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064809_))));
    vlSelf->wasmetal_core__DOT___064817_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064814_))));
    vlSelf->wasmetal_core__DOT___065114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064177_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064154_))));
    vlSelf->wasmetal_core__DOT___067058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067057_))));
    vlSelf->wasmetal_core__DOT___066738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066737_))));
    vlSelf->wasmetal_core__DOT___066571_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066239_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066570_))));
    vlSelf->wasmetal_core__DOT___066928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066927_))));
    vlSelf->wasmetal_core__DOT___066823_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066822_))));
    vlSelf->wasmetal_core__DOT___066495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066170_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066494_))));
    vlSelf->wasmetal_core__DOT___066688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066687_))));
    vlSelf->wasmetal_core__DOT___067011_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066687_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067010_))));
    vlSelf->wasmetal_core__DOT___065675_ = (1U & (IData)(
                                                         (0x3f5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065672_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xbU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064199_)))))))));
    vlSelf->wasmetal_core__DOT___068176_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b4a166b__0))));
    vlSelf->wasmetal_core__DOT___065112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065104_))))))));
    vlSelf->wasmetal_core__DOT___065528_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065104_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065527_))));
    vlSelf->wasmetal_core__DOT___064053_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064052_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064051_))));
    vlSelf->wasmetal_core__DOT___066360_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066249_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066359_))));
    wasmetal_core__DOT___064980_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064778_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064979_))));
    wasmetal_core__DOT___064560_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064047_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064052_))));
    wasmetal_core__DOT___066250_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066150_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066249_))));
    vlSelf->wasmetal_core__DOT___064076_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064070_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064069_))));
    wasmetal_core__DOT___065090_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064979_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065089_))));
    wasmetal_core__DOT___064054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064048_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064047_))));
    wasmetal_core__DOT___066151_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066053_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066150_))));
    wasmetal_core__DOT___065268_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065089_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065267_))));
    vlSelf->wasmetal_core__DOT___064557_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064048_))));
    wasmetal_core__DOT___066054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065987_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066053_))));
    wasmetal_core__DOT___064043_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064042_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064041_))));
    wasmetal_core__DOT___065988_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065872_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065987_))));
    vlSelf->wasmetal_core__DOT___064066_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064060_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064059_))));
    wasmetal_core__DOT___065355_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065267_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065354_))));
    vlSelf->wasmetal_core__DOT___064564_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064064_))));
    wasmetal_core__DOT___065462_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065354_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065461_))));
    vlSelf->wasmetal_core__DOT___064558_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064042_))));
    wasmetal_core__DOT___065873_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065774_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065872_))));
    wasmetal_core__DOT___064044_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064037_))));
    wasmetal_core__DOT___065775_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065676_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065774_))));
    wasmetal_core__DOT___064563_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___064065_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064064_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___065677_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065535_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065676_))));
    wasmetal_core__DOT___065536_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065461_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065535_))));
    vlSelf->wasmetal_core__DOT___064779_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064778_))));
    vlSelf->wasmetal_core__DOT___066941_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064237_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064235_))));
    vlSelf->wasmetal_core__DOT___065547_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065546_))));
    wasmetal_core__DOT___064951_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064821_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064950_))));
    vlSelf->__VdfgTmp_hd333e317__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064231_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064236_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                << 1U))));
    wasmetal_core__DOT___065453_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065343_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065452_))));
    wasmetal_core__DOT___065344_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065255_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065343_))));
    vlSelf->wasmetal_core__DOT___064578_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064222_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064232_))));
    vlSelf->wasmetal_core__DOT___064228_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064222_))));
    wasmetal_core__DOT___065256_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065120_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065255_))));
    wasmetal_core__DOT___065121_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064950_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065120_))));
    vlSelf->__VdfgTmp_hdfea75fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___064827_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0x8fU 
                                                           >> 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                            << 2U)))))));
    vlSelf->wasmetal_core__DOT___065349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065348_))));
    vlSelf->wasmetal_core__DOT___064575_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064571_))))))))));
    vlSelf->wasmetal_core__DOT___064822_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064821_))));
    wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128717___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035108_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035107_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035105_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035104_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035039_)))));
    vlSelf->wasmetal_core__DOT___035044_ = ((IData)(vlSelf->wasmetal_core__DOT___035108_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128717___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d));
    wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030801_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d));
    wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128342___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128366___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063220_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063218_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063217_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063226_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063224_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063223_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063232_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063230_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063229_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063238_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063236_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063235_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128218___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128365___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032498_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128454___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032498_))));
    wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031759_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d));
    wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029766_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127840___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026280_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026279_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026278_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026277_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026244_)))));
    vlSelf->wasmetal_core__DOT___026248_ = ((IData)(vlSelf->wasmetal_core__DOT___026280_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127840___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d));
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032887_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032695_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    if ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))) {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                     >> 3U));
    } else {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellinp___128523___S 
        = ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                      >> 3U)) << 1U)) | (1U & (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                  >> 2U))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128522___S 
        = ((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                      >> 1U)) << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                << 2U)) 
                                         | ((2U & (
                                                   (~ 
                                                    ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                     >> 3U)) 
                                                   << 1U)) 
                                            | (1U & 
                                               (~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                   >> 2U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128017___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027825_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027824_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027822_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027821_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___027824_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027788_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127849___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026381_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026380_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026378_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026377_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026380_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026344_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128433___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032218_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032217_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032215_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032214_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032217_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128433___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032181_)))));
    vlSelf->wasmetal_core__DOT___032789_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032821_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128480___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032821_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032820_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032819_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032818_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128480___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032785_)))));
    wasmetal_core__DOT___044564_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044578_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044577_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044576_)
                                                   ? 
                                                  (0xcU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h93fa449d__0))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044576_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044577_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044578_))));
    wasmetal_core__DOT___044584_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044598_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044597_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044596_)
                                                   ? 
                                                  (0xcU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he2c88566__0))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044596_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044597_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044598_))));
    vlSelf->__VdfgTmp_h3c0e85cc__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065475_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065474_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065478_));
    vlSelf->__VdfgTmp_h96c6858e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065368_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065367_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065371_));
    vlSelf->__VdfgTmp_h84a28025__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065213_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065212_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065216_));
    vlSelf->__VdfgTmp_h2f6e42c0__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___065136_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___065135_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___065139_));
    vlSelf->wasmetal_core__DOT___064977_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064949_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064948_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064947_)))))))));
    vlSelf->wasmetal_core__DOT___065252_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065245_))))));
    vlSelf->wasmetal_core__DOT___065340_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065333_))))));
    vlSelf->wasmetal_core__DOT___065449_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065444_))))));
    vlSelf->__VdfgTmp_h11c2cb19__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064961_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064960_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064964_));
    vlSelf->wasmetal_core__DOT___067125_ = (1U & (IData)(
                                                         (0xffcf0040ffcfffcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067123_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064812_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (1U 
                                                                          >> 
                                                                          (3U 
                                                                           & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))));
    vlSelf->__VdfgTmp_ha9e0ea4b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064809_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064808_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064812_));
    vlSelf->wasmetal_core__DOT___065669_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065668_))));
    vlSelf->__VdfgTmp_hcce0135b__0 = (((IData)(vlSelf->wasmetal_core__DOT___064156_) 
                                       << 1U) | (1U 
                                                 & (0x55330f0fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___064154_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_he8a45048__0)))));
    vlSelf->wasmetal_core__DOT___065864_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064940_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065863_))));
    vlSelf->wasmetal_core__DOT___065747_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064796_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065746_))));
    vlSelf->wasmetal_core__DOT___065980_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065104_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065979_))));
    vlSelf->wasmetal_core__DOT___067996_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067517_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066042_))));
    vlSelf->wasmetal_core__DOT___067928_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067415_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066240_))));
    vlSelf->wasmetal_core__DOT___066172_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066171_))));
    vlSelf->wasmetal_core__DOT___067874_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067373_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067633_))))));
    vlSelf->wasmetal_core__DOT___066450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065668_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066449_))));
    vlSelf->wasmetal_core__DOT___066694_ = (1U & (IData)(
                                                         (0xf7770000f333f333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x5cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h0f450401__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (3U 
                                                                              & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U))))))))))))))));
    vlSelf->wasmetal_core__DOT___067781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067229_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067780_))));
    vlSelf->wasmetal_core__DOT___067693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067692_))));
    vlSelf->wasmetal_core__DOT___067847_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067549_))))));
    vlSelf->wasmetal_core__DOT___065674_ = (1U & (IData)(
                                                         (0x330f5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064606_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___064621_))))))));
    vlSelf->wasmetal_core__DOT___064622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064606_))));
    vlSelf->wasmetal_core__DOT___065254_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064619_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065239_))))))));
    vlSelf->wasmetal_core__DOT___066048_ = (1U & (0xff55ccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065239_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha0b0298a__0)))));
    vlSelf->wasmetal_core__DOT___065451_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064614_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065438_))))))));
    vlSelf->wasmetal_core__DOT___066246_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065438_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf24dfeba__0)))))));
    vlSelf->wasmetal_core__DOT___066177_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065327_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hedd7926b__0)))))));
    vlSelf->wasmetal_core__DOT___065342_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hedd7926b__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064187_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___065327_))))))));
    vlSelf->wasmetal_core__DOT___065986_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065114_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0f450401__0)))))));
    vlSelf->wasmetal_core__DOT___067059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066449_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067058_))));
    vlSelf->wasmetal_core__DOT___067635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067634_))));
    vlSelf->wasmetal_core__DOT___067374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067373_))));
    vlSelf->wasmetal_core__DOT___066739_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066738_))));
    vlSelf->wasmetal_core__DOT___067230_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067229_))));
    vlSelf->wasmetal_core__DOT___066572_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066571_))));
    vlSelf->wasmetal_core__DOT___066929_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066928_))));
    vlSelf->wasmetal_core__DOT___067518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067517_))));
    vlSelf->wasmetal_core__DOT___067416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066823_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067415_))));
    vlSelf->wasmetal_core__DOT___066824_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066823_))));
    vlSelf->wasmetal_core__DOT___067120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066495_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067119_))));
    vlSelf->wasmetal_core__DOT___066496_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065746_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066495_))));
    vlSelf->wasmetal_core__DOT___066689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066688_))));
    vlSelf->wasmetal_core__DOT___067276_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066688_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067275_))));
    vlSelf->wasmetal_core__DOT___067012_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067011_))));
    vlSelf->wasmetal_core__DOT___067551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067011_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067550_))));
    vlSelf->wasmetal_core__DOT___065532_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065528_))))));
    vlSelf->wasmetal_core__DOT___066350_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066349_))));
    vlSelf->wasmetal_core__DOT___064981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064544_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064980_))));
    vlSelf->wasmetal_core__DOT___064561_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064560_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___066427_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066250_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066151_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066360_))));
    vlSelf->wasmetal_core__DOT___065269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064980_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065268_))));
    vlSelf->__VdfgTmp_h9d56b9e6__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064557_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064560_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                     << 1U)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___066251_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066054_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066250_))));
    vlSelf->__VdfgTmp_h23108600__0 = ((2U & ((0xacU 
                                              >> (((IData)(wasmetal_core__DOT___064043_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064054_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066152_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065988_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066151_))));
    vlSelf->wasmetal_core__DOT___065356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065090_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065355_))));
    vlSelf->wasmetal_core__DOT___065463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065268_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065462_))));
    vlSelf->wasmetal_core__DOT___066055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065873_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066054_))));
    vlSelf->wasmetal_core__DOT___064056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064043_))));
    vlSelf->wasmetal_core__DOT___065989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065775_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065988_))));
    vlSelf->wasmetal_core__DOT___064566_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064564_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064563_))));
    vlSelf->wasmetal_core__DOT___064989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064558_))));
    vlSelf->wasmetal_core__DOT___064789_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___064077_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064066_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___065678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065462_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065677_))));
    vlSelf->wasmetal_core__DOT___065874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065677_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065873_))));
    vlSelf->wasmetal_core__DOT___065537_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065355_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065536_))));
    vlSelf->wasmetal_core__DOT___065776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065536_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065775_))));
    vlSelf->wasmetal_core__DOT___065091_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064779_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065090_))));
    vlSelf->__VdfgTmp_ha92622e4__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064232_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064231_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064237_));
    vlSelf->wasmetal_core__DOT___066804_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065547_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064952_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064571_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064951_))));
    vlSelf->wasmetal_core__DOT___065639_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065453_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065547_))));
    vlSelf->wasmetal_core__DOT___065257_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064951_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065256_))));
    vlSelf->wasmetal_core__DOT___065454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065256_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065453_))));
    vlSelf->wasmetal_core__DOT___065345_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065121_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065344_))));
    vlSelf->wasmetal_core__DOT___064828_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064822_))))))));
    vlSelf->wasmetal_core__DOT___065122_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064822_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065121_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128684___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034655_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034652_)))) 
           ^ (((IData)(wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128684___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034715_)))));
    vlSelf->wasmetal_core__DOT___034719_ = ((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                            & (IData)(wasmetal_core__DOT___128684___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034660_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___034659_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___034657_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128717___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___034656_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128717___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035109_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035044_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128309___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030802_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030801_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030800_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030799_)))) 
           ^ (((IData)(wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128309___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030733_)))));
    vlSelf->wasmetal_core__DOT___030738_ = ((IData)(vlSelf->wasmetal_core__DOT___030802_)
                                             ? (IData)(wasmetal_core__DOT___128309___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d));
    wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)
            : (IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)
            : (IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032499_)
                  ? (IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032499_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128389___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031760_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031759_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031758_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031757_)))) 
           ^ (((IData)(wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128389___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031691_)))));
    vlSelf->wasmetal_core__DOT___031696_ = ((IData)(vlSelf->wasmetal_core__DOT___031760_)
                                             ? (IData)(wasmetal_core__DOT___128389___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128701___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128701___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034911_)))));
    vlSelf->wasmetal_core__DOT___034916_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)) 
                                            & (IData)(wasmetal_core__DOT___128701___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128220___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029938_)
              ? (IData)(vlSelf->wasmetal_core__DOT___128220___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___128220___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029938_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029937_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029935_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029934_)))) 
           ^ (((IData)(wasmetal_core__DOT___128220___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029900_)));
    vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d));
    vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026281_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026248_)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128489___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032890_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032887_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032886_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032889_)
                 ? (IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032853_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128473___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032698_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032697_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032694_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032697_)
                 ? (IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032661_)))));
    if ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O));
    } else {
        vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__));
    }
    wasmetal_core__DOT___044382_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                  >> 2U)))))))));
    wasmetal_core__DOT___045536_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                << 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                  >> 2U)))))))));
    wasmetal_core__DOT___045545_ = (1U & (IData)((0x7f13370177113300ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___045548_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                >> 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                                     >> 2U))))))))));
    wasmetal_core__DOT___045557_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128433___O) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128432___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032822_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032789_)
                  : (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O)));
    vlSelf->__VdfgTmp_h005ba8bd__0 = (((IData)(wasmetal_core__DOT___044584_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___044564_));
    vlSelf->wasmetal_core__DOT___065869_ = (1U & (IData)(
                                                         (0x55330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064969_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h11c2cb19__0)))))));
    vlSelf->wasmetal_core__DOT___065673_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065669_))));
    vlSelf->wasmetal_core__DOT___066355_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f7f000000ff0000ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b16__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064203_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_haf6246da__0))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x3aU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcce0135b__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066352_)))));
    vlSelf->wasmetal_core__DOT___065534_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((8U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064197_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcce0135b__0)))))));
    vlSelf->wasmetal_core__DOT___065866_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065864_))));
    vlSelf->wasmetal_core__DOT___065750_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065747_))));
    vlSelf->wasmetal_core__DOT___065984_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065980_))));
    vlSelf->wasmetal_core__DOT___066044_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066043_))));
    vlSelf->wasmetal_core__DOT___066243_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066241_))));
    vlSelf->wasmetal_core__DOT___066174_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066172_))));
    vlSelf->wasmetal_core__DOT___066454_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (1U 
                                                                    & (8U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066450_)))));
    vlSelf->wasmetal_core__DOT___064634_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064622_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064621_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064619_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xff00ff000f0fbbbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064617_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064192_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064616_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128568___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___066051_ = (1U & (IData)(
                                                         (0xf7770000f333f333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064200_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066048_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066047_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xbb0fU 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 2U) 
                                                                                | (2U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U))))))) 
                                                                                << 1U))))))))))))));
    vlSelf->wasmetal_core__DOT___067061_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065669_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067059_)))));
    vlSelf->__VdfgTmp_h46342433__0 = (((IData)(vlSelf->wasmetal_core__DOT___064632_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066450_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067635_))))));
    vlSelf->wasmetal_core__DOT___067376_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066043_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067374_)))));
    vlSelf->__VdfgTmp_hc01ceff5__0 = (((IData)(vlSelf->wasmetal_core__DOT___065252_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066739_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067874_))))));
    vlSelf->wasmetal_core__DOT___066741_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065245_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066739_)))));
    vlSelf->wasmetal_core__DOT___067232_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065864_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067230_)))));
    vlSelf->__VdfgTmp_h799a13b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___064948_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066572_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067781_))))));
    vlSelf->wasmetal_core__DOT___066574_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___064940_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066572_)))));
    vlSelf->__VdfgTmp_h066a303e__0 = (((IData)(vlSelf->wasmetal_core__DOT___065449_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066929_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067996_))))));
    vlSelf->wasmetal_core__DOT___066931_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065444_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066929_)))));
    vlSelf->wasmetal_core__DOT___067520_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066241_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067518_)))));
    vlSelf->wasmetal_core__DOT___067419_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066172_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067416_)))));
    vlSelf->__VdfgTmp_ha0f18469__0 = (((IData)(vlSelf->wasmetal_core__DOT___065340_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066824_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067928_))))));
    vlSelf->wasmetal_core__DOT___066826_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065333_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066824_)))));
    vlSelf->wasmetal_core__DOT___067121_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065747_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067120_)))));
    vlSelf->__VdfgTmp_hd3e9f05a__0 = (((IData)(vlSelf->wasmetal_core__DOT___064806_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066496_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067693_))))));
    vlSelf->wasmetal_core__DOT___066498_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (8U 
                                                               >> 
                                                               (1U 
                                                                & (4U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___064796_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066496_)))));
    vlSelf->__VdfgTmp_hd98b4743__0 = (((IData)(vlSelf->wasmetal_core__DOT___065112_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066689_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___067847_))))));
    vlSelf->wasmetal_core__DOT___066693_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___065104_)))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066689_)))));
    vlSelf->wasmetal_core__DOT___067277_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067276_)))));
    vlSelf->wasmetal_core__DOT___067014_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065528_)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067012_)))));
    vlSelf->__VdfgTmp_h01abed45__0 = (((IData)(vlSelf->wasmetal_core__DOT___065532_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067012_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067550_))))))));
    vlSelf->wasmetal_core__DOT___067552_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067551_)))));
    vlSelf->wasmetal_core__DOT___066354_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066350_))));
    vlSelf->__VdfgTmp_h2cdbdda9__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064558_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064557_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064561_));
    vlSelf->wasmetal_core__DOT___065270_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065269_))));
    vlSelf->wasmetal_core__DOT___066562_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066251_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066485_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066152_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066360_))))));
    vlSelf->wasmetal_core__DOT___065357_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064779_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065356_))));
    vlSelf->wasmetal_core__DOT___065464_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064981_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065463_))));
    vlSelf->wasmetal_core__DOT___066428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066427_))));
    vlSelf->wasmetal_core__DOT___064081_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064055_))));
    vlSelf->wasmetal_core__DOT___066362_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066361_))));
    vlSelf->wasmetal_core__DOT___065679_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065269_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065678_))));
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b30__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___019808_) {
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b46__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b45__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054556_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128642___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034323_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b45__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b44__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054555_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128642___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034322_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b44__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b43__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054554_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128642___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034321_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b43__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b42__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054553_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128641___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034320_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b42__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054552_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128641___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034319_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b41__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054551_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128641___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034318_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b40__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b39__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054550_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128641___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034317_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b39__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b38__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054549_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128655___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034315_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b38__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b37__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054548_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128655___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034314_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b37__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054547_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128655___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034313_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b36__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054546_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128655___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034312_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b35__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b34__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054545_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128654___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034311_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b34__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054544_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128654___O) 
                                                                    >> 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034310_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b33__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054543_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128654___O)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034309_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b32__05d 
            = (1U & (0xaa33f0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b31__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054542_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xc5U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128654___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___034308_)))))))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b31__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b30__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054573_))))));
        vlSelf->wasmetal_core__DOT__divider__02edividend__05b30__05d 
            = (1U & (0x44f0U >> (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b29__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054572_))))));
    }
    vlSelf->wasmetal_core__DOT___066056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066055_))));
    vlSelf->wasmetal_core__DOT___065875_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065463_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065874_))));
    vlSelf->wasmetal_core__DOT___066252_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066251_))));
    vlSelf->wasmetal_core__DOT___065990_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065989_))));
    vlSelf->wasmetal_core__DOT___066153_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065776_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066152_))));
    vlSelf->wasmetal_core__DOT___065777_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065776_))));
    vlSelf->wasmetal_core__DOT___065538_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065091_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065537_))));
    vlSelf->wasmetal_core__DOT___064954_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064952_))))));
    vlSelf->wasmetal_core__DOT___066722_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065639_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___066667_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065548_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___065640_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065639_))));
    vlSelf->wasmetal_core__DOT___065258_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064571_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065257_))));
    vlSelf->wasmetal_core__DOT___065835_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065454_))));
    vlSelf->wasmetal_core__DOT___065346_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064822_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065345_))));
    vlSelf->wasmetal_core__DOT___065735_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065345_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065547_))))));
    vlSelf->wasmetal_core__DOT___065124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065122_))))));
    vlSelf->wasmetal_core__DOT___065973_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065122_)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065548_)))))));
    vlSelf->__VdfgTmp_h20cdb85c__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___065122_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___065548_)))));
    vlSelf->wasmetal_core__DOT___128685___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034719_));
    vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035110_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d));
    vlSelf->wasmetal_core__DOT___128310___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030803_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030738_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128342___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128342___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031121_)))));
    vlSelf->wasmetal_core__DOT___031125_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128342___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128366___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128366___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031409_)))));
    vlSelf->wasmetal_core__DOT___031413_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d)
                                             : (IData)(wasmetal_core__DOT___128366___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128454___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032500_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032499_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032498_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032497_)))) 
           ^ (((IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128454___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032432_)))));
    vlSelf->wasmetal_core__DOT___032436_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032500_)
                                                   ? (IData)(wasmetal_core__DOT___128454___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032500_))));
    vlSelf->wasmetal_core__DOT___128390___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031761_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031696_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d));
    vlSelf->wasmetal_core__DOT___128702___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034916_));
    vlSelf->wasmetal_core__DOT___063289_ = (1U & (8U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___029769_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__)
                                                      : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d)) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128203___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026282_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d));
    vlSelf->wasmetal_core__DOT___070661_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128522___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033121_)))));
    if ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___033125_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033219_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
        vlSelf->wasmetal_core__DOT___033991_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                   >> 1U));
    } else {
        vlSelf->wasmetal_core__DOT___033125_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128522___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033219_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___033991_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128530___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128530___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033215_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128607___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128522___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128607___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033987_)))));
    vlSelf->wasmetal_core__DOT___044368_ = (1U & ((IData)(wasmetal_core__DOT___044382_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044381_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044380_)
                                                     ? 
                                                    (0xcU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd4f12848__0))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044380_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044381_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044382_))));
    vlSelf->wasmetal_core__DOT___053257_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___045557_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045553_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045552_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045550_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___045547_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___045554_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045549_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045551_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045556_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___045548_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045555_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___045525_ = ((IData)(wasmetal_core__DOT___045548_)
                                             ? ((IData)(wasmetal_core__DOT___045557_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045556_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045555_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045554_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045553_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045552_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045551_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045550_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045549_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045547_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045535_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045537_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045538_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045539_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045540_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045541_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045542_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045543_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045544_))
                                                 : (IData)(wasmetal_core__DOT___045545_))
                                             : (IData)(wasmetal_core__DOT___045536_));
    wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032823_)
                  ? (IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__)
                  : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                     >> 1U)));
    vlSelf->__VdfgTmp_h0e48eaa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___065673_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067059_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067634_))))))));
    vlSelf->wasmetal_core__DOT___065870_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065867_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065866_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0))))))))))));
    vlSelf->__VdfgTmp_h28baf300__0 = (((IData)(vlSelf->wasmetal_core__DOT___065866_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067230_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067780_))))))));
    vlSelf->__VdfgTmp_he6f0d7f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___065750_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067120_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___067692_))))))));
    vlSelf->wasmetal_core__DOT___065753_ = (1U & (0x20003fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065750_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___065749_))))));
    vlSelf->__VdfgTmp_h051c8ed8__0 = (((IData)(vlSelf->wasmetal_core__DOT___065984_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067276_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___067549_)) 
                                                                  << 1U)))))))));
    vlSelf->__VdfgTmp_hc00cbbb6__0 = (((IData)(vlSelf->wasmetal_core__DOT___066044_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067374_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___067633_)) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066050_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066044_)))));
    vlSelf->wasmetal_core__DOT___066247_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066244_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066243_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xfffe000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h88f593f0__0))))))))))));
    vlSelf->__VdfgTmp_h482142a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066243_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067518_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   (2U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                              << 1U)) 
                                                                            << 1U))) 
                                                                       << 1U))) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___066178_ = (1U & (IData)(
                                                         (0x3fff20003fff3fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066175_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066173_)))))))));
    vlSelf->__VdfgTmp_h0c18689a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066174_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067416_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   (2U 
                                                                    & ((1U 
                                                                        >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                                       << 1U))) 
                                                                  << 1U)))))))));
    vlSelf->__VdfgTmp_h6c009ef6__0 = (((IData)(vlSelf->wasmetal_core__DOT___066454_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067635_)))));
    vlSelf->__VdfgTmp_he7e046c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___067061_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067634_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___067639_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46342433__0))));
    vlSelf->__VdfgTmp_h1f61adb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___067376_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___067633_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___067878_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc01ceff5__0))));
    vlSelf->__VdfgTmp_hdbe4c80a__0 = (((IData)(vlSelf->wasmetal_core__DOT___066741_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067874_)))));
    vlSelf->__VdfgTmp_h7b734092__0 = (((IData)(vlSelf->wasmetal_core__DOT___067232_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067780_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_h37cccaef__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h799a13b5__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h90da4ee0__0)))));
    vlSelf->__VdfgTmp_h205cfcf2__0 = (((IData)(vlSelf->wasmetal_core__DOT___066574_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067781_)))));
    vlSelf->wasmetal_core__DOT___068001_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h066a303e__0))));
    vlSelf->wasmetal_core__DOT___066934_ = (1U & (IData)(
                                                         (0x4000cfff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b23__05d) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066931_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xffff01ffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h38f5e1f6__0)))))))))));
    vlSelf->__VdfgTmp_he61b9416__0 = (((IData)(vlSelf->wasmetal_core__DOT___066931_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067996_)))));
    vlSelf->__VdfgTmp_hf4f03bfc__0 = (((IData)(vlSelf->wasmetal_core__DOT___067520_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_hbbe8c33f__0 = (((IData)(vlSelf->wasmetal_core__DOT___067419_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___067548_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___067425_ = (1U & (IData)(
                                                         (0xffffff4000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067420_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___067419_)))))))));
    vlSelf->__VdfgTmp_h4f29c7eb__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha0f18469__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94800df3__0)))));
    vlSelf->__VdfgTmp_he5ddd7d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___066826_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067928_)))));
    vlSelf->__VdfgTmp_h1f0809ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___067121_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067692_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_he8248827__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_hd3e9f05a__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h321017d8__0)))));
    vlSelf->wasmetal_core__DOT___066513_ = (1U & (IData)(
                                                         (0xcccccccc5f000f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000cfffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b18__05d) 
                                                                              << 4U) 
                                                                             | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066498_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066497_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h3616a991__0)))))))))));
    vlSelf->__VdfgTmp_h44e97a03__0 = (((IData)(vlSelf->wasmetal_core__DOT___066498_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067693_)))));
    vlSelf->wasmetal_core__DOT___067850_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd98b4743__0))));
    vlSelf->wasmetal_core__DOT___066704_ = (1U & (0x40ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066694_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___066693_)))))));
    vlSelf->__VdfgTmp_h657da1af__0 = (((IData)(vlSelf->wasmetal_core__DOT___066693_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067847_)))));
    vlSelf->wasmetal_core__DOT___067290_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               >> 2U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067277_)))));
    vlSelf->__VdfgTmp_h33628a1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___067277_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___067549_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->__VdfgTmp_hb4521a0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___067014_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___067550_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O))))));
    vlSelf->wasmetal_core__DOT___069477_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b72__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hf36de292__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h01abed45__0))))));
    vlSelf->__VdfgTmp_h220538c2__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h01abed45__0))) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf36de292__0)))));
    vlSelf->wasmetal_core__DOT___069271_ = (1U & (IData)(
                                                         (0x20000000fcffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b64__05d) 
                                                            << 5U) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067552_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___064588_))))))));
    vlSelf->__VdfgTmp_h62827519__0 = (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___067552_));
    vlSelf->__VdfgTmp_h9b35e8c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___066354_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___067551_)))));
    vlSelf->wasmetal_core__DOT___066429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066428_))));
    vlSelf->wasmetal_core__DOT___065680_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065679_))));
    vlSelf->wasmetal_core__DOT___066057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066056_))));
    vlSelf->wasmetal_core__DOT___066730_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066056_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066427_))))));
    vlSelf->wasmetal_core__DOT___066563_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066562_))));
    vlSelf->wasmetal_core__DOT___065876_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064981_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065875_))));
    vlSelf->wasmetal_core__DOT___066936_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066252_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066253_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066252_))));
    vlSelf->wasmetal_core__DOT___066676_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065990_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066361_))))));
    vlSelf->wasmetal_core__DOT___065991_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065091_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065990_))));
    vlSelf->wasmetal_core__DOT___066154_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066153_))));
    vlSelf->wasmetal_core__DOT___066814_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066153_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___066360_)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065778_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064779_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065777_))));
    vlSelf->wasmetal_core__DOT___066486_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066485_))));
    vlSelf->wasmetal_core__DOT___066363_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065538_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066362_))));
    vlSelf->wasmetal_core__DOT___066421_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065640_))));
    vlSelf->wasmetal_core__DOT___065259_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065258_))));
    vlSelf->wasmetal_core__DOT___066554_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065835_))));
    vlSelf->wasmetal_core__DOT___065456_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065455_))));
    vlSelf->wasmetal_core__DOT___065347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065346_))));
    vlSelf->wasmetal_core__DOT___066475_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065735_))));
    vlSelf->__VdfgTmp_h90496874__0 = (((IData)(vlSelf->wasmetal_core__DOT___065973_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___065972_));
    vlSelf->__VdfgTmp_hfdfb8f5f__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h20cdb85c__0)) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___064570_)))));
    vlSelf->__VdfgTmp_h737b874d__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h20cdb85c__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___064570_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))));
    wasmetal_core__DOT___128685___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034657_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128685___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128718___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035111_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d));
    wasmetal_core__DOT___128310___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030804_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128310___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d));
    vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031125_));
    vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031413_));
    wasmetal_core__DOT___063242_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128454___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063248_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128454___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063254_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128454___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063260_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128454___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032501_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032436_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032501_))));
    wasmetal_core__DOT___128390___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031762_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128390___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d));
    wasmetal_core__DOT___128702___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128702___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128203___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___029769_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___029768_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___029766_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___029765_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128203___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___029731_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127841___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026285_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026284_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026282_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026281_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026284_)
                 ? (IData)(wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127841___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127841___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026248_)))));
    if ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))) {
        vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
        vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__ 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                     >> 2U));
    } else {
        vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033125_));
        vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033219_));
        vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___033991_));
    }
    vlSelf->wasmetal_core__DOT___063431_ = (1U & (IData)(
                                                         (0x11fff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbbbbfffff0ff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053257_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__copy_next__05b3__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___045941_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063375_)))))))));
    vlSelf->wasmetal_core__DOT___053258_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053257_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128481___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032826_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032825_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032823_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032822_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___032825_)
                       ? (IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__)
                       : ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                          >> 2U)) << 3U)) | (((IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__1__KET__) 
                                              << 2U) 
                                             | (((IData)(wasmetal_core__DOT___128481___DOT__CO__BRA__0__KET__) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___032789_)))));
    vlSelf->wasmetal_core__DOT___068129_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e48eaa1__0))));
    vlSelf->wasmetal_core__DOT___068215_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28baf300__0))));
    vlSelf->wasmetal_core__DOT___068177_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he6f0d7f4__0))));
    vlSelf->wasmetal_core__DOT___065756_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065753_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x55330f00000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 1U))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064817_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9e0ea4b__0)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x11f00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                >> 1U))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 2U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                                << 1U)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___068263_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h051c8ed8__0))));
    vlSelf->wasmetal_core__DOT___068321_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc00cbbb6__0))));
    vlSelf->wasmetal_core__DOT___068453_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h482142a8__0))));
    vlSelf->__VdfgTmp_hda165e4b__0 = ((2U & ((0xa3U 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h0c18689a__0))) 
                                             << 1U)) 
                                      | (1U & (0xc5U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h866f258c__0)))));
    vlSelf->wasmetal_core__DOT___068530_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c009ef6__0))));
    vlSelf->wasmetal_core__DOT___068922_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7e046c1__0))));
    vlSelf->wasmetal_core__DOT___069115_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f61adb3__0))));
    vlSelf->wasmetal_core__DOT___068726_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdbe4c80a__0))));
    vlSelf->wasmetal_core__DOT___069020_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b734092__0))));
    vlSelf->wasmetal_core__DOT___068629_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h205cfcf2__0))));
    vlSelf->wasmetal_core__DOT___068826_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he61b9416__0))));
    vlSelf->wasmetal_core__DOT___069210_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf4f03bfc__0))));
    vlSelf->wasmetal_core__DOT___069182_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbe8c33f__0))));
    vlSelf->wasmetal_core__DOT___068772_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he5ddd7d8__0))));
    vlSelf->wasmetal_core__DOT___068989_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1f0809ce__0))));
    vlSelf->wasmetal_core__DOT___068575_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h44e97a03__0))));
    vlSelf->wasmetal_core__DOT___070072_ = (1U & (IData)(
                                                         (0x5fcf00000f0f0f0fULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067850_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b100__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h102f49bb__0))))))));
    vlSelf->wasmetal_core__DOT___068674_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h657da1af__0))));
    vlSelf->wasmetal_core__DOT___069920_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b92__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((0xf5cfU 
                                                                 >> 
                                                                 ((0xcU 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                      << 1U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h33628a1f__0))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xfffe01ffffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                            << 5U) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))))))))))));
    vlSelf->wasmetal_core__DOT___069067_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33628a1f__0))));
    vlSelf->wasmetal_core__DOT___068867_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4521a0c__0))));
    vlSelf->wasmetal_core__DOT___069660_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xa82aaaaaaaaaaaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b80__05d))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9b35e8c1__0))))));
    vlSelf->wasmetal_core__DOT___068491_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9b35e8c1__0))));
    vlSelf->__VdfgTmp_ha994bb2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___066363_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___064543_));
    wasmetal_core__DOT___128685___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034659_) 
           & (IData)(wasmetal_core__DOT___128685___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128718___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035112_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035111_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035110_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035109_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128718___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128718___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035044_)))));
    vlSelf->wasmetal_core__DOT___035048_ = ((IData)(vlSelf->wasmetal_core__DOT___035112_)
                                             ? (IData)(wasmetal_core__DOT___128718___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d));
    wasmetal_core__DOT___128310___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030805_)
            ? (IData)(wasmetal_core__DOT___128310___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d));
    vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063244_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063242_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063241_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128219___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128366___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063250_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063247_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128219___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128366___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063256_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063254_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063253_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128219___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128366___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063262_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063260_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063259_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128219___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128366___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032502_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032502_))));
    wasmetal_core__DOT___128390___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031763_)
            ? (IData)(wasmetal_core__DOT___128390___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d));
    wasmetal_core__DOT___128702___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d)) 
           & (IData)(wasmetal_core__DOT___128702___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063271_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128203___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063277_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___063283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128203___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128523___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128523___S) 
           ^ ((8U & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O), 2U) 
                     << 1U)) | ((4U & (((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))
                                         ? ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                            >> 3U) : (IData)(vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__)) 
                                       << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___128523___DOT__CO__BRA__0__KET__) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___033125_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128531___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128523___S) 
           ^ ((8U & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O), 2U) 
                     << 1U)) | ((4U & (((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))
                                         ? ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                            >> 3U) : (IData)(vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__)) 
                                       << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___128531___DOT__CO__BRA__0__KET__) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___033219_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128608___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128523___S) 
           ^ ((8U & (VL_SHIFTR_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O), 2U) 
                     << 1U)) | ((4U & (((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))
                                         ? ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                            >> 3U) : (IData)(vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__)) 
                                       << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___128608___DOT__CO__BRA__0__KET__) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___033991_)))));
    vlSelf->wasmetal_core__DOT___053259_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053258_))));
    vlSelf->wasmetal_core__DOT___063376_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053258_))));
    vlSelf->wasmetal_core__DOT___070251_ = (1U & (IData)(
                                                         (0x7d55000055555555ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068491_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d))))))));
    vlSelf->wasmetal_core__DOT___068497_ = (1U & (IData)(
                                                         (0x7d55000055555555ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068491_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064588_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128685___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034660_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034659_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034657_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034656_)))) 
           ^ (((IData)(wasmetal_core__DOT___128685___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128685___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128685___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034719_)))));
    vlSelf->wasmetal_core__DOT___034724_ = ((IData)(vlSelf->wasmetal_core__DOT___034660_) 
                                            & (IData)(wasmetal_core__DOT___128685___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034664_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128718___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___034663_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128718___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___034662_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128718___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___034661_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128718___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___128719___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035113_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035048_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128310___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030806_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030805_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030804_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030803_)))) 
           ^ (((IData)(wasmetal_core__DOT___128310___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128310___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128310___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030738_)))));
    vlSelf->wasmetal_core__DOT___030742_ = ((IData)(vlSelf->wasmetal_core__DOT___030806_)
                                             ? (IData)(wasmetal_core__DOT___128310___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d));
    vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032504_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032504_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128390___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031764_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031762_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031761_)))) 
           ^ (((IData)(wasmetal_core__DOT___128390___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128390___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128390___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031696_)))));
    vlSelf->wasmetal_core__DOT___031700_ = ((IData)(vlSelf->wasmetal_core__DOT___031764_)
                                             ? (IData)(wasmetal_core__DOT___128390___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128702___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128702___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128702___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128702___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034916_)))));
    vlSelf->wasmetal_core__DOT___034920_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d)) 
                                            & (IData)(wasmetal_core__DOT___128702___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063420_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063376_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h13477f5c__0))));
    vlSelf->wasmetal_core__DOT___063378_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063376_))));
    wasmetal_core__DOT___128686___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034661_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034724_));
    wasmetal_core__DOT___128719___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035114_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128719___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d));
    wasmetal_core__DOT___128311___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030807_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030742_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128343___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b30__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b29__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b28__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031125_)))));
    wasmetal_core__DOT___031130_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b31__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128343___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128367___O = (
                                                   ((8U 
                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___031413_)))));
    wasmetal_core__DOT___031418_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d)
                                     : (IData)(vlSelf->wasmetal_core__DOT___128367___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128455___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___032505_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___032504_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___032502_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032501_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032436_)))));
    wasmetal_core__DOT___032441_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032505_)
                                           ? (IData)(vlSelf->wasmetal_core__DOT___128455___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032505_))));
    wasmetal_core__DOT___128391___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031765_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031700_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d));
    wasmetal_core__DOT___128703___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034920_));
    wasmetal_core__DOT___128686___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034662_) 
           & (IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128719___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035115_)
            ? (IData)(wasmetal_core__DOT___128719___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d));
    wasmetal_core__DOT___128311___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030808_)
            ? (IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d));
    wasmetal_core__DOT___128344___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d)
            : (IData)(wasmetal_core__DOT___031130_));
    wasmetal_core__DOT___128368___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d)
            : (IData)(wasmetal_core__DOT___031418_));
    wasmetal_core__DOT___063266_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128455___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063272_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128455___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063278_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128455___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___063284_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128455___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128456___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032506_)
                  ? (IData)(wasmetal_core__DOT___032441_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032506_))));
    wasmetal_core__DOT___128391___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031766_)
            ? (IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d));
    wasmetal_core__DOT___128703___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d)) 
           & (IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128686___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034663_) 
           & (IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128719___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035116_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035115_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035114_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035113_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128719___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128719___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128719___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035048_)))));
    wasmetal_core__DOT___035052_ = ((IData)(vlSelf->wasmetal_core__DOT___035116_)
                                     ? (IData)(wasmetal_core__DOT___128719___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d));
    wasmetal_core__DOT___128311___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030810_)
            ? (IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d));
    wasmetal_core__DOT___128344___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d)
            : (IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128368___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d)
            : (IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063268_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063266_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063265_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128220___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128367___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063274_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063272_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063271_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128220___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128367___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063280_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063278_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063277_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128220___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___128367___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    vlSelf->wasmetal_core__DOT___063286_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063283_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128220___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(wasmetal_core__DOT____Vcellout___128367___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128456___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032507_)
                  ? (IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032507_))));
    wasmetal_core__DOT___128391___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031768_)
            ? (IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d));
    wasmetal_core__DOT___128703___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d)) 
           & (IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128686___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034664_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034663_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034662_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034661_)))) 
           ^ (((IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034724_)))));
    wasmetal_core__DOT___034728_ = ((IData)(vlSelf->wasmetal_core__DOT___034664_) 
                                    & (IData)(wasmetal_core__DOT___128686___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034668_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128719___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___034667_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128719___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___034666_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128719___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___034665_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128719___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))));
    wasmetal_core__DOT___128705___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035118_)
            ? (IData)(wasmetal_core__DOT___035052_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128311___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030811_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030810_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030808_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030807_)))) 
           ^ (((IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030742_)))));
    wasmetal_core__DOT___030747_ = ((IData)(vlSelf->wasmetal_core__DOT___030811_)
                                     ? (IData)(wasmetal_core__DOT___128311___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d));
    wasmetal_core__DOT___128344___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d)
            : (IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128368___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d)
            : (IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128456___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032508_)
                  ? (IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032508_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128391___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031769_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031768_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031766_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031765_)))) 
           ^ (((IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031700_)))));
    wasmetal_core__DOT___031705_ = ((IData)(vlSelf->wasmetal_core__DOT___031769_)
                                     ? (IData)(wasmetal_core__DOT___128391___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128703___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034920_)))));
    wasmetal_core__DOT___034924_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d)) 
                                    & (IData)(wasmetal_core__DOT___128703___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128687___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034665_) 
           & (IData)(wasmetal_core__DOT___034728_));
    wasmetal_core__DOT___128705___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035119_)
            ? (IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d));
    wasmetal_core__DOT___128312___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030812_)
            ? (IData)(wasmetal_core__DOT___030747_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128344___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031130_)))));
    wasmetal_core__DOT___031134_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b35__05d)
                                     : (IData)(wasmetal_core__DOT___128344___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128368___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031418_)))));
    wasmetal_core__DOT___031422_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d)
                                     : (IData)(wasmetal_core__DOT___128368___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128456___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032509_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032508_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032507_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032506_)))) 
           ^ (((IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032441_)))));
    wasmetal_core__DOT___032445_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032509_)
                                           ? (IData)(wasmetal_core__DOT___128456___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032509_))));
    wasmetal_core__DOT___128392___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031770_)
            ? (IData)(wasmetal_core__DOT___031705_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d));
    wasmetal_core__DOT___128689___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d)) 
           & (IData)(wasmetal_core__DOT___034924_));
    wasmetal_core__DOT___128687___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034666_) 
           & (IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128705___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035120_)
            ? (IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d));
    wasmetal_core__DOT___128312___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030813_)
            ? (IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d));
    wasmetal_core__DOT___128345___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d)
            : (IData)(wasmetal_core__DOT___031134_));
    wasmetal_core__DOT___128369___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d)
            : (IData)(wasmetal_core__DOT___031422_));
    wasmetal_core__DOT___063290_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128456___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048482_))));
    wasmetal_core__DOT___128457___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032510_)
                  ? (IData)(wasmetal_core__DOT___032445_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032510_))));
    wasmetal_core__DOT___128392___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031771_)
            ? (IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d));
    wasmetal_core__DOT___128689___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d)) 
           & (IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128687___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034667_) 
           & (IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128705___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035121_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035120_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035119_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035118_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035052_)))));
    wasmetal_core__DOT___035057_ = ((IData)(vlSelf->wasmetal_core__DOT___035121_)
                                     ? (IData)(wasmetal_core__DOT___128705___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d));
    wasmetal_core__DOT___128312___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030814_)
            ? (IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d));
    wasmetal_core__DOT___128345___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d)
            : (IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128369___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d)
            : (IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___063292_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063290_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063289_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128220___CO)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128368___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e4445d3__0))))))));
    wasmetal_core__DOT___128457___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032511_)
                  ? (IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032511_))));
    wasmetal_core__DOT___128392___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031772_)
            ? (IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d));
    wasmetal_core__DOT___128689___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d)) 
           & (IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128687___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034668_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034667_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034666_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034665_)))) 
           ^ (((IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034728_)))));
    wasmetal_core__DOT___034732_ = ((IData)(vlSelf->wasmetal_core__DOT___034668_) 
                                    & (IData)(wasmetal_core__DOT___128687___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034673_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128705___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___034672_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128705___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___034671_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128705___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___034670_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128705___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d)))));
    wasmetal_core__DOT___128706___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035122_)
            ? (IData)(wasmetal_core__DOT___035057_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128312___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030815_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030814_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030813_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030812_)))) 
           ^ (((IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030747_)))));
    wasmetal_core__DOT___030751_ = ((IData)(vlSelf->wasmetal_core__DOT___030815_)
                                     ? (IData)(wasmetal_core__DOT___128312___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d));
    wasmetal_core__DOT___128345___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d)
            : (IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128369___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d)
            : (IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128457___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032512_)
                  ? (IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032512_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128392___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031773_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031772_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031771_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031770_)))) 
           ^ (((IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031705_)))));
    wasmetal_core__DOT___031709_ = ((IData)(vlSelf->wasmetal_core__DOT___031773_)
                                     ? (IData)(wasmetal_core__DOT___128392___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128689___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034924_)))));
    wasmetal_core__DOT___034929_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d)) 
                                    & (IData)(wasmetal_core__DOT___128689___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128673___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034670_) 
           & (IData)(wasmetal_core__DOT___034732_));
    wasmetal_core__DOT___128706___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035123_)
            ? (IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d));
    wasmetal_core__DOT___128313___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030816_)
            ? (IData)(wasmetal_core__DOT___030751_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128345___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b36__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031134_)))));
    wasmetal_core__DOT___031138_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b39__05d)
                                     : (IData)(wasmetal_core__DOT___128345___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128369___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031422_)))));
    wasmetal_core__DOT___031426_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d)
                                     : (IData)(wasmetal_core__DOT___128369___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128457___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032513_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032512_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032511_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032510_)))) 
           ^ (((IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032445_)))));
    wasmetal_core__DOT___032449_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032513_)
                                           ? (IData)(wasmetal_core__DOT___128457___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032513_))));
    wasmetal_core__DOT___128393___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031774_)
            ? (IData)(wasmetal_core__DOT___031709_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d));
    wasmetal_core__DOT___128690___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d)) 
           & (IData)(wasmetal_core__DOT___034929_));
    wasmetal_core__DOT___128673___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034671_) 
           & (IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128706___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035124_)
            ? (IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d));
    wasmetal_core__DOT___128313___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030817_)
            ? (IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d));
    wasmetal_core__DOT___128331___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d)
            : (IData)(wasmetal_core__DOT___031138_));
    wasmetal_core__DOT___128355___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d)
            : (IData)(wasmetal_core__DOT___031426_));
    wasmetal_core__DOT___128443___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032515_)
                  ? (IData)(wasmetal_core__DOT___032449_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032515_))));
    wasmetal_core__DOT___128393___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031775_)
            ? (IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d));
    wasmetal_core__DOT___128690___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d)) 
           & (IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128673___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034672_) 
           & (IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128706___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035125_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035124_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035123_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035122_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035057_)))));
    wasmetal_core__DOT___035061_ = ((IData)(vlSelf->wasmetal_core__DOT___035125_)
                                     ? (IData)(wasmetal_core__DOT___128706___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d));
    wasmetal_core__DOT___128313___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030818_)
            ? (IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d));
    wasmetal_core__DOT___128331___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d)
            : (IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128355___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d)
            : (IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128443___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032516_)
                  ? (IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032516_))));
    wasmetal_core__DOT___128393___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031776_)
            ? (IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d));
    wasmetal_core__DOT___128690___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d)) 
           & (IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128673___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034673_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034672_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034671_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034670_)))) 
           ^ (((IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034732_)))));
    wasmetal_core__DOT___034737_ = ((IData)(vlSelf->wasmetal_core__DOT___034673_) 
                                    & (IData)(wasmetal_core__DOT___128673___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034677_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128706___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___034676_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128706___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___034675_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128706___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___034674_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128706___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d)))));
    wasmetal_core__DOT___128707___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035126_)
            ? (IData)(wasmetal_core__DOT___035061_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128313___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030819_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030818_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030817_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030816_)))) 
           ^ (((IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030751_)))));
    wasmetal_core__DOT___030755_ = ((IData)(vlSelf->wasmetal_core__DOT___030819_)
                                     ? (IData)(wasmetal_core__DOT___128313___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d));
    wasmetal_core__DOT___128331___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d)
            : (IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128355___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d)
            : (IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128443___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032517_)
                  ? (IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032517_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128393___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031777_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031776_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031775_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031774_)))) 
           ^ (((IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031709_)))));
    wasmetal_core__DOT___031713_ = ((IData)(vlSelf->wasmetal_core__DOT___031777_)
                                     ? (IData)(wasmetal_core__DOT___128393___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128690___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034929_)))));
    wasmetal_core__DOT___034933_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d)) 
                                    & (IData)(wasmetal_core__DOT___128690___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128674___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034674_) 
           & (IData)(wasmetal_core__DOT___034737_));
    wasmetal_core__DOT___128707___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035127_)
            ? (IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d));
    wasmetal_core__DOT___128299___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030821_)
            ? (IData)(wasmetal_core__DOT___030755_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128331___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b40__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031138_)))));
    wasmetal_core__DOT___031143_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b43__05d)
                                     : (IData)(wasmetal_core__DOT___128331___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128355___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031426_)))));
    wasmetal_core__DOT___031431_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d)
                                     : (IData)(wasmetal_core__DOT___128355___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128443___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032518_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032517_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032516_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032515_)))) 
           ^ (((IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032449_)))));
    wasmetal_core__DOT___032454_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032518_)
                                           ? (IData)(wasmetal_core__DOT___128443___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032518_))));
    wasmetal_core__DOT___128379___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031779_)
            ? (IData)(wasmetal_core__DOT___031713_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d));
    wasmetal_core__DOT___128691___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d)) 
           & (IData)(wasmetal_core__DOT___034933_));
    wasmetal_core__DOT___128674___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034675_) 
           & (IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128707___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035129_)
            ? (IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d));
    wasmetal_core__DOT___128299___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030822_)
            ? (IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d));
    wasmetal_core__DOT___128332___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d)
            : (IData)(wasmetal_core__DOT___031143_));
    wasmetal_core__DOT___128356___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d)
            : (IData)(wasmetal_core__DOT___031431_));
    wasmetal_core__DOT___128444___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032519_)
                  ? (IData)(wasmetal_core__DOT___032454_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032519_))));
    wasmetal_core__DOT___128379___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031780_)
            ? (IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d));
    wasmetal_core__DOT___128691___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d)) 
           & (IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128674___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034676_) 
           & (IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128707___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035130_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035129_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035127_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035126_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035061_)))));
    wasmetal_core__DOT___035066_ = ((IData)(vlSelf->wasmetal_core__DOT___035130_)
                                     ? (IData)(wasmetal_core__DOT___128707___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d));
    wasmetal_core__DOT___128299___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030823_)
            ? (IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d));
    wasmetal_core__DOT___128332___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d)
            : (IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128356___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d)
            : (IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128444___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032520_)
                  ? (IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032520_))));
    wasmetal_core__DOT___128379___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031781_)
            ? (IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d));
    wasmetal_core__DOT___128691___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d)) 
           & (IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128674___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034677_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034676_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034675_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034674_)))) 
           ^ (((IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034737_)))));
    wasmetal_core__DOT___034741_ = ((IData)(vlSelf->wasmetal_core__DOT___034677_) 
                                    & (IData)(wasmetal_core__DOT___128674___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034682_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128707___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___034681_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128707___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___034679_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128707___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___034678_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128707___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))));
    wasmetal_core__DOT___128708___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035131_)
            ? (IData)(wasmetal_core__DOT___035066_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128299___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030824_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030823_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030822_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030821_)))) 
           ^ (((IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030755_)))));
    wasmetal_core__DOT___030760_ = ((IData)(vlSelf->wasmetal_core__DOT___030824_)
                                     ? (IData)(wasmetal_core__DOT___128299___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d));
    wasmetal_core__DOT___128332___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d)
            : (IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128356___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d)
            : (IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128444___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032521_)
                  ? (IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032521_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128379___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031782_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031781_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031780_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031779_)))) 
           ^ (((IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031713_)))));
    wasmetal_core__DOT___031718_ = ((IData)(vlSelf->wasmetal_core__DOT___031782_)
                                     ? (IData)(wasmetal_core__DOT___128379___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128691___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034933_)))));
    wasmetal_core__DOT___034938_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d)) 
                                    & (IData)(wasmetal_core__DOT___128691___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128675___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034678_) 
           & (IData)(wasmetal_core__DOT___034741_));
    wasmetal_core__DOT___128708___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035132_)
            ? (IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d));
    wasmetal_core__DOT___128300___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030825_)
            ? (IData)(wasmetal_core__DOT___030760_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128332___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031143_)))));
    wasmetal_core__DOT___031147_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b47__05d)
                                     : (IData)(wasmetal_core__DOT___128332___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128356___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031431_)))));
    wasmetal_core__DOT___031435_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d)
                                     ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d)
                                     : (IData)(wasmetal_core__DOT___128356___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128444___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032522_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032521_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032520_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032519_)))) 
           ^ (((IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032454_)))));
    wasmetal_core__DOT___032458_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032522_)
                                           ? (IData)(wasmetal_core__DOT___128444___DOT__CO__BRA__2__KET__)
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___032522_))));
    wasmetal_core__DOT___128380___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031783_)
            ? (IData)(wasmetal_core__DOT___031718_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d));
    wasmetal_core__DOT___128692___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d)) 
           & (IData)(wasmetal_core__DOT___034938_));
    wasmetal_core__DOT___128675___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034679_) 
           & (IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128708___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035133_)
            ? (IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d));
    wasmetal_core__DOT___128300___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030826_)
            ? (IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d));
    wasmetal_core__DOT___128333___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d)
            : (IData)(wasmetal_core__DOT___031147_));
    wasmetal_core__DOT___128357___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d)
            : (IData)(wasmetal_core__DOT___031435_));
    wasmetal_core__DOT___128445___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032523_)
                  ? (IData)(wasmetal_core__DOT___032458_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032523_))));
    wasmetal_core__DOT___128380___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031784_)
            ? (IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d));
    wasmetal_core__DOT___128692___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d)) 
           & (IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128675___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034681_) 
           & (IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128708___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035134_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035133_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035132_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035131_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035066_)))));
    wasmetal_core__DOT___035070_ = ((IData)(vlSelf->wasmetal_core__DOT___035134_)
                                     ? (IData)(wasmetal_core__DOT___128708___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d));
    wasmetal_core__DOT___128300___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030827_)
            ? (IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d));
    wasmetal_core__DOT___128333___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d)
            : (IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128357___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d)
            : (IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128445___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032524_)
                  ? (IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032524_))));
    wasmetal_core__DOT___128380___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031785_)
            ? (IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d));
    wasmetal_core__DOT___128692___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d)) 
           & (IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128675___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034682_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034681_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034679_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034678_)))) 
           ^ (((IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034741_)))));
    wasmetal_core__DOT___034746_ = ((IData)(vlSelf->wasmetal_core__DOT___034682_) 
                                    & (IData)(wasmetal_core__DOT___128675___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034686_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128708___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___034685_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128708___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___034684_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128708___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d)))));
    vlSelf->wasmetal_core__DOT___034683_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128708___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d)))));
    wasmetal_core__DOT___128709___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035135_)
            ? (IData)(wasmetal_core__DOT___035070_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128300___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030828_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030827_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030826_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030825_)))) 
           ^ (((IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030760_)))));
    vlSelf->wasmetal_core__DOT___030764_ = ((IData)(vlSelf->wasmetal_core__DOT___030828_)
                                             ? (IData)(wasmetal_core__DOT___128300___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d));
    wasmetal_core__DOT___128333___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d)
            : (IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128357___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d)
            : (IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128445___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032526_)
                  ? (IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032526_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128380___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031786_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031785_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031784_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031783_)))) 
           ^ (((IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031718_)))));
    vlSelf->wasmetal_core__DOT___031722_ = ((IData)(vlSelf->wasmetal_core__DOT___031786_)
                                             ? (IData)(wasmetal_core__DOT___128380___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128692___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034938_)))));
    vlSelf->wasmetal_core__DOT___034942_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d)) 
                                            & (IData)(wasmetal_core__DOT___128692___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128676___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034683_) 
           & (IData)(wasmetal_core__DOT___034746_));
    wasmetal_core__DOT___128709___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035136_)
            ? (IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d));
    vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030829_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030764_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128333___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031147_)))));
    vlSelf->wasmetal_core__DOT___031152_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b51__05d)
                                             : (IData)(wasmetal_core__DOT___128333___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128357___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031435_)))));
    vlSelf->wasmetal_core__DOT___031440_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d)
                                             : (IData)(wasmetal_core__DOT___128357___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128445___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032527_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032526_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032524_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032523_)))) 
           ^ (((IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___032458_)))));
    vlSelf->wasmetal_core__DOT___032463_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032527_)
                                                   ? (IData)(wasmetal_core__DOT___128445___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032527_))));
    vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031787_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031722_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d));
    vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034942_));
    wasmetal_core__DOT___128676___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034684_) 
           & (IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128709___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035137_)
            ? (IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d));
    vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030830_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d));
    vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031152_));
    vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031440_));
    vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032528_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032463_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032528_))));
    vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031788_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d));
    vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128676___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034685_) 
           & (IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128709___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035138_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035137_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035136_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035135_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035070_)))));
    vlSelf->wasmetal_core__DOT___035074_ = ((IData)(vlSelf->wasmetal_core__DOT___035138_)
                                             ? (IData)(wasmetal_core__DOT___128709___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d));
    vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030832_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d));
    vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032529_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032529_))));
    vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031790_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d));
    vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128676___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034686_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034685_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034684_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034683_)))) 
           ^ (((IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034746_)))));
    vlSelf->wasmetal_core__DOT___034750_ = ((IData)(vlSelf->wasmetal_core__DOT___034686_) 
                                            & (IData)(wasmetal_core__DOT___128676___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034690_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128709___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d)))));
    vlSelf->wasmetal_core__DOT___034689_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128709___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___034688_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128709___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))));
    vlSelf->wasmetal_core__DOT___034687_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128709___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d)))));
    wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035140_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035074_)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128301___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030833_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030832_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030830_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030829_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030764_)))));
    wasmetal_core__DOT___030769_ = ((IData)(vlSelf->wasmetal_core__DOT___030833_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128301___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d));
    wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032530_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032530_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128381___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031791_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031790_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031788_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031787_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031722_)))));
    wasmetal_core__DOT___031727_ = ((IData)(vlSelf->wasmetal_core__DOT___031791_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128381___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128693___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034942_)))));
    wasmetal_core__DOT___034946_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128693___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034687_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034750_));
    wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035141_)
            ? (IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d));
    wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030834_)
            ? (IData)(wasmetal_core__DOT___030769_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128334___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128334___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031152_)))));
    vlSelf->wasmetal_core__DOT___031156_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b55__05d)
                                             : (IData)(wasmetal_core__DOT___128334___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128358___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128358___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031440_)))));
    vlSelf->wasmetal_core__DOT___031444_ = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d)
                                             : (IData)(wasmetal_core__DOT___128358___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128446___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032531_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032530_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032529_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032528_)))) 
           ^ (((IData)(wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128446___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032463_)))));
    vlSelf->wasmetal_core__DOT___032467_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032531_)
                                                   ? (IData)(wasmetal_core__DOT___128446___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___032531_))));
    wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031792_)
            ? (IData)(wasmetal_core__DOT___031727_)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d));
    wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)) 
           & (IData)(wasmetal_core__DOT___034946_));
    wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034688_) 
           & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128710___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035143_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035142_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035141_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035140_)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___035142_)
                                                       ? (IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128710___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035074_)))));
    wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030835_)
            ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b56__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031156_));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031444_));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032532_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___032467_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032532_))));
    wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031793_)
            ? (IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d));
    wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)) 
           & (IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034689_) 
           & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___034695_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___034694_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___034693_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128710___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d)))));
    vlSelf->wasmetal_core__DOT___034692_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128710___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))));
    wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030836_)
            ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b57__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032533_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032533_))));
    vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031794_)
            ? (IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128694___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)) 
                & (IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128694___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034946_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128677___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034690_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034687_)))) 
           ^ (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034750_)))));
    vlSelf->wasmetal_core__DOT___034754_ = ((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                            & (IData)(wasmetal_core__DOT___128677___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128302___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030837_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030836_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030835_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030834_)))) 
           ^ (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___030769_)))));
    vlSelf->wasmetal_core__DOT___030773_ = ((IData)(vlSelf->wasmetal_core__DOT___030837_)
                                             ? (IData)(wasmetal_core__DOT___128302___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d));
    vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b58__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128335___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128359___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___032534_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128447___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___032534_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128382___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031795_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031794_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031793_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031792_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128382___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128382___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___031727_)))));
}
