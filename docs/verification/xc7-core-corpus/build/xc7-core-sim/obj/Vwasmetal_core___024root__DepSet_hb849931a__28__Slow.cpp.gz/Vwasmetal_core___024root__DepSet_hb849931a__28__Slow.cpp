#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__46(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__46\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___008807_;
    wasmetal_core__DOT___008807_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009686_;
    wasmetal_core__DOT___009686_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009687_;
    wasmetal_core__DOT___009687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009688_;
    wasmetal_core__DOT___009688_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009689_;
    wasmetal_core__DOT___009689_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009896_;
    wasmetal_core__DOT___009896_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010654_;
    wasmetal_core__DOT___010654_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010657_;
    wasmetal_core__DOT___010657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___010658_;
    wasmetal_core__DOT___010658_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013630_;
    wasmetal_core__DOT___013630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035598_;
    wasmetal_core__DOT___035598_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035918_;
    wasmetal_core__DOT___035918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036346_;
    wasmetal_core__DOT___036346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043164_;
    wasmetal_core__DOT___043164_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043165_;
    wasmetal_core__DOT___043165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043166_;
    wasmetal_core__DOT___043166_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043168_;
    wasmetal_core__DOT___043168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043173_;
    wasmetal_core__DOT___043173_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043175_;
    wasmetal_core__DOT___043175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043181_;
    wasmetal_core__DOT___043181_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043182_;
    wasmetal_core__DOT___043182_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043184_;
    wasmetal_core__DOT___043184_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043187_;
    wasmetal_core__DOT___043187_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043188_;
    wasmetal_core__DOT___043188_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043189_;
    wasmetal_core__DOT___043189_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043190_;
    wasmetal_core__DOT___043190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043191_;
    wasmetal_core__DOT___043191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043192_;
    wasmetal_core__DOT___043192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043193_;
    wasmetal_core__DOT___043193_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043194_;
    wasmetal_core__DOT___043194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043195_;
    wasmetal_core__DOT___043195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043196_;
    wasmetal_core__DOT___043196_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043198_;
    wasmetal_core__DOT___043198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043199_;
    wasmetal_core__DOT___043199_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043204_;
    wasmetal_core__DOT___043204_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043205_;
    wasmetal_core__DOT___043205_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043206_;
    wasmetal_core__DOT___043206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043207_;
    wasmetal_core__DOT___043207_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043607_;
    wasmetal_core__DOT___043607_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043608_;
    wasmetal_core__DOT___043608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043609_;
    wasmetal_core__DOT___043609_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043610_;
    wasmetal_core__DOT___043610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043611_;
    wasmetal_core__DOT___043611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043612_;
    wasmetal_core__DOT___043612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043613_;
    wasmetal_core__DOT___043613_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043614_;
    wasmetal_core__DOT___043614_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043615_;
    wasmetal_core__DOT___043615_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043616_;
    wasmetal_core__DOT___043616_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043618_;
    wasmetal_core__DOT___043618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043619_;
    wasmetal_core__DOT___043619_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043623_;
    wasmetal_core__DOT___043623_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043624_;
    wasmetal_core__DOT___043624_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043625_;
    wasmetal_core__DOT___043625_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043626_;
    wasmetal_core__DOT___043626_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055722_;
    wasmetal_core__DOT___055722_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055733_;
    wasmetal_core__DOT___055733_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055865_;
    wasmetal_core__DOT___055865_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055875_;
    wasmetal_core__DOT___055875_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055880_;
    wasmetal_core__DOT___055880_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055893_;
    wasmetal_core__DOT___055893_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055905_;
    wasmetal_core__DOT___055905_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055913_;
    wasmetal_core__DOT___055913_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055919_;
    wasmetal_core__DOT___055919_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055930_;
    wasmetal_core__DOT___055930_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055968_;
    wasmetal_core__DOT___055968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055973_;
    wasmetal_core__DOT___055973_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055980_;
    wasmetal_core__DOT___055980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056020_;
    wasmetal_core__DOT___056020_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056051_;
    wasmetal_core__DOT___056051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056139_;
    wasmetal_core__DOT___056139_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056140_;
    wasmetal_core__DOT___056140_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056212_;
    wasmetal_core__DOT___056212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056215_;
    wasmetal_core__DOT___056215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056217_;
    wasmetal_core__DOT___056217_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056354_;
    wasmetal_core__DOT___056354_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056357_;
    wasmetal_core__DOT___056357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056358_;
    wasmetal_core__DOT___056358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056362_;
    wasmetal_core__DOT___056362_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056363_;
    wasmetal_core__DOT___056363_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056364_;
    wasmetal_core__DOT___056364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068410_;
    wasmetal_core__DOT___068410_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068805_;
    wasmetal_core__DOT___068805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070517_;
    wasmetal_core__DOT___070517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070518_;
    wasmetal_core__DOT___070518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070526_;
    wasmetal_core__DOT___070526_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070528_;
    wasmetal_core__DOT___070528_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070529_;
    wasmetal_core__DOT___070529_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070530_;
    wasmetal_core__DOT___070530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070531_;
    wasmetal_core__DOT___070531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070537_;
    wasmetal_core__DOT___070537_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070538_;
    wasmetal_core__DOT___070538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070539_;
    wasmetal_core__DOT___070539_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070542_;
    wasmetal_core__DOT___070542_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070543_;
    wasmetal_core__DOT___070543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070544_;
    wasmetal_core__DOT___070544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070545_;
    wasmetal_core__DOT___070545_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070547_;
    wasmetal_core__DOT___070547_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070548_;
    wasmetal_core__DOT___070548_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070549_;
    wasmetal_core__DOT___070549_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070550_;
    wasmetal_core__DOT___070550_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070551_;
    wasmetal_core__DOT___070551_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070552_;
    wasmetal_core__DOT___070552_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070553_;
    wasmetal_core__DOT___070553_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070554_;
    wasmetal_core__DOT___070554_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070555_;
    wasmetal_core__DOT___070555_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070556_;
    wasmetal_core__DOT___070556_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070557_;
    wasmetal_core__DOT___070557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070558_;
    wasmetal_core__DOT___070558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070559_;
    wasmetal_core__DOT___070559_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070560_;
    wasmetal_core__DOT___070560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070561_;
    wasmetal_core__DOT___070561_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070562_;
    wasmetal_core__DOT___070562_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070563_;
    wasmetal_core__DOT___070563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070564_;
    wasmetal_core__DOT___070564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071743_;
    wasmetal_core__DOT___071743_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071746_;
    wasmetal_core__DOT___071746_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127497___O;
    wasmetal_core__DOT____Vcellout___127497___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127498___O;
    wasmetal_core__DOT____Vcellout___127498___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127530___O;
    wasmetal_core__DOT____Vcellout___127530___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127531___O;
    wasmetal_core__DOT____Vcellout___127531___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h242203a7__0;
    __VdfgTmp_h242203a7__0 = 0;
    CData/*1:0*/ __VdfgTmp_h40167917__0;
    __VdfgTmp_h40167917__0 = 0;
    CData/*5:0*/ __VdfgTmp_h2dd5429b__0;
    __VdfgTmp_h2dd5429b__0 = 0;
    CData/*5:0*/ __VdfgTmp_hc61624da__0;
    __VdfgTmp_hc61624da__0 = 0;
    CData/*1:0*/ __VdfgTmp_hcca0817d__0;
    __VdfgTmp_hcca0817d__0 = 0;
    CData/*1:0*/ __VdfgTmp_had20add3__0;
    __VdfgTmp_had20add3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h9dd569ac__0;
    __VdfgTmp_h9dd569ac__0 = 0;
    CData/*5:0*/ __VdfgTmp_hc12c3471__0;
    __VdfgTmp_hc12c3471__0 = 0;
    CData/*5:0*/ __VdfgTmp_h5dfa3f6d__0;
    __VdfgTmp_h5dfa3f6d__0 = 0;
    CData/*5:0*/ __VdfgTmp_ha1de3516__0;
    __VdfgTmp_ha1de3516__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2115d7e3__0;
    __VdfgTmp_h2115d7e3__0 = 0;
    CData/*5:0*/ __VdfgTmp_h3874720c__0;
    __VdfgTmp_h3874720c__0 = 0;
    CData/*5:0*/ __VdfgTmp_h58192683__0;
    __VdfgTmp_h58192683__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0d445bfa__0;
    __VdfgTmp_h0d445bfa__0 = 0;
    // Body
    wasmetal_core__DOT___068805_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061265_))));
    vlSelf->wasmetal_core__DOT___061266_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061265_))));
    vlSelf->wasmetal_core__DOT___070521_ = (1U & (IData)(
                                                         (0x8eafffffffff8eafULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013181_)))))))));
    vlSelf->wasmetal_core__DOT___024477_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010033_))));
    vlSelf->__VdfgTmp_hfe94c053__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012944_));
    vlSelf->wasmetal_core__DOT___024469_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055839_))));
    __VdfgTmp_h40167917__0 = (((IData)(vlSelf->wasmetal_core__DOT___056030_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    __VdfgTmp_h242203a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010623_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010622_));
    vlSelf->wasmetal_core__DOT___055661_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010627_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010622_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010623_)))))));
    vlSelf->wasmetal_core__DOT___061370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009998_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33550f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h6c7838ff__0))))))))));
    vlSelf->wasmetal_core__DOT___056250_ = ((IData)(vlSelf->wasmetal_core__DOT___009998_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)) 
                                               & (IData)(
                                                         (0xccffaafff0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6c7838ff__0))))))));
    vlSelf->wasmetal_core__DOT___056708_ = (1U & (0x1f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009868_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf1710ca9__0)))));
    vlSelf->wasmetal_core__DOT___024509_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010034_))));
    vlSelf->wasmetal_core__DOT___068597_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___012054_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012053_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012052_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___060930_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010084_)))))))));
    vlSelf->wasmetal_core__DOT___024501_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010647_))));
    vlSelf->__VdfgTmp_h50e83fab__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055888_));
    wasmetal_core__DOT___009896_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056243_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056242_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056241_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056240_))))));
    vlSelf->wasmetal_core__DOT___056752_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056160_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056161_)))));
    wasmetal_core__DOT___056215_ = (1U & (IData)((0xeee00000fff00ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056162_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011285_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011286_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056161_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056160_)))))))));
    vlSelf->wasmetal_core__DOT___067741_ = (1U & (IData)(
                                                         (0x88fff8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012002_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012001_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056014_)))))))));
    vlSelf->wasmetal_core__DOT___060890_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056014_))));
    wasmetal_core__DOT___010654_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___056014_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___024221_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010042_))));
    vlSelf->__VdfgTmp_hd62224af__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010032_)))));
    vlSelf->wasmetal_core__DOT___024466_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055789_))));
    wasmetal_core__DOT___070530_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h30bed265__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010646_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010647_)))))));
    vlSelf->__VdfgTmp_hbf1fbd0a__0 = (((IData)(vlSelf->wasmetal_core__DOT___056018_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___010049_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055491_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055489_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055490_)))))))));
    vlSelf->wasmetal_core__DOT___010614_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055491_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055490_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055489_)))))));
    vlSelf->wasmetal_core__DOT___056262_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he07352b1__0)))));
    vlSelf->wasmetal_core__DOT___024470_ = (1U & (0xb00f4ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h69066ba7__0))))));
    vlSelf->wasmetal_core__DOT___055853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0))))));
    vlSelf->wasmetal_core__DOT___043256_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056104_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h284e2fd7__0))))))));
    vlSelf->wasmetal_core__DOT___068438_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013076_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061304_)))))))));
    vlSelf->wasmetal_core__DOT___024498_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056070_))));
    __VdfgTmp_hcca0817d__0 = (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    vlSelf->wasmetal_core__DOT___065433_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057617_)))));
    vlSelf->__VdfgTmp_h71fdadc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010043_));
    vlSelf->wasmetal_core__DOT___055713_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xf4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055712_)))))));
    vlSelf->wasmetal_core__DOT___055721_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010043_)))));
    vlSelf->wasmetal_core__DOT___056135_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056096_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056086_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->wasmetal_core__DOT___056063_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->__VdfgTmp_h14375066__0 = (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055239_));
    wasmetal_core__DOT___010657_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___010026_ = (1U & (0x401004abU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056009_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___024486_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h30ace780__0))))));
    vlSelf->wasmetal_core__DOT___060761_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060759_))));
    wasmetal_core__DOT___056357_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056062_))))));
    vlSelf->__VdfgTmp_h11bce3c4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056074_));
    vlSelf->wasmetal_core__DOT___056075_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056003_))));
    vlSelf->__VdfgTmp_h27adf041__0 = (((IData)(vlSelf->wasmetal_core__DOT___060754_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___056038_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h672152ba__0))))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009308_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009309_))))));
    wasmetal_core__DOT___008807_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h672152ba__0)))));
    wasmetal_core__DOT___056140_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055869_))));
    vlSelf->__VdfgTmp_hf4167eb1__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055869_));
    wasmetal_core__DOT___056354_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056107_))))));
    wasmetal_core__DOT___056212_ = (1U & (0xbU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2275929a__0))));
    vlSelf->wasmetal_core__DOT___070510_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056129_)))))));
    vlSelf->wasmetal_core__DOT___024511_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056129_))));
    vlSelf->__VdfgTmp_hd684d3d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009707_));
    vlSelf->__VdfgTmp_h4528de02__0 = (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009707_)));
    vlSelf->wasmetal_core__DOT___070533_ = (1U & (IData)(
                                                         (0xbfbf00bfffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010032_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010034_)))))))));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023193_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060286_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058497_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128885___O))))))));
    vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036498_));
    vlSelf->wasmetal_core__DOT____Vcellout___128804___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035969_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035968_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035967_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035966_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035909_)))));
    vlSelf->wasmetal_core__DOT___035913_ = ((IData)(vlSelf->wasmetal_core__DOT___035969_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128804___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d));
    vlSelf->__VdfgTmp_h3d6ee6a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h0d37526f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h3a7e26d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127496___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___023017_));
    vlSelf->wasmetal_core__DOT____Vcellout___128849___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h46466860__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_h9ce496ce__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h3d32f603__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9110e1f3__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036342_)))));
    wasmetal_core__DOT___036346_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h46466860__0)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128849___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h1e507ca5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017531_));
    vlSelf->__VdfgTmp_h6bcf76cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017548_));
    vlSelf->__VdfgTmp_h71876852__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017561_)));
    vlSelf->__VdfgTmp_h5bb2fc7d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017576_)));
    vlSelf->__VdfgTmp_h8d1d0ffb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013519_)));
    vlSelf->__VdfgTmp_h6171bc25__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017676_)));
    vlSelf->__VdfgTmp_haf11557d__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017701_)));
    vlSelf->__VdfgTmp_heb003047__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017610_)));
    vlSelf->__VdfgTmp_h43b37fbe__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017623_)));
    vlSelf->__VdfgTmp_h69609ee5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017533_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017532_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017728_)));
    vlSelf->wasmetal_core__DOT___035366_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071728_))))));
    vlSelf->wasmetal_core__DOT___035387_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xacU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___019751_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xaaaaf0f0ff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058060_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058059_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058057_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058061_)))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071728_)))))));
    vlSelf->wasmetal_core__DOT___035364_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h15d2d521__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071721_))))));
    vlSelf->wasmetal_core__DOT___035356_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3dc01c55__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f5f0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019706_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51855551__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaaccf0f0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hf1e8a9a9__0)))))))))));
    wasmetal_core__DOT___071746_ = (1U & (IData)((0x55330f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 5U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e8a9a9__0)))));
    vlSelf->wasmetal_core__DOT___035360_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b28__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013627_))))));
    vlSelf->wasmetal_core__DOT___035374_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071748_))))));
    vlSelf->wasmetal_core__DOT___035341_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h9195d647__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071748_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> 
                                                                   (1U 
                                                                    & (IData)(
                                                                              (0xaaaaf0f0ff00ccccULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058029_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058028_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057971_))))))))))
                                                                   : 
                                                                  (0xfafcU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019710_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he15aac2f__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035370_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h04542857__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071739_))))));
    vlSelf->wasmetal_core__DOT___035390_ = (1U & (0x3cc3a55aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b5__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xf0f0ccaaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057982_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058030_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058029_)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___071737_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071739_)))))));
    vlSelf->wasmetal_core__DOT___035355_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b23__05d) 
                                                       << 1U) 
                                                      | ((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                         & (IData)(
                                                                   (0xff00ff0f33335555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019698_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019697_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hf6f65f53__0))))))))))));
    vlSelf->wasmetal_core__DOT___035339_ = (1U & (0x69U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b7__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                              ? 
                                                             (2U 
                                                              >> 
                                                              (1U 
                                                               & (0xf0f0ccaaU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058067_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058025_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___058024_))))))))
                                                              : 
                                                             (0xcaU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf6f65f53__0))))
                                                             : 
                                                            ((~ (IData)(vlSelf->wasmetal_core__DOT___013631_)) 
                                                             | (0x32U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019698_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___019697_)))))))))));
    vlSelf->wasmetal_core__DOT___035381_ = (1U & (0x807f7f80U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019734_)))))));
    vlSelf->wasmetal_core__DOT___035363_ = (1U & (IData)(
                                                         (0x50c0af3faf3f50c0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf97b813d__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019734_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058071_)))))))));
    vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035701_) 
           | (IData)(vlSelf->wasmetal_core__DOT___035676_));
    vlSelf->wasmetal_core__DOT___035362_ = (1U & (0x4bb4U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h89d2961b__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058065_))))));
    vlSelf->wasmetal_core__DOT___035354_ = (1U & (IData)(
                                                         (0xf1000eff0efff100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x5300U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hc1e5da71__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071742_)))))))));
    wasmetal_core__DOT___071743_ = (1U & (IData)((0xf0f553300000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xf0f0ccaaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058064_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha0dc9087__0))))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc1e5da71__0))))))));
    vlSelf->wasmetal_core__DOT___035346_ = (1U & (0xe11eU 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf5a62b29__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x305000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h06185798__0))))))) 
                                                             << 1U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                ? 
                                                               (1U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___019728_))
                                                                : 
                                                               (0xf0f5533U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4eafc8bd__0)))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d 
        = (1U & (0xc3a5U >> (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                              << 3U) | ((4U & ((0xdf2f20dU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                               << 2U)) 
                                        | ((2U & ((IData)(
                                                          (0x1111f0f0ff00ff00ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___019728_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058064_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x5030000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (1U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___058061_))))))))))) 
                                                  << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___058065_))))));
    vlSelf->wasmetal_core__DOT___035349_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h93626d60__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071760_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___019744_))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                                    ? 
                                                                   (0xacU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___014371_))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___019676_)))))))))))));
    vlSelf->wasmetal_core__DOT___035380_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((0xfdf0000U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___071723_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057972_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058037_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h625062d0__0))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___019744_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071725_)))))));
    __VdfgTmp_h58192683__0 = ((0x20U & ((0xcaU >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                        << 5U)) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019725_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019724_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xccccaaaaff00f0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014374_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014373_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5970a25a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035348_ = (1U & (IData)(
                                                         (0x55c0aa3faa3f55c0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0xcaU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdf4ff5ef__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071758_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                              ? 
                                                                             (2U 
                                                                              >> (IData)(vlSelf->wasmetal_core__DOT___019737_))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___014357_)
                                                                               ? 
                                                                              (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019668_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014353_))))
                                                                               : 
                                                                              (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014354_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019669_)))))))))))))));
    vlSelf->wasmetal_core__DOT___035369_ = (1U & (0x3cc35aa5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xdf2f20dU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xddf0f0f0f0ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___071720_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___071719_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019737_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014455_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014456_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f89240a__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56cb633a__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd09be45d__0)))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___071721_)))))));
    __VdfgTmp_h3874720c__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b12__05d) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___019720_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014363_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xfcfaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___014359_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h51e83899__0)))))))))));
    vlSelf->wasmetal_core__DOT___035347_ = (1U & (0x69U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h84f7054c__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                             ? 
                                                            (0xf0f0ccaaU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019733_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h42589940__0)))))
                                                             : 
                                                            (7U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___019734_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d 
        = (1U & (IData)((0xaaaacc0f555533f0ULL >> (
                                                   (0x20U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019734_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058071_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xcaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0x555f444cULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058068_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057975_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057976_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058067_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058037_)))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___019733_)))))))))))));
    vlSelf->wasmetal_core__DOT___035343_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___013631_)
                                                   ? 
                                                  (0x35caca35U 
                                                   >> 
                                                   ((0x10U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019715_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfcfaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___014385_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd4b4ff41__0)))))))))))
                                                   : 
                                                  (0x96U 
                                                   >> 
                                                   ((4U 
                                                     & ((0xdf2f20dU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b11__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___019713_))))));
    wasmetal_core__DOT___013630_ = (1U & (4U >> ((2U 
                                                  & ((0x1000000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___058051_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___058050_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((IData)(
                                                                         (0xa0c0f0f0f0f0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___058046_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h70d6e582__0)) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c001b5f__0))))))) 
                                                                 << 2U)) 
                                                             | ((2U 
                                                                 & ((IData)(
                                                                            (0x7fff00007fff7fffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058045_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058044_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058043_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h767f4755__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc5b0708b__0)))))))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0x7fffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058041_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2bde81d3__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057939_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1b003ae2__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057926_)))))))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff0000077770000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___014360_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058040_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xff7f7fU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057985_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057984_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057982_)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___019720_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019725_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019715_)))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128757___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035653_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035642_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035631_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035620_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    wasmetal_core__DOT___035598_ = ((IData)(vlSelf->wasmetal_core__DOT___035653_)
                                     ? (IData)(vlSelf->wasmetal_core__DOT___128757___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b4__05d));
    vlSelf->wasmetal_core__DOT___024475_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0))))));
    vlSelf->wasmetal_core__DOT___067825_ = (1U & (IData)(
                                                         (0xffff88f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056021_)))))))));
    vlSelf->wasmetal_core__DOT___010656_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056021_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->__VdfgTmp_h4a210212__0 = (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010021_));
    vlSelf->wasmetal_core__DOT___055559_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055558_)))))));
    vlSelf->wasmetal_core__DOT___024487_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010653_))));
    vlSelf->wasmetal_core__DOT___067766_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012280_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___060986_))))));
    vlSelf->__VdfgTmp_haf42252b__0 = (((IData)(vlSelf->wasmetal_core__DOT___060986_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___070522_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h33ebc999__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055954_)))))));
    vlSelf->__VdfgTmp_h6850d65a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010053_));
    vlSelf->wasmetal_core__DOT___043254_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h356ffba0__0))))))));
    vlSelf->wasmetal_core__DOT___070532_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010651_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056104_)))))));
    vlSelf->wasmetal_core__DOT___060804_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fc94011__0))));
    vlSelf->wasmetal_core__DOT___056044_ = (1U & (0x3000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9fc94011__0)))));
    __VdfgTmp_hc61624da__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                           << 3U) | 
                                          ((4U & ((0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5cf792c3__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___008814_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___008813_))))));
    vlSelf->__VdfgTmp_hc6176170__0 = (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & ((0x305U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5cf792c3__0)) 
                                                        << 2U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008813_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___008814_)))));
    wasmetal_core__DOT___056358_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010651_)) 
                                          & (IData)(
                                                    (1ULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                       << 5U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___010646_))))))))));
    wasmetal_core__DOT___070531_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010649_)))))));
    vlSelf->__VdfgTmp_h7f725de9__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009904_));
    wasmetal_core__DOT___070517_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h740b215b__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___055789_)))));
    __VdfgTmp_h5dfa3f6d__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         ((8U & ((0x305U 
                                                  >> (IData)(vlSelf->__VdfgTmp_heedd871e__0)) 
                                                 << 3U)) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT___010069_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h740b215b__0)))));
    vlSelf->wasmetal_core__DOT___068304_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068285_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x10U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___012440_)))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061071_)))))));
    wasmetal_core__DOT___070528_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc194321c__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056057_)))))));
    vlSelf->wasmetal_core__DOT___010063_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3b65973b__0))))))));
    vlSelf->wasmetal_core__DOT___024495_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056057_))));
    vlSelf->wasmetal_core__DOT___010064_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9b8fed80__0))));
    vlSelf->wasmetal_core__DOT___055608_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055606_)))))));
    vlSelf->wasmetal_core__DOT___068744_ = (1U & (IData)(
                                                         (0x88ff8f8fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057257_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057256_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061182_)))))))));
    vlSelf->wasmetal_core__DOT___061183_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061182_))));
    __VdfgTmp_h9dd569ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___013181_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010054_)));
    vlSelf->__VdfgTmp_h26c3fed8__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010054_));
    wasmetal_core__DOT___056362_ = (1U & (0x1000U >> 
                                          ((8U & ((0xd0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055869_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055849_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___007844_)))))) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0xbU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0))))) 
                                                << 2U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055826_))))));
    vlSelf->__VdfgTmp_h64128247__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055826_));
    wasmetal_core__DOT___009686_ = (1U & (0x10000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___056232_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056231_) 
                                                  << 3U) 
                                                 | ((4U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                         | (IData)(
                                                                   (0xee0e0000ff0fff0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009868_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009867_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009866_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hf1710ca9__0)))))))) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((0xd00U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___011268_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011267_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___007844_))))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056228_)))))));
    wasmetal_core__DOT___068410_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___061218_))));
    vlSelf->wasmetal_core__DOT___067979_ = (1U & (IData)(
                                                         (0xc0ffeaeaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067960_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061223_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065289_)))))))));
    vlSelf->__VdfgTmp_hb48e4863__0 = (((IData)(vlSelf->wasmetal_core__DOT___061223_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007874_));
    vlSelf->wasmetal_core__DOT___068806_ = (1U & (IData)(
                                                         (0xff00ee00ff000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___068805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h90d51bf1__0)))))));
    vlSelf->wasmetal_core__DOT___043245_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070521_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7fb8523__0))));
    vlSelf->wasmetal_core__DOT___010061_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe94c053__0))))))));
    vlSelf->wasmetal_core__DOT___010059_ = (1U & (0x4bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h40167917__0))));
    vlSelf->wasmetal_core__DOT___010023_ = (1U & (IData)(
                                                         (0xffff010f0000fef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010627_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h242203a7__0))))))));
    vlSelf->wasmetal_core__DOT___055662_ = (1U & (0xf0f3355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055660_)))))));
    vlSelf->wasmetal_core__DOT___068165_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056835_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___061370_))))));
    vlSelf->wasmetal_core__DOT___043257_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010032_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024509_)))));
    vlSelf->wasmetal_core__DOT___070519_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h50e83fab__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055869_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011249_)))))));
    wasmetal_core__DOT___009687_ = (1U & ((1U >> ((2U 
                                                   & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                        ? 
                                                       (0xc0005U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 4U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009872_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___009329_))))))
                                                        : 
                                                       (0x200U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0xf0f0ccaaU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha296f98c__0)) 
                                                                                << 2U)) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h23e0654e__0))))))))))) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___056250_))) 
                                          & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056249_) 
                                                   << 2U) 
                                                  | ((2U 
                                                      & (((IData)(
                                                                  (0xfafcf0f0ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h38f150ef__0))))))) 
                                                          & (IData)(
                                                                    (0xccffaafff0fff0ffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___009988_) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_hcfb95646__0)))))))) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))) 
                                             & (IData)(
                                                       (0x8000000000000000ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___009898_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009897_) 
                                                             << 4U) 
                                                            | (((IData)(wasmetal_core__DOT___009896_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___056239_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012954_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056238_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___056237_))))) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & (((~ (IData)(vlSelf->wasmetal_core__DOT___009911_)) 
                                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT___009910_)) 
                                                                             & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009909_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009908_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009907_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009906_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009905_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009904_)))))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (1U 
                                                                           >> 
                                                                           ((8U 
                                                                             & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                                                << 3U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056104_))))))))))))))));
    vlSelf->__VdfgTmp_h3e52c1ca__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                       << 1U) | (IData)(wasmetal_core__DOT___010654_));
    vlSelf->__VdfgTmp_hee926831__0 = (((IData)(vlSelf->wasmetal_core__DOT___010035_) 
                                       << 5U) | (IData)(vlSelf->__VdfgTmp_hd62224af__0));
    vlSelf->wasmetal_core__DOT___043236_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070530_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h30bed265__0))));
    vlSelf->wasmetal_core__DOT___010027_ = (1U & (0x401004abU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056021_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0))))));
    vlSelf->wasmetal_core__DOT___024489_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0))))));
    vlSelf->wasmetal_core__DOT___010013_ = ((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010048_) 
                                               & (IData)(
                                                         (0x1428000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010042_))))))))));
    vlSelf->wasmetal_core__DOT___043197_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010048_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024221_)))));
    vlSelf->__VdfgTmp_h4c3f9374__0 = (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033390_));
    __VdfgTmp_h2115d7e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010614_));
    vlSelf->wasmetal_core__DOT___055511_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010614_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055510_)))))))));
    vlSelf->wasmetal_core__DOT___043263_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___024477_))));
    wasmetal_core__DOT___070518_ = (1U & (0x8eafffffU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___055839_)))))));
    vlSelf->wasmetal_core__DOT___055854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055853_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008810_))));
    vlSelf->__VdfgTmp_hcfdcf3c6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 2U) | (IData)(__VdfgTmp_hcca0817d__0));
    vlSelf->wasmetal_core__DOT___056035_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hcca0817d__0))));
    wasmetal_core__DOT___070537_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010058_)))));
    vlSelf->wasmetal_core__DOT___070540_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055839_)))));
    vlSelf->wasmetal_core__DOT___024205_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___024204_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->__VdfgTmp_h3691f72d__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055721_)));
    vlSelf->wasmetal_core__DOT___024202_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055789_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___024201_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___127636___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__)) 
                 | (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
    vlSelf->wasmetal_core__DOT___127653___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__)) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
    vlSelf->wasmetal_core__DOT___043250_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h04c057c0__0))))));
    wasmetal_core__DOT___070529_ = (1U & (0x8eafffffU 
                                          >> ((0x10U 
                                               & ((9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h11bce3c4__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056070_)))))));
    vlSelf->wasmetal_core__DOT___068089_ = (1U & (IData)(
                                                         (0x88fff8f8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068071_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf400U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056038_)))))))));
    vlSelf->wasmetal_core__DOT___060724_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056038_))));
    __VdfgTmp_had20add3__0 = (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d));
    __VdfgTmp_h2dd5429b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___008808_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___008807_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___008806_))))));
    wasmetal_core__DOT___055722_ = (1U & (IData)((0xfef0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008808_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008806_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___008807_)))))))));
    vlSelf->wasmetal_core__DOT___043261_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf4167eb1__0))))))));
    wasmetal_core__DOT___056217_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056212_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056211_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056210_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0x1000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056174_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056173_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056172_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d)))))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(
                                                                           (0x3faf00000000ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___056170_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009218_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056169_)))))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056207_)))))))));
    vlSelf->wasmetal_core__DOT___043240_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070510_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haa7da8bd__0))));
    vlSelf->wasmetal_core__DOT___043258_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024511_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h78ee927d__0))))));
    vlSelf->wasmetal_core__DOT___024485_ = (1U & (0x10efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4528de02__0))));
    vlSelf->wasmetal_core__DOT___043239_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070533_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha0636656__0))));
    vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023194_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035913_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d));
    wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
           & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0)) 
           & (IData)(wasmetal_core__DOT___036346_));
    vlSelf->wasmetal_core__DOT___035373_ = (1U & (0x8778U 
                                                  >> 
                                                  ((8U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0xcaU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071746_))))));
    vlSelf->wasmetal_core__DOT___035340_ = (1U & (0x5ca3a35cU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xdf2f20dU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b8__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___071746_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___014360_)
                                                                   ? 
                                                                  (2U 
                                                                   >> 
                                                                   (1U 
                                                                    & (IData)(
                                                                              (0xaaaaf0f0ff00ccccULL 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058035_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058034_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058033_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057980_))))))))))
                                                                   : 
                                                                  (0xfafcU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___019706_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h51855551__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035391_ = (1U & (IData)(
                                                         (0xff1000ef00efff10ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___071743_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h74456d25__0)))))));
    __VdfgTmp_ha1de3516__0 = (((IData)(vlSelf->wasmetal_core__DOT___013631_) 
                               << 5U) | (((IData)(wasmetal_core__DOT___013630_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013629_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013628_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013627_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xff000b00ff00ffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___057908_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057907_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057906_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((4U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___014358_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((0x8000U 
                                                                              >> 
                                                                              ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h5721c23b__0)) 
                                                                                << 3U)) 
                                                                               | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf30cf57d__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9cb72e5a__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h04542857__0))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0x7fff00007fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___014357_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb0772ee2__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x53U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))))))))))))))))))))))));
    if ((1U & (0xdf2f20dU >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))) {
        vlSelf->wasmetal_core__DOT___035345_ = (1U 
                                                & (IData)(
                                                          (0xfcc5500f033aaffULL 
                                                           >> (IData)(__VdfgTmp_h58192683__0))));
        vlSelf->wasmetal_core__DOT___035344_ = (1U 
                                                & (IData)(
                                                          (0xf335500f0ccaaffULL 
                                                           >> (IData)(__VdfgTmp_h3874720c__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d 
            = (1U & (IData)((0xffff000040000000ULL 
                             >> (IData)(__VdfgTmp_ha1de3516__0))));
    } else {
        vlSelf->wasmetal_core__DOT___035345_ = (1U 
                                                & (IData)(
                                                          (0xf033aaff0fcc5500ULL 
                                                           >> (IData)(__VdfgTmp_h58192683__0))));
        vlSelf->wasmetal_core__DOT___035344_ = (1U 
                                                & (IData)(
                                                          (0xf0ccaaff0f335500ULL 
                                                           >> (IData)(__VdfgTmp_h3874720c__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d 
            = (1U & (IData)((0xffffbfffffffULL >> (IData)(__VdfgTmp_ha1de3516__0))));
    }
    wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035398_));
    wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035664_)
            ? (IData)(wasmetal_core__DOT___035598_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b5__05d));
    vlSelf->__VdfgTmp_h78c69d21__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010656_));
    vlSelf->wasmetal_core__DOT___043177_ = (1U & (IData)(
                                                         (0x2220bbb33332fffbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070514_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070513_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))))))))));
    vlSelf->wasmetal_core__DOT___043620_ = (1U & (IData)(
                                                         (0xeeef888cccce0008ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055607_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070514_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070513_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055661_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))))))))));
    vlSelf->wasmetal_core__DOT___070524_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024487_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h30ace780__0)))))));
    vlSelf->wasmetal_core__DOT___043246_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070522_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33ebc999__0))));
    __VdfgTmp_hc12c3471__0 = (((IData)(vlSelf->wasmetal_core__DOT___010055_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010054_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h6850d65a__0)))));
    vlSelf->wasmetal_core__DOT___043238_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070532_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h862c0500__0))));
    vlSelf->wasmetal_core__DOT___068114_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056689_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___060804_))))));
    vlSelf->__VdfgTmp_h9d55d8c7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056044_));
    vlSelf->wasmetal_core__DOT___010025_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)
                                                   ? (IData)(
                                                             (0xfef0ULL 
                                                              >> (IData)(__VdfgTmp_hc61624da__0)))
                                                   : (IData)(
                                                             (0xffffffffffff010fULL 
                                                              >> (IData)(__VdfgTmp_hc61624da__0)))));
    vlSelf->wasmetal_core__DOT___011276_ = (1U & (IData)(
                                                         (0xfef0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc6176170__0)))));
    wasmetal_core__DOT___056363_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056358_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___056357_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056044_)))))))));
    vlSelf->wasmetal_core__DOT___043237_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070531_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6abc2452__0))));
    vlSelf->wasmetal_core__DOT___043255_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7f725de9__0))))))));
    vlSelf->wasmetal_core__DOT___010062_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)
                                                   ? (IData)(
                                                             (0x9990ULL 
                                                              >> (IData)(__VdfgTmp_h5dfa3f6d__0)))
                                                   : (IData)(
                                                             (0x9999999999990009ULL 
                                                              >> (IData)(__VdfgTmp_h5dfa3f6d__0)))));
    vlSelf->wasmetal_core__DOT___043234_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070528_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc194321c__0))));
    wasmetal_core__DOT___010658_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h9dd569ac__0))));
    wasmetal_core__DOT___056139_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___012502_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h9dd569ac__0))));
    vlSelf->wasmetal_core__DOT___070520_ = (1U & (0x8eafffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h26c3fed8__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0)))))))));
    vlSelf->wasmetal_core__DOT___043260_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024469_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h64128247__0)))))));
    vlSelf->wasmetal_core__DOT___068414_ = (1U & (IData)(
                                                         (0xff00ee00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___068410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7a970221__0)))))));
    vlSelf->__VdfgTmp_h50ba50d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010023_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010028_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))));
    vlSelf->wasmetal_core__DOT___043243_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070519_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h50e83fab__0))));
    __VdfgTmp_h0d445bfa__0 = (((IData)(wasmetal_core__DOT___009687_) 
                               << 1U) | (IData)(wasmetal_core__DOT___009686_));
    vlSelf->wasmetal_core__DOT___043251_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010027_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0))))));
    vlSelf->wasmetal_core__DOT___043174_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(__VdfgTmp_h2115d7e3__0)))))))))));
    vlSelf->wasmetal_core__DOT___043617_ = (1U & (IData)(
                                                         (0xfeeaeaeaaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010049_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(__VdfgTmp_h2115d7e3__0)))))))))));
    vlSelf->wasmetal_core__DOT___043242_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070518_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055854_)))));
    wasmetal_core__DOT___055865_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___010043_)))));
    wasmetal_core__DOT___070526_ = (1U & (IData)((0x405444ffffffffffULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4bU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h40167917__0))))))));
    vlSelf->wasmetal_core__DOT___043252_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4bU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010064_)))));
    wasmetal_core__DOT___070539_ = (1U & (0xe00U >> 
                                          ((8U & ((0xe1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055789_))))));
    wasmetal_core__DOT___070538_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___024202_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0xe1U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h3691f72d__0))))));
    if (vlSelf->wasmetal_core__DOT___010048_) {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127636___DOT__CO__BRA__0__KET__));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010338_)));
    } else {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010338_)));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127653___DOT__CO__BRA__0__KET__));
    }
    vlSelf->wasmetal_core__DOT___043235_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070529_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11bce3c4__0))));
    vlSelf->__VdfgTmp_h6a2679f3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 2U) | (IData)(__VdfgTmp_had20add3__0));
    vlSelf->wasmetal_core__DOT___010024_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)
                                                   ? (IData)(
                                                             (0xfef0ULL 
                                                              >> (IData)(__VdfgTmp_h2dd5429b__0)))
                                                   : (IData)(
                                                             (0xffffffffffff010fULL 
                                                              >> (IData)(__VdfgTmp_h2dd5429b__0)))));
    wasmetal_core__DOT___055733_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___055722_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055721_))));
    wasmetal_core__DOT___009688_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056217_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056216_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___056215_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___007847_)
                                                                  ? 
                                                                 (0xc05U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xacU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009698_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaf0f0ff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007854_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007906_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008642_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haff0ba2f__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008639_)))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___009267_)))))
                                                                  : 
                                                                 (0xc0aU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009758_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___009757_)))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056213_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055363_)))))))));
    vlSelf->wasmetal_core__DOT___043229_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009807_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x10U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)))))))))));
    vlSelf->__VdfgTmp_h2237a749__0 = (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___024484_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)))));
    wasmetal_core__DOT____Vcellout___127530___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023195_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023194_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023193_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023192_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023254_)))));
    vlSelf->wasmetal_core__DOT___023259_ = ((IData)(vlSelf->wasmetal_core__DOT___023195_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127530___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
           & (IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035972_)
            ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d));
    wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
           & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h7594c868__0)) 
           & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035669_)
            ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b6__05d));
    vlSelf->wasmetal_core__DOT___070525_ = (1U & (IData)(
                                                         (0xbf00bfbfbfbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((9U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h78c69d21__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010027_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0))))))));
    vlSelf->wasmetal_core__DOT___043230_ = (1U & (IData)(
                                                         (0xffffffff40ff4040ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070524_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010653_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h04c057c0__0))))))));
    vlSelf->wasmetal_core__DOT___043262_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d)
                                                   ? (IData)(
                                                             (0x900900000000ULL 
                                                              >> (IData)(__VdfgTmp_hc12c3471__0)))
                                                   : (IData)(
                                                             (0x9009000090099009ULL 
                                                              >> (IData)(__VdfgTmp_hc12c3471__0)))));
    vlSelf->wasmetal_core__DOT___043621_ = (1U & (IData)(
                                                         (0xaaffffff80ecc8feULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___055722_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))))))))));
    vlSelf->wasmetal_core__DOT___024259_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055721_)))));
    vlSelf->wasmetal_core__DOT___043241_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070517_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h740b215b__0))))));
    vlSelf->wasmetal_core__DOT___043179_ = (1U & (IData)(
                                                         (0xffffffffff101010ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070517_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hef18707b__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3691f72d__0)))))));
    vlSelf->wasmetal_core__DOT___043259_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (9U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hef18707b__0))))));
    wasmetal_core__DOT___056364_ = (1U & ((0xf1U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056038_)))) 
                                          & ((0xf1U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056026_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___056030_)))) 
                                             & (IData)(
                                                       (0x1000000000000ULL 
                                                        >> 
                                                        (((IData)(wasmetal_core__DOT___010658_) 
                                                          << 5U) 
                                                         | (((IData)(wasmetal_core__DOT___010657_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010656_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)) 
                                                                      << 2U)) 
                                                                  | (((IData)(wasmetal_core__DOT___010654_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010653_)))))))))));
    wasmetal_core__DOT___009689_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___056140_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___056139_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056138_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & (((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                                  ? 
                                                                 (1U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___009711_)))
                                                                  : (IData)(
                                                                            (0xb0bbULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009710_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009709_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd684d3d4__0)))))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055888_)))))))));
    vlSelf->wasmetal_core__DOT___043244_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070520_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h26c3fed8__0))));
    vlSelf->__VdfgTmp_hc8f8c4ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055865_));
    vlSelf->__VdfgTmp_h10a93ed5__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055865_));
    vlSelf->__VdfgTmp_hfadc0d9c__0 = (((IData)(wasmetal_core__DOT___055865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055854_));
    vlSelf->__VdfgTmp_h9415b560__0 = (((IData)(wasmetal_core__DOT___055865_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_));
    vlSelf->wasmetal_core__DOT___043232_ = (1U & (0xb0ffU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070526_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0))));
    vlSelf->wasmetal_core__DOT___043622_ = (1U & (IData)(
                                                         (0xfffff000fffffeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___070539_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070538_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___070537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))))));
    vlSelf->wasmetal_core__DOT___043663_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070539_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___070538_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___043202_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024201_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070538_))));
    if (vlSelf->wasmetal_core__DOT___024221_) {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010045_)));
    } else {
        vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010045_)));
        vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT___010014_ = (1U & (IData)(
                                                         (0x9000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x4bU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043255_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0))))))));
    vlSelf->wasmetal_core__DOT___043233_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056044_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xb0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)))))))))));
    vlSelf->wasmetal_core__DOT___043253_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x4bU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9d55d8c7__0)))))));
    vlSelf->wasmetal_core__DOT___043178_ = (1U & (IData)(
                                                         (0xabaaffff0000abaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010024_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(wasmetal_core__DOT___055722_))))))))))));
    vlSelf->wasmetal_core__DOT___043201_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010025_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010024_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))))));
    vlSelf->wasmetal_core__DOT___024258_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___055733_))));
    vlSelf->wasmetal_core__DOT___055735_ = (1U & (0xfcf5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___055733_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055732_)))))));
    vlSelf->wasmetal_core__DOT___006037_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h04d557bc__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf628d2c5__0)))));
    vlSelf->wasmetal_core__DOT___006010_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9bddaa79__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9bddaa79__0)))))));
    vlSelf->wasmetal_core__DOT___006035_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h9c9f5aae__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9c9f5aae__0)))))));
    vlSelf->wasmetal_core__DOT___006036_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127530___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9be9fa04__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9be9fa04__0)))))));
    vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023196_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023259_));
    vlSelf->wasmetal_core__DOT____Vcellout___128871___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b42__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b41__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b40__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128871___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036498_)))));
    vlSelf->wasmetal_core__DOT___036503_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b43__05d) 
                                            & (IData)(wasmetal_core__DOT___128871___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035973_)
            ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d));
    wasmetal_core__DOT____Vcellout___127497___O = (
                                                   ((8U 
                                                     & ((6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023017_)))));
    vlSelf->wasmetal_core__DOT___022990_ = ((6U >> (IData)(vlSelf->__VdfgTmp_hff2cd213__0)) 
                                            & (IData)(wasmetal_core__DOT___127497___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hb3fd333a__0)) 
           & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d) 
           & (0xdf2f20dU >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)));
    vlSelf->wasmetal_core__DOT____Vcellout___128743___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O)) 
                                               << 1U)) 
                                             | (IData)(vlSelf->wasmetal_core__DOT___035398_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___035398_) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035486_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128743___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035670_)
            ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b7__05d));
    vlSelf->wasmetal_core__DOT___043231_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070525_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h78c69d21__0))));
    vlSelf->wasmetal_core__DOT___010015_ = (1U & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___043262_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___024470_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h64128247__0))))))));
    vlSelf->wasmetal_core__DOT___012496_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___056364_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___056363_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056362_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___056354_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056353_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056352_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055239_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x10U 
                                                                            >> 
                                                                            ((4U 
                                                                              & ((0xfff1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010068_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x305U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heedd871e__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010069_)))))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011276_)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((1U 
                                                                              >> 
                                                                              ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009711_)))) 
                                                                             & (((IData)(vlSelf->wasmetal_core__DOT___010627_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008809_))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010626_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___008809_))
                                                                                 : (IData)(
                                                                                (0xffffffff0001ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___008809_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010625_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010624_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_h242203a7__0))))))))) 
                                                                                & (IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x10U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0x10U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010043_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010021_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010614_)))))))))))))))))));
    vlSelf->__VdfgTmp_h1cb679e9__0 = (((IData)(wasmetal_core__DOT___009687_) 
                                       << 4U) | (((IData)(wasmetal_core__DOT___009686_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___009688_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___009689_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h46d848cb__0)))))));
    vlSelf->__VdfgTmp_h22919fe9__0 = (((IData)(wasmetal_core__DOT___009689_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009687_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___009686_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___009688_))));
    vlSelf->__VdfgTmp_h238f5c0e__0 = (((IData)(wasmetal_core__DOT___009688_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009689_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h0d445bfa__0)));
    vlSelf->__VdfgTmp_h83b9759e__0 = (((IData)(wasmetal_core__DOT___009689_) 
                                       << 3U) | (((IData)(wasmetal_core__DOT___009688_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_h0d445bfa__0)));
    vlSelf->wasmetal_core__DOT___024206_ = (1U & (0x5ca3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8f8c4ae__0)))));
    vlSelf->__VdfgTmp_h27f90c9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___056135_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hdb7f5f3b__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056129_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h09d9ebba__0 = ((4U & ((1U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h2275929a__0)) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hf2504815__0 = ((4U & ((1U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)) 
                                                   << 1U)) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hf8fd63d3__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010651_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h5c2c85cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_he887753f__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010649_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd9969096__0 = (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h7fe84144__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h3971bdc1__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___010646_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h373f306d__0 = (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h2f82e844__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056070_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hc699f06e__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h86e2747e__0 = (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hb788ecb2__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056057_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h03f01150__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056052_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056003_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h8c718ae9__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___056044_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h3300e967__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(__VdfgTmp_had20add3__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hde8b5012__0 = (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd8684912__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(__VdfgTmp_h40167917__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_h27272852__0 = ((4U & ((0xbU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h9b8fed80__0))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_hd2c8a10e__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (IData)(wasmetal_core__DOT___010654_))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->__VdfgTmp_ha16f0aa3__0 = ((4U & ((1U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                << 1U) 
                                               | (1U 
                                                  & (4U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h30ace780__0))))) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0));
    vlSelf->wasmetal_core__DOT___043180_ = (1U & (0xcf5f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070518_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfadc0d9c__0))))));
    vlSelf->wasmetal_core__DOT___043169_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070528_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043167_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070526_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043172_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070531_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043171_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070530_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___043170_ = (1U & (0xdf0f0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___070529_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))));
    vlSelf->wasmetal_core__DOT___056122_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056112_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010034_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056108_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056105_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056104_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056091_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009904_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9415b560__0)))));
    vlSelf->wasmetal_core__DOT___056023_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010656_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->__VdfgTmp_h5553b859__0 = (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h9415b560__0));
    vlSelf->wasmetal_core__DOT___056011_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056003_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010653_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055998_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055991_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x10U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    wasmetal_core__DOT___055980_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((0x10U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    wasmetal_core__DOT___055973_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___009712_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    wasmetal_core__DOT___055968_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055960_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055954_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055951_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011169_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055942_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055936_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013181_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055929_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010033_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055918_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010054_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055911_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0ff5ee52__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055904_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010053_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055892_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055879_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011249_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT___055873_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055869_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9415b560__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127636___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010049_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024221_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010048_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h14375066__0)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127636___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    if (vlSelf->wasmetal_core__DOT___010049_) {
        vlSelf->wasmetal_core__DOT___024168_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___127670___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___024299_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033390_)));
    } else {
        vlSelf->wasmetal_core__DOT___024168_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033390_)));
        vlSelf->wasmetal_core__DOT___024299_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127653___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010049_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024221_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010048_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h14375066__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127703___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127653___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    if (vlSelf->wasmetal_core__DOT___043201_) {
        if ((1U & (0x80U >> (IData)(vlSelf->__VdfgTmp_h50ba50d5__0)))) {
            if (vlSelf->wasmetal_core__DOT___043197_) {
                vlSelf->wasmetal_core__DOT___043156_ 
                    = (1U & (7U >> (IData)(vlSelf->__VdfgTmp_h14375066__0)));
                vlSelf->wasmetal_core__DOT___043599_ 
                    = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h14375066__0)));
                vlSelf->wasmetal_core__DOT___043301_ 
                    = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))) 
                             & (1U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
                vlSelf->wasmetal_core__DOT___043690_ 
                    = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))) 
                             & (8U >> (IData)(vlSelf->__VdfgTmp_h14375066__0))));
            } else {
                vlSelf->wasmetal_core__DOT___043156_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___043174_));
                vlSelf->wasmetal_core__DOT___043599_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___043617_));
                vlSelf->wasmetal_core__DOT___043301_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___043174_));
                vlSelf->wasmetal_core__DOT___043690_ 
                    = (1U & (IData)(vlSelf->wasmetal_core__DOT___043617_));
            }
        } else {
            vlSelf->wasmetal_core__DOT___043156_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___043177_));
            vlSelf->wasmetal_core__DOT___043599_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___043620_));
            vlSelf->wasmetal_core__DOT___043301_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___043177_));
            vlSelf->wasmetal_core__DOT___043690_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___043620_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___043156_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___043178_));
        vlSelf->wasmetal_core__DOT___043599_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___043621_));
        vlSelf->wasmetal_core__DOT___043301_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___043178_));
        vlSelf->wasmetal_core__DOT___043690_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___043621_));
    }
    vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023197_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036503_));
    vlSelf->wasmetal_core__DOT____Vcellout___128805___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035974_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035973_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035972_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035971_)))) 
           ^ (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035913_)))));
    wasmetal_core__DOT___035918_ = ((IData)(vlSelf->wasmetal_core__DOT___035974_)
                                     ? (IData)(wasmetal_core__DOT___128805___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d));
    vlSelf->__VdfgTmp_h9b49e40f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         >> 2U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h95fb6f3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h8c2e6c21__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___018495_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016447_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127497___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022990_));
    vlSelf->wasmetal_core__DOT____Vcellout___128850___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hb3fd333a__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h7594c868__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8c0ae79e__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___036346_)))));
    vlSelf->wasmetal_core__DOT___036325_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h219534f4__0)) 
                                            & (IData)(wasmetal_core__DOT___128850___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h834dc827__0 = (((IData)(vlSelf->wasmetal_core__DOT___035398_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O)));
    vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035486_));
    vlSelf->wasmetal_core__DOT____Vcellout___128762___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035671_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035670_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035669_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035664_)))) 
           ^ (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035598_)))));
    vlSelf->wasmetal_core__DOT___035617_ = ((IData)(vlSelf->wasmetal_core__DOT___035671_)
                                             ? (IData)(wasmetal_core__DOT___128762___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b8__05d));
    vlSelf->wasmetal_core__DOT___012167_ = (((IData)(vlSelf->wasmetal_core__DOT___010064_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___010063_) 
                                                & (IData)(
                                                          (0x9000000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010062_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010061_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((0x4bU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcfdcf3c6__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010059_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hef18707b__0))))))))) 
                                            & ((8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___043264_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043261_))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010015_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010014_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010013_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x9000U 
                                                                         >> 
                                                                         ((8U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__)
                                                                                ? 
                                                                               ((IData)(vlSelf->wasmetal_core__DOT___008809_)
                                                                                 ? 
                                                                                (0x82000082U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd62224af__0))
                                                                                 : (IData)(
                                                                                (0x8200008200000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hee926831__0))))
                                                                                : 
                                                                               ((~ (IData)(vlSelf->wasmetal_core__DOT___008809_)) 
                                                                                & (IData)(
                                                                                (0x82000082ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hee926831__0))))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043258_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h3e52c1ca__0)))) 
                                                                        << 2U)) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___010028_) 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT___010027_) 
                                                                            & (IData)(
                                                                                (0x6000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010025_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010024_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010023_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4a210212__0))))))))) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x80000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___056262_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043256_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2237a749__0))))))))))))));
    vlSelf->__VdfgTmp_ha271a2f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012496_));
    vlSelf->wasmetal_core__DOT___043203_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024204_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024205_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___024206_)))));
    vlSelf->wasmetal_core__DOT___070541_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024206_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024205_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055826_)))))));
    vlSelf->wasmetal_core__DOT___043176_ = (1U & (0xff4fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070510_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27f90c9b__0)))));
    vlSelf->wasmetal_core__DOT___024256_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h27f90c9b__0))));
    vlSelf->wasmetal_core__DOT___039157_ = (1U & (IData)(
                                                         (0xffffffffff000e00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27f90c9b__0)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))));
    vlSelf->__VdfgTmp_h36d9d765__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hdb7f5f3b__0));
    vlSelf->__VdfgTmp_h5b180012__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h09d9ebba__0));
    vlSelf->__VdfgTmp_h5f27695b__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hf2504815__0));
    vlSelf->__VdfgTmp_h8bc92329__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hf8fd63d3__0));
    vlSelf->wasmetal_core__DOT___024247_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c2c85cd__0))));
    vlSelf->__VdfgTmp_heca6da7c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_he887753f__0));
    vlSelf->wasmetal_core__DOT___024244_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9969096__0))));
    vlSelf->__VdfgTmp_hed15da38__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h7fe84144__0));
    vlSelf->__VdfgTmp_h405c6a5f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h3971bdc1__0));
    vlSelf->wasmetal_core__DOT___024240_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h373f306d__0))));
    vlSelf->__VdfgTmp_hed7a2bc7__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h2f82e844__0));
    vlSelf->__VdfgTmp_h86dd6551__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hc699f06e__0));
    vlSelf->wasmetal_core__DOT___024237_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86e2747e__0))));
    vlSelf->__VdfgTmp_h39529667__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hb788ecb2__0));
    vlSelf->__VdfgTmp_he7bd57fe__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h03f01150__0));
    vlSelf->__VdfgTmp_hc3266ade__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h8c718ae9__0));
    vlSelf->__VdfgTmp_h19ff1492__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h3300e967__0));
    vlSelf->wasmetal_core__DOT___024231_ = (1U & (0x4fb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde8b5012__0))));
    vlSelf->__VdfgTmp_h3d84b27a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hd8684912__0));
    vlSelf->__VdfgTmp_h16107c49__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_h27272852__0));
    vlSelf->__VdfgTmp_h3114cc84__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hd2c8a10e__0));
    vlSelf->__VdfgTmp_h8511e463__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_ha16f0aa3__0));
    vlSelf->__VdfgTmp_h7b799034__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056122_));
    vlSelf->wasmetal_core__DOT___056123_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056122_)))))))));
    vlSelf->__VdfgTmp_h546dd473__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056112_));
    vlSelf->wasmetal_core__DOT___056113_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056112_)))))))));
    vlSelf->__VdfgTmp_h742ef24c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056108_));
    vlSelf->wasmetal_core__DOT___056109_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056108_)))))))));
    vlSelf->__VdfgTmp_hde45e173__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056105_));
    vlSelf->wasmetal_core__DOT___056106_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056105_)))))))));
    vlSelf->__VdfgTmp_hfd423f40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056091_));
    vlSelf->wasmetal_core__DOT___056092_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056091_)))))))));
    vlSelf->__VdfgTmp_h17e0a363__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056023_));
    vlSelf->wasmetal_core__DOT___056050_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5553b859__0))));
    vlSelf->wasmetal_core__DOT___056019_ = (1U & (0xdU 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbf1fbd0a__0)) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5553b859__0))));
    vlSelf->wasmetal_core__DOT___024225_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056011_))));
    vlSelf->wasmetal_core__DOT___024223_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055998_))));
    vlSelf->wasmetal_core__DOT___056000_ = (1U & (IData)(
                                                         (0xf0f0f0fdULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055999_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055998_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    vlSelf->__VdfgTmp_ha26e7faa__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055991_));
    vlSelf->wasmetal_core__DOT___055993_ = (1U & (IData)(
                                                         (0xf0f0f0fdULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055992_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055991_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    vlSelf->__VdfgTmp_ha141c58a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055980_));
    vlSelf->wasmetal_core__DOT___055982_ = (1U & (IData)(
                                                         (0xf0f0f0fdULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055981_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___055980_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    vlSelf->__VdfgTmp_h5230c890__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055973_));
    vlSelf->wasmetal_core__DOT___055975_ = (1U & (IData)(
                                                         (0xf0f0f0fdULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055974_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___055973_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    vlSelf->__VdfgTmp_hda2ae911__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055968_));
    vlSelf->wasmetal_core__DOT___055969_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___055968_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055967_)))))))));
    vlSelf->wasmetal_core__DOT___024217_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055960_))));
    vlSelf->wasmetal_core__DOT___055961_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055960_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019232_)))))))));
    vlSelf->wasmetal_core__DOT___043627_ = (1U & (IData)(
                                                         (0x31703170317173fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055951_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___055968_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055960_)))))))));
    vlSelf->wasmetal_core__DOT___024216_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055951_))));
    vlSelf->wasmetal_core__DOT___055952_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055951_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055950_)))))))));
    vlSelf->wasmetal_core__DOT___043183_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070521_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055942_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___024215_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055942_))));
    vlSelf->wasmetal_core__DOT___055943_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055942_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019211_)))))))));
    vlSelf->wasmetal_core__DOT___024214_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055936_))));
    vlSelf->wasmetal_core__DOT___055937_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055936_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055935_)))))))));
    wasmetal_core__DOT___043626_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055942_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055936_)))))))));
    vlSelf->wasmetal_core__DOT___024213_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055929_))));
    wasmetal_core__DOT___055930_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055928_)))))))));
    vlSelf->__VdfgTmp_h89795cd5__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055918_));
    wasmetal_core__DOT___055919_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055918_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055917_)))))))));
    vlSelf->wasmetal_core__DOT___024211_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055911_))));
    wasmetal_core__DOT___055913_ = (1U & (IData)((0xf0f0f0fdULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055912_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055911_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055109_)))))))));
    wasmetal_core__DOT___043625_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055918_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055911_)))))))));
    vlSelf->wasmetal_core__DOT___024210_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055904_))));
    wasmetal_core__DOT___055905_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055903_)))))))));
    vlSelf->__VdfgTmp_h7884e356__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055892_));
    wasmetal_core__DOT___055893_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055892_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055891_)))))))));
    vlSelf->wasmetal_core__DOT___024208_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055879_))));
    wasmetal_core__DOT___055880_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055879_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055878_)))))))));
    wasmetal_core__DOT___043624_ = (1U & (IData)((0x31703170317173fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055892_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055879_)))))))));
    vlSelf->wasmetal_core__DOT___024207_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055873_))));
    wasmetal_core__DOT___055875_ = (1U & (IData)((0xf0faf0f3ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___019200_)))))))));
    vlSelf->wasmetal_core__DOT___056576_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010376_))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h4a210212__0)))) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___024168_));
        wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010022_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___010022_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__ 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT___024299_));
    }
    vlSelf->wasmetal_core__DOT___056979_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056584_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128541___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134164___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O))));
    if (vlSelf->wasmetal_core__DOT___043258_) {
        if (vlSelf->wasmetal_core__DOT___043257_) {
            if (vlSelf->wasmetal_core__DOT___043256_) {
                if (vlSelf->wasmetal_core__DOT___043255_) {
                    if (vlSelf->wasmetal_core__DOT___043254_) {
                        if (vlSelf->wasmetal_core__DOT___010061_) {
                            if (vlSelf->wasmetal_core__DOT___010063_) {
                                if (vlSelf->wasmetal_core__DOT___043253_) {
                                    if (vlSelf->wasmetal_core__DOT___043252_) {
                                        if (vlSelf->wasmetal_core__DOT___043251_) {
                                            if (vlSelf->wasmetal_core__DOT___043250_) {
                                                if (
                                                    (1U 
                                                     & (0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2237a749__0)))) {
                                                    if (vlSelf->wasmetal_core__DOT___043264_) {
                                                        if (vlSelf->wasmetal_core__DOT___043263_) {
                                                            if (vlSelf->wasmetal_core__DOT___043262_) {
                                                                if (vlSelf->wasmetal_core__DOT___043261_) {
                                                                    if (vlSelf->wasmetal_core__DOT___043260_) {
                                                                        if (vlSelf->wasmetal_core__DOT___043259_) {
                                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                                = vlSelf->wasmetal_core__DOT___043156_;
                                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                                = vlSelf->wasmetal_core__DOT___043301_;
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                                = vlSelf->wasmetal_core__DOT___043241_;
                                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                                = vlSelf->wasmetal_core__DOT___043241_;
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___038804_ 
                                                                            = vlSelf->wasmetal_core__DOT___043242_;
                                                                        vlSelf->wasmetal_core__DOT___011171_ 
                                                                            = vlSelf->wasmetal_core__DOT___043242_;
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___038804_ 
                                                                        = vlSelf->wasmetal_core__DOT___043243_;
                                                                    vlSelf->wasmetal_core__DOT___011171_ 
                                                                        = vlSelf->wasmetal_core__DOT___043243_;
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___038804_ 
                                                                    = vlSelf->wasmetal_core__DOT___043244_;
                                                                vlSelf->wasmetal_core__DOT___011171_ 
                                                                    = vlSelf->wasmetal_core__DOT___043244_;
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                                = vlSelf->wasmetal_core__DOT___043245_;
                                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                                = vlSelf->wasmetal_core__DOT___043245_;
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___038804_ 
                                                            = vlSelf->wasmetal_core__DOT___043246_;
                                                        vlSelf->wasmetal_core__DOT___011171_ 
                                                            = vlSelf->wasmetal_core__DOT___043246_;
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___038804_ 
                                                        = vlSelf->wasmetal_core__DOT___043229_;
                                                    vlSelf->wasmetal_core__DOT___011171_ 
                                                        = vlSelf->wasmetal_core__DOT___043229_;
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___038804_ 
                                                    = vlSelf->wasmetal_core__DOT___043230_;
                                                vlSelf->wasmetal_core__DOT___011171_ 
                                                    = vlSelf->wasmetal_core__DOT___043230_;
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___038804_ 
                                                = vlSelf->wasmetal_core__DOT___043231_;
                                            vlSelf->wasmetal_core__DOT___011171_ 
                                                = vlSelf->wasmetal_core__DOT___043231_;
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___038804_ 
                                            = vlSelf->wasmetal_core__DOT___043232_;
                                        vlSelf->wasmetal_core__DOT___011171_ 
                                            = vlSelf->wasmetal_core__DOT___043232_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___038804_ 
                                        = vlSelf->wasmetal_core__DOT___043233_;
                                    vlSelf->wasmetal_core__DOT___011171_ 
                                        = vlSelf->wasmetal_core__DOT___043233_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___038804_ 
                                    = vlSelf->wasmetal_core__DOT___043234_;
                                vlSelf->wasmetal_core__DOT___011171_ 
                                    = vlSelf->wasmetal_core__DOT___043234_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___038804_ 
                                = vlSelf->wasmetal_core__DOT___043235_;
                            vlSelf->wasmetal_core__DOT___011171_ 
                                = vlSelf->wasmetal_core__DOT___043235_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___038804_ 
                            = vlSelf->wasmetal_core__DOT___043236_;
                        vlSelf->wasmetal_core__DOT___011171_ 
                            = vlSelf->wasmetal_core__DOT___043236_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___038804_ 
                        = vlSelf->wasmetal_core__DOT___043237_;
                    vlSelf->wasmetal_core__DOT___011171_ 
                        = vlSelf->wasmetal_core__DOT___043237_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___038804_ 
                    = vlSelf->wasmetal_core__DOT___043238_;
                vlSelf->wasmetal_core__DOT___011171_ 
                    = vlSelf->wasmetal_core__DOT___043238_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___038804_ = vlSelf->wasmetal_core__DOT___043239_;
            vlSelf->wasmetal_core__DOT___011171_ = vlSelf->wasmetal_core__DOT___043239_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___038804_ = vlSelf->wasmetal_core__DOT___043240_;
        vlSelf->wasmetal_core__DOT___011171_ = vlSelf->wasmetal_core__DOT___043240_;
    }
    wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023198_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___053601_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                         >> 3U)))));
    wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035975_)
            ? (IData)(wasmetal_core__DOT___035918_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d));
    vlSelf->wasmetal_core__DOT___018538_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                                          ? 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))
                                                                          : 
                                                                         (0xc0c5U 
                                                                          >> 
                                                                          ((8U 
                                                                            & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8d5d3612__0)) 
                                                                               << 3U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h95fb6f3e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf0f0cc55U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f0cc55U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hdb61f435__0))))))))))));
    vlSelf->wasmetal_core__DOT___059619_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___017940_)
                                                               ? 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))
                                                               : 
                                                              (0xc0c5U 
                                                               >> 
                                                               ((8U 
                                                                 & ((4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h2a4257a8__0)) 
                                                                    << 3U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h8c2e6c21__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0fccaa00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                              << 4U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0000ccaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h5aa7dbd9__0))))))))))));
    wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___036325_));
    wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035672_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035617_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b9__05d));
    vlSelf->__VdfgTmp_h4b49f700__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h648a31a7__0)));
    vlSelf->__VdfgTmp_h54798c59__0 = (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012167_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010378_)));
    wasmetal_core__DOT___043623_ = (1U & (IData)((0xffffffff50f5c0fcULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070541_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___070540_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc8f8c4ae__0))))))));
    vlSelf->wasmetal_core__DOT___043664_ = (1U & (0xfffff444U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070541_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024206_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___070540_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055854_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)))))));
    wasmetal_core__DOT___070563_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h36d9d765__0))));
    wasmetal_core__DOT___043199_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024256_)))));
    wasmetal_core__DOT___070564_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5b180012__0))))));
    wasmetal_core__DOT___070558_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_heca6da7c__0))));
    wasmetal_core__DOT___070556_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024244_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hed15da38__0))));
    wasmetal_core__DOT___043194_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h405c6a5f__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024244_)))));
    wasmetal_core__DOT___070555_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed15da38__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024244_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h405c6a5f__0))))));
    wasmetal_core__DOT___070554_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024240_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0))));
    wasmetal_core__DOT___043193_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h86dd6551__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024240_)))));
    wasmetal_core__DOT___070553_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hed7a2bc7__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024240_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h86dd6551__0))))));
    wasmetal_core__DOT___070552_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024237_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h39529667__0))));
    wasmetal_core__DOT___043192_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he7bd57fe__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h39529667__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024237_)))));
    wasmetal_core__DOT___070551_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h39529667__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024237_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7bd57fe__0))))));
    wasmetal_core__DOT___070548_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024231_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h3d84b27a__0))));
    wasmetal_core__DOT___043190_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h16107c49__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024231_)))));
    wasmetal_core__DOT___070547_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d84b27a__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___024231_) 
                                                       << 4U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h16107c49__0))))));
    wasmetal_core__DOT___043165_ = (1U & (IData)((0xfeeaeaeaeaeaeaeaULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055998_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056011_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070524_)))))))));
    wasmetal_core__DOT___043175_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070533_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7b799034__0))));
    wasmetal_core__DOT___070562_ = (1U & (0x4f0000U 
                                          >> ((0x10U 
                                               & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)) 
                                                  << 4U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h5f27695b__0))));
    wasmetal_core__DOT___043198_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))))));
    wasmetal_core__DOT___070561_ = (1U & (0x1000U >> 
                                          ((8U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h546dd473__0)))));
    wasmetal_core__DOT___043173_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070532_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h742ef24c__0))));
    wasmetal_core__DOT___043196_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)))))));
    wasmetal_core__DOT___070559_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                          << 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8bc92329__0))))));
    wasmetal_core__DOT___070560_ = (1U & (0x10U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hde45e173__0))));
    wasmetal_core__DOT___043195_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))))));
    wasmetal_core__DOT___070557_ = (1U & (0x1000U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                                            << 3U) 
                                           | ((4U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134221___B 
        = ((0x3e000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039157_))) 
                        << 0xdU)) | ((0x1000U & ((0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___039157_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))) 
                                                 << 0xcU)) 
                                     | ((0x800U & ((IData)(
                                                           (0xff000e00ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___056132_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdb7f5f3b__0)))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                   << 0xbU)) 
                                        | ((0x400U 
                                            & ((IData)(
                                                       (0xff000e00ffffffffULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___056128_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h09d9ebba__0)))))) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                               << 0xaU)) 
                                           | ((0x200U 
                                               & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056123_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 9U)) 
                                              | ((0x100U 
                                                  & ((IData)(
                                                             (0xff000e00ffffffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___056118_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2504815__0)))))) 
                                                                               << 1U)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                     << 8U)) 
                                                 | ((0x80U 
                                                     & ((IData)(
                                                                (0xfffffff8ffff8888ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056113_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                        << 7U)) 
                                                    | ((0x40U 
                                                        & ((IData)(
                                                                   (0xfffffff8ffff8888ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056109_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                           << 6U)) 
                                                       | ((0x20U 
                                                           & ((IData)(
                                                                      (0xfffffff8ffff8888ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056106_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                              << 5U)) 
                                                          | ((0x10U 
                                                              & ((IData)(
                                                                         (0xff000e00ffffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___056101_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf8fd63d3__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                 << 4U)) 
                                                             | ((8U 
                                                                 & ((IData)(
                                                                            (0xff000e00ffffffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___056098_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5c2c85cd__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                    << 3U)) 
                                                                | ((4U 
                                                                    & ((IData)(
                                                                               (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056095_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he887753f__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056088_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9969096__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_))))))))))))))))))))));
    wasmetal_core__DOT___043166_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070525_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h17e0a363__0))));
    vlSelf->__VdfgTmp_had236f40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056050_));
    wasmetal_core__DOT___056051_ = (1U & (IData)((0xff00fff1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056050_)))))))));
    wasmetal_core__DOT___043609_ = (1U & (0x173f0317U 
                                          >> ((0x10U 
                                               & ((0x4fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                  << 4U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056023_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___056019_)))))));
    vlSelf->wasmetal_core__DOT___043653_ = (1U & (IData)(
                                                         (0x4fff444f44444444ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x4fU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056019_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010656_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___024227_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056019_))));
    wasmetal_core__DOT___056020_ = (1U & (IData)((0xff00fff1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055874_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___056019_)))))))));
    wasmetal_core__DOT___070545_ = (1U & (0x4f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___024225_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h8511e463__0))));
    wasmetal_core__DOT___070544_ = (1U & (8U >> ((2U 
                                                  & ((0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h8511e463__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___024225_))));
    wasmetal_core__DOT___043164_ = (1U & (IData)((0xf8ff88f888888888ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024485_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009807_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((0x10U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h8b57d846__0)) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h78ac443f__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_ha26e7faa__0))))))));
    wasmetal_core__DOT___070543_ = (1U & (0x10U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_ha141c58a__0))));
    wasmetal_core__DOT___043187_ = (1U & (0x80U >> 
                                          ((4U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5230c890__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)))))));
    wasmetal_core__DOT___070542_ = (1U & (0x1000U >> 
                                          ((8U & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha141c58a__0)) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_ha26e7faa__0)) 
                                                << 2U)) 
                                              | (IData)(vlSelf->__VdfgTmp_h5230c890__0)))));
    wasmetal_core__DOT___043184_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070522_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hda2ae911__0))));
    vlSelf->wasmetal_core__DOT___043668_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055951_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055960_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055964_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___011020_))))))))))));
    wasmetal_core__DOT___043207_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024216_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024217_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hda2ae911__0)))))));
    vlSelf->wasmetal_core__DOT___043667_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___024215_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055936_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055938_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))))))))));
    wasmetal_core__DOT___043206_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024213_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024214_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___024215_)))));
    wasmetal_core__DOT___043182_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070520_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h89795cd5__0))));
    vlSelf->wasmetal_core__DOT___043666_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055911_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010054_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d))))))))))));
    wasmetal_core__DOT___043205_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024210_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024211_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h89795cd5__0)))))));
    wasmetal_core__DOT___043181_ = (1U & (0x8fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___070519_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7884e356__0))));
    vlSelf->wasmetal_core__DOT___043665_ = (1U & (IData)(
                                                         (0xabababbfaaaaaaaaULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055873_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055879_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055888_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134223___B 
        = ((0x10000U & ((IData)((0xff000e00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___056013_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xf1U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___056011_))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xff000e00ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___056007_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha16f0aa3__0)))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((0xffff88f8U 
                                            >> (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___056000_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((0xffff88f8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055993_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((0xffff88f8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055982_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((0xffff88f8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055975_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055969_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055961_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055952_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffff8ffff8888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055943_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffff8ffff8888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055937_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055930_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055919_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((0xffff88f8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055913_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055905_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055893_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___055880_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))))))))))))))))))));
    wasmetal_core__DOT___043204_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___024207_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024208_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7884e356__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134220___B 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                 << 4U) 
                                                | (((IData)(wasmetal_core__DOT___055875_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffffffffff010ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055867_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xcc550f0fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfadc0d9c__0))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffff8ffff8888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                            << 3U) 
                                                           | ((4U 
                                                               & ((0xfc00aaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055839_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___019266_)))))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffff8ffff8888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((0xfc00aaU 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055826_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019255_)))))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffff8ffff8888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xfa00ccU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055805_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010068_)))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffff8ffff8888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xfc00aaU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019243_)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                          << 3U) 
                                                                         | ((4U 
                                                                             & ((0xfc00aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055777_)))))) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                             << 3U) 
                                                                            | ((4U 
                                                                                & ((0xfc00aaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011276_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055759_)))))) 
                                                                                << 2U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((0xffff88f8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055735_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xffff88f8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055713_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xf888fffff888f888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055662_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055660_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001475_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055608_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055606_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001443_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xf888fffff888f888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055559_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055558_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffff888ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055511_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048442_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055510_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xffffffffffff8f88ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055469_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf0f3355U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010042_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055467_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055467_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055412_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x4fU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0x777U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0f5533U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055364_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055363_)))))))))))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___010028_) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__));
        wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033411_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033411_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__));
    }
    wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127531___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___023197_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023196_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127531___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023259_)))));
    vlSelf->wasmetal_core__DOT___023263_ = ((IData)(vlSelf->wasmetal_core__DOT___023199_) 
                                            & (IData)(wasmetal_core__DOT___127531___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
           & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035976_)
            ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d));
    wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
           & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128728___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035369_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b1__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_negAlignedSigSmaller__05b0__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128728___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (1U & 
                                               (0xdf2f20dU 
                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)))))));
    vlSelf->wasmetal_core__DOT___035315_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035369_)
                                                   ? (IData)(wasmetal_core__DOT___128728___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce64fd81__0))));
    wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035673_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b10__05d));
    vlSelf->wasmetal_core__DOT___012472_ = (1U & (0xbe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056601_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54798c59__0))));
    vlSelf->wasmetal_core__DOT___012015_ = (1U & (0xbe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h54798c59__0))));
    wasmetal_core__DOT___043619_ = (1U & (IData)((0xffffffffffffb000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070564_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070563_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056135_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h10a93ed5__0))))))));
    vlSelf->wasmetal_core__DOT___043662_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070563_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070564_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056134_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d))))));
    wasmetal_core__DOT___043614_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070556_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070555_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056086_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043658_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070556_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070555_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010648_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d))))));
    wasmetal_core__DOT___043613_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070554_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070553_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056075_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043657_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070554_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070553_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056074_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d))))));
    wasmetal_core__DOT___043612_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070552_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070551_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056063_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043656_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070552_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070551_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056062_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d))))));
    wasmetal_core__DOT___043610_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070548_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070547_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056035_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043654_ = (1U & (0xffffff10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070547_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___070548_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056034_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)))))));
    wasmetal_core__DOT___043618_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070562_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070561_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056122_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d))))));
    vlSelf->wasmetal_core__DOT___043661_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070562_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070561_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056121_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d))))));
    wasmetal_core__DOT___043616_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070560_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070559_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056108_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d))))));
    vlSelf->wasmetal_core__DOT___043660_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070560_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070559_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056107_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d))))));
    wasmetal_core__DOT___043615_ = (1U & (IData)((0xffffffffffff020fULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070558_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___070557_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056096_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h9415b560__0))))))));
    vlSelf->wasmetal_core__DOT___043659_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070558_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070557_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010650_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d))))));
    wasmetal_core__DOT___043168_ = (1U & (IData)((0xf8ff88f888888888ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___024493_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056044_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xb0U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6a2679f3__0)) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_had236f40__0))))))));
    wasmetal_core__DOT___043191_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h19ff1492__0)) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)) 
                                                << 1U)) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_had236f40__0)))))));
    wasmetal_core__DOT___070549_ = (1U & (IData)((0x4f000000000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((0x4fb0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc3266ade__0)) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_had236f40__0)) 
                                                          << 4U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h19ff1492__0))))));
    wasmetal_core__DOT___070550_ = (1U & (0x4f0000U 
                                          >> ((0x10U 
                                               & ((6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_had236f40__0)) 
                                                  << 4U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc3266ade__0))));
    wasmetal_core__DOT___043189_ = (1U & (0x80U >> 
                                          ((4U & ((0x4fb0U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3114cc84__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___024227_) 
                                               << 1U) 
                                              | (1U 
                                                 & (6U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h17e0a363__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134224___B 
        = ((0x10000U & ((IData)((0xff000e00ffffffffULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___056085_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff00ff4fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h7fe84144__0)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xff000e00ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___056082_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3971bdc1__0)))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xff000e00ffffffffULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___056077_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & ((IData)(
                                                                             (0xff00ff4fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h373f306d__0)))))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xff000e00ffffffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___056073_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2f82e844__0)))))) 
                                                                          << 1U)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xff000e00ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___056069_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc699f06e__0)))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xff000e00ffffffffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___056065_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86e2747e__0)))))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xff000e00ffffffffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___056060_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb788ecb2__0)))))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xff000e00ffffffffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___056055_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h03f01150__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                             << 4U) 
                                                                            | (((IData)(wasmetal_core__DOT___056051_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xff000e00ffffffffULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___056047_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8c718ae9__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xff000e00ffffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___056041_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3300e967__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056037_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde8b5012__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056033_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8684912__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056029_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27272852__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056025_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056023_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___056020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff000e00ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___056017_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ff4fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056005_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd2c8a10e__0)))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055874_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___043652_ = (1U & (IData)(
                                                         (0xffffffff40ff4040ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070545_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010653_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010026_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfef0U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)))))))))));
    wasmetal_core__DOT___043608_ = (1U & (IData)((0xffffffff101010ffULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070545_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056011_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___070544_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055998_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d)))))))));
    wasmetal_core__DOT___043188_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___024223_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___070544_))));
    wasmetal_core__DOT___043607_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070543_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070542_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___055991_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d))))));
    vlSelf->wasmetal_core__DOT___043651_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070543_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070542_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x10U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4528de02__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010972_))))));
    if (vlSelf->wasmetal_core__DOT___010023_) {
        wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__));
        wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033416_)));
    } else {
        wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__ 
            = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033416_)));
        wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__ 
            = (1U & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127719___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)))) 
           ^ (((IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___024855_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127719___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___005913_ = (1U & ((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85d5ffaf__0)))))));
    vlSelf->wasmetal_core__DOT___005847_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hbca1455c__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_haeb15d33__0)))));
    vlSelf->wasmetal_core__DOT___005779_ = (1U & (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))))
                                                      : 
                                                     (0x302U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85c84d1a__0)))))));
    vlSelf->wasmetal_core__DOT___005778_ = (IData)(
                                                   (((IData)(wasmetal_core__DOT____Vcellout___127531___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h850cecd0__0)))))));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023200_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023263_));
    vlSelf->wasmetal_core__DOT____Vcellout___128872___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b46__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b45__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b44__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036503_)))));
    vlSelf->wasmetal_core__DOT___036507_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b47__05d) 
                                            & (IData)(wasmetal_core__DOT___128872___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035977_)
            ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d));
    wasmetal_core__DOT____Vcellout___127498___O = (
                                                   ((8U 
                                                     & ((0xf10eU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha253f9f2__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((6U 
                                                               >> (IData)(vlSelf->__VdfgTmp_hbca2c4ae__0)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3c71f500__0)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127498___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022990_)))));
    vlSelf->wasmetal_core__DOT___022994_ = ((0xf10eU 
                                             >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                            & (IData)(wasmetal_core__DOT___127498___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__ 
        = ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
           & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035380_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035315_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hf76f8bb1__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128748___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                       >> 2U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                   >> 1U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ 
                                                   ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 3U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128748___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035486_)))));
    vlSelf->wasmetal_core__DOT___035505_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                >> 2U)) 
                                            & (IData)(wasmetal_core__DOT___128748___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035621_)
            ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b11__05d));
    wasmetal_core__DOT___043611_ = (1U & (0xfff1U >> 
                                          (((IData)(wasmetal_core__DOT___070550_) 
                                            << 3U) 
                                           | (((IData)(wasmetal_core__DOT___070549_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___056050_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___043655_ = (1U & (0xfff4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070550_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___070549_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4cbaee21__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d))))));
    if (wasmetal_core__DOT___043199_) {
        if (wasmetal_core__DOT___043198_) {
            if (wasmetal_core__DOT___043196_) {
                if (wasmetal_core__DOT___043195_) {
                    if (wasmetal_core__DOT___043194_) {
                        if (wasmetal_core__DOT___043193_) {
                            if (wasmetal_core__DOT___043192_) {
                                if (wasmetal_core__DOT___043191_) {
                                    if (wasmetal_core__DOT___043190_) {
                                        if (wasmetal_core__DOT___043189_) {
                                            if (wasmetal_core__DOT___043188_) {
                                                if (wasmetal_core__DOT___043187_) {
                                                    if (wasmetal_core__DOT___043207_) {
                                                        if (wasmetal_core__DOT___043206_) {
                                                            if (wasmetal_core__DOT___043205_) {
                                                                if (wasmetal_core__DOT___043204_) {
                                                                    if (vlSelf->wasmetal_core__DOT___043203_) {
                                                                        if (vlSelf->wasmetal_core__DOT___043202_) {
                                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                                = vlSelf->wasmetal_core__DOT___043156_;
                                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                                = vlSelf->wasmetal_core__DOT___043301_;
                                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                                = vlSelf->wasmetal_core__DOT___043599_;
                                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                                = vlSelf->wasmetal_core__DOT___043690_;
                                                                        } else {
                                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                                = vlSelf->wasmetal_core__DOT___043179_;
                                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                                = vlSelf->wasmetal_core__DOT___043179_;
                                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                                = vlSelf->wasmetal_core__DOT___043622_;
                                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                                = vlSelf->wasmetal_core__DOT___043622_;
                                                                        }
                                                                    } else {
                                                                        vlSelf->wasmetal_core__DOT___038803_ 
                                                                            = vlSelf->wasmetal_core__DOT___043180_;
                                                                        vlSelf->wasmetal_core__DOT___011170_ 
                                                                            = vlSelf->wasmetal_core__DOT___043180_;
                                                                        vlSelf->wasmetal_core__DOT___038801_ 
                                                                            = wasmetal_core__DOT___043623_;
                                                                        vlSelf->wasmetal_core__DOT___011246_ 
                                                                            = wasmetal_core__DOT___043623_;
                                                                    }
                                                                } else {
                                                                    vlSelf->wasmetal_core__DOT___038803_ 
                                                                        = wasmetal_core__DOT___043181_;
                                                                    vlSelf->wasmetal_core__DOT___011170_ 
                                                                        = wasmetal_core__DOT___043181_;
                                                                    vlSelf->wasmetal_core__DOT___038801_ 
                                                                        = wasmetal_core__DOT___043624_;
                                                                    vlSelf->wasmetal_core__DOT___011246_ 
                                                                        = wasmetal_core__DOT___043624_;
                                                                }
                                                            } else {
                                                                vlSelf->wasmetal_core__DOT___038803_ 
                                                                    = wasmetal_core__DOT___043182_;
                                                                vlSelf->wasmetal_core__DOT___011170_ 
                                                                    = wasmetal_core__DOT___043182_;
                                                                vlSelf->wasmetal_core__DOT___038801_ 
                                                                    = wasmetal_core__DOT___043625_;
                                                                vlSelf->wasmetal_core__DOT___011246_ 
                                                                    = wasmetal_core__DOT___043625_;
                                                            }
                                                        } else {
                                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                                = vlSelf->wasmetal_core__DOT___043183_;
                                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                                = vlSelf->wasmetal_core__DOT___043183_;
                                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                                = wasmetal_core__DOT___043626_;
                                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                                = wasmetal_core__DOT___043626_;
                                                        }
                                                    } else {
                                                        vlSelf->wasmetal_core__DOT___038803_ 
                                                            = wasmetal_core__DOT___043184_;
                                                        vlSelf->wasmetal_core__DOT___011170_ 
                                                            = wasmetal_core__DOT___043184_;
                                                        vlSelf->wasmetal_core__DOT___038801_ 
                                                            = vlSelf->wasmetal_core__DOT___043627_;
                                                        vlSelf->wasmetal_core__DOT___011246_ 
                                                            = vlSelf->wasmetal_core__DOT___043627_;
                                                    }
                                                } else {
                                                    vlSelf->wasmetal_core__DOT___038803_ 
                                                        = wasmetal_core__DOT___043164_;
                                                    vlSelf->wasmetal_core__DOT___011170_ 
                                                        = wasmetal_core__DOT___043164_;
                                                    vlSelf->wasmetal_core__DOT___038801_ 
                                                        = wasmetal_core__DOT___043607_;
                                                    vlSelf->wasmetal_core__DOT___011246_ 
                                                        = wasmetal_core__DOT___043607_;
                                                }
                                            } else {
                                                vlSelf->wasmetal_core__DOT___038803_ 
                                                    = wasmetal_core__DOT___043165_;
                                                vlSelf->wasmetal_core__DOT___011170_ 
                                                    = wasmetal_core__DOT___043165_;
                                                vlSelf->wasmetal_core__DOT___038801_ 
                                                    = wasmetal_core__DOT___043608_;
                                                vlSelf->wasmetal_core__DOT___011246_ 
                                                    = wasmetal_core__DOT___043608_;
                                            }
                                        } else {
                                            vlSelf->wasmetal_core__DOT___038803_ 
                                                = wasmetal_core__DOT___043166_;
                                            vlSelf->wasmetal_core__DOT___011170_ 
                                                = wasmetal_core__DOT___043166_;
                                            vlSelf->wasmetal_core__DOT___038801_ 
                                                = wasmetal_core__DOT___043609_;
                                            vlSelf->wasmetal_core__DOT___011246_ 
                                                = wasmetal_core__DOT___043609_;
                                        }
                                    } else {
                                        vlSelf->wasmetal_core__DOT___038803_ 
                                            = vlSelf->wasmetal_core__DOT___043167_;
                                        vlSelf->wasmetal_core__DOT___011170_ 
                                            = vlSelf->wasmetal_core__DOT___043167_;
                                        vlSelf->wasmetal_core__DOT___038801_ 
                                            = wasmetal_core__DOT___043610_;
                                        vlSelf->wasmetal_core__DOT___011246_ 
                                            = wasmetal_core__DOT___043610_;
                                    }
                                } else {
                                    vlSelf->wasmetal_core__DOT___038803_ 
                                        = wasmetal_core__DOT___043168_;
                                    vlSelf->wasmetal_core__DOT___011170_ 
                                        = wasmetal_core__DOT___043168_;
                                    vlSelf->wasmetal_core__DOT___038801_ 
                                        = wasmetal_core__DOT___043611_;
                                    vlSelf->wasmetal_core__DOT___011246_ 
                                        = wasmetal_core__DOT___043611_;
                                }
                            } else {
                                vlSelf->wasmetal_core__DOT___038803_ 
                                    = vlSelf->wasmetal_core__DOT___043169_;
                                vlSelf->wasmetal_core__DOT___011170_ 
                                    = vlSelf->wasmetal_core__DOT___043169_;
                                vlSelf->wasmetal_core__DOT___038801_ 
                                    = wasmetal_core__DOT___043612_;
                                vlSelf->wasmetal_core__DOT___011246_ 
                                    = wasmetal_core__DOT___043612_;
                            }
                        } else {
                            vlSelf->wasmetal_core__DOT___038803_ 
                                = vlSelf->wasmetal_core__DOT___043170_;
                            vlSelf->wasmetal_core__DOT___011170_ 
                                = vlSelf->wasmetal_core__DOT___043170_;
                            vlSelf->wasmetal_core__DOT___038801_ 
                                = wasmetal_core__DOT___043613_;
                            vlSelf->wasmetal_core__DOT___011246_ 
                                = wasmetal_core__DOT___043613_;
                        }
                    } else {
                        vlSelf->wasmetal_core__DOT___038803_ 
                            = vlSelf->wasmetal_core__DOT___043171_;
                        vlSelf->wasmetal_core__DOT___011170_ 
                            = vlSelf->wasmetal_core__DOT___043171_;
                        vlSelf->wasmetal_core__DOT___038801_ 
                            = wasmetal_core__DOT___043614_;
                        vlSelf->wasmetal_core__DOT___011246_ 
                            = wasmetal_core__DOT___043614_;
                    }
                } else {
                    vlSelf->wasmetal_core__DOT___038803_ 
                        = vlSelf->wasmetal_core__DOT___043172_;
                    vlSelf->wasmetal_core__DOT___011170_ 
                        = vlSelf->wasmetal_core__DOT___043172_;
                    vlSelf->wasmetal_core__DOT___038801_ 
                        = wasmetal_core__DOT___043615_;
                    vlSelf->wasmetal_core__DOT___011246_ 
                        = wasmetal_core__DOT___043615_;
                }
            } else {
                vlSelf->wasmetal_core__DOT___038803_ 
                    = wasmetal_core__DOT___043173_;
                vlSelf->wasmetal_core__DOT___011170_ 
                    = wasmetal_core__DOT___043173_;
                vlSelf->wasmetal_core__DOT___038801_ 
                    = wasmetal_core__DOT___043616_;
                vlSelf->wasmetal_core__DOT___011246_ 
                    = wasmetal_core__DOT___043616_;
            }
        } else {
            vlSelf->wasmetal_core__DOT___038803_ = wasmetal_core__DOT___043175_;
            vlSelf->wasmetal_core__DOT___011170_ = wasmetal_core__DOT___043175_;
            vlSelf->wasmetal_core__DOT___038801_ = wasmetal_core__DOT___043618_;
            vlSelf->wasmetal_core__DOT___011246_ = wasmetal_core__DOT___043618_;
        }
    } else {
        vlSelf->wasmetal_core__DOT___038803_ = vlSelf->wasmetal_core__DOT___043176_;
        vlSelf->wasmetal_core__DOT___011170_ = vlSelf->wasmetal_core__DOT___043176_;
        vlSelf->wasmetal_core__DOT___038801_ = wasmetal_core__DOT___043619_;
        vlSelf->wasmetal_core__DOT___011246_ = wasmetal_core__DOT___043619_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127644___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)) 
                   << 3U)) | (IData)(vlSelf->__VdfgTmp_h50ba50d5__0)) 
           ^ (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024168_)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0)))) {
        vlSelf->wasmetal_core__DOT___024197_ = (1U 
                                                & (IData)(wasmetal_core__DOT___127677___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___024328_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___010044_)));
    } else {
        vlSelf->wasmetal_core__DOT___024197_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___010044_)));
        vlSelf->wasmetal_core__DOT___024328_ = (1U 
                                                & (IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127661___O 
        = (((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h71fdadc4__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010023_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___010028_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4a210212__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127710___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024299_)))));
    vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023201_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127532___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128873___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i64__02ecomplUnroundedInt__05b48__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036507_));
    vlSelf->wasmetal_core__DOT____Vcellout___128806___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035978_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035977_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035976_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035975_)))) 
           ^ (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035918_)))));
    vlSelf->wasmetal_core__DOT___035922_ = ((IData)(vlSelf->wasmetal_core__DOT___035978_)
                                             ? (IData)(wasmetal_core__DOT___128806___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d));
    vlSelf->wasmetal_core__DOT___059797_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018498_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xff00aaaafc0cfc0cULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017938_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0xdU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((0xf100U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h37243dd3__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                                                >> 3U))))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xff00aaaafc0cfc0cULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___017940_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017947_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (0x770f0fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058456_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128865___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058455_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058438_)))))))))))))))))))))));
    vlSelf->__VdfgTmp_hc406f1dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_h0017edb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___127498___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->__VdfgTmp_hc4afcee8__0 = (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & (IData)(wasmetal_core__DOT____Vcellout___127498___O)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___005713_)))));
    vlSelf->wasmetal_core__DOT___127499___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hf599dae9__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___022994_));
    vlSelf->wasmetal_core__DOT____Vcellout___128851___O 
        = (((8U & ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                   << 3U)) | ((4U & ((7U >> (IData)(vlSelf->__VdfgTmp_hf223abb4__0)) 
                                     << 2U)) | ((2U 
                                                 & ((7U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2f0f6f72__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h692ab415__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036325_)))));
    vlSelf->wasmetal_core__DOT___036329_ = ((7U >> (IData)(vlSelf->__VdfgTmp_h77210e87__0)) 
                                            & (IData)(wasmetal_core__DOT___128851___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035387_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128734___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h90b8d623__0))));
    vlSelf->wasmetal_core__DOT___128749___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
               >> 3U)) & (IData)(vlSelf->wasmetal_core__DOT___035505_));
    vlSelf->wasmetal_core__DOT____Vcellout___128763___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035622_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035621_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035673_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035672_)))) 
           ^ (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035617_)))));
    vlSelf->wasmetal_core__DOT___035567_ = ((IData)(vlSelf->wasmetal_core__DOT___035622_)
                                             ? (IData)(wasmetal_core__DOT___128763___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b12__05d));
}
