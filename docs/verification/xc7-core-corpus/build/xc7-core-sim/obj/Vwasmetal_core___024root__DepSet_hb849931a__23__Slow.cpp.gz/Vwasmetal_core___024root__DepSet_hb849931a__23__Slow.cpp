#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__30(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__30\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___051269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049944_))));
    vlSelf->wasmetal_core__DOT___049945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050484_))));
    vlSelf->wasmetal_core__DOT___050486_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050484_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049924_))));
    vlSelf->wasmetal_core__DOT___051274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049924_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049921_))));
    vlSelf->wasmetal_core__DOT___050494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049921_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___013701_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000143_))));
    vlSelf->wasmetal_core__DOT___017284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___058005_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001797_))));
    vlSelf->wasmetal_core__DOT___013652_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002188_))));
    vlSelf->__VdfgTmp_h15d2df15__0 = (((IData)(vlSelf->wasmetal_core__DOT___049567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049566_));
    vlSelf->wasmetal_core__DOT___049100_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049090_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049089_))));
    vlSelf->wasmetal_core__DOT___048980_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048978_))));
    vlSelf->__VdfgTmp_h32efca0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___049265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049264_));
    vlSelf->__VdfgTmp_h65c50ed7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049567_));
    vlSelf->wasmetal_core__DOT___049485_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049107_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049090_))));
    vlSelf->wasmetal_core__DOT___049837_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048970_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048979_))));
    vlSelf->wasmetal_core__DOT___049456_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049254_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049265_))));
    vlSelf->__VdfgTmp_hd992aaf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049564_));
    vlSelf->wasmetal_core__DOT___049109_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049107_))));
    vlSelf->wasmetal_core__DOT___048981_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048971_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048970_))));
    vlSelf->wasmetal_core__DOT___049258_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049254_))));
    vlSelf->__VdfgTmp_h6f0935bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___049554_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049565_));
    vlSelf->__VdfgTmp_h337a7e76__0 = (((IData)(vlSelf->wasmetal_core__DOT___049103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049108_));
    vlSelf->wasmetal_core__DOT___050602_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048971_))));
    vlSelf->wasmetal_core__DOT___049457_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049256_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049255_))));
    vlSelf->__VdfgTmp_hd0aa9c81__0 = (((IData)(vlSelf->wasmetal_core__DOT___049555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049554_));
    vlSelf->__VdfgTmp_hf7ec4412__0 = (((IData)(vlSelf->wasmetal_core__DOT___049104_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049103_));
    vlSelf->wasmetal_core__DOT___048998_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048996_))));
    vlSelf->wasmetal_core__DOT___049259_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049256_))));
    vlSelf->__VdfgTmp_h92ec5796__0 = (((IData)(vlSelf->wasmetal_core__DOT___049552_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049555_));
    vlSelf->__VdfgTmp_h97f76463__0 = (((IData)(vlSelf->wasmetal_core__DOT___049202_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049104_));
    vlSelf->wasmetal_core__DOT___050607_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048997_))));
    vlSelf->wasmetal_core__DOT___049469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049257_))));
    vlSelf->__VdfgTmp_h2cac88ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___049553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049552_));
    vlSelf->wasmetal_core__DOT___049204_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049202_))));
    vlSelf->wasmetal_core__DOT___048999_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048988_))));
    vlSelf->wasmetal_core__DOT___049307_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049305_))));
    vlSelf->wasmetal_core__DOT___050626_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049553_))));
    vlSelf->wasmetal_core__DOT___049516_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049198_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049203_))));
    vlSelf->wasmetal_core__DOT___050608_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048989_))));
    vlSelf->wasmetal_core__DOT___049470_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049306_))));
    vlSelf->wasmetal_core__DOT___049562_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049560_))));
    vlSelf->__VdfgTmp_h10a4b2d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049199_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049198_));
    vlSelf->wasmetal_core__DOT___050508_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050506_))));
    vlSelf->wasmetal_core__DOT___049308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049304_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049303_))));
    vlSelf->wasmetal_core__DOT___050627_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049561_))));
    vlSelf->wasmetal_core__DOT___049517_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049188_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049199_))));
    vlSelf->wasmetal_core__DOT___050619_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050507_))));
    vlSelf->wasmetal_core__DOT___049471_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049304_))));
    vlSelf->wasmetal_core__DOT___049563_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049558_))));
    vlSelf->__VdfgTmp_hcb165b79__0 = (((IData)(vlSelf->wasmetal_core__DOT___049189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049188_));
    vlSelf->wasmetal_core__DOT___050509_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050504_))));
    vlSelf->__VdfgTmp_hf18161ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___049298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049297_));
    vlSelf->wasmetal_core__DOT___050624_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049559_))));
    vlSelf->wasmetal_core__DOT___049518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049180_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049189_))));
    vlSelf->wasmetal_core__DOT___050620_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050505_))));
    vlSelf->wasmetal_core__DOT___049472_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049293_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049298_))));
    vlSelf->wasmetal_core__DOT___049575_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049570_))));
    vlSelf->__VdfgTmp_h2121b61a__0 = (((IData)(vlSelf->wasmetal_core__DOT___049181_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049180_));
    vlSelf->wasmetal_core__DOT___050515_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050513_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050512_))));
    vlSelf->wasmetal_core__DOT___049300_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049294_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049293_))));
    vlSelf->wasmetal_core__DOT___060487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffffff007f7f0000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)))))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0)))))))))));
    vlSelf->wasmetal_core__DOT___058550_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT___051510_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))))));
    vlSelf->wasmetal_core__DOT___049574_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->wasmetal_core__DOT___050625_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049571_))));
    vlSelf->__VdfgTmp_ha51ab883__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049181_));
    vlSelf->__VdfgTmp_hef58fdbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050514_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___050633_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050513_))));
    vlSelf->wasmetal_core__DOT___049466_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049294_))));
    vlSelf->wasmetal_core__DOT___049319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028113_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 2U)));
    vlSelf->__VdfgTmp_habccd4be__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049152_));
    vlSelf->__VdfgTmp_hebb238d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049160_));
    vlSelf->wasmetal_core__DOT___049464_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049321_))));
    vlSelf->__VdfgTmp_hd698a5e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049313_));
    vlSelf->wasmetal_core__DOT___065944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065932_))));
    vlSelf->wasmetal_core__DOT___067466_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066134_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067162_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067306_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15099632__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066862_)))))))));
    vlSelf->wasmetal_core__DOT___066135_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066134_))));
    vlSelf->wasmetal_core__DOT___063851_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063849_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042427_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001414_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128112___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028871_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028868_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028857_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028846_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028839_ = ((IData)(vlSelf->wasmetal_core__DOT___028871_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___028875_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___028874_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___028873_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___028872_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028491_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028458_)
            : (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->wasmetal_core__DOT____Vcellout___128095___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028666_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028665_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028664_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028663_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028630_)))));
    vlSelf->wasmetal_core__DOT___028634_ = ((IData)(vlSelf->wasmetal_core__DOT___028666_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029076_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT____Vcellout___128122___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028978_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028977_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028976_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028975_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028942_)))));
    vlSelf->wasmetal_core__DOT___028946_ = ((IData)(vlSelf->wasmetal_core__DOT___028978_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d));
    vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001369_)
            : (IData)(vlSelf->wasmetal_core__DOT___032287_));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028769_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026481_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026723_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___045206_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070681_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    vlSelf->wasmetal_core__DOT___045230_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071867_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027193_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d));
    vlSelf->wasmetal_core__DOT___045478_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071343_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045502_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071343_)))))))));
    vlSelf->wasmetal_core__DOT___045274_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071406_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045298_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071406_)))))))));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026588_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026529_)
            : (IData)(vlSelf->wasmetal_core__DOT___001438_));
    vlSelf->wasmetal_core__DOT___044934_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070784_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___044958_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026993_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___067086_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064499_)))));
    vlSelf->wasmetal_core__DOT___067164_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064755_)))));
    vlSelf->wasmetal_core__DOT___067205_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064924_)))));
    vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001369_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034569_));
    vlSelf->wasmetal_core__DOT___039996_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039995_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039994_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___040006_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d)))))))));
    vlSelf->__VdfgTmp_heaadd324__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->__VdfgTmp_h6f4f7aa5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->__VdfgTmp_h4482002c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->__VdfgTmp_hc5cbe3a9__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___063836_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063837_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___063861_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O))))));
    vlSelf->wasmetal_core__DOT___066538_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064761_))));
    vlSelf->wasmetal_core__DOT___064763_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064761_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064756_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064759_)))))))));
    vlSelf->wasmetal_core__DOT___067308_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065950_))));
    vlSelf->wasmetal_core__DOT___066660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065081_))));
    vlSelf->wasmetal_core__DOT___065085_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___065076_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065081_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0aaccU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065079_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063994_))))))))))))));
    vlSelf->wasmetal_core__DOT___064001_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff0000f4f4ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063997_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xf0f000055ccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063995_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063835_)))));
    vlSelf->wasmetal_core__DOT___065429_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064926_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065421_)))))))));
    vlSelf->wasmetal_core__DOT___066906_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065423_))));
    vlSelf->wasmetal_core__DOT___065205_ = (1U & (0x4f44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___065198_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (0xf0f0aaccU 
                                                                        >> 
                                                                        ((0x18U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                             << 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065196_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064503_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___064510_))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___065201_))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))));
    vlSelf->wasmetal_core__DOT___066782_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065198_))));
    vlSelf->wasmetal_core__DOT___067338_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066095_))));
    vlSelf->wasmetal_core__DOT___066413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064513_))));
    vlSelf->wasmetal_core__DOT___064516_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064513_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | ((2U 
                                                                                & ((0xf0f05533U 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064500_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h769a413d__0)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064503_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064511_)))))))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030115_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030243_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___068423_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068027_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068422_)))));
    vlSelf->wasmetal_core__DOT___068399_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067970_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068398_)))));
    vlSelf->wasmetal_core__DOT___068290_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067817_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068289_)))));
    vlSelf->wasmetal_core__DOT___068344_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068343_)))));
    vlSelf->wasmetal_core__DOT___068152_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068151_)))));
    vlSelf->wasmetal_core__DOT___068076_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068075_)))));
    vlSelf->wasmetal_core__DOT___067971_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067970_)))));
    vlSelf->wasmetal_core__DOT___067818_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067302_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067817_)))));
    vlSelf->wasmetal_core__DOT___067733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067147_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067732_)))));
    vlSelf->wasmetal_core__DOT___067595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067594_)))));
    vlSelf->wasmetal_core__DOT___068237_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067756_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068236_)))));
    vlSelf->wasmetal_core__DOT___067450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066845_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067449_)))));
    vlSelf->wasmetal_core__DOT___068101_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068100_)))));
    vlSelf->wasmetal_core__DOT___067303_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066640_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067302_)))));
    vlSelf->wasmetal_core__DOT___068028_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068027_)))));
    vlSelf->wasmetal_core__DOT___067905_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067332_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067904_)))));
    vlSelf->wasmetal_core__DOT___067148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066518_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067147_)))));
    vlSelf->wasmetal_core__DOT___067757_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067188_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067756_)))));
    vlSelf->wasmetal_core__DOT___067667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067069_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067666_)))));
    vlSelf->wasmetal_core__DOT___066965_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066306_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066964_)))));
    vlSelf->wasmetal_core__DOT___067499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067498_)))));
    vlSelf->wasmetal_core__DOT___066846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066118_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066845_)))));
    vlSelf->wasmetal_core__DOT___067333_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066762_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067332_)))));
    vlSelf->wasmetal_core__DOT___067189_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067188_)))));
    vlSelf->wasmetal_core__DOT___066641_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066640_)))));
    vlSelf->wasmetal_core__DOT___066519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065795_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066518_)))));
    vlSelf->wasmetal_core__DOT___067070_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067069_)))));
    vlSelf->wasmetal_core__DOT___066887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066262_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066886_)))));
    vlSelf->wasmetal_core__DOT___066763_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066762_)))));
    vlSelf->wasmetal_core__DOT___066596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066595_)))));
    vlSelf->wasmetal_core__DOT___066307_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066306_)))));
    vlSelf->wasmetal_core__DOT___066393_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066392_)))));
    vlSelf->wasmetal_core__DOT___065407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065406_))));
    vlSelf->wasmetal_core__DOT___066263_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065406_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066262_)))));
    vlSelf->wasmetal_core__DOT___064893_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064892_))));
    vlSelf->wasmetal_core__DOT___065892_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065891_)))));
    vlSelf->wasmetal_core__DOT___065178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065177_))));
    vlSelf->wasmetal_core__DOT___066073_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065177_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066072_)))));
    vlSelf->wasmetal_core__DOT___064485_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064484_))));
    vlSelf->wasmetal_core__DOT___065694_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065693_)))));
    vlSelf->wasmetal_core__DOT___065294_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065293_))));
    vlSelf->wasmetal_core__DOT___066119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066118_)))));
    vlSelf->wasmetal_core__DOT___065796_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064725_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065795_)))));
    vlSelf->wasmetal_core__DOT___064726_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064725_))));
    vlSelf->wasmetal_core__DOT___065073_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065072_))));
    vlSelf->wasmetal_core__DOT___065928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065927_)))));
    vlSelf->wasmetal_core__DOT___065598_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065597_)))));
    vlSelf->wasmetal_core__DOT___063863_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063831_))));
    vlSelf->wasmetal_core__DOT___053505_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffff44f400000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053498_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052845_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052847_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053499_))));
    vlSelf->wasmetal_core__DOT___063096_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063102_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063108_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063114_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028311_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028278_)
            : (IData)(vlSelf->wasmetal_core__DOT___028246_));
    vlSelf->wasmetal_core__DOT___066089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066077_))));
    vlSelf->wasmetal_core__DOT___066272_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066269_))));
    vlSelf->wasmetal_core__DOT___064915_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___064918_ = (1U & (IData)(
                                                         (0xdf0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064911_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063924_)))))))));
    vlSelf->wasmetal_core__DOT___065192_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063929_)))));
    vlSelf->wasmetal_core__DOT___036900_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0))))))));
    vlSelf->wasmetal_core__DOT___036899_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036636_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0))))))));
    vlSelf->wasmetal_core__DOT___036898_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036635_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___036897_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))))));
    vlSelf->wasmetal_core__DOT___027472_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d))));
    vlSelf->wasmetal_core__DOT___027471_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d))));
    vlSelf->wasmetal_core__DOT___027470_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d))));
    vlSelf->wasmetal_core__DOT___027469_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d))));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027377_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027301_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029126_));
    vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031045_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031012_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___050600_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050585_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049023_))))));
    vlSelf->wasmetal_core__DOT___049775_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049447_))))));
    vlSelf->wasmetal_core__DOT___050060_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050053_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xacU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)))))));
    vlSelf->__VdfgTmp_hcef50cee__0 = (((IData)(vlSelf->wasmetal_core__DOT___012131_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013095_));
    vlSelf->wasmetal_core__DOT___011701_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___010166_)) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010197_)))));
    vlSelf->wasmetal_core__DOT___057264_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012992_)))));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011413_)));
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h479e0c47__0)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012131_)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hbc86843d__0)));
        } else {
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010575_)));
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011389_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011604_)));
        }
    } else {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012742_)));
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012729_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
        } else {
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011530_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011390_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
        }
        vlSelf->wasmetal_core__DOT___011633_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011636_));
        vlSelf->wasmetal_core__DOT___011595_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011603_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011602_))));
    }
    vlSelf->wasmetal_core__DOT___056725_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012125_)))))))));
    vlSelf->wasmetal_core__DOT___011923_ = (1U & (IData)(
                                                         (0x33330f0f00ff5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010574_)))))))));
    vlSelf->__VdfgTmp_h23ac912c__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056433_));
    vlSelf->__VdfgTmp_h3784db21__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050526_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050521_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050528_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051403_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051401_))));
    vlSelf->wasmetal_core__DOT___049731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049252_))));
    vlSelf->wasmetal_core__DOT___049869_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049657_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___049659_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049657_))));
    vlSelf->wasmetal_core__DOT___049625_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049623_))));
    vlSelf->wasmetal_core__DOT___049045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049043_))));
    vlSelf->wasmetal_core__DOT___051543_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___049690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049688_))));
    vlSelf->wasmetal_core__DOT___052604_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84446dc0__0)))))));
    vlSelf->wasmetal_core__DOT___067179_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050046_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050058_))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050053_)))))));
    vlSelf->wasmetal_core__DOT___050061_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050058_))));
    vlSelf->wasmetal_core__DOT___049372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049363_))));
    vlSelf->wasmetal_core__DOT___051461_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051426_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051433_)))))));
    vlSelf->wasmetal_core__DOT___053388_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___052592_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___053111_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051918_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051904_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___051905_)))))));
    vlSelf->wasmetal_core__DOT___050899_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___049799_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049493_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049505_))));
    vlSelf->wasmetal_core__DOT___049507_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049504_))));
    vlSelf->wasmetal_core__DOT___049707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049705_))));
    vlSelf->wasmetal_core__DOT___050695_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049700_))));
    vlSelf->wasmetal_core__DOT___049147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049144_))));
    vlSelf->wasmetal_core__DOT___049751_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049145_))));
    vlSelf->wasmetal_core__DOT___049888_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049618_))));
    vlSelf->wasmetal_core__DOT___049620_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049617_))));
    vlSelf->__VdfgTmp_h9b5fb542__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0));
    vlSelf->__VdfgTmp_h890ba8da__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0)));
    vlSelf->__VdfgTmp_ha28d971c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)));
    vlSelf->wasmetal_core__DOT___011029_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011030_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011031_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010282_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011038_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010273_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011039_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011040_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT___053895_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053646_))));
    vlSelf->__VdfgTmp_h0a5eca32__0 = (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011529_)));
    vlSelf->__VdfgTmp_h86de1fc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0));
    vlSelf->wasmetal_core__DOT___055309_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d))));
    vlSelf->wasmetal_core__DOT___013103_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056895_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012178_)))))));
    vlSelf->__VdfgTmp_hc338337f__0 = (((IData)(vlSelf->wasmetal_core__DOT___012182_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012183_));
    vlSelf->__VdfgTmp_hc49b4927__0 = (((IData)(vlSelf->wasmetal_core__DOT___012183_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012182_));
    vlSelf->wasmetal_core__DOT___056717_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0)))));
    vlSelf->wasmetal_core__DOT___011937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0)))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___012042_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011722_));
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011198_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
        } else {
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010259_)));
        }
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___011722_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d))))));
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010260_)));
        } else {
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)));
        }
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
    }
    vlSelf->__VdfgTmp_he9aaeb48__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb1f92188__0)))));
    if (vlSelf->wasmetal_core__DOT___010530_) {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_ha7112868__0))));
            vlSelf->wasmetal_core__DOT___011405_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011413_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
        } else {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011388_)));
            vlSelf->wasmetal_core__DOT___011405_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010574_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
        }
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
        vlSelf->wasmetal_core__DOT___010841_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
    } else {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011389_)));
            vlSelf->wasmetal_core__DOT___010841_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010574_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
        } else {
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011390_)));
            vlSelf->wasmetal_core__DOT___010841_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010573_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
        }
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
        vlSelf->wasmetal_core__DOT___011405_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
    }
    vlSelf->wasmetal_core__DOT___011960_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010221_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d803b7__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010342_)));
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010197_))));
        } else {
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (0x302U >> (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010198_)));
        }
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___012287_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0))))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)));
        } else {
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010196_)));
        }
        vlSelf->wasmetal_core__DOT___011770_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   | (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
        vlSelf->wasmetal_core__DOT___012548_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___011697_)) 
                                                   & (0xf0fbU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0))))));
        vlSelf->wasmetal_core__DOT___057009_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011701_));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d 
        = (1U & (0xeU >> ((2U & ((0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___055194_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___011191_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011181_))));
    vlSelf->__VdfgTmp_h43b12a4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011528_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011381_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___012797_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___011887_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14d4af94__0))));
    vlSelf->wasmetal_core__DOT___056964_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                      ? 
                                                     (0xfff4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x5c00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___011522_))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))
                                                      : 
                                                     (0xf1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xa300U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa03U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011513_))))))))))));
    vlSelf->wasmetal_core__DOT___071999_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf996b543__0))))));
    vlSelf->__VdfgTmp_hefe0e1be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h146131dd__0)));
    vlSelf->wasmetal_core__DOT___010850_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h146131dd__0))))))));
    vlSelf->wasmetal_core__DOT___056578_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___011253_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    vlSelf->__VdfgTmp_h55e24ebb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011205_));
    vlSelf->__VdfgTmp_hef0b5c34__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)))))));
    vlSelf->wasmetal_core__DOT___063401_ = (1U & (0xeeeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053096_))))));
    vlSelf->wasmetal_core__DOT___063424_ = (1U & (IData)(
                                                         (0xff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->insn_valid) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048392_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x22330a0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063414_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063418_)))))))));
    vlSelf->wasmetal_core__DOT___056277_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012293_)))));
    vlSelf->wasmetal_core__DOT___056643_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012293_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4a9b748c__0)))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___011473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_))));
    } else {
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h16c112d2__0))));
        vlSelf->wasmetal_core__DOT___011473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011478_)));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h16c112d2__0)))));
    vlSelf->wasmetal_core__DOT___056894_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x5300U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013099_))));
    vlSelf->wasmetal_core__DOT___010390_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056284_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0931b472__0)))))))))));
    vlSelf->__VdfgTmp_h3a025ab3__0 = (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0931b472__0)));
    vlSelf->wasmetal_core__DOT____Vcellout___128541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___033390_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___033452_ = ((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hc33f85b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___033411_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x69U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6af19a3e__0)))));
    vlSelf->__VdfgTmp_haddc65cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___011906_)) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfaf3f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                            ? 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (2U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011522_)))
                                                                            : 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011518_))))))))));
    vlSelf->__VdfgTmp_h30784950__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011539_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011906_));
    vlSelf->__VdfgTmp_h06746976__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0));
    vlSelf->__VdfgTmp_hf037ddb3__0 = ((2U & ((IData)(
                                                     (0xf0faacc00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0))))
                                                : (0xa03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))))));
    vlSelf->__VdfgTmp_h2d927cdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011207_));
    vlSelf->wasmetal_core__DOT___011772_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010259_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)))))));
    vlSelf->wasmetal_core__DOT___011961_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))));
    vlSelf->__VdfgTmp_hc77b1aaa__0 = ((2U & ((IData)(
                                                     (0xf4f4000000ffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                         & (IData)(
                                                   (0xff00ffaaf0f0fcfcULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))))))));
    vlSelf->wasmetal_core__DOT___072147_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee315f88__0))));
    vlSelf->wasmetal_core__DOT___051432_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051429_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051426_)))))));
    vlSelf->wasmetal_core__DOT___050544_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050542_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___050678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050675_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050674_))));
    vlSelf->wasmetal_core__DOT___051466_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049857_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049363_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049370_)))))));
    vlSelf->wasmetal_core__DOT___049495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049493_))));
    vlSelf->wasmetal_core__DOT___049800_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049494_))));
    vlSelf->wasmetal_core__DOT___050696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049703_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049706_))));
    vlSelf->wasmetal_core__DOT___049889_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049621_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049624_))));
    vlSelf->wasmetal_core__DOT___049113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049086_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049085_))));
    vlSelf->wasmetal_core__DOT___051474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049044_))));
    vlSelf->__VdfgTmp_h2966b870__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050585_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050598_))));
    vlSelf->wasmetal_core__DOT___050529_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050526_))));
    vlSelf->wasmetal_core__DOT___051412_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051410_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051402_))));
    vlSelf->wasmetal_core__DOT___050712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049689_))));
    vlSelf->wasmetal_core__DOT___049776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049460_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049455_))));
    vlSelf->wasmetal_core__DOT___049462_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049454_))));
    vlSelf->wasmetal_core__DOT___049287_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049285_))));
    vlSelf->wasmetal_core__DOT___049870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049655_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049658_))));
    vlSelf->__VdfgTmp_hcd2c6110__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011470_)));
    vlSelf->__VdfgTmp_h58c9f225__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha4e3e772__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hda718c9e__0)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->__VdfgTmp_hdd9e6a33__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056378_))))));
    vlSelf->wasmetal_core__DOT___056346_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056172_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    if (vlSelf->wasmetal_core__DOT___010721_) {
        vlSelf->wasmetal_core__DOT___012179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                   | (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012123_)))));
        vlSelf->wasmetal_core__DOT___011955_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011924_))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011921_)))));
    } else {
        vlSelf->wasmetal_core__DOT___012179_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011413_))))));
        vlSelf->wasmetal_core__DOT___011955_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011923_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0))));
    }
    vlSelf->__VdfgTmp_h6bff4562__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))));
    vlSelf->wasmetal_core__DOT___010842_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)))))));
    vlSelf->__VdfgTmp_h8127a3d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)));
    vlSelf->__VdfgTmp_h9484b551__0 = (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011390_));
    vlSelf->wasmetal_core__DOT___012402_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0))))))));
    vlSelf->wasmetal_core__DOT___010720_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0))))))));
    vlSelf->wasmetal_core__DOT___056206_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009842_)) 
                                                  & ((~ 
                                                      (0xfef0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009840_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT___010402_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010391_))));
    vlSelf->__VdfgTmp_hc88b842e__0 = (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010182_));
    vlSelf->__VdfgTmp_h84e2ca83__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056377_))))));
    vlSelf->__VdfgTmp_h584e6b29__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056376_))))));
    vlSelf->__VdfgTmp_h29c29c56__0 = (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h375c9c07__0));
    vlSelf->__VdfgTmp_h766276ef__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->__VdfgTmp_h0e06d26a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0)));
    vlSelf->wasmetal_core__DOT___013143_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0))))));
    vlSelf->wasmetal_core__DOT___072002_ = (1U & (IData)(
                                                         (0x55553333000f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056596_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011388_)))))))));
    vlSelf->wasmetal_core__DOT___010719_ = (1U & (IData)(
                                                         (0xff000f33335555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056369_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1055e951__0)))))));
    vlSelf->wasmetal_core__DOT___012045_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    vlSelf->wasmetal_core__DOT___012295_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    vlSelf->wasmetal_core__DOT___011831_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011478_)));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT___011962_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010220_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010219_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010261_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010260_)))))))));
    vlSelf->__VdfgTmp_h744d21e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010259_));
    vlSelf->__VdfgTmp_h028857f6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb211d2c2__0));
    vlSelf->wasmetal_core__DOT___057068_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057066_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057065_)))))));
    vlSelf->wasmetal_core__DOT___056801_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->__VdfgTmp_h2aa20ca5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010197_)));
    vlSelf->wasmetal_core__DOT___056922_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->wasmetal_core__DOT___072145_ = (1U & (IData)(
                                                         (0xe8e8e800e8000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xfef0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))));
    vlSelf->wasmetal_core__DOT___072146_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072160_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009833_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072177_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___011110_ = (1U & (IData)(
                                                         (0x5050f0f00ff0033ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056499_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___010969_)))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___011115_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011604_)))))))));
    vlSelf->wasmetal_core__DOT___011359_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056593_)))));
    vlSelf->wasmetal_core__DOT___072175_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))))));
    vlSelf->__VdfgTmp_hab99f676__0 = ((2U & ((IData)(
                                                     (0x55f366c366cfaa0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                        << 5U) 
                                                       | ((0x10U 
                                                           & ((0xfef0U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))));
    vlSelf->wasmetal_core__DOT___056289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011998_))));
    vlSelf->wasmetal_core__DOT___013139_ = (1U & (IData)(
                                                         (0x111111110000ff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011602_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011603_)))))))));
    vlSelf->__VdfgTmp_h5e559da9__0 = ((2U & ((0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010530_)))) 
                                             << 1U)) 
                                      | (1U & (0xdU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010530_))))));
    vlSelf->__VdfgTmp_h5fdab2da__0 = (((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011604_));
    vlSelf->wasmetal_core__DOT___011109_ = (1U & (IData)(
                                                         (0xff005533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056500_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___010948_ = (1U & (IData)(
                                                         (0xff00ff5533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___053581_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051779_))));
    vlSelf->wasmetal_core__DOT___053887_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053634_))));
    vlSelf->__VdfgTmp_hf19e2482__0 = (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056720_));
    vlSelf->wasmetal_core__DOT___056774_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4284cb76__0))))));
    vlSelf->__VdfgTmp_h36a8bb37__0 = (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011922_));
    vlSelf->wasmetal_core__DOT___039366_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019277_)))));
    vlSelf->wasmetal_core__DOT___013668_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001802_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001798_))));
    vlSelf->wasmetal_core__DOT___013656_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002189_))));
    vlSelf->__VdfgTmp_h0ed8cd5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002634_));
    vlSelf->wasmetal_core__DOT___058013_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001743_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001742_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001741_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001740_))))))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002152_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002151_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h3fe5e3ea__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___000144_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001744_))));
        vlSelf->wasmetal_core__DOT___002030_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002153_))));
    }
    vlSelf->__VdfgTmp_h80016717__0 = (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___002473_));
    vlSelf->wasmetal_core__DOT___017283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048787_))));
    vlSelf->wasmetal_core__DOT___013694_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001799_))));
    vlSelf->wasmetal_core__DOT___013687_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000141_))));
    vlSelf->__VdfgTmp_h6c83109e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012175_));
    vlSelf->wasmetal_core__DOT___071993_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfff4f4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha620249b__0)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0faaccU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))))));
    vlSelf->wasmetal_core__DOT___011403_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88f91f2d__0)))));
    vlSelf->wasmetal_core__DOT___011184_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___056921_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h00eaf9c7__0))))));
    vlSelf->wasmetal_core__DOT___000137_ = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                            & (IData)(
                                                      (1ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002189_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___002187_)))))))));
    vlSelf->wasmetal_core__DOT___013658_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002187_))));
    vlSelf->wasmetal_core__DOT___053551_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051763_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050255_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050255_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051305_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051305_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051307_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051307_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050269_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050272_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051311_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051311_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051304_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051304_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050273_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050273_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050262_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050262_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051312_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051312_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051530_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051530_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050266_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050266_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050140_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050140_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051306_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051306_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051280_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051280_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050276_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050276_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050166_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051308_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051308_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051283_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051283_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050155_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050155_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051310_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051310_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051300_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051300_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051285_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051285_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050274_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050268_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050268_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051299_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051299_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051282_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051282_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050144_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050144_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051380_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051380_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___017815_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013805_))));
    vlSelf->wasmetal_core__DOT___017355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017273_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))));
    vlSelf->wasmetal_core__DOT___053545_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051751_))));
    vlSelf->wasmetal_core__DOT___013722_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000142_))));
    vlSelf->wasmetal_core__DOT___017383_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013712_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002028_))));
    vlSelf->wasmetal_core__DOT___013666_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002471_))));
    vlSelf->wasmetal_core__DOT___000139_ = ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                            & (IData)(
                                                      (0xe00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))));
    vlSelf->wasmetal_core__DOT___000138_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048789_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048788_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048787_)))))))));
    vlSelf->wasmetal_core__DOT___013654_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048789_))));
    vlSelf->wasmetal_core__DOT___000135_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001803_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___001802_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001799_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001798_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001797_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___001796_)))))))))));
    vlSelf->wasmetal_core__DOT___013672_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001796_))));
    vlSelf->wasmetal_core__DOT___013635_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002027_))));
    vlSelf->wasmetal_core__DOT___002635_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002885_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002883_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002882_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_))))));
    vlSelf->wasmetal_core__DOT___011915_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf508d85__0))))))));
    vlSelf->__VdfgTmp_h619b0a2b__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_haf508d85__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011912_));
    vlSelf->wasmetal_core__DOT___057134_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010395_)))));
    vlSelf->wasmetal_core__DOT___012506_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057102_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056291_)))))));
    vlSelf->__VdfgTmp_h234e76cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___012383_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056291_));
    vlSelf->wasmetal_core__DOT___056573_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                               & (IData)(
                                                         (0xfffcff00aaaa0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011207_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011205_))))))))));
    vlSelf->__VdfgTmp_h77b6db08__0 = ((4U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010395_)));
    vlSelf->wasmetal_core__DOT___057551_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h98e4ab16__0))))))));
    vlSelf->wasmetal_core__DOT___056431_ = (1U & (0xf0f00077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xccccaaaaf0f000ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011520_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011522_)))))))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))));
    vlSelf->wasmetal_core__DOT___053534_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051741_))));
    vlSelf->wasmetal_core__DOT___053518_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051720_))));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006151_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___052718_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051707_))));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___052633_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051691_))));
    vlSelf->wasmetal_core__DOT___061662_ = (1U & (IData)(
                                                         (0xc0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061518_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048458_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf56802d2__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha1796962__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048414_)))))))));
    vlSelf->wasmetal_core__DOT___057549_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057065_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057066_)))))));
    vlSelf->__VdfgTmp_h31fa1bee__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056281_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056280_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_had4ae229__0)))));
    vlSelf->wasmetal_core__DOT___013167_ = (1U & (IData)(
                                                         (0x30303030000ffaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056925_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056920_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))))));
    vlSelf->wasmetal_core__DOT___056340_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))))))));
    vlSelf->wasmetal_core__DOT___056174_ = ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b16__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT___049722_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049721_))));
    vlSelf->wasmetal_core__DOT___051889_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051652_))));
    vlSelf->__VdfgTmp_h454dd727__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049530_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((0xacU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050869_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050791_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))));
    vlSelf->wasmetal_core__DOT___050895_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050791_))));
    vlSelf->wasmetal_core__DOT___051467_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049926_)))));
    vlSelf->wasmetal_core__DOT___049860_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049384_))));
    vlSelf->__VdfgTmp_h444aee6e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049384_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049383_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___050857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050855_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)))))));
    vlSelf->wasmetal_core__DOT___049649_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he62a830e__0))));
    vlSelf->wasmetal_core__DOT___050830_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050828_)))));
    vlSelf->wasmetal_core__DOT___052620_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_had82d15e__0))));
    vlSelf->wasmetal_core__DOT___050546_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050543_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049898_)))));
    vlSelf->wasmetal_core__DOT___049243_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049241_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                                  << 1U)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051922_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051907_)))));
    vlSelf->wasmetal_core__DOT___051583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051582_))));
    vlSelf->wasmetal_core__DOT___051058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051057_))));
    vlSelf->wasmetal_core__DOT___051348_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049749_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051347_))));
    vlSelf->wasmetal_core__DOT___049753_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049750_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049749_))));
    vlSelf->wasmetal_core__DOT___049890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049887_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049886_))));
    vlSelf->wasmetal_core__DOT___051522_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051521_))));
    vlSelf->wasmetal_core__DOT___051290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051289_))));
    vlSelf->wasmetal_core__DOT___051632_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051631_))));
    vlSelf->wasmetal_core__DOT___049801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049797_))));
    vlSelf->wasmetal_core__DOT___051368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051367_))));
    vlSelf->wasmetal_core__DOT___051115_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051114_))));
    vlSelf->wasmetal_core__DOT___051615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051614_))));
    vlSelf->wasmetal_core__DOT___049709_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049702_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049701_))));
    vlSelf->wasmetal_core__DOT___051328_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051327_))));
    vlSelf->wasmetal_core__DOT___051551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050693_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051550_))));
    vlSelf->wasmetal_core__DOT___050697_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050693_))));
    vlSelf->wasmetal_core__DOT___017437_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013692_))));
    vlSelf->wasmetal_core__DOT___014394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013648_))));
    vlSelf->wasmetal_core__DOT___051276_ = (1U & (0xb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___050463_ = (1U & (0xe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050459_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050458_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050457_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->reset)))))));
    vlSelf->wasmetal_core__DOT___053571_ = (1U & (IData)(
                                                         (0x1f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))));
    vlSelf->wasmetal_core__DOT___059112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->wasmetal_core__DOT___059106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___059153_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___059156_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006215_))))));
    vlSelf->wasmetal_core__DOT___059113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006085_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049918_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049918_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050492_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050492_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049913_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049913_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051269_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049945_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049945_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051270_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051270_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050486_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050486_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049925_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049925_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051274_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051272_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050494_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050494_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT___014425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013701_))));
    vlSelf->wasmetal_core__DOT___057941_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013670_))));
    vlSelf->wasmetal_core__DOT___051424_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051919_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___049111_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049100_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049099_))));
    vlSelf->wasmetal_core__DOT___051413_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050525_))));
    vlSelf->wasmetal_core__DOT___049268_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049266_))));
    vlSelf->wasmetal_core__DOT___049858_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h40926396__0))))));
    vlSelf->wasmetal_core__DOT___049704_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0))))));
    vlSelf->wasmetal_core__DOT___049845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049836_))));
    vlSelf->wasmetal_core__DOT___049589_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049459_))));
    vlSelf->wasmetal_core__DOT___053212_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049576_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0))))));
    vlSelf->wasmetal_core__DOT___049622_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049109_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049100_))));
    vlSelf->wasmetal_core__DOT___049000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048981_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048980_))));
    vlSelf->wasmetal_core__DOT___049656_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049258_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0))))));
    vlSelf->wasmetal_core__DOT___050688_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0))))));
    vlSelf->wasmetal_core__DOT___049488_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049485_))));
    vlSelf->wasmetal_core__DOT___050609_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049837_))));
    vlSelf->wasmetal_core__DOT___049461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049457_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049456_))));
    vlSelf->wasmetal_core__DOT___051317_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd992aaf0__0))))));
    vlSelf->wasmetal_core__DOT___049112_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049109_))));
    vlSelf->wasmetal_core__DOT___051414_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048981_))));
    vlSelf->wasmetal_core__DOT___049269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049259_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049258_))));
    vlSelf->wasmetal_core__DOT___053386_ = (1U & (0xa300U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xf0f5533U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))))))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048680_))))));
    vlSelf->wasmetal_core__DOT___050623_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0))))));
    vlSelf->wasmetal_core__DOT___049711_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97f76463__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0))))));
    vlSelf->wasmetal_core__DOT___051483_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050607_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050602_))));
    vlSelf->wasmetal_core__DOT___049600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049457_))));
    vlSelf->wasmetal_core__DOT___049577_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd0aa9c81__0))))));
    vlSelf->wasmetal_core__DOT___049631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049204_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf7ec4412__0))))));
    vlSelf->wasmetal_core__DOT___049001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048998_))));
    vlSelf->wasmetal_core__DOT___049662_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049259_))));
    vlSelf->wasmetal_core__DOT___050689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050626_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h92ec5796__0))))));
    vlSelf->wasmetal_core__DOT___049519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h97f76463__0))))));
    vlSelf->wasmetal_core__DOT___050610_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050608_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050607_))));
    vlSelf->wasmetal_core__DOT___049473_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049469_))));
    vlSelf->wasmetal_core__DOT___051318_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049562_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2cac88ff__0))))));
    vlSelf->wasmetal_core__DOT___049206_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049204_))));
    vlSelf->wasmetal_core__DOT___051415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050508_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048999_))));
    vlSelf->wasmetal_core__DOT___049309_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049307_))));
    vlSelf->wasmetal_core__DOT___050628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050627_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050626_))));
    vlSelf->wasmetal_core__DOT___049712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049516_))));
    vlSelf->wasmetal_core__DOT___051484_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050608_))));
    vlSelf->wasmetal_core__DOT___049601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049471_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049470_))));
    vlSelf->wasmetal_core__DOT___049578_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049562_))));
    vlSelf->wasmetal_core__DOT___049632_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))));
    vlSelf->wasmetal_core__DOT___050516_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050509_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050508_))));
    vlSelf->wasmetal_core__DOT___049663_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049308_))));
    vlSelf->wasmetal_core__DOT___050730_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050627_))));
    vlSelf->wasmetal_core__DOT___049520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049517_))));
    vlSelf->wasmetal_core__DOT___050634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050620_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050619_))));
    vlSelf->wasmetal_core__DOT___049474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049471_))));
    vlSelf->wasmetal_core__DOT___051425_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049575_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049563_))));
    vlSelf->wasmetal_core__DOT___049207_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0))))));
    vlSelf->wasmetal_core__DOT___051416_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050509_))));
    vlSelf->wasmetal_core__DOT___049310_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049300_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf18161ea__0))))));
    vlSelf->wasmetal_core__DOT___018279_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058550_))));
    vlSelf->wasmetal_core__DOT___058551_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051509_)))));
    vlSelf->wasmetal_core__DOT___050629_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050624_))));
    vlSelf->wasmetal_core__DOT___051646_ = (1U & (0x5cU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___049513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___049713_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049518_))));
    vlSelf->wasmetal_core__DOT___049629_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))));
    vlSelf->wasmetal_core__DOT___051485_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050620_))));
    vlSelf->wasmetal_core__DOT___049683_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049472_))));
    vlSelf->wasmetal_core__DOT___049467_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049466_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->wasmetal_core__DOT___049661_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049319_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049300_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128042___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028116_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028113_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028102_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028091_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028084_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028116_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 3U)));
    vlSelf->wasmetal_core__DOT___051647_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___050977_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> 
                                                                 (1U 
                                                                  & (0x35U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_habccd4be__0))))))))))));
    vlSelf->wasmetal_core__DOT___049714_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x35U 
                                                        >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))));
    vlSelf->wasmetal_core__DOT___051833_ = (1U & (IData)(
                                                         (0xaaccf00000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 5U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   ((2U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      ((2U 
                                                                        & ((0xcaU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0))))) 
                                                                     << 1U)) 
                                                                 | (1U 
                                                                    & (0xacU 
                                                                       >> 
                                                                       ((2U 
                                                                         & ((0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xacU 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0))))))))))));
    vlSelf->wasmetal_core__DOT___049173_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x35U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0))))));
    vlSelf->wasmetal_core__DOT___049630_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))));
    vlSelf->wasmetal_core__DOT___049684_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049465_))));
    vlSelf->wasmetal_core__DOT___049545_ = (1U & (0xc5U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))));
    vlSelf->wasmetal_core__DOT___049324_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd698a5e2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049319_))));
    vlSelf->wasmetal_core__DOT___066143_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066135_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066140_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065315_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065313_)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128648___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001426_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001414_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001382_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001370_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034408_)))));
    vlSelf->wasmetal_core__DOT___034349_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001426_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028872_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028839_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028492_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003632_));
    vlSelf->wasmetal_core__DOT___054052_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054056_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054055_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054060_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054059_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054064_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128095___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028667_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028634_)
            : (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->wasmetal_core__DOT____Vcellout___128130___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029079_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029076_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029065_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029054_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___029047_ = ((IData)(vlSelf->wasmetal_core__DOT___029079_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___029083_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___029082_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___029081_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___029080_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128122___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028979_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028946_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d));
    vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001381_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001381_)
            : (IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128104___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028770_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028769_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028768_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028767_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028734_)))));
    vlSelf->wasmetal_core__DOT___028738_ = ((IData)(vlSelf->wasmetal_core__DOT___028770_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026482_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127884___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026724_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026723_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026718_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026707_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026631_)))));
    vlSelf->wasmetal_core__DOT___026660_ = ((IData)(vlSelf->wasmetal_core__DOT___026724_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT____Vcellout___127935___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027194_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027188_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027177_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027101_)))));
    vlSelf->wasmetal_core__DOT___027130_ = ((IData)(vlSelf->wasmetal_core__DOT___027194_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026589_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001444_));
    vlSelf->wasmetal_core__DOT____Vcellout___127918___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026994_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026993_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026988_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026977_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026901_)))));
    vlSelf->wasmetal_core__DOT___026930_ = ((IData)(vlSelf->wasmetal_core__DOT___026994_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT____Vcellout___127901___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026766_)))));
    vlSelf->wasmetal_core__DOT___026795_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001381_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___030122_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heaadd324__0)))));
    vlSelf->wasmetal_core__DOT___030282_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heaadd324__0)))));
    vlSelf->wasmetal_core__DOT___030121_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6f4f7aa5__0)))));
    vlSelf->wasmetal_core__DOT___030281_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6f4f7aa5__0)))));
    vlSelf->wasmetal_core__DOT___030120_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4482002c__0)))));
    vlSelf->wasmetal_core__DOT___030276_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4482002c__0)))));
    vlSelf->wasmetal_core__DOT___030119_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5cbe3a9__0)))));
    vlSelf->wasmetal_core__DOT___030265_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5cbe3a9__0)))));
    vlSelf->wasmetal_core__DOT___067596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___063838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063836_))));
    vlSelf->wasmetal_core__DOT___067320_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065932_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066653_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066980_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067161_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067306_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067350_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067338_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066077_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066775_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067084_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067336_)))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128231___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030118_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030115_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030104_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030093_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030086_ = ((IData)(vlSelf->wasmetal_core__DOT___030118_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128239___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030254_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030243_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030221_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030190_ = ((IData)(vlSelf->wasmetal_core__DOT___030254_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___068795_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067971_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068792_)))))))));
    vlSelf->wasmetal_core__DOT___068702_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067818_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068289_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068699_)))))))));
    vlSelf->wasmetal_core__DOT___068604_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068151_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068601_)))))))));
    vlSelf->wasmetal_core__DOT___068850_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___068028_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068422_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068847_)))))))));
    vlSelf->wasmetal_core__DOT___068751_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067905_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068748_)))))))));
    vlSelf->wasmetal_core__DOT___068654_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067757_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068236_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068651_)))))))));
    vlSelf->wasmetal_core__DOT___068552_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067667_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___068100_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068549_)))))))));
    vlSelf->wasmetal_core__DOT___067821_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066641_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067818_))))));
    vlSelf->wasmetal_core__DOT___067735_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066519_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067733_))))));
    vlSelf->wasmetal_core__DOT___068031_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066887_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___068028_))))));
    vlSelf->wasmetal_core__DOT___067759_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066596_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067757_))))));
    vlSelf->wasmetal_core__DOT___067669_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063837_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066393_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___067667_))))));
    vlSelf->wasmetal_core__DOT___066888_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066887_)))));
    vlSelf->wasmetal_core__DOT___065427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065407_))));
    vlSelf->wasmetal_core__DOT___067500_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066263_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067499_)))));
    vlSelf->wasmetal_core__DOT___066288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066263_))));
    vlSelf->wasmetal_core__DOT___066597_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064893_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066596_)))));
    vlSelf->wasmetal_core__DOT___064913_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064893_))));
    vlSelf->wasmetal_core__DOT___065909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065892_))));
    vlSelf->wasmetal_core__DOT___067190_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067189_)))));
    vlSelf->wasmetal_core__DOT___066764_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065178_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066763_)))));
    vlSelf->wasmetal_core__DOT___066088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066073_))));
    vlSelf->wasmetal_core__DOT___067335_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067333_)))));
    vlSelf->wasmetal_core__DOT___066394_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064485_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066393_)))));
    vlSelf->wasmetal_core__DOT___064515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064485_))));
    vlSelf->wasmetal_core__DOT___067071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067070_)))));
    vlSelf->wasmetal_core__DOT___065711_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065694_))));
    vlSelf->wasmetal_core__DOT___066847_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066846_)))));
    vlSelf->wasmetal_core__DOT___066141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066119_))));
    vlSelf->wasmetal_core__DOT___067468_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066119_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067450_)))));
    vlSelf->wasmetal_core__DOT___065813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065796_))));
    vlSelf->wasmetal_core__DOT___067149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065796_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067148_)))));
    vlSelf->wasmetal_core__DOT___066520_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064726_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066519_)))));
    vlSelf->wasmetal_core__DOT___064747_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064726_))));
    vlSelf->wasmetal_core__DOT___066642_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066641_)))));
    vlSelf->wasmetal_core__DOT___065083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065073_))));
    vlSelf->wasmetal_core__DOT___065943_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065928_))));
    vlSelf->wasmetal_core__DOT___067305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067303_)))));
    vlSelf->wasmetal_core__DOT___066966_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065598_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066965_)))));
    vlSelf->wasmetal_core__DOT___065623_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065598_))));
    vlSelf->wasmetal_core__DOT___066308_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063863_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066307_)))));
    vlSelf->wasmetal_core__DOT___063099_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063095_)))))));
    vlSelf->wasmetal_core__DOT___063105_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063101_)))))));
    vlSelf->wasmetal_core__DOT___063111_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063108_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063107_)))))));
    vlSelf->wasmetal_core__DOT___063117_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063113_)))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028312_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028247_));
    vlSelf->wasmetal_core__DOT___064933_ = (1U & (0x4fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064918_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0791be06__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x4fff00ff00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036897_)) 
                 & (0x96U >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027469_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027388_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127434___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7a338fa__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022537_)))));
    vlSelf->wasmetal_core__DOT___022565_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031046_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->__VdfgTmp_h1d16dec4__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcef50cee__0));
    vlSelf->wasmetal_core__DOT___012801_ = (1U & (IData)(
                                                         (0xff00aa0f0f0c0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcef50cee__0))))))));
    vlSelf->wasmetal_core__DOT___057558_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057557_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057264_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___056728_ = (1U & (0xa030000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056725_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011924_)))))));
    vlSelf->wasmetal_core__DOT___012806_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056720_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056725_)))))));
    vlSelf->wasmetal_core__DOT___056775_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011923_)))))));
    vlSelf->__VdfgTmp_h1d3dc22c__0 = ((2U & ((0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h23ac912c__0)))) 
                                             << 1U)) 
                                      | (1U & (0x3500U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x53U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011870_)))))));
    vlSelf->wasmetal_core__DOT___051295_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049659_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___050658_ = (1U & (0x3f203f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049049_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                   << 1U)))))))));
    vlSelf->wasmetal_core__DOT___053662_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051543_))));
    vlSelf->wasmetal_core__DOT___051321_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___050069_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050060_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___050048_)))))))))));
    vlSelf->wasmetal_core__DOT___053195_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050061_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050048_))));
    vlSelf->wasmetal_core__DOT___049387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049371_))));
    vlSelf->wasmetal_core__DOT___051804_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051461_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050855_))))))));
    vlSelf->wasmetal_core__DOT___053392_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he62a830e__0)))))));
    vlSelf->wasmetal_core__DOT___053115_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053111_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049241_))))))));
    vlSelf->wasmetal_core__DOT___050982_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050899_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_had82d15e__0)))));
    vlSelf->wasmetal_core__DOT___050861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049799_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049798_))));
    vlSelf->wasmetal_core__DOT___049508_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049506_))));
    vlSelf->wasmetal_core__DOT___051329_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049707_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049702_))));
    vlSelf->wasmetal_core__DOT___050870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050695_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050694_))));
    vlSelf->wasmetal_core__DOT___049148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049146_))));
    vlSelf->wasmetal_core__DOT___050801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049751_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049750_))));
}
