#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__17(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__17\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___010192_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h551248b6__0))))))));
    vlSelf->__VdfgTmp_h2aa6a52e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbda9acd7__0))))));
    vlSelf->wasmetal_core__DOT___055073_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0))))));
    vlSelf->__VdfgTmp_h009b2026__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h815644ec__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h41aaabca__0))))));
    vlSelf->wasmetal_core__DOT___007688_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0))))));
    vlSelf->wasmetal_core__DOT___007689_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7690c014__0)))));
    vlSelf->wasmetal_core__DOT___007640_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->wasmetal_core__DOT___007641_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h69484b9c__0)))));
    vlSelf->wasmetal_core__DOT___007628_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                     & (IData)(
                                                               (0xccaaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h40471efb__0))))) 
                                                    << 1U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                      & (IData)(
                                                                (0xccaa0000f0f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                      << 4U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_haf65e04e__0)))))))));
    vlSelf->wasmetal_core__DOT___007599_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0))))));
    vlSelf->wasmetal_core__DOT___007600_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h624c4f06__0)))));
    vlSelf->wasmetal_core__DOT___007565_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0))))));
    vlSelf->wasmetal_core__DOT___007566_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h878f9978__0)))));
    vlSelf->wasmetal_core__DOT___007544_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0))))));
    vlSelf->wasmetal_core__DOT___007545_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h01d6394a__0)))));
    vlSelf->wasmetal_core__DOT___007524_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0))))));
    vlSelf->wasmetal_core__DOT___007525_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hee719ca8__0)))));
    vlSelf->wasmetal_core__DOT___007586_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf224ceca__0)))));
    vlSelf->wasmetal_core__DOT___007585_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0))))));
    vlSelf->wasmetal_core__DOT___007588_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hffa75465__0)))));
    vlSelf->wasmetal_core__DOT___007587_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0))))));
    vlSelf->wasmetal_core__DOT___007590_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h127745a0__0)))));
    vlSelf->wasmetal_core__DOT___007589_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0))))));
    vlSelf->__VdfgTmp_h0fc2ac4f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h62d1863a__0))))));
    vlSelf->wasmetal_core__DOT___054928_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007718_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007720_)))))))));
    vlSelf->wasmetal_core__DOT___009806_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007772_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5ad8b1f1__0))))))));
    vlSelf->wasmetal_core__DOT___010333_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007370_)))))))));
    vlSelf->wasmetal_core__DOT___010331_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007385_)))))))));
    vlSelf->wasmetal_core__DOT___010319_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007359_)))))))));
    vlSelf->__VdfgTmp_hba71a165__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007344_))))));
    vlSelf->wasmetal_core__DOT___010358_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007333_)))))))));
    vlSelf->wasmetal_core__DOT___010371_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007257_)))))))));
    vlSelf->wasmetal_core__DOT___010369_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5af86920__0))))))));
    vlSelf->wasmetal_core__DOT___010348_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8d9b1452__0))))))));
    vlSelf->wasmetal_core__DOT___010350_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007284_)))))))));
    vlSelf->wasmetal_core__DOT___007250_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8763693__0))))))));
    vlSelf->__VdfgTmp_h7b1353df__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007230_))))));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007338_))))));
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007373_))))));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007260_))))));
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007786_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007754_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007717_;
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0)));
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)));
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007639_));
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007369_));
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007310_));
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf8957689__0)));
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007659_;
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007504_;
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007422_));
    } else {
        vlSelf->wasmetal_core__DOT___010359_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007339_))))));
        vlSelf->wasmetal_core__DOT___010754_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007789_));
        vlSelf->wasmetal_core__DOT___010089_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007778_));
        vlSelf->wasmetal_core__DOT___010139_ = vlSelf->wasmetal_core__DOT___007739_;
        vlSelf->wasmetal_core__DOT___009781_ = vlSelf->wasmetal_core__DOT___007639_;
        vlSelf->wasmetal_core__DOT___009814_ = vlSelf->wasmetal_core__DOT___007618_;
        vlSelf->wasmetal_core__DOT___009795_ = vlSelf->wasmetal_core__DOT___007584_;
        vlSelf->wasmetal_core__DOT___009791_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1e9537b6__0)));
        vlSelf->wasmetal_core__DOT___010213_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h65d58b23__0)));
        vlSelf->wasmetal_core__DOT___010956_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h02da39da__0)));
        vlSelf->wasmetal_core__DOT___054850_ = vlSelf->wasmetal_core__DOT___007488_;
        vlSelf->wasmetal_core__DOT___010987_ = vlSelf->wasmetal_core__DOT___007469_;
        vlSelf->wasmetal_core__DOT___010981_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha44be0e2__0)));
        vlSelf->wasmetal_core__DOT___010191_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0)));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007391_))))));
        vlSelf->wasmetal_core__DOT___010239_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007365_))))));
        vlSelf->wasmetal_core__DOT___010251_ = vlSelf->wasmetal_core__DOT___007369_;
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007306_))))));
        vlSelf->wasmetal_core__DOT___010279_ = vlSelf->wasmetal_core__DOT___007310_;
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007279_))))));
        vlSelf->wasmetal_core__DOT___010287_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0)));
        vlSelf->wasmetal_core__DOT___054853_ = vlSelf->wasmetal_core__DOT___007504_;
        vlSelf->wasmetal_core__DOT___009649_ = vlSelf->wasmetal_core__DOT___007422_;
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007418_))))));
    }
    vlSelf->wasmetal_core__DOT___007622_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc57757c5__0)))));
    vlSelf->wasmetal_core__DOT___007621_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hab3c597f__0))))));
    vlSelf->wasmetal_core__DOT___007624_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->wasmetal_core__DOT___007623_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0))))));
    vlSelf->wasmetal_core__DOT___007604_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h2e0ea116__0)))));
    vlSelf->wasmetal_core__DOT___007603_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h707c99af__0))))));
    vlSelf->wasmetal_core__DOT___007602_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h40b73a73__0)))));
    vlSelf->wasmetal_core__DOT___007601_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb18976f4__0))))));
    vlSelf->wasmetal_core__DOT___053918_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he34a288c__0)))));
    vlSelf->wasmetal_core__DOT___053919_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0))))));
    vlSelf->wasmetal_core__DOT___007568_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8f363e22__0)))));
    vlSelf->wasmetal_core__DOT___007567_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0))))));
    vlSelf->wasmetal_core__DOT___007570_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5ba532b7__0)))));
    vlSelf->wasmetal_core__DOT___007569_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb918ea35__0))))));
    vlSelf->wasmetal_core__DOT___007547_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd1dc222f__0)))));
    vlSelf->wasmetal_core__DOT___007546_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf2656e40__0))))));
    vlSelf->wasmetal_core__DOT___007549_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6ee5998b__0)))));
    vlSelf->wasmetal_core__DOT___007548_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0))))));
    vlSelf->wasmetal_core__DOT___007529_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h88de5544__0)))));
    vlSelf->wasmetal_core__DOT___007528_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0))))));
    vlSelf->wasmetal_core__DOT___007527_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc86399cc__0))))));
    vlSelf->wasmetal_core__DOT___007526_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3f534570__0))))));
    vlSelf->wasmetal_core__DOT___010240_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007388_)))))))));
    vlSelf->wasmetal_core__DOT___010242_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007372_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007373_)))))))));
    vlSelf->wasmetal_core__DOT___010250_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007362_)))))))));
    vlSelf->wasmetal_core__DOT___010252_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007346_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))))));
    vlSelf->wasmetal_core__DOT___010253_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd5551ada__0)))))));
    vlSelf->wasmetal_core__DOT___010269_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007336_)))))))));
    vlSelf->wasmetal_core__DOT___010271_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007473_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007471_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007470_)))))))));
    vlSelf->wasmetal_core__DOT___010272_ = (1U & (IData)(
                                                         (0xaa00f000ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d168d9__0)))))));
    vlSelf->wasmetal_core__DOT___010278_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007303_)))))))));
    vlSelf->wasmetal_core__DOT___010280_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007286_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))))));
    vlSelf->wasmetal_core__DOT___010288_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007273_)))))))));
    vlSelf->wasmetal_core__DOT___010290_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007259_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007260_)))))))));
    vlSelf->wasmetal_core__DOT___054278_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007232_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))))));
    vlSelf->wasmetal_core__DOT___054139_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0))))));
    vlSelf->wasmetal_core__DOT___054140_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2814f082__0))))));
    vlSelf->wasmetal_core__DOT___054141_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7780ec55__0))))));
    vlSelf->wasmetal_core__DOT___054142_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h42498a1f__0))))));
    vlSelf->wasmetal_core__DOT___054151_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0))))));
    vlSelf->wasmetal_core__DOT___054152_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0))))));
    vlSelf->wasmetal_core__DOT___054149_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8893fd49__0))))));
    vlSelf->wasmetal_core__DOT___054150_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hce5bccc4__0))))));
    vlSelf->wasmetal_core__DOT___007677_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                                  & (IData)(
                                                            (0x33ff55ff0fff0fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c5b87f4__0))))))));
    vlSelf->wasmetal_core__DOT___007678_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(
                                                      (0x33ff55ff0fff0fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hd5b1a253__0)))))));
    vlSelf->wasmetal_core__DOT___007743_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7146d025__0)))));
    vlSelf->wasmetal_core__DOT___007744_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h437f0271__0))))));
    vlSelf->wasmetal_core__DOT___007740_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h83a675b5__0))))));
    vlSelf->wasmetal_core__DOT___054338_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc3b7ffa9__0)))));
    vlSelf->wasmetal_core__DOT___054339_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd0975535__0))))));
    vlSelf->wasmetal_core__DOT___007703_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc530df9f__0))))));
    vlSelf->wasmetal_core__DOT___007706_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4fcd3c01__0)))));
    vlSelf->wasmetal_core__DOT___007707_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h79bfec12__0))))));
    vlSelf->wasmetal_core__DOT___007690_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h15014ab6__0)))));
    vlSelf->wasmetal_core__DOT___007691_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4f29d017__0))))));
    vlSelf->wasmetal_core__DOT___007692_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0))))));
    vlSelf->wasmetal_core__DOT___007679_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h782800f0__0))))));
    vlSelf->wasmetal_core__DOT___007664_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha292c154__0))))));
    vlSelf->wasmetal_core__DOT___054739_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007523_));
    vlSelf->wasmetal_core__DOT___054738_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007522_));
    vlSelf->wasmetal_core__DOT___007505_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(
                                                      (0x33ff55ff0fff0fffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf6ccaf8c__0)))))));
    vlSelf->wasmetal_core__DOT___007506_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007517_));
    vlSelf->wasmetal_core__DOT___007507_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007520_));
    vlSelf->wasmetal_core__DOT___007508_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007521_));
    vlSelf->wasmetal_core__DOT___007509_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007518_));
    vlSelf->wasmetal_core__DOT___007510_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007519_));
    vlSelf->wasmetal_core__DOT___009650_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007415_)))))))));
    vlSelf->wasmetal_core__DOT___009652_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))))));
    vlSelf->wasmetal_core__DOT___007758_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6127a0a0__0)))));
    vlSelf->wasmetal_core__DOT___007759_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb69256f0__0))))));
    vlSelf->wasmetal_core__DOT___007755_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0919a607__0))))));
    vlSelf->wasmetal_core__DOT___010308_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007412_)))))))));
    vlSelf->__VdfgTmp_h22d02546__0 = (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007398_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007396_))))));
    vlSelf->wasmetal_core__DOT___007643_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4a43ab44__0)))));
    vlSelf->wasmetal_core__DOT___007642_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hde24342a__0))))));
    vlSelf->wasmetal_core__DOT___007645_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->wasmetal_core__DOT___007644_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128231___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030118_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030115_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030104_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030093_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030086_ = ((IData)(vlSelf->wasmetal_core__DOT___030118_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128239___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030254_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030243_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030232_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030221_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030190_ = ((IData)(vlSelf->wasmetal_core__DOT___030254_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___064915_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___065944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065932_))));
    vlSelf->wasmetal_core__DOT___066089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066077_))));
    vlSelf->wasmetal_core__DOT___067466_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066134_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067162_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067306_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15099632__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066862_)))))))));
    vlSelf->wasmetal_core__DOT___066135_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066134_))));
    vlSelf->wasmetal_core__DOT___066272_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066269_))));
    vlSelf->__VdfgTmp_h2f60644c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(vlSelf->__VdfgTmp_h826c8569__0))));
    vlSelf->wasmetal_core__DOT___036636_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)))))));
    vlSelf->wasmetal_core__DOT___036635_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))))));
    vlSelf->__VdfgTmp_h79b76beb__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))));
    vlSelf->wasmetal_core__DOT___064918_ = (1U & (IData)(
                                                         (0xdf0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064911_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063924_)))))))));
    vlSelf->wasmetal_core__DOT___063839_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048367_)))));
    vlSelf->wasmetal_core__DOT___063847_ = (1U & (IData)(
                                                         (0x777ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))))));
    vlSelf->wasmetal_core__DOT___063845_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042391_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048371_))));
    vlSelf->wasmetal_core__DOT___063844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042212_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048363_))));
    vlSelf->wasmetal_core__DOT___063849_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042451_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048377_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042199_)))))));
    vlSelf->wasmetal_core__DOT___063842_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042072_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042272_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048317_)))))));
    vlSelf->wasmetal_core__DOT___065429_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064926_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065421_)))))))));
    vlSelf->wasmetal_core__DOT___066906_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065423_))));
    vlSelf->wasmetal_core__DOT___065205_ = (1U & (0x4f44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___065198_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (0xf0f0aaccU 
                                                                        >> 
                                                                        ((0x18U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                             << 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065196_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064503_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___064510_))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___065201_))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))));
    vlSelf->wasmetal_core__DOT___066782_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065198_))));
    vlSelf->wasmetal_core__DOT___067338_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066095_))));
    vlSelf->wasmetal_core__DOT___066413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064513_))));
    vlSelf->wasmetal_core__DOT___064516_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064513_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | ((2U 
                                                                                & ((0xf0f05533U 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064500_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h769a413d__0)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064503_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064511_)))))))));
    vlSelf->wasmetal_core__DOT___066538_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064761_))));
    vlSelf->wasmetal_core__DOT___064763_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064761_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064756_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064759_)))))))));
    vlSelf->wasmetal_core__DOT___067308_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065950_))));
    vlSelf->wasmetal_core__DOT___066660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065081_))));
    vlSelf->wasmetal_core__DOT___065085_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___065076_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065081_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0aaccU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065079_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063994_))))))))))))));
    vlSelf->__VdfgTmp_h912dcb78__0 = (((IData)(vlSelf->wasmetal_core__DOT___002894_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002893_));
    vlSelf->wasmetal_core__DOT___068437_ = (1U & (IData)(
                                                         (0xcc000f000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf11U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9934c93f__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048729_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048730_)))))))));
    vlSelf->wasmetal_core__DOT___003054_ = (1U & ((1U 
                                                   & (0x10000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he03432df__0))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9934c93f__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h162766a7__0)))))));
    vlSelf->wasmetal_core__DOT___066293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002476_))));
    vlSelf->wasmetal_core__DOT___067822_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb62f452d__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))))))))))));
    vlSelf->wasmetal_core__DOT___001250_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb62f452d__0)))));
    vlSelf->wasmetal_core__DOT___069089_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048851_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048852_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h22ba1a50__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___002719_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h22ba1a50__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hdf798121__0)))))));
    vlSelf->wasmetal_core__DOT___002076_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))))));
    vlSelf->wasmetal_core__DOT___002516_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfd6c95b6__0)))))));
    vlSelf->wasmetal_core__DOT___068486_ = (1U & (IData)(
                                                         (0xf0ccf0f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___001807_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002068_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))))));
    vlSelf->__VdfgTmp_hf699b114__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha952ad99__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001854_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (0xfdfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___002479_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002478_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002476_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002475_)))))));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001901_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001900_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001899_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001898_))))))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002243_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51461c8e__0))))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002395_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002394_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002393_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002392_))))))));
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001678_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001677_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd9c0d0dd__0)))))));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002115_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002114_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002113_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002112_))))))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001253_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001252_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001250_))))))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002078_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002077_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002076_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002075_))))))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002518_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002517_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002516_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002515_))))))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001810_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001809_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001808_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001807_))))))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002040_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf699b114__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002477_)));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001902_))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002244_))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002396_))));
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001679_))));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002116_))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001254_))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002079_))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002519_))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001811_))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002041_))));
    }
    vlSelf->wasmetal_core__DOT___002431_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5a517e30__0)))))));
    vlSelf->wasmetal_core__DOT___001947_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002288_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b64371c__0))))))));
    vlSelf->__VdfgTmp_h85a07a94__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbd418077__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001964_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5b64371c__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___068967_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002811_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048859_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048860_)))))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h5e317429__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hae207145__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002563_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002562_)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002799_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002811_))));
        vlSelf->wasmetal_core__DOT___002554_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002564_)))));
    }
    vlSelf->__VdfgTmp_h07469665__0 = (((IData)(vlSelf->wasmetal_core__DOT___002564_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0));
    vlSelf->wasmetal_core__DOT___068032_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6dac888a__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))))))))))));
    vlSelf->wasmetal_core__DOT___002196_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6dac888a__0)))))));
    vlSelf->wasmetal_core__DOT___002353_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002851_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002852_)))))))));
    vlSelf->__VdfgTmp_hcbcea2b7__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                 & (IData)(
                                                           (0xfff0ffff1111ffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000163_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001727_)
                                                                               : 
                                                                              (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                             << 1U)) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001726_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb4d5b900__0))))))))));
    vlSelf->__VdfgTmp_h91cc03bd__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h343b1824__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000163_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb4d5b900__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___064001_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff0000f4f4ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063997_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xf0f000055ccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063995_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063835_)))));
    vlSelf->wasmetal_core__DOT___065192_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063929_)))));
    vlSelf->wasmetal_core__DOT___068792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068600_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068791_)))));
    vlSelf->wasmetal_core__DOT___068847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068650_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068846_)))));
    vlSelf->wasmetal_core__DOT___068699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068698_)))));
    vlSelf->wasmetal_core__DOT___068601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068397_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068600_)))));
    vlSelf->wasmetal_core__DOT___068748_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068548_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068747_)))));
    vlSelf->wasmetal_core__DOT___068475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068288_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068474_)))));
    vlSelf->wasmetal_core__DOT___068651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068421_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068650_)))));
    vlSelf->wasmetal_core__DOT___068398_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068150_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068397_)))));
    vlSelf->wasmetal_core__DOT___068549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068342_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068548_)))));
    vlSelf->wasmetal_core__DOT___068289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068288_)))));
    vlSelf->wasmetal_core__DOT___068422_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068235_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068421_)))));
    vlSelf->wasmetal_core__DOT___068343_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068099_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068342_)))));
    vlSelf->wasmetal_core__DOT___068075_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068074_)))));
    vlSelf->wasmetal_core__DOT___068151_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068150_)))));
    vlSelf->wasmetal_core__DOT___068236_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068235_)))));
    vlSelf->wasmetal_core__DOT___068027_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068026_)))));
    vlSelf->wasmetal_core__DOT___068100_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068099_)))));
    vlSelf->wasmetal_core__DOT___067970_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067969_)))));
    vlSelf->wasmetal_core__DOT___067817_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067816_)))));
    vlSelf->wasmetal_core__DOT___067904_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067903_)))));
    vlSelf->wasmetal_core__DOT___067732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067731_)))));
    vlSelf->wasmetal_core__DOT___067594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067301_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067593_)))));
    vlSelf->wasmetal_core__DOT___067449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067448_)))));
    vlSelf->wasmetal_core__DOT___067302_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066963_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067301_)))));
    vlSelf->wasmetal_core__DOT___067147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067146_)))));
    vlSelf->wasmetal_core__DOT___066964_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066639_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066963_)))));
    vlSelf->wasmetal_core__DOT___067756_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067755_)))));
    vlSelf->wasmetal_core__DOT___066845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066844_)))));
    vlSelf->wasmetal_core__DOT___067666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067665_)))));
    vlSelf->wasmetal_core__DOT___066640_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066305_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066639_)))));
    vlSelf->wasmetal_core__DOT___067498_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067497_)))));
    vlSelf->wasmetal_core__DOT___067332_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067068_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067331_)))));
    vlSelf->wasmetal_core__DOT___066518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066117_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066517_)))));
    vlSelf->wasmetal_core__DOT___067188_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066885_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067187_)))));
    vlSelf->wasmetal_core__DOT___067069_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067068_)))));
    vlSelf->wasmetal_core__DOT___066306_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066305_)))));
    vlSelf->wasmetal_core__DOT___066886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066885_)))));
    vlSelf->wasmetal_core__DOT___066118_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065794_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066117_)))));
    vlSelf->wasmetal_core__DOT___066762_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066391_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066761_)))));
    vlSelf->wasmetal_core__DOT___066595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066594_)))));
    vlSelf->wasmetal_core__DOT___065927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065596_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065926_)))));
    vlSelf->wasmetal_core__DOT___065795_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065292_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065794_)))));
    vlSelf->wasmetal_core__DOT___066392_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066391_)))));
    vlSelf->wasmetal_core__DOT___066262_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066261_)))));
    vlSelf->wasmetal_core__DOT___066072_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066071_)))));
    vlSelf->wasmetal_core__DOT___065891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065405_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065890_)))));
    vlSelf->wasmetal_core__DOT___065597_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065596_)))));
    vlSelf->wasmetal_core__DOT___065693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065176_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065692_)))));
    vlSelf->wasmetal_core__DOT___065406_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065405_)))));
    vlSelf->wasmetal_core__DOT___064892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064891_))));
    vlSelf->wasmetal_core__DOT___065177_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064483_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065176_)))));
    vlSelf->wasmetal_core__DOT___064484_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064483_))));
    vlSelf->wasmetal_core__DOT___065293_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064724_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065292_)))));
    vlSelf->wasmetal_core__DOT___064725_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064724_))));
    vlSelf->wasmetal_core__DOT___065072_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065071_)))));
    vlSelf->wasmetal_core__DOT___063831_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063829_))));
    vlSelf->wasmetal_core__DOT___049044_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049041_))));
    vlSelf->wasmetal_core__DOT___050526_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050523_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050522_))));
    vlSelf->wasmetal_core__DOT___049689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049451_))));
    vlSelf->wasmetal_core__DOT___049658_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049284_))));
    vlSelf->wasmetal_core__DOT___053210_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->wasmetal_core__DOT___049364_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___049706_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049490_))));
    vlSelf->wasmetal_core__DOT___049624_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049073_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049084_))));
    vlSelf->wasmetal_core__DOT___051402_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050519_))));
    vlSelf->wasmetal_core__DOT___049285_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049283_))));
    vlSelf->wasmetal_core__DOT___051428_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___049085_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049083_))));
    vlSelf->wasmetal_core__DOT___050585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049024_))));
    vlSelf->wasmetal_core__DOT___049454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049450_))));
    vlSelf->wasmetal_core__DOT___050053_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___049493_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049490_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))));
    vlSelf->wasmetal_core__DOT___053895_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053646_))));
    vlSelf->wasmetal_core__DOT___053902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053663_))));
    vlSelf->wasmetal_core__DOT___053634_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051651_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___048680_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84446dc0__0))));
    vlSelf->wasmetal_core__DOT___050709_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049926_))));
    vlSelf->wasmetal_core__DOT___053581_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051779_))));
    vlSelf->wasmetal_core__DOT___049043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049024_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049023_))));
    vlSelf->wasmetal_core__DOT___050521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050518_))));
    vlSelf->wasmetal_core__DOT___051401_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050518_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___049688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049447_))));
    vlSelf->wasmetal_core__DOT___049252_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049251_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___049657_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049251_))));
    vlSelf->wasmetal_core__DOT___052590_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___051427_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0))))));
    vlSelf->wasmetal_core__DOT___051918_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))));
    vlSelf->__VdfgTmp_h10726817__0 = ((4U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xacU 
                                                 >> 
                                                 ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))) 
                                                << 1U)) 
                                         | (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))))));
    vlSelf->wasmetal_core__DOT___052600_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           ((2U 
                                                             & ((0xacU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))))))));
    vlSelf->wasmetal_core__DOT___050059_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0))))));
    vlSelf->__VdfgTmp_h7f4141b2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)))))));
    vlSelf->wasmetal_core__DOT___049363_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0))))));
    vlSelf->wasmetal_core__DOT___049505_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049501_))));
    vlSelf->wasmetal_core__DOT___049705_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049502_))));
    vlSelf->wasmetal_core__DOT___049145_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049132_))));
    vlSelf->wasmetal_core__DOT___049623_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049083_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0))))));
    vlSelf->wasmetal_core__DOT___049371_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047952_))));
    vlSelf->wasmetal_core__DOT___051907_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049226_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051905_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051904_)))))));
    vlSelf->wasmetal_core__DOT___049750_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049121_))));
    vlSelf->wasmetal_core__DOT___049702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048590_))));
    vlSelf->wasmetal_core__DOT___050500_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049630_))))))));
    vlSelf->wasmetal_core__DOT___051744_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049714_))))))));
    vlSelf->wasmetal_core__DOT___065165_ = (1U & (IData)(
                                                         (0x7fff7fff7fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065162_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (1U 
                                                                       & (4U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049684_)))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))));
    vlSelf->wasmetal_core__DOT___051424_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051919_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15d2df15__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___049111_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049100_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049099_))));
    vlSelf->wasmetal_core__DOT___051413_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048980_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050525_))));
    vlSelf->wasmetal_core__DOT___049268_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h32efca0f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049266_))));
    vlSelf->wasmetal_core__DOT___049209_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049173_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))));
    vlSelf->wasmetal_core__DOT___049326_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049324_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))));
    vlSelf->wasmetal_core__DOT___050675_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h40926396__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))));
    vlSelf->wasmetal_core__DOT___049487_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049483_))));
    vlSelf->wasmetal_core__DOT___050599_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049843_))));
    vlSelf->wasmetal_core__DOT___049460_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049458_))));
    vlSelf->wasmetal_core__DOT___053545_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051751_))));
    vlSelf->wasmetal_core__DOT___053551_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051763_))));
    vlSelf->wasmetal_core__DOT___053534_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051741_))));
    vlSelf->wasmetal_core__DOT___053209_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051429_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->__VdfgTmp_h28b05b3d__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)))))));
    vlSelf->wasmetal_core__DOT___050542_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0))))));
    vlSelf->wasmetal_core__DOT___050674_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0))))));
    vlSelf->wasmetal_core__DOT___049857_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0))))));
    vlSelf->wasmetal_core__DOT___049494_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049491_))));
    vlSelf->wasmetal_core__DOT___049703_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049483_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))))));
    vlSelf->wasmetal_core__DOT___049621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049074_))));
    vlSelf->wasmetal_core__DOT___049086_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049074_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049073_))));
    vlSelf->wasmetal_core__DOT___049844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049842_))));
    vlSelf->wasmetal_core__DOT___050598_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049042_))));
    vlSelf->wasmetal_core__DOT___050527_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050524_))));
    vlSelf->wasmetal_core__DOT___051410_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050523_))));
    vlSelf->wasmetal_core__DOT___049588_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049458_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049453_))));
    vlSelf->wasmetal_core__DOT___049455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049453_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049452_))));
    vlSelf->wasmetal_core__DOT___049286_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049277_))));
    vlSelf->wasmetal_core__DOT___049655_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049278_))));
    vlSelf->wasmetal_core__DOT___049522_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049513_))));
    vlSelf->wasmetal_core__DOT___049476_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049464_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049467_))));
    vlSelf->wasmetal_core__DOT___049634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049629_))));
    vlSelf->wasmetal_core__DOT___049665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049545_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049661_))));
    vlSelf->wasmetal_core__DOT___049716_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049713_))));
    vlSelf->wasmetal_core__DOT___049685_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049684_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049683_))));
    vlSelf->wasmetal_core__DOT___053388_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___049620_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049617_))));
    vlSelf->wasmetal_core__DOT___049757_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049173_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049207_))));
    vlSelf->wasmetal_core__DOT___049736_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049310_))));
    vlSelf->wasmetal_core__DOT___049805_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049513_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049520_))));
    vlSelf->wasmetal_core__DOT___049780_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049467_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049474_))));
    vlSelf->wasmetal_core__DOT___049893_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049629_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049632_))));
    vlSelf->wasmetal_core__DOT___049873_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049661_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049663_))));
    vlSelf->wasmetal_core__DOT___050701_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049712_))));
    vlSelf->wasmetal_core__DOT___050716_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049601_))));
    vlSelf->wasmetal_core__DOT___049208_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049207_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049206_))));
    vlSelf->wasmetal_core__DOT___049325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049309_))));
    vlSelf->wasmetal_core__DOT___049521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049519_))));
    vlSelf->wasmetal_core__DOT___049475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049474_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049473_))));
    vlSelf->wasmetal_core__DOT___049633_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049631_))));
    vlSelf->wasmetal_core__DOT___049664_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049663_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049662_))));
    vlSelf->wasmetal_core__DOT___053117_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050628_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050623_))));
    vlSelf->wasmetal_core__DOT___049715_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049711_))));
    vlSelf->wasmetal_core__DOT___053126_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051483_))));
    vlSelf->wasmetal_core__DOT___049603_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049600_))));
    vlSelf->wasmetal_core__DOT___051594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051317_))));
    vlSelf->wasmetal_core__DOT___049756_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049206_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049112_))));
    vlSelf->wasmetal_core__DOT___051898_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051415_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051414_))));
    vlSelf->wasmetal_core__DOT___049735_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049269_))));
    vlSelf->wasmetal_core__DOT___050731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050688_))));
    vlSelf->wasmetal_core__DOT___049804_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049488_))));
    vlSelf->wasmetal_core__DOT___050637_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050609_))));
    vlSelf->wasmetal_core__DOT___049779_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049473_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049461_))));
    vlSelf->wasmetal_core__DOT___050895_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050791_))));
    vlSelf->wasmetal_core__DOT___049801_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049797_))));
    vlSelf->wasmetal_core__DOT___049892_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049622_))));
    vlSelf->wasmetal_core__DOT___050530_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049001_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049000_))));
    vlSelf->wasmetal_core__DOT___049872_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049662_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049656_))));
    vlSelf->wasmetal_core__DOT___049890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049887_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049886_))));
    vlSelf->wasmetal_core__DOT___051468_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((4U 
                                                               & ((0xacU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050623_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049858_))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050629_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050628_)))))));
    vlSelf->wasmetal_core__DOT___050700_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049704_))));
    vlSelf->wasmetal_core__DOT___051486_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049845_))));
    vlSelf->wasmetal_core__DOT___050715_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049589_))));
    vlSelf->__VdfgTmp_h454dd727__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049530_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((0xacU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050869_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050791_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))));
    vlSelf->wasmetal_core__DOT___051467_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049926_)))));
    vlSelf->__VdfgTmp_h444aee6e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049384_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049383_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___049721_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049383_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___050857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050855_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)))))));
    vlSelf->wasmetal_core__DOT___049649_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he62a830e__0))));
    vlSelf->wasmetal_core__DOT___050830_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050828_)))));
    vlSelf->wasmetal_core__DOT___052620_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_had82d15e__0))));
    vlSelf->wasmetal_core__DOT___049901_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049898_))));
    vlSelf->wasmetal_core__DOT___050546_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050543_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049898_)))));
    vlSelf->wasmetal_core__DOT___049243_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049241_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                                  << 1U)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___049768_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051347_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051690_))));
    vlSelf->wasmetal_core__DOT___051348_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049749_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051347_))));
    vlSelf->wasmetal_core__DOT___051583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051582_))));
    vlSelf->wasmetal_core__DOT___051058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051057_))));
    vlSelf->wasmetal_core__DOT___051720_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051719_))));
    vlSelf->wasmetal_core__DOT___051522_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049886_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051521_))));
    vlSelf->wasmetal_core__DOT___051290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049619_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051289_))));
    vlSelf->wasmetal_core__DOT___051632_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051631_))));
    vlSelf->wasmetal_core__DOT___051707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051706_))));
    vlSelf->wasmetal_core__DOT___051368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051367_))));
    vlSelf->wasmetal_core__DOT___051115_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051114_))));
    vlSelf->wasmetal_core__DOT___051615_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051614_))));
    vlSelf->wasmetal_core__DOT___051652_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051651_))));
    vlSelf->wasmetal_core__DOT___051328_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051327_))));
    vlSelf->wasmetal_core__DOT___051551_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050693_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051550_))));
    vlSelf->wasmetal_core__DOT___050697_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050694_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050693_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128180___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)) 
            | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___029608_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128282___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128180___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128283___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058528_ = (1U & (0xf44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xffff007fffffffffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005723_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc058618d__0)))))))))) 
                                                             << 1U)) 
                                                         | ((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___003034_) 
                                                               & (IData)(
                                                                         (0x1000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003032_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb9f44c2b__0)))))))))))));
    vlSelf->wasmetal_core__DOT___047992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___042662_)))));
    vlSelf->wasmetal_core__DOT___048119_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___042601_))));
    vlSelf->wasmetal_core__DOT___047995_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042564_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042601_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042703_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042693_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042554_)))))));
    vlSelf->wasmetal_core__DOT___017940_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047991_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048130_)))));
    vlSelf->wasmetal_core__DOT___048131_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042748_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042632_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4702c863__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127850___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026476_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026465_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026454_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026447_ = ((IData)(vlSelf->wasmetal_core__DOT___026479_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d));
    vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036787_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134153___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h20c332a4__0))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028313_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028248_));
    vlSelf->wasmetal_core__DOT____Vcellout___127859___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026587_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026584_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026573_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026562_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026529_ = ((IData)(vlSelf->wasmetal_core__DOT___026587_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001887_));
    vlSelf->wasmetal_core__DOT___063011_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062989_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052687_)))));
    vlSelf->wasmetal_core__DOT___062992_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062967_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___062989_)))));
    vlSelf->wasmetal_core__DOT___045043_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071265_)))));
    vlSelf->wasmetal_core__DOT___045019_ = (1U & (IData)(
                                                         (0xff737340ff404040ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071263_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071266_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071265_)))))))));
    vlSelf->wasmetal_core__DOT___045045_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071274_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045021_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071274_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054119_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054123_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071272_))))));
    vlSelf->wasmetal_core__DOT___045046_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071279_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045022_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071279_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b8__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054131_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054135_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071277_))))));
    vlSelf->wasmetal_core__DOT___045028_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045004_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071294_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b17__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054186_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b18__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071292_))))));
    vlSelf->wasmetal_core__DOT___045029_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045005_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071299_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054193_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071297_))))));
    vlSelf->wasmetal_core__DOT___045032_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045008_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071314_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071312_))))));
    vlSelf->wasmetal_core__DOT___045033_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071319_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___045009_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071319_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054217_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071317_))))));
    vlSelf->wasmetal_core__DOT___045036_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071334_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045012_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071334_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054235_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071332_))))));
    vlSelf->wasmetal_core__DOT___045038_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___045014_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071339_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                        << 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054241_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                   << 3U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071337_))))));
    vlSelf->wasmetal_core__DOT___045044_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071269_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054107_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045020_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071269_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054107_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054111_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071267_))))));
    vlSelf->wasmetal_core__DOT___045047_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045023_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071284_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054162_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071282_))))));
    vlSelf->wasmetal_core__DOT___045027_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045003_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071289_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054174_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071287_))))));
    vlSelf->wasmetal_core__DOT___045030_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___045006_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071304_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071302_))))));
    vlSelf->wasmetal_core__DOT___045031_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045007_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071309_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054205_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071307_))))));
    vlSelf->wasmetal_core__DOT___045034_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071324_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___045010_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071324_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054223_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071322_))))));
    vlSelf->wasmetal_core__DOT___045035_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071329_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___045011_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071329_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054229_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071327_))))));
    vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031358_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128347___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___128641___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034317_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034379_));
    vlSelf->wasmetal_core__DOT___128657___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034484_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034540_));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027355_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128029___O 
        = (0xfU & ((vlSelf->insn_z >> 0xcU) ^ (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__1__KET__) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__0__KET__) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___027931_))))));
    vlSelf->wasmetal_core__DOT___027935_ = ((vlSelf->insn_z 
                                             >> 0xfU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128029___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128269___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0xfU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0xeU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0xdU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0xcU)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030466_)))));
    vlSelf->wasmetal_core__DOT___030470_ = (1U & ((0x8000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0xfU)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128269___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032870_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128485___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027805_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128013___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128053___O 
        = (0xfU & ((vlSelf->insn_x >> 0xcU) ^ (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__1__KET__) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__0__KET__) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___028157_))))));
    vlSelf->wasmetal_core__DOT___028161_ = ((vlSelf->insn_x 
                                             >> 0xfU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128053___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028092_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xaU)));
    vlSelf->wasmetal_core__DOT____Vcellout___128317___O 
        = (((8U & ((~ (vlSelf->function_params >> 0xfU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0xeU)) 
                                     << 2U)) | ((2U 
                                                 & (vlSelf->function_params 
                                                    >> 0xcU)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0xcU)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030948_)))));
    vlSelf->wasmetal_core__DOT___030952_ = ((~ (vlSelf->function_params 
                                                >> 0xfU)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128317___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070642_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134210___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070640_)))))))));
    vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032678_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128469___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037188_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134211___DOT__CO__BRA__0__KET__)
                  : (9U >> (IData)(vlSelf->__VdfgTmp_h629179e3__0))));
    vlSelf->wasmetal_core__DOT___063520_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063519_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063528_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063527_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063536_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063535_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063544_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063543_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128492___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054494_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054493_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054496_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054495_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054498_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054497_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054500_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054499_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127828___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026361_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127845___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d));
    vlSelf->wasmetal_core__DOT___053368_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053367_)))));
    vlSelf->wasmetal_core__DOT___128403___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031960_));
    vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128290___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128171___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128291___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___062104_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062124_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xfff05550fff0333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048419_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061705_)))))))));
    vlSelf->wasmetal_core__DOT___062045_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaa33330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062035_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf0f3355U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xcaU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee831718__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062046_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062031_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062057_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062054_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x5533fffff0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057288_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057289_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057243_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057247_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057290_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___054972_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019319_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f5U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___054939_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8cc03967__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054966_)))))))));
    vlSelf->wasmetal_core__DOT___062007_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062001_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061995_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061994_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061708_)))))))));
    vlSelf->wasmetal_core__DOT___061985_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___054930_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054920_))));
    vlSelf->wasmetal_core__DOT___061806_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055411_)))))))));
    vlSelf->wasmetal_core__DOT___019303_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1111f0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054884_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054878_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1327a702__0)))))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054875_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___061878_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff44ff00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f00003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055467_))))))))))));
    vlSelf->wasmetal_core__DOT___061513_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061502_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061482_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061475_)))))))));
    vlSelf->wasmetal_core__DOT___062171_ = (1U & (IData)(
                                                         (0xb3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062164_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062163_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))))));
    vlSelf->wasmetal_core__DOT___061512_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061459_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4dc07bf4__0))))))));
    vlSelf->__VdfgTmp_hf56802d2__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061504_))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___061491_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___061490_)))));
    vlSelf->wasmetal_core__DOT___055201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055196_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_hb5edd3cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 2U) | ((2U 
                                                  & ((0xfa330000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha587a88f__0)))))))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019337_)));
    vlSelf->__VdfgTmp_h058d1256__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___019337_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfefeff00ff00ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha587a88f__0))))))))));
    vlSelf->wasmetal_core__DOT___061868_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061849_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaacccc0f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061842_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd50fd36__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061846_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d87626c__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061929_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061919_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x555533330f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061912_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habef704b__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061916_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061517_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048384_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061514_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061504_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061491_)))))));
    vlSelf->wasmetal_core__DOT___055112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___056088_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___056095_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000980_)))));
    vlSelf->wasmetal_core__DOT___056098_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000992_)))));
    vlSelf->wasmetal_core__DOT___056101_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001014_)))));
    vlSelf->wasmetal_core__DOT___056118_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001102_)))));
    vlSelf->wasmetal_core__DOT___056128_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001146_)))));
    vlSelf->wasmetal_core__DOT___056132_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001168_)))));
    vlSelf->wasmetal_core__DOT___056017_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___056025_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___056029_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___056033_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___056037_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___056041_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___056047_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___056055_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___056060_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___056065_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___056069_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___056073_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___056077_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___056082_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___056085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___056007_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___056013_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___012933_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012275_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012007_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012011_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___011752_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___013064_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012008_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056745_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___012012_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056730_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___011753_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011458_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___056374_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0)))));
    vlSelf->wasmetal_core__DOT___013040_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034180_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128623___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d));
    vlSelf->__VdfgTmp_h249314f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb9c84dcf__0))
                                                     : 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he182d032__0)))))));
    vlSelf->__VdfgTmp_hf96aac0e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007420_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007399_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007792_))));
    vlSelf->__VdfgTmp_h4ec1ed59__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007308_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007287_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007782_))));
    vlSelf->__VdfgTmp_h724ed7d2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xff00aaaaf0f0ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007254_))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? 
                                                    (0xc0aU 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007447_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007233_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___007776_))));
    vlSelf->__VdfgTmp_hf6bbf4d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007390_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007789_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007754_)));
    vlSelf->__VdfgTmp_h25286e3d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h37472320__0)))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007782_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007717_)));
    vlSelf->__VdfgTmp_h41c2ec0e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___007778_)
                                               : (0xc0aU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b8e4425__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                         & (IData)(
                                                   (0xf0f0aaaaff00ccccULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h05980b33__0)))))))));
    vlSelf->__VdfgTmp_hde094a0f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h860ce20a__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___007776_)
                                                     : 
                                                    (0xc0aU 
                                                     >> (IData)(vlSelf->__VdfgTmp_h3297ffb7__0)))));
    vlSelf->__VdfgTmp_h5ffe6cff__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007792_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007769_)));
    vlSelf->__VdfgTmp_h6a47c3d1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007418_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                  ? (IData)(vlSelf->wasmetal_core__DOT___007769_)
                                                  : (IData)(vlSelf->wasmetal_core__DOT___007659_)));
    vlSelf->__VdfgTmp_hc2fc9f8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5812bf47__0));
    vlSelf->__VdfgTmp_h143507db__0 = (((IData)(vlSelf->wasmetal_core__DOT___010131_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                      & (IData)(
                                                                (0xff00aaaaf0f0ccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___007367_))))))))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                           ? 
                                                          (0xc0aU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___007347_)))))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___007786_))))));
    vlSelf->wasmetal_core__DOT___009840_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xaaf0ccU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h544074d8__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         & (IData)(
                                                                                (0xff00aaaaf0f0ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007340_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007341_))))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010110_)))))))));
    vlSelf->__VdfgTmp_h63abc8ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___011712_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055135_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                                       << 2U) 
                                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                           & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))) 
                                                                          << 1U) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc18298c4__0))))))))))))));
    vlSelf->__VdfgTmp_hbc09f2bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053783_))))));
    vlSelf->__VdfgTmp_ha85bab6c__0 = (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053787_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053790_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___053789_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff00000eeee0000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053784_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053783_) 
                                                                              << 2U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaaf0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528a2190__0))))) 
                                                                                << 1U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                & (IData)(
                                                                                (0xccaa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h38ad22b9__0))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053788_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053787_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053786_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053785_)))))))))))))));
    vlSelf->__VdfgTmp_hb4fb5a01__0 = (((IData)(vlSelf->wasmetal_core__DOT___007661_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007660_));
    vlSelf->__VdfgTmp_h86442115__0 = (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054894_));
    vlSelf->wasmetal_core__DOT___009818_ = (1U & (IData)(
                                                         (0xff00f0aaaaccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007772_)))))))));
    vlSelf->wasmetal_core__DOT___010594_ = (1U & (IData)(
                                                         (0xf000f0000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054893_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007204_)))))))));
    vlSelf->__VdfgTmp_h3856dbf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007587_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007588_));
    if (vlSelf->wasmetal_core__DOT___007235_) {
        if (vlSelf->wasmetal_core__DOT___007234_) {
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007588_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007587_))));
            vlSelf->wasmetal_core__DOT___054852_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007601_))));
        } else {
            vlSelf->wasmetal_core__DOT___054806_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007585_))));
            vlSelf->wasmetal_core__DOT___054852_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___007600_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007599_))));
        }
        vlSelf->wasmetal_core__DOT___010215_ = (1U 
                                                & (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd5802a9c__0))))));
        vlSelf->wasmetal_core__DOT___010321_ = (1U 
                                                & (IData)(
                                                          (0xf0f0aaaaff00ccccULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_hba71a165__0))));
    } else {
        vlSelf->wasmetal_core__DOT___054806_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007590_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007589_)))));
        vlSelf->wasmetal_core__DOT___054852_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                   | (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007604_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007603_)))));
        vlSelf->wasmetal_core__DOT___010215_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007679_))));
        vlSelf->wasmetal_core__DOT___010321_ = 0U;
    }
    vlSelf->__VdfgTmp_he9e11b30__0 = (((IData)(vlSelf->wasmetal_core__DOT___010359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010358_));
    vlSelf->__VdfgTmp_h8d86a2a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007622_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007621_));
    vlSelf->wasmetal_core__DOT___007824_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007624_))))));
    vlSelf->wasmetal_core__DOT___010332_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007623_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007624_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007622_)))))))));
    vlSelf->__VdfgTmp_h973345c0__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0aaaaff00ccccULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007602_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007599_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007600_))))))))));
    vlSelf->__VdfgTmp_h37a4ed19__0 = (((IData)(vlSelf->wasmetal_core__DOT___007601_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007602_));
    vlSelf->__VdfgTmp_h3d308cc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007585_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007586_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___053918_))))));
    vlSelf->__VdfgTmp_h496bba40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaaf0f000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                         << 5U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h504ea901__0))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaa0000f0f0ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                             << 4U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h2cdc7e5b__0)))))))))));
    vlSelf->__VdfgTmp_h8a3dc284__0 = (((IData)(vlSelf->wasmetal_core__DOT___053919_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___053918_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & (((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                                         & (IData)(
                                                                   (0x33ff55ff0fff0fffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                            << 3U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h6277318a__0))))))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                       & (IData)(
                                                                 (0x33ff55ff0fff0fffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hbaaa25aa__0))))))))));
    vlSelf->__VdfgTmp_h0761bbb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007567_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007570_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007568_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007566_)))))))))))))));
    vlSelf->wasmetal_core__DOT___010351_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007568_)))))))));
    vlSelf->__VdfgTmp_h66742b2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007546_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007549_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007547_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007544_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007545_)))))))))))))));
    vlSelf->wasmetal_core__DOT___010370_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007548_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007549_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007546_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007547_)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007529_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hca913760__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007524_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007525_)))))))))))))));
    vlSelf->__VdfgTmp_h939caa69__0 = (((IData)(vlSelf->wasmetal_core__DOT___007527_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007526_));
    vlSelf->wasmetal_core__DOT___054797_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007528_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007529_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007526_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007527_)))))))));
    vlSelf->__VdfgTmp_he26aa999__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054141_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054139_))))));
    vlSelf->__VdfgTmp_hcab0eaad__0 = ((2U & ((IData)(
                                                     (0xfff00000eeee0000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054140_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054139_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___054150_)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff00000eeeeULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054142_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___054141_))))))))));
    vlSelf->__VdfgTmp_h2966a39c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054150_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054149_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h81bae7c4__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hc859778d__0))))))))));
    vlSelf->wasmetal_core__DOT___010558_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007743_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2aa6a52e__0))))));
    vlSelf->__VdfgTmp_h29ef1e90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007744_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007743_));
    vlSelf->__VdfgTmp_h79c46d44__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007234_))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))));
    vlSelf->__VdfgTmp_hcb043302__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055073_) 
                                                     << 3U) 
                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         & (IData)(
                                                                   (0xccaaf0f000000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                      << 5U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6ab1a2ea__0))))) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___054339_))))));
    vlSelf->__VdfgTmp_h2cfd74cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054339_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054338_) 
                                                        << 2U) 
                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            & (IData)(
                                                                      (0xccaa0000f0f0ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                            << 4U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h7678d7b9__0)))))) 
                                                           << 1U) 
                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                             & (IData)(
                                                                       (0xccaaf0f000000000ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                          << 5U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0))))))))));
    vlSelf->wasmetal_core__DOT___010585_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007703_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___010582_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007706_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h009b2026__0))))))));
    vlSelf->__VdfgTmp_h7619e45d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007707_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007706_));
    vlSelf->wasmetal_core__DOT___010589_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007688_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007689_)))))))));
    vlSelf->wasmetal_core__DOT___010591_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___010760_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007691_))))));
    vlSelf->wasmetal_core__DOT___009793_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___007693_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                      ? 
                                                     (0xf1111U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007690_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007689_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007688_))))))
                                                      : 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___007692_))))));
    vlSelf->wasmetal_core__DOT___010289_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007691_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007690_)))))));
    vlSelf->wasmetal_core__DOT___011713_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___010102_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055136_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055135_))))));
    vlSelf->__VdfgTmp_h86da9f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___054278_) 
                                       << 3U) | ((4U 
                                                  & ((0xf00eeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007677_)))))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & (((IData)(vlSelf->wasmetal_core__DOT___007204_)
                                                          ? 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcd9d6cde__0))
                                                          : 
                                                         (0x305U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hf8957689__0))) 
                                                        << 1U)) 
                                                    | ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       & (IData)(
                                                                 (0xf0f333300ff5555ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___007246_))))))))))));
    vlSelf->wasmetal_core__DOT___010780_ = (1U & (0xf0110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007662_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007663_)))))));
    vlSelf->wasmetal_core__DOT___010386_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___011622_ = (1U & (0xf11U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054151_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054152_))))));
    vlSelf->wasmetal_core__DOT___054157_ = (1U & (0xf000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007664_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054152_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054151_)))))));
    vlSelf->__VdfgTmp_hdeccdd32__0 = (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054738_));
    vlSelf->wasmetal_core__DOT___010229_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054738_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054739_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcc135002__0))))))));
    vlSelf->wasmetal_core__DOT___056201_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007506_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007505_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007234_))))));
    vlSelf->__VdfgTmp_hae0eb281__0 = (((IData)(vlSelf->wasmetal_core__DOT___007508_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007507_));
    vlSelf->__VdfgTmp_hd4d40399__0 = (((IData)(vlSelf->wasmetal_core__DOT___007510_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007509_));
    vlSelf->__VdfgTmp_hce8e9d12__0 = ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                        & (IData)((0xf0f0ccccff00aaaaULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___007419_))))))))) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfff00000eeeeULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007758_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0fc2ac4f__0)))))))));
    vlSelf->__VdfgTmp_h7e54e6f3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007759_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007758_));
    vlSelf->wasmetal_core__DOT___010569_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___010310_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h22d02546__0))));
    vlSelf->__VdfgTmp_hf2283ef8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007642_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   (4U 
                                                    & ((0xe00U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___007645_))))) 
                                                       << 2U)) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        & (IData)(
                                                                  (0xf0f0aaaaff00ccccULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)))))))) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007643_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007640_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007641_)))))))))))))));
    vlSelf->wasmetal_core__DOT___010311_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007644_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007645_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007642_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007643_)))))))));
    vlSelf->wasmetal_core__DOT___064907_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___064473_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___064738_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128231___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030119_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030086_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030265_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030190_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->wasmetal_core__DOT___066143_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066135_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066140_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065315_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065313_)))))))))))));
    vlSelf->wasmetal_core__DOT___036900_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0))))))));
    vlSelf->wasmetal_core__DOT___036899_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036636_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0))))))));
    vlSelf->wasmetal_core__DOT___036898_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036635_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___036897_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))))));
    vlSelf->wasmetal_core__DOT___064933_ = (1U & (0x4fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064918_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0791be06__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048344_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x4fff00ff00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063924_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61f75715__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___063851_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063849_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042427_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___067350_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067338_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066077_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066775_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067084_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067202_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067336_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067320_ = (1U & (IData)(
                                                         (0xf0f00000ccaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065932_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066653_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0ccaaU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066980_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067161_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___067306_)))))))))))))));
    vlSelf->wasmetal_core__DOT___002883_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he03432df__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))));
    vlSelf->__VdfgTmp_h3fe5e3ea__0 = ((2U & ((IData)(
                                                     (0xff00ff00ff000eULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___048829_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1111fff000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048828_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? 
                                                                      (0xc0aU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002106_)) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))))));
}
