#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__33(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__33\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006190_;
    wasmetal_core__DOT___006190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006195_;
    wasmetal_core__DOT___006195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006251_;
    wasmetal_core__DOT___006251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006252_;
    wasmetal_core__DOT___006252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006260_;
    wasmetal_core__DOT___006260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006261_;
    wasmetal_core__DOT___006261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006269_;
    wasmetal_core__DOT___006269_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006270_;
    wasmetal_core__DOT___006270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006286_;
    wasmetal_core__DOT___006286_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006287_;
    wasmetal_core__DOT___006287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006293_;
    wasmetal_core__DOT___006293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006294_;
    wasmetal_core__DOT___006294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006302_;
    wasmetal_core__DOT___006302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006303_;
    wasmetal_core__DOT___006303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006312_;
    wasmetal_core__DOT___006312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006313_;
    wasmetal_core__DOT___006313_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006327_;
    wasmetal_core__DOT___006327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006328_;
    wasmetal_core__DOT___006328_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006336_;
    wasmetal_core__DOT___006336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006337_;
    wasmetal_core__DOT___006337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006346_;
    wasmetal_core__DOT___006346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006347_;
    wasmetal_core__DOT___006347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006355_;
    wasmetal_core__DOT___006355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006356_;
    wasmetal_core__DOT___006356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006365_;
    wasmetal_core__DOT___006365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006366_;
    wasmetal_core__DOT___006366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006367_;
    wasmetal_core__DOT___006367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006368_;
    wasmetal_core__DOT___006368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006371_;
    wasmetal_core__DOT___006371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006379_;
    wasmetal_core__DOT___006379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006442_;
    wasmetal_core__DOT___006442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006443_;
    wasmetal_core__DOT___006443_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006489_;
    wasmetal_core__DOT___006489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006531_;
    wasmetal_core__DOT___006531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006532_;
    wasmetal_core__DOT___006532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006572_;
    wasmetal_core__DOT___006572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006608_;
    wasmetal_core__DOT___006608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006611_;
    wasmetal_core__DOT___006611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006612_;
    wasmetal_core__DOT___006612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006618_;
    wasmetal_core__DOT___006618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007069_;
    wasmetal_core__DOT___007069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007072_;
    wasmetal_core__DOT___007072_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007075_;
    wasmetal_core__DOT___007075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007087_;
    wasmetal_core__DOT___007087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007091_;
    wasmetal_core__DOT___007091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007100_;
    wasmetal_core__DOT___007100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007109_;
    wasmetal_core__DOT___007109_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007113_;
    wasmetal_core__DOT___007113_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007117_;
    wasmetal_core__DOT___007117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007123_;
    wasmetal_core__DOT___007123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007135_;
    wasmetal_core__DOT___007135_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007145_;
    wasmetal_core__DOT___007145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007155_;
    wasmetal_core__DOT___007155_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007169_;
    wasmetal_core__DOT___007169_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007185_;
    wasmetal_core__DOT___007185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009495_;
    wasmetal_core__DOT___009495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014473_;
    wasmetal_core__DOT___014473_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014483_;
    wasmetal_core__DOT___014483_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014497_;
    wasmetal_core__DOT___014497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014500_;
    wasmetal_core__DOT___014500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014501_;
    wasmetal_core__DOT___014501_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014511_;
    wasmetal_core__DOT___014511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014525_;
    wasmetal_core__DOT___014525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014553_;
    wasmetal_core__DOT___014553_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015115_;
    wasmetal_core__DOT___015115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015117_;
    wasmetal_core__DOT___015117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015154_;
    wasmetal_core__DOT___015154_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023099_;
    wasmetal_core__DOT___023099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023103_;
    wasmetal_core__DOT___023103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023107_;
    wasmetal_core__DOT___023107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035319_;
    wasmetal_core__DOT___035319_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035323_;
    wasmetal_core__DOT___035323_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035332_;
    wasmetal_core__DOT___035332_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035490_;
    wasmetal_core__DOT___035490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035494_;
    wasmetal_core__DOT___035494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035499_;
    wasmetal_core__DOT___035499_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035606_;
    wasmetal_core__DOT___035606_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035611_;
    wasmetal_core__DOT___035611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035704_;
    wasmetal_core__DOT___035704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035705_;
    wasmetal_core__DOT___035705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035706_;
    wasmetal_core__DOT___035706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035792_;
    wasmetal_core__DOT___035792_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035801_;
    wasmetal_core__DOT___035801_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035805_;
    wasmetal_core__DOT___035805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035809_;
    wasmetal_core__DOT___035809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035814_;
    wasmetal_core__DOT___035814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035825_;
    wasmetal_core__DOT___035825_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___042782_;
    wasmetal_core__DOT___042782_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048080_;
    wasmetal_core__DOT___048080_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048081_;
    wasmetal_core__DOT___048081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048082_;
    wasmetal_core__DOT___048082_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048083_;
    wasmetal_core__DOT___048083_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048084_;
    wasmetal_core__DOT___048084_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048085_;
    wasmetal_core__DOT___048085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048088_;
    wasmetal_core__DOT___048088_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048089_;
    wasmetal_core__DOT___048089_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048090_;
    wasmetal_core__DOT___048090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048091_;
    wasmetal_core__DOT___048091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048092_;
    wasmetal_core__DOT___048092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048093_;
    wasmetal_core__DOT___048093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048094_;
    wasmetal_core__DOT___048094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048095_;
    wasmetal_core__DOT___048095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048096_;
    wasmetal_core__DOT___048096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048099_;
    wasmetal_core__DOT___048099_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048100_;
    wasmetal_core__DOT___048100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048101_;
    wasmetal_core__DOT___048101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048102_;
    wasmetal_core__DOT___048102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048103_;
    wasmetal_core__DOT___048103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048105_;
    wasmetal_core__DOT___048105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048106_;
    wasmetal_core__DOT___048106_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048107_;
    wasmetal_core__DOT___048107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048162_;
    wasmetal_core__DOT___048162_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048215_;
    wasmetal_core__DOT___048215_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048216_;
    wasmetal_core__DOT___048216_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048217_;
    wasmetal_core__DOT___048217_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048218_;
    wasmetal_core__DOT___048218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048219_;
    wasmetal_core__DOT___048219_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048220_;
    wasmetal_core__DOT___048220_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048221_;
    wasmetal_core__DOT___048221_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048222_;
    wasmetal_core__DOT___048222_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048223_;
    wasmetal_core__DOT___048223_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048224_;
    wasmetal_core__DOT___048224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048225_;
    wasmetal_core__DOT___048225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048227_;
    wasmetal_core__DOT___048227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048228_;
    wasmetal_core__DOT___048228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048229_;
    wasmetal_core__DOT___048229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048247_;
    wasmetal_core__DOT___048247_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048248_;
    wasmetal_core__DOT___048248_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048249_;
    wasmetal_core__DOT___048249_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048250_;
    wasmetal_core__DOT___048250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048251_;
    wasmetal_core__DOT___048251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048252_;
    wasmetal_core__DOT___048252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048253_;
    wasmetal_core__DOT___048253_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048254_;
    wasmetal_core__DOT___048254_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048255_;
    wasmetal_core__DOT___048255_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048268_;
    wasmetal_core__DOT___048268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048932_;
    wasmetal_core__DOT___048932_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048933_;
    wasmetal_core__DOT___048933_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048934_;
    wasmetal_core__DOT___048934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048935_;
    wasmetal_core__DOT___048935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048936_;
    wasmetal_core__DOT___048936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048938_;
    wasmetal_core__DOT___048938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048939_;
    wasmetal_core__DOT___048939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048940_;
    wasmetal_core__DOT___048940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050077_;
    wasmetal_core__DOT___050077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058379_;
    wasmetal_core__DOT___058379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058393_;
    wasmetal_core__DOT___058393_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058422_;
    wasmetal_core__DOT___058422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059229_;
    wasmetal_core__DOT___059229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070491_;
    wasmetal_core__DOT___070491_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071843_;
    wasmetal_core__DOT___071843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127506___O;
    wasmetal_core__DOT____Vcellout___127506___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127509___O;
    wasmetal_core__DOT____Vcellout___127509___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128729___O;
    wasmetal_core__DOT____Vcellout___128729___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128730___O;
    wasmetal_core__DOT____Vcellout___128730___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128732___O;
    wasmetal_core__DOT____Vcellout___128732___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128744___O;
    wasmetal_core__DOT____Vcellout___128744___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128745___O;
    wasmetal_core__DOT____Vcellout___128745___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128746___O;
    wasmetal_core__DOT____Vcellout___128746___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128747___O;
    wasmetal_core__DOT____Vcellout___128747___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128759___O;
    wasmetal_core__DOT____Vcellout___128759___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128760___O;
    wasmetal_core__DOT____Vcellout___128760___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128761___O;
    wasmetal_core__DOT____Vcellout___128761___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128782___O;
    wasmetal_core__DOT____Vcellout___128782___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128783___O;
    wasmetal_core__DOT____Vcellout___128783___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128784___O;
    wasmetal_core__DOT____Vcellout___128784___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128785___O;
    wasmetal_core__DOT____Vcellout___128785___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128786___O;
    wasmetal_core__DOT____Vcellout___128786___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___O;
    wasmetal_core__DOT____Vcellout___128787___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___CO;
    wasmetal_core__DOT____Vcellout___128787___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1c23bbd1__0;
    __VdfgTmp_h1c23bbd1__0 = 0;
    CData/*2:0*/ __VdfgTmp_h3a48ed75__0;
    __VdfgTmp_h3a48ed75__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf115889b__0;
    __VdfgTmp_hf115889b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h13ac9eb3__0;
    __VdfgTmp_h13ac9eb3__0 = 0;
    CData/*2:0*/ __VdfgTmp_h859eb527__0;
    __VdfgTmp_h859eb527__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7fda4de5__0;
    __VdfgTmp_h7fda4de5__0 = 0;
    CData/*2:0*/ __VdfgTmp_h385c50c6__0;
    __VdfgTmp_h385c50c6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h06108119__0;
    __VdfgTmp_h06108119__0 = 0;
    CData/*3:0*/ __VdfgTmp_hd93d0b50__0;
    __VdfgTmp_hd93d0b50__0 = 0;
    CData/*4:0*/ __VdfgTmp_h00a84c57__0;
    __VdfgTmp_h00a84c57__0 = 0;
    CData/*2:0*/ __VdfgTmp_h32160e17__0;
    __VdfgTmp_h32160e17__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc24ed5a6__0;
    __VdfgTmp_hc24ed5a6__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3be775f9__0;
    __VdfgTmp_h3be775f9__0 = 0;
    CData/*1:0*/ __VdfgTmp_h35fc6168__0;
    __VdfgTmp_h35fc6168__0 = 0;
    CData/*1:0*/ __VdfgTmp_h38f8e813__0;
    __VdfgTmp_h38f8e813__0 = 0;
    CData/*1:0*/ __VdfgTmp_h4954f743__0;
    __VdfgTmp_h4954f743__0 = 0;
    CData/*1:0*/ __VdfgTmp_h57c36911__0;
    __VdfgTmp_h57c36911__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb49f8759__0;
    __VdfgTmp_hb49f8759__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2242a82b__0;
    __VdfgTmp_h2242a82b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1785588f__0;
    __VdfgTmp_h1785588f__0 = 0;
    CData/*4:0*/ __VdfgTmp_he4f3e8d5__0;
    __VdfgTmp_he4f3e8d5__0 = 0;
    CData/*4:0*/ __VdfgTmp_hf41e7b3e__0;
    __VdfgTmp_hf41e7b3e__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___048264_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006010_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005848_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006009_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006008_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005910_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h2af4e7f7__0))))))))));
    __VdfgTmp_hd93d0b50__0 = (((IData)(vlSelf->wasmetal_core__DOT___005702_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005701_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h2af4e7f7__0)));
    vlSelf->wasmetal_core__DOT___040108_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071475_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0))))));
    __VdfgTmp_hf41e7b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___071515_) 
                               << 4U) | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0));
    __VdfgTmp_he4f3e8d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___071492_) 
                               << 4U) | (IData)(vlSelf->__VdfgTmp_hcfa19df1__0));
    wasmetal_core__DOT____Vcellout___127506___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___023094_)))));
    wasmetal_core__DOT___023099_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127506___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hc9bde5b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc3641189__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hcdd8cada__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h152c16b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128741___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035370_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035314_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h04542857__0))));
    wasmetal_core__DOT____Vcellout___128744___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035485_)))));
    wasmetal_core__DOT___035490_ = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                        >> 2U)) & (IData)(vlSelf->wasmetal_core__DOT___128744___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035660_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b47__05d));
    vlSelf->wasmetal_core__DOT___048267_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005977_)) 
                                                  & ((~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127526___O) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                           ? (IData)(
                                                                     (0xf3f0f2e0f3faaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9fcc5824__0)))))))
                                                           : 
                                                          (0x302U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h9fcc5824__0))))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005916_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005850_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h35bc9263__0))))))));
    vlSelf->wasmetal_core__DOT___006126_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006009_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127533___O) 
                                                        >> 2U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___006144_)
                                                           ? (IData)(
                                                                     (0x2aa00000202ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb47c9e11__0)))
                                                           : (IData)(
                                                                     (0xfffffeaafffffefeULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hb47c9e11__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005844_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005843_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfdd5af20__0))))))));
    vlSelf->wasmetal_core__DOT___048161_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005706_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___005705_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___005704_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005703_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hd93d0b50__0))))))));
    vlSelf->wasmetal_core__DOT___006191_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___006199_)) 
                                                  & ((~ 
                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127522___O) 
                                                        >> 1U) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___006204_)
                                                           ? (IData)(
                                                                     (0x2aa00000202ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h16a355a8__0)))
                                                           : (IData)(
                                                                     (0xfffffeaafffffefeULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h16a355a8__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006078_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006077_) 
                                                                     << 4U) 
                                                                    | (IData)(__VdfgTmp_hd93d0b50__0))))))));
    vlSelf->wasmetal_core__DOT___039758_ = (1U & (IData)(
                                                         (0xffffffff00ae0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b15__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf41e7b3e__0)))));
    vlSelf->wasmetal_core__DOT___040079_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b47__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_hf41e7b3e__0)))));
    vlSelf->wasmetal_core__DOT___039761_ = (1U & (IData)(
                                                         (0xffffffff00ae0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b7__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_he4f3e8d5__0)))));
    vlSelf->wasmetal_core__DOT___040053_ = (1U & (IData)(
                                                         (0xffffffffae000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b39__05d) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_he4f3e8d5__0)))));
    vlSelf->wasmetal_core__DOT___060425_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff007700ff000f00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hb5f365d2__0))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xf0f0335500000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058355_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127506___O))))))))))))));
    vlSelf->wasmetal_core__DOT___060451_ = (1U & (IData)(
                                                         (0x3f5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060449_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x11ffffff0f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(wasmetal_core__DOT____Vcellout___127506___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___060435_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xfcf0faf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058507_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128873___O) 
                                                                                >> 1U))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf0f03355U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058356_) 
                                                                      << 1U) 
                                                                     | (1U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127506___O) 
                                                                           >> 1U))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))));
    vlSelf->wasmetal_core__DOT___060472_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058357_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127506___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d) 
           & (IData)(wasmetal_core__DOT___023099_));
    wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035371_)
                  ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7d7923ea__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035490_));
    wasmetal_core__DOT____Vcellout___128759___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035661_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035660_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035659_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035658_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128759___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035602_)))));
    wasmetal_core__DOT___035606_ = ((IData)(vlSelf->wasmetal_core__DOT___035661_)
                                     ? (IData)(wasmetal_core__DOT___128759___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b48__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___048266_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048265_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048267_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006125_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006124_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006123_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006122_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006126_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___048160_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___048159_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048161_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006408_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006407_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hfdd5af20__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006191_)))))))));
    wasmetal_core__DOT___070491_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006191_))));
    vlSelf->__VdfgTmp_h1e09234e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___006192_)))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
           & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035372_)
                  ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h7f56c529__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128759___O)) 
           & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035662_)
            ? (IData)(wasmetal_core__DOT___035606_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b49__05d));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d 
        = (1U & (0x8000U >> (((IData)(vlSelf->wasmetal_core__DOT___006392_) 
                              << 3U) | ((4U & ((1U 
                                                >> (IData)(vlSelf->__VdfgTmp_h35bc9263__0)) 
                                               << 2U)) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___070491_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d 
        = (1U & (0x80U >> (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___070491_)))));
    vlSelf->wasmetal_core__DOT___058412_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006598_)))));
    vlSelf->wasmetal_core__DOT___058397_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006604_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006603_)))));
    vlSelf->wasmetal_core__DOT___058403_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006603_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006596_)))));
    vlSelf->wasmetal_core__DOT___058380_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006602_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006601_)))));
    vlSelf->wasmetal_core__DOT___058388_ = (1U & (0x35U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006601_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006604_)))));
    wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
           & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128729___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035373_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035372_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035371_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035370_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035314_)))));
    wasmetal_core__DOT___035319_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035373_)
                                           ? (IData)(wasmetal_core__DOT___128729___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h16c6eb53__0))));
    wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035663_)
            ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b50__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    vlSelf->__VdfgTmp_h08354128__0 = ((8U & ((0x7fff0000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___058388_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_hefac2d69__0)));
    vlSelf->wasmetal_core__DOT____Vcellout___127507___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023099_)))));
    wasmetal_core__DOT___023103_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127507___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h51de0e2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128729___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h783c16d6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hdd32c6cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128729___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h6673ab20__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128742___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035374_)
                  ? (IData)(wasmetal_core__DOT___035319_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_he5f506d8__0))));
    wasmetal_core__DOT____Vcellout___128745___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(wasmetal_core__DOT____Vcellout___128759___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035490_)))));
    wasmetal_core__DOT___035494_ = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128745___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035665_)
            ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b51__05d));
    vlSelf->wasmetal_core__DOT___060540_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xfcf0faf00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058511_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 3U))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f0335500000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058361_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 3U)))))))))))));
    wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d) 
           & (IData)(wasmetal_core__DOT___023103_));
    wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035375_)
                  ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h885d0717__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035494_));
    wasmetal_core__DOT____Vcellout___128760___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035666_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035665_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035663_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035662_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035606_)))));
    wasmetal_core__DOT___035611_ = ((IData)(vlSelf->wasmetal_core__DOT___035666_)
                                     ? (IData)(wasmetal_core__DOT___128760___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b52__05d));
    wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035376_)
                  ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h1caccec5__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128760___O)) 
           & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035667_)
            ? (IData)(wasmetal_core__DOT___035611_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b53__05d));
    wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
           & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128730___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035377_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035376_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035375_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035374_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035319_)))));
    wasmetal_core__DOT___035323_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035377_)
                                           ? (IData)(wasmetal_core__DOT___128730___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_h4b8dd412__0))));
    wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
               >> 1U)) & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)
            : (IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127508___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023103_)))));
    wasmetal_core__DOT___023107_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___127508___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hab2a3827__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128730___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc1ac3ed9__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h4f4cafcf__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128730___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h05032e00__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128729___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035378_)
                  ? (IData)(wasmetal_core__DOT___035323_)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h6a2ef1d7__0))));
    wasmetal_core__DOT____Vcellout___128746___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                          >> 2U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                             >> 1U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ (IData)(wasmetal_core__DOT____Vcellout___128760___O)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ 
                                                                ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                                 >> 3U)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035494_)))));
    wasmetal_core__DOT___035499_ = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                        >> 2U)) & (IData)(wasmetal_core__DOT___128746___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___128761___O = (
                                                   (4U 
                                                    | ((2U 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_alignedSigA__05b54__05d)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___035667_))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__2__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128761___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035611_)))));
    vlSelf->wasmetal_core__DOT___060583_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058362_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060567_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xbfffbfff0000ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ac41acf__0)))))))))))));
    vlSelf->wasmetal_core__DOT___060553_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xbfffbfff0000ffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015932_)))))))))))))));
    wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d) 
           & (IData)(wasmetal_core__DOT___023107_));
    wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035379_)
                  ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h030e49d3__0))));
    wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__ 
        = ((~ ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___035499_));
    wasmetal_core__DOT___042782_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x38U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                       << 3U)) 
                                                   | (7U 
                                                      & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                         >> 1U))))));
    wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035381_)
                  ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h77324dc0__0))));
    wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT____Vcellout___128761___O)) 
           & (IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___042770_ = (1U & ((~ (IData)(wasmetal_core__DOT___042782_)) 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                     >> 2U)));
    wasmetal_core__DOT____Vcellout___127509___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b63__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d)))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d) 
                                                      & (IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127509___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023107_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128731___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035382_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035381_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035379_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035378_)))) 
           ^ (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___035323_)))));
    vlSelf->wasmetal_core__DOT___035328_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035382_)
                                                   ? (IData)(wasmetal_core__DOT___128731___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (0xcaU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfd12f0c5__0))));
    wasmetal_core__DOT____Vcellout___128747___O = (
                                                   ((4U 
                                                     & ((~ 
                                                         ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                          >> 1U)) 
                                                        << 2U)) 
                                                    | ((2U 
                                                        & ((~ (IData)(wasmetal_core__DOT____Vcellout___128761___O)) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (~ 
                                                             ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                              >> 3U))))) 
                                                   ^ 
                                                   ((((~ 
                                                       ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                        >> 1U)) 
                                                      & (IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__)) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128747___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035499_)))));
    vlSelf->wasmetal_core__DOT___006479_ = (1U & (0xf0f055ccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___023239_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h834dc827__0))))));
    vlSelf->wasmetal_core__DOT___035790_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h834dc827__0))));
    wasmetal_core__DOT___048250_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048249_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O))))));
    wasmetal_core__DOT___048223_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048222_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128743___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128757___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048935_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048934_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O))))));
    wasmetal_core__DOT___048085_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048084_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128748___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128762___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048089_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048088_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O))))));
    wasmetal_core__DOT___048091_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048090_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128749___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128763___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048083_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048082_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O))))));
    wasmetal_core__DOT___048221_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048220_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128750___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128764___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048248_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048247_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O))))));
    wasmetal_core__DOT___048216_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048215_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128751___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128765___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___048932_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___048933_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O))))));
    wasmetal_core__DOT___048100_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___048099_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128752___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128766___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___048079_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048078_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O))))));
    vlSelf->wasmetal_core__DOT___048098_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048097_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128753___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128767___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048087_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048086_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O))))));
    vlSelf->wasmetal_core__DOT___006352_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048168_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128754___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128768___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006343_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048201_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O))))));
    vlSelf->wasmetal_core__DOT___006333_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006340_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128755___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128769___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048202_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O))))));
    vlSelf->wasmetal_core__DOT___006309_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006316_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128756___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128770___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006299_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006306_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128744___O)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O))))));
    vlSelf->wasmetal_core__DOT___006290_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048077_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128744___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128758___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___006277_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048076_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128745___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128759___O))))));
    vlSelf->wasmetal_core__DOT___048214_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___048213_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128745___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128759___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048246_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___006264_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128746___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128760___O))))));
    vlSelf->wasmetal_core__DOT___006255_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128746___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___060653_ = (1U & (0xefefefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xf0f000003355ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___060224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058516_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128876___O) 
                                                                                >> 3U))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0335500000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___019014_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058365_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                                >> 3U))))))))))))))));
    vlSelf->wasmetal_core__DOT___060615_ = (1U & (0x3f5f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x7f7f00ffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))))))))));
    vlSelf->wasmetal_core__DOT___060639_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058364_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___060623_ = (1U & (IData)(
                                                         (0xf0f0335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058363_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127509___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_h9f7a6ca7__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h7bf8c9f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc3230cc7__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hc03ce175__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128730___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035383_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035328_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02efar_sigLarger__05b49__05d));
    vlSelf->wasmetal_core__DOT___048943_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128747___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128761___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___048683_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___128747___O)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___128761___O))))));
    vlSelf->wasmetal_core__DOT___006246_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128747___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128760___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___006568_ = (1U & (IData)(
                                                         (0x8000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006479_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))));
    vlSelf->wasmetal_core__DOT___006475_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048250_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hba4cc4c7__0))))));
    vlSelf->wasmetal_core__DOT___006478_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048249_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hffde1553__0))))));
    vlSelf->wasmetal_core__DOT___035789_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048250_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048249_))));
    vlSelf->wasmetal_core__DOT___006469_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048223_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfaf781e7__0))))));
    vlSelf->wasmetal_core__DOT___006474_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048222_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9fccfed0__0))))));
    vlSelf->wasmetal_core__DOT___035788_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048223_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048222_))));
    vlSelf->wasmetal_core__DOT___006463_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048935_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc23424b0__0))))));
    vlSelf->wasmetal_core__DOT___006468_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023233_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048934_)))));
    vlSelf->wasmetal_core__DOT___035787_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048935_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048934_))));
    vlSelf->wasmetal_core__DOT___006457_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023230_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048085_)))));
    vlSelf->wasmetal_core__DOT___006462_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023231_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048084_)))));
    vlSelf->wasmetal_core__DOT___035786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048085_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048084_))));
    vlSelf->wasmetal_core__DOT___006451_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048089_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9fa4f51d__0))))));
    vlSelf->wasmetal_core__DOT___006456_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048088_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc21b3046__0))))));
    vlSelf->wasmetal_core__DOT___035785_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048089_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048088_))));
    vlSelf->wasmetal_core__DOT___006445_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048091_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6ec85b19__0))))));
    vlSelf->wasmetal_core__DOT___006450_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023227_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048090_)))));
    vlSelf->wasmetal_core__DOT___035784_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048091_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048090_))));
    vlSelf->wasmetal_core__DOT___006435_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048083_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6d7fd34d__0))))));
    vlSelf->wasmetal_core__DOT___006444_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023225_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048082_)))));
    vlSelf->wasmetal_core__DOT___035783_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048083_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048082_))));
    vlSelf->wasmetal_core__DOT___006429_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023221_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048221_)))));
    vlSelf->wasmetal_core__DOT___006434_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048220_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h445a0824__0))))));
    vlSelf->wasmetal_core__DOT___035781_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048221_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048220_))));
    vlSelf->wasmetal_core__DOT___006423_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023219_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048248_)))));
    vlSelf->wasmetal_core__DOT___006428_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048247_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd90860df__0))))));
    vlSelf->wasmetal_core__DOT___035780_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048248_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048247_))));
    vlSelf->wasmetal_core__DOT___006419_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048216_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbec5a32d__0))))));
    vlSelf->wasmetal_core__DOT___006422_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048215_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hbedf9838__0))))));
    vlSelf->wasmetal_core__DOT___035779_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048216_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048215_))));
    vlSelf->wasmetal_core__DOT___006384_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023215_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048932_)))));
    vlSelf->wasmetal_core__DOT___006418_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048933_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hcdb7900c__0))))));
    vlSelf->wasmetal_core__DOT___035778_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048933_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048932_))));
    vlSelf->wasmetal_core__DOT___006380_ = (1U & (0x33aaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048100_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4caf4ac4__0))))));
    vlSelf->wasmetal_core__DOT___006383_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023214_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___048099_)))));
    vlSelf->wasmetal_core__DOT___035777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048100_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048099_))));
    vlSelf->wasmetal_core__DOT___006372_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___023210_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048079_)))));
    wasmetal_core__DOT___006379_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048078_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h454147c9__0))))));
    vlSelf->wasmetal_core__DOT___035776_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048078_))));
    wasmetal_core__DOT___006368_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))))));
    wasmetal_core__DOT___006371_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023209_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048097_)))));
    vlSelf->wasmetal_core__DOT___035775_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048097_))));
    wasmetal_core__DOT___006356_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048087_)))));
    wasmetal_core__DOT___006367_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048086_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))))));
    vlSelf->wasmetal_core__DOT___035774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048086_))));
    wasmetal_core__DOT___006355_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048168_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))))));
    vlSelf->wasmetal_core__DOT___035773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006352_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048168_))));
    wasmetal_core__DOT___006346_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048201_)))));
    vlSelf->wasmetal_core__DOT___035772_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006343_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048201_))));
    vlSelf->wasmetal_core__DOT___035798_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006340_))));
    wasmetal_core__DOT___006327_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048202_)))));
    vlSelf->wasmetal_core__DOT___035797_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006319_))));
    vlSelf->wasmetal_core__DOT___035796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006316_))));
    vlSelf->wasmetal_core__DOT___035795_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006306_))));
    wasmetal_core__DOT___006293_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023192_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048077_)))));
    vlSelf->wasmetal_core__DOT___035794_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006290_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048077_))));
    wasmetal_core__DOT___006286_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048076_)))));
    vlSelf->wasmetal_core__DOT___035793_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048076_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006277_))));
    wasmetal_core__DOT___006261_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048214_)))));
    wasmetal_core__DOT___006269_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023187_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048213_)))));
    wasmetal_core__DOT___035792_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048214_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048213_))));
    wasmetal_core__DOT___006252_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023184_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048246_)))));
    vlSelf->wasmetal_core__DOT___035791_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048246_))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035384_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h04659776__0))));
    wasmetal_core__DOT___006489_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048943_)))));
    wasmetal_core__DOT___006190_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048683_)))));
    if (vlSelf->wasmetal_core__DOT___006127_) {
        wasmetal_core__DOT___006347_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))))));
        wasmetal_core__DOT___006337_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h13911493__0))))));
        wasmetal_core__DOT___006328_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))))));
        wasmetal_core__DOT___006336_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))))));
        wasmetal_core__DOT___006313_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))))));
        wasmetal_core__DOT___006303_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))))));
        wasmetal_core__DOT___006312_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))))));
        wasmetal_core__DOT___006294_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0283b263__0))))));
        wasmetal_core__DOT___006302_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))))));
        wasmetal_core__DOT___006287_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))))));
        wasmetal_core__DOT___006270_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))))));
        wasmetal_core__DOT___006260_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))))));
        wasmetal_core__DOT___006251_ = (1U & (0xf0f0077U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_he55adf41__0))))));
        wasmetal_core__DOT___006195_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h21922827__0))))));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006479_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006478_)))))))));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006478_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006475_)))))))));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006475_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006474_)))))))));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006474_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006469_)))))))));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006469_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006468_)))))))));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006468_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006463_)))))))));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006463_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006462_)))))))));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006457_)))))))));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006457_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006456_)))))))));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006456_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006451_)))))))));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006451_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006450_)))))))));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006450_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006445_)))))))));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006445_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006444_)))))))));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006444_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006435_)))))))));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006435_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006434_)))))))));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006434_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006429_)))))))));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006429_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006428_)))))))));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006428_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006423_)))))))));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006423_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006422_)))))))));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006422_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006419_)))))))));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006419_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006418_)))))))));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006384_)))))))));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006384_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006383_)))))))));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006383_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006380_)))))))));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006380_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006379_)))))))));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006379_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006372_)))))))));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006372_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006371_)))))))));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006371_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006368_)))))))));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006368_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006367_)))))))));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006367_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006356_)))))))));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006356_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006355_)))))))));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006355_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006347_)))))))));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006347_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006346_)))))))));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006346_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006337_)))))))));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006337_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006336_)))))))));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006336_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006328_)))))))));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006328_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006327_)))))))));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006327_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006313_)))))))));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006313_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006312_)))))))));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006312_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006303_)))))))));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006303_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006302_)))))))));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006302_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006294_)))))))));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006294_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006293_)))))))));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006293_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006287_)))))))));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006287_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006286_)))))))));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006286_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006270_)))))))));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006270_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006269_)))))))));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006269_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006261_)))))))));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006261_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006260_)))))))));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006260_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006252_)))))))));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006252_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006251_)))))))));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006190_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006489_)))))))));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006195_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006190_)))))))));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006251_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006195_)))))))));
    } else {
        wasmetal_core__DOT___006347_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006352_)));
        wasmetal_core__DOT___006337_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006343_)));
        wasmetal_core__DOT___006328_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006333_)));
        wasmetal_core__DOT___006336_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006340_)));
        wasmetal_core__DOT___006313_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006319_)));
        wasmetal_core__DOT___006303_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006309_)));
        wasmetal_core__DOT___006312_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006316_)));
        wasmetal_core__DOT___006294_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006299_)));
        wasmetal_core__DOT___006302_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006306_)));
        wasmetal_core__DOT___006287_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006290_)));
        wasmetal_core__DOT___006270_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006277_)));
        wasmetal_core__DOT___006260_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006264_)));
        wasmetal_core__DOT___006251_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006255_)));
        wasmetal_core__DOT___006195_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006246_)));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006478_)));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006475_)));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006474_)));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006469_)));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006468_)));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006463_)));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006462_)));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006457_)));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006456_)));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006451_)));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006450_)));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006445_)));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006444_)));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006435_)));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006434_)));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006429_)));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006428_)));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006423_)));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006422_)));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006419_)));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006418_)));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006384_)));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006383_)));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006380_)));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006379_)));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006372_)));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006371_)));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006368_)));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006367_)));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006356_)));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006355_)));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006347_)));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006346_)));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006337_)));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006336_)));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006328_)));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006327_)));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006313_)));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006312_)));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006303_)));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006302_)));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006294_)));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006293_)));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006287_)));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006286_)));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006270_)));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006269_)));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006261_)));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006260_)));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006252_)));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006251_)));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006489_)));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006190_)));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006195_)));
    }
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d 
        = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___048943_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048683_))));
    vlSelf->wasmetal_core__DOT___035782_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006246_))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035385_)
                  ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0))));
    vlSelf->__VdfgTmp_hf3b81358__0 = (((IData)(wasmetal_core__DOT___006489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050073_));
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035782_));
    vlSelf->__VdfgTmp_hb69d909d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006568_));
    vlSelf->__VdfgTmp_h46e4da0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006615_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006614_));
    vlSelf->__VdfgTmp_hc1f8ef63__0 = (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_));
    vlSelf->__VdfgTmp_he99783ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_));
    vlSelf->__VdfgTmp_h8be5cf2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006554_));
    vlSelf->__VdfgTmp_ha20d2c5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006440_));
    vlSelf->__VdfgTmp_h45e8af23__0 = (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006281_));
    vlSelf->__VdfgTmp_h19cea986__0 = (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006501_));
    vlSelf->__VdfgTmp_hc8c3f180__0 = (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006282_));
    vlSelf->__VdfgTmp_h8170b1e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006502_));
    vlSelf->__VdfgTmp_h980f95b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006283_));
    vlSelf->__VdfgTmp_h088d475b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006503_));
    vlSelf->__VdfgTmp_ha3862ccc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005691_));
    vlSelf->__VdfgTmp_hfc403f7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006484_));
    wasmetal_core__DOT___035332_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035386_)
                                           ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_heb875033__0))));
    wasmetal_core__DOT____Vcellout___128732___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035386_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035385_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035384_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035383_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035328_)))));
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035791_) 
           & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_ha576ac17__0 = (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    vlSelf->__VdfgTmp_h455b45b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    vlSelf->__VdfgTmp_hd481047b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h1c3d35c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf5c220e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf7faa60c__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_ha523ac5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & (((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               ^ (IData)(wasmetal_core__DOT___035332_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128781___O 
        = ((((IData)(wasmetal_core__DOT___035792_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                   << 1U) | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035821_ = ((IData)(wasmetal_core__DOT___035792_) 
                                            & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___048226_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                       >> 2U)) 
                                                   | (IData)(wasmetal_core__DOT___035792_))));
    vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035793_) 
           & (IData)(vlSelf->wasmetal_core__DOT___035821_));
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035794_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035795_) 
           & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128782___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035794_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035793_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035821_)))));
    wasmetal_core__DOT___035825_ = ((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                    & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048081_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128782___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035794_))));
    wasmetal_core__DOT___048096_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035796_))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035797_) 
           & (IData)(wasmetal_core__DOT___035825_));
    wasmetal_core__DOT___048107_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035798_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035772_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128783___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035798_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035797_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035825_)))));
    wasmetal_core__DOT___035801_ = ((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                    & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048219_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128783___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035798_))));
    wasmetal_core__DOT___048218_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035773_))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035774_) 
           & (IData)(wasmetal_core__DOT___035801_));
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035775_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035776_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128784___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035776_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035775_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035774_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035801_)))));
    wasmetal_core__DOT___035805_ = ((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                    & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048095_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035774_))));
    wasmetal_core__DOT___048080_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035776_))));
    wasmetal_core__DOT___048102_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128784___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035775_))));
    wasmetal_core__DOT___048101_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035777_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035778_) 
           & (IData)(wasmetal_core__DOT___035805_));
    wasmetal_core__DOT___048939_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048102_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048095_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048219_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035797_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128783___O))))))));
    wasmetal_core__DOT___048253_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048218_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048080_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048101_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___048106_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048102_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048101_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035779_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035780_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128785___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035779_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035778_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035805_)))));
    wasmetal_core__DOT___035809_ = ((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                    & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048217_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128785___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035779_))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035783_) 
           & (IData)(wasmetal_core__DOT___035809_));
    wasmetal_core__DOT___048228_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___048106_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___048096_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048219_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048218_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048217_)))))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035784_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035785_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128786___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035783_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035809_)))));
    wasmetal_core__DOT___035814_ = ((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                    & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048103_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035783_))));
    wasmetal_core__DOT___048094_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035785_))));
    wasmetal_core__DOT___048093_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128786___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035784_))));
    wasmetal_core__DOT___048092_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035786_))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035787_) 
           & (IData)(wasmetal_core__DOT___035814_));
    wasmetal_core__DOT___048105_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048095_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048094_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048093_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048092_))))));
    wasmetal_core__DOT___048225_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035788_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035789_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT____Vcellout___128787___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___035790_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128787___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035790_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035789_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035788_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035787_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___035814_)));
    wasmetal_core__DOT___048162_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048107_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048106_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048105_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___048081_) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___048080_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___035793_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(wasmetal_core__DOT____Vcellout___128782___O)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                                   >> 2U)) 
                                                               | (IData)(wasmetal_core__DOT___048103_)))))))));
    wasmetal_core__DOT___048936_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035787_))));
    wasmetal_core__DOT___048251_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035789_))));
    wasmetal_core__DOT___048224_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128787___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035788_))));
    wasmetal_core__DOT___071843_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035790_))));
    vlSelf->wasmetal_core__DOT___005697_ = (1U & (IData)(
                                                         (0x80008000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___048162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048160_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048159_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048158_)))))))));
    wasmetal_core__DOT___035706_ = (1U & (0x4bU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035681_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048162_)))));
    wasmetal_core__DOT___048252_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048251_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___048094_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                               >> 2U)))))));
    wasmetal_core__DOT___048940_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048939_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048253_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128787___CO)) 
                                                         | (((IData)(wasmetal_core__DOT___048251_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___048224_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___048936_)))))))));
    wasmetal_core__DOT___048227_ = (1U & (0x10U >> 
                                          (((IData)(wasmetal_core__DOT___048225_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___048093_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048224_)))));
    wasmetal_core__DOT___048254_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___048253_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048252_))));
    vlSelf->wasmetal_core__DOT___007130_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048940_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006408_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006407_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfdd5af20__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035707_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035682_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048938_ = (1U & (0x80U >> 
                                          (((IData)(wasmetal_core__DOT___048252_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xdULL 
                                                         >> 
                                                         ((0x20U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                              << 2U)) 
                                                          | (((IData)(wasmetal_core__DOT___048936_) 
                                                              << 4U) 
                                                             | (((IData)(wasmetal_core__DOT___048103_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___048217_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035778_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(wasmetal_core__DOT____Vcellout___128785___O))))))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___048227_)))));
    wasmetal_core__DOT___048229_ = (1U & (IData)((0xd000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048228_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048227_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048081_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___048255_ = (1U & (IData)((0xd00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048225_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048254_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048107_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___007129_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048938_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & (IData)(
                                                            (0x80000000ffffffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006392_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h35bc9263__0)) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006192_))))))))));
    vlSelf->wasmetal_core__DOT___035708_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035683_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048938_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___005696_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048229_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006125_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006124_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006123_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006122_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006121_)))))))))));
    wasmetal_core__DOT___035704_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035679_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048229_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048268_ = (1U & (IData)((0xaf3f0f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048255_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h834dc827__0))))))));
    wasmetal_core__DOT___035705_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035680_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048255_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___058404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058403_)))));
    vlSelf->wasmetal_core__DOT___058382_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058380_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    vlSelf->wasmetal_core__DOT___058381_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005693_)))));
    wasmetal_core__DOT___058379_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0))));
    vlSelf->wasmetal_core__DOT___058374_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h088d475b__0))));
    vlSelf->__VdfgTmp_h2d64090c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h980f95b2__0));
    vlSelf->wasmetal_core__DOT___058373_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006485_)))));
    vlSelf->wasmetal_core__DOT___058372_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hefac2d69__0))))));
    vlSelf->wasmetal_core__DOT___050074_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005692_)))));
    vlSelf->wasmetal_core__DOT___050075_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    wasmetal_core__DOT___015115_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_he99783ec__0))));
    __VdfgTmp_hb49f8759__0 = ((2U & ((0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006615_)))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
    __VdfgTmp_hc24ed5a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    __VdfgTmp_h32160e17__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035704_) ? (IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035679_));
    vlSelf->wasmetal_core__DOT___005695_ = (1U & (IData)(
                                                         (0x8000ffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___048268_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048267_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048266_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048265_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048264_)))))))));
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035705_) ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035680_));
    vlSelf->wasmetal_core__DOT___058561_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xccaaf0f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___015115_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___058420_ = (1U & (IData)(
                                                         (0x7777f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058412_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058408_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058379_)))));
    wasmetal_core__DOT___058393_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))));
    vlSelf->wasmetal_core__DOT___058384_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058379_))));
    wasmetal_core__DOT___050077_ = ((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                    & (IData)((0xff00ccccf0f0aaaaULL 
                                               >> (
                                                   (0x20U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006598_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))));
    vlSelf->wasmetal_core__DOT___058376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058373_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058372_)))));
    __VdfgTmp_h1785588f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))));
    __VdfgTmp_h2242a82b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006486_))))));
    vlSelf->wasmetal_core__DOT___015107_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0xfaa330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___015115_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___014966_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0x3500000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_hc24ed5a6__0)))))));
    vlSelf->wasmetal_core__DOT___015076_ = ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                            & (IData)(
                                                      (0x3355f0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x3a00U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h32160e17__0))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))))))));
    vlSelf->wasmetal_core__DOT___058073_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h19cea986__0))))))));
    vlSelf->wasmetal_core__DOT___014540_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006500_)))))))));
    vlSelf->wasmetal_core__DOT___014526_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006280_)))))))));
    vlSelf->wasmetal_core__DOT___014498_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006325_)))))))));
    vlSelf->wasmetal_core__DOT___014484_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006516_)))))))));
    vlSelf->wasmetal_core__DOT___009486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006323_)))))))));
    vlSelf->wasmetal_core__DOT___014464_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006515_)))))))));
    vlSelf->wasmetal_core__DOT___007166_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006530_)))))))));
    vlSelf->wasmetal_core__DOT___007156_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006364_)))))))));
    vlSelf->wasmetal_core__DOT___007146_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006529_)))))))));
    vlSelf->wasmetal_core__DOT___007136_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006363_)))))))));
    vlSelf->wasmetal_core__DOT___014573_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))));
    vlSelf->wasmetal_core__DOT___006284_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006280_))))));
    vlSelf->wasmetal_core__DOT___014570_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006325_))))));
    vlSelf->wasmetal_core__DOT___014514_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006544_)))))))));
    vlSelf->wasmetal_core__DOT___014502_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006416_)))))))));
    vlSelf->wasmetal_core__DOT___014488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006543_)))))))));
    vlSelf->wasmetal_core__DOT___014476_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006415_)))))))));
    vlSelf->wasmetal_core__DOT___009488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006414_)))))))));
    vlSelf->wasmetal_core__DOT___014466_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006542_)))))))));
    vlSelf->wasmetal_core__DOT___014487_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb69d909d__0))))));
    vlSelf->wasmetal_core__DOT___014486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))));
    vlSelf->wasmetal_core__DOT___014528_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006361_)))))))));
    vlSelf->wasmetal_core__DOT___007124_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006528_)))))))));
    vlSelf->wasmetal_core__DOT___014567_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006516_))))));
    vlSelf->wasmetal_core__DOT___014542_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006527_)))))))));
    vlSelf->wasmetal_core__DOT___014558_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006362_)))))))));
    vlSelf->wasmetal_core__DOT___006609_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))));
    wasmetal_core__DOT___014553_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006515_))))));
    wasmetal_core__DOT___014525_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006514_))))));
    wasmetal_core__DOT___014511_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006322_))))));
    wasmetal_core__DOT___014497_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006530_))))));
    wasmetal_core__DOT___014483_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006364_))))));
    wasmetal_core__DOT___014473_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006529_))))));
    wasmetal_core__DOT___009495_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006363_))))));
    wasmetal_core__DOT___006608_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006323_))))));
    vlSelf->wasmetal_core__DOT___006504_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006500_))))));
    vlSelf->wasmetal_core__DOT___009490_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___007168_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006557_)))))))));
    vlSelf->wasmetal_core__DOT___007179_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006413_)))))))));
    vlSelf->wasmetal_core__DOT___007160_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hc24ed5a6__0)))));
    vlSelf->wasmetal_core__DOT___007158_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006441_)))))))));
    vlSelf->wasmetal_core__DOT___007148_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006556_)))))))));
    vlSelf->wasmetal_core__DOT___007138_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))))));
    vlSelf->wasmetal_core__DOT___014517_ = (1U & (IData)(
                                                         (0xf00aa00330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    vlSelf->wasmetal_core__DOT___014516_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006571_)))))))));
    wasmetal_core__DOT___014501_ = (1U & (0x3050000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0))))));
    wasmetal_core__DOT___014500_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006616_)))))))));
    vlSelf->wasmetal_core__DOT___014531_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___014530_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he99783ec__0))))))));
    vlSelf->wasmetal_core__DOT___007126_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006555_)))))))));
    vlSelf->wasmetal_core__DOT___014544_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))))))));
    vlSelf->wasmetal_core__DOT___014556_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006439_)))))))));
    wasmetal_core__DOT___006366_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006362_))))));
    vlSelf->wasmetal_core__DOT___007128_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006568_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005697_))))));
    vlSelf->wasmetal_core__DOT___007186_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006541_)))))))));
    vlSelf->wasmetal_core__DOT___007170_ = (1U & (IData)(
                                                         (0xfaa330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    __VdfgTmp_h00a84c57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                          << 3U) | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)));
    vlSelf->wasmetal_core__DOT___007150_ = (1U & (0x3a000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h32160e17__0)))));
    vlSelf->wasmetal_core__DOT___007140_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
    wasmetal_core__DOT___006532_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006528_))))));
    wasmetal_core__DOT___006365_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006361_))))));
    wasmetal_core__DOT___007155_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006544_))))));
    wasmetal_core__DOT___007145_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006416_))))));
    wasmetal_core__DOT___006572_ = (1U & (IData)((0xff33330f0faaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    wasmetal_core__DOT___007109_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006557_))))));
    wasmetal_core__DOT___007100_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006441_))))));
    wasmetal_core__DOT___007091_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006556_))))));
    wasmetal_core__DOT___007087_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006440_))))));
    wasmetal_core__DOT___007135_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006543_))))));
    wasmetal_core__DOT___006612_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006415_))))));
    wasmetal_core__DOT___007113_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006413_))))));
    wasmetal_core__DOT___007117_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006541_))))));
    wasmetal_core__DOT___006611_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006414_))))));
    wasmetal_core__DOT___007123_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006542_))))));
    wasmetal_core__DOT___006531_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006527_))))));
    wasmetal_core__DOT___006443_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006439_))))));
    vlSelf->wasmetal_core__DOT___006559_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006555_))))));
    wasmetal_core__DOT___006442_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006438_))))));
    vlSelf->wasmetal_core__DOT___007078_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006571_))))));
    wasmetal_core__DOT___007075_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006616_))))));
    wasmetal_core__DOT___007072_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006570_))))));
    wasmetal_core__DOT___006618_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006615_))))));
    wasmetal_core__DOT___007069_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006569_))))));
    vlSelf->wasmetal_core__DOT___006558_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006554_))))));
    if (vlSelf->wasmetal_core__DOT___005696_) {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xc5U >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006568_)))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006616_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006281_))))));
        vlSelf->wasmetal_core__DOT___058072_ = vlSelf->wasmetal_core__DOT___014567_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014497_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___006608_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006501_))))));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___009495_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___006365_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___006531_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___014467_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007149_ = vlSelf->wasmetal_core__DOT___007078_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (IData)(wasmetal_core__DOT___006618_));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (IData)(wasmetal_core__DOT___007069_));
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___006558_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006559_;
    } else {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006571_))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006615_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006569_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006284_));
        vlSelf->wasmetal_core__DOT___058072_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014525_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014483_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006504_));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___006366_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___006532_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___014467_ = vlSelf->wasmetal_core__DOT___006559_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___007149_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___006618_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007069_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (0x30aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006568_))))));
        wasmetal_core__DOT___007169_ = vlSelf->wasmetal_core__DOT___007078_;
        wasmetal_core__DOT___007185_ = vlSelf->wasmetal_core__DOT___006558_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128771___O 
        = ((((IData)(wasmetal_core__DOT___035706_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035705_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035704_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035701_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035694_ = ((IData)(wasmetal_core__DOT___035706_)
                                             ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___035681_));
    vlSelf->wasmetal_core__DOT___050081_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050077_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006604_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006602_)))))
                                                                          : 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006603_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006601_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050074_)))))))));
    vlSelf->wasmetal_core__DOT___058417_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5300U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058403_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058412_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058394_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058393_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0fccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->__VdfgTmp_hf7593d1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0))))));
    vlSelf->__VdfgTmp_h1a5afed0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0))))));
    vlSelf->__VdfgTmp_h00939515__0 = (((IData)(vlSelf->wasmetal_core__DOT___014487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014486_));
    vlSelf->__VdfgTmp_h9f75ffc3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014525_)
                                         : (IData)(wasmetal_core__DOT___014497_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))))))));
    vlSelf->__VdfgTmp_ha7c43d57__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014483_)
                                         : (IData)(wasmetal_core__DOT___009495_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))))))));
    vlSelf->__VdfgTmp_he4917e71__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___006609_)
                                         : (IData)(wasmetal_core__DOT___006608_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))))))));
    vlSelf->wasmetal_core__DOT___015194_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009490_)))));
    vlSelf->wasmetal_core__DOT___015030_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014468_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014517_))))));
    vlSelf->__VdfgTmp_h2165c3f7__0 = (((IData)(wasmetal_core__DOT___014501_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014500_));
    vlSelf->__VdfgTmp_he4fae0fa__0 = (((IData)(wasmetal_core__DOT___014500_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014501_));
    vlSelf->__VdfgTmp_h4a9651b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014531_));
    vlSelf->wasmetal_core__DOT___014878_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007128_)))));
    vlSelf->wasmetal_core__DOT___015070_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0))))));
    vlSelf->wasmetal_core__DOT___007180_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0)))));
    vlSelf->wasmetal_core__DOT___014949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007150_))));
    vlSelf->wasmetal_core__DOT___014979_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007140_)))));
    vlSelf->__VdfgTmp_h99d13f88__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006322_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006366_)
                                                  : (IData)(wasmetal_core__DOT___006365_)));
    vlSelf->wasmetal_core__DOT___058134_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(wasmetal_core__DOT___006572_)));
    vlSelf->wasmetal_core__DOT___007187_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(wasmetal_core__DOT___006572_));
    vlSelf->__VdfgTmp_h3016d5c6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006514_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006532_)
                                                  : (IData)(wasmetal_core__DOT___006531_)));
    vlSelf->wasmetal_core__DOT___058098_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O))))))));
    vlSelf->wasmetal_core__DOT___058095_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b3__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b2__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134179___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128771___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035707_)
            ? (IData)(vlSelf->wasmetal_core__DOT___035694_)
            : (IData)(vlSelf->wasmetal_core__DOT___035682_));
    vlSelf->wasmetal_core__DOT___058423_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h00939515__0)))))));
    wasmetal_core__DOT___058422_ = (1U & (IData)((0xff00f0f011111111ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058420_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058072_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058073_)))))))));
    vlSelf->wasmetal_core__DOT___058418_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014540_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014541_)))));
    vlSelf->wasmetal_core__DOT___058395_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014485_)))));
    vlSelf->__VdfgTmp_h3f743267__0 = (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0x33330f270f0f331bULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0)))
                                                     : (IData)(
                                                               (0xf0f331b33330f27ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbff92af3__0))))));
    vlSelf->__VdfgTmp_h210df1ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h15de5b2d__0))))));
    vlSelf->__VdfgTmp_h1e28f3c0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_haaae3cf9__0))))));
    vlSelf->wasmetal_core__DOT___015094_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0)))));
    vlSelf->wasmetal_core__DOT___014632_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048942_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99d13f88__0))))))));
    vlSelf->wasmetal_core__DOT___014659_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007156_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980f95b2__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006284_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014570_))))))))));
    wasmetal_core__DOT___059229_ = (1U & (IData)((0x1ffULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015194_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015070_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014949_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058134_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___007170_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014488_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014486_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014487_)))))))));
    __VdfgTmp_h38f8e813__0 = (((IData)(vlSelf->wasmetal_core__DOT___014489_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014488_));
    wasmetal_core__DOT___015117_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014476_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014477_))))));
    vlSelf->wasmetal_core__DOT___014827_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007146_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014573_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014567_))))))))));
    vlSelf->wasmetal_core__DOT___014757_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007136_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___014570_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___006609_))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0xf1111U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014498_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014499_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf0f335500000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xccaaf0f0U 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058380_)))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014502_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_he4fae0fa__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014514_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014515_)))))))));
    __VdfgTmp_h4954f743__0 = (((IData)(vlSelf->wasmetal_core__DOT___014515_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014514_));
    if (vlSelf->wasmetal_core__DOT___007129_) {
        if (vlSelf->wasmetal_core__DOT___007130_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014499_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014498_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014484_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014503_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014502_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014558_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
                = (1U & (0xeU >> (IData)(__VdfgTmp_h38f8e813__0)));
        }
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (0x33550f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 << 3U) 
                                                | ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058372_)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058374_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___058373_)))))))))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h2165c3f7__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014557_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014556_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                     & (0xeU >> (IData)(vlSelf->__VdfgTmp_h00939515__0))));
        vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d 
            = (1U & (1U >> (1U & (0x1111000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h4954f743__0))))))));
    }
    __VdfgTmp_h06108119__0 = (((IData)(vlSelf->wasmetal_core__DOT___014528_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014529_));
    vlSelf->wasmetal_core__DOT___014792_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007124_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058073_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058072_)))))))));
    __VdfgTmp_h1c23bbd1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007124_));
    __VdfgTmp_h57c36911__0 = (((IData)(vlSelf->wasmetal_core__DOT___014543_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014542_));
    vlSelf->wasmetal_core__DOT___014746_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007166_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                         & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h088d475b__0)))))))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                                           ? (IData)(vlSelf->wasmetal_core__DOT___006504_)
                                                                           : (IData)(vlSelf->wasmetal_core__DOT___014573_))))))))));
    vlSelf->wasmetal_core__DOT___014602_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048945_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                      & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))))))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((0x110fU 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009489_))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009486_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___009487_)))) 
                                                  << 1U)) 
                                           | (1U & 
                                              (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (IData)(
                                                             (0xff00f0f011111111ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050074_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0x3500U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2d64090c__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009488_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___009490_)))))));
    wasmetal_core__DOT___015154_ = (1U & (0x11f0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014466_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___014467_))))));
    vlSelf->wasmetal_core__DOT___014631_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007178_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007180_)))))));
    __VdfgTmp_h3be775f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007179_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007178_));
    __VdfgTmp_h385c50c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007158_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007160_)));
    __VdfgTmp_h3a48ed75__0 = (((IData)(vlSelf->wasmetal_core__DOT___007148_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007150_)));
    vlSelf->__VdfgTmp_hce3e66a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___007139_)))))));
    vlSelf->wasmetal_core__DOT___014756_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007138_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007140_)))))));
    __VdfgTmp_h13ac9eb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014556_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014557_));
    __VdfgTmp_h35fc6168__0 = (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007126_));
    if (vlSelf->wasmetal_core__DOT___007130_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___014478_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0)))));
        if (vlSelf->wasmetal_core__DOT___007129_) {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014527_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014526_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h9f75ffc3__0)));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014541_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014540_))));
        } else {
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014530_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014517_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014516_))));
            vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
                = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014544_))));
        }
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009490_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___009487_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___009486_))))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014468_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014465_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014464_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007160_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007157_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007156_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007150_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007147_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007146_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007140_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007137_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007136_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007170_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___007167_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007166_))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007187_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h3016d5c6__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                             << 2U) 
                                            | (IData)(vlSelf->__VdfgTmp_h99d13f88__0)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xeef0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007128_) 
                                             << 2U) 
                                            | (IData)(__VdfgTmp_h1c23bbd1__0)))));
    } else {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___014477_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014476_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014529_) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014528_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009489_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009488_)))));
        vlSelf->wasmetal_core__DOT___014712_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014467_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014466_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007159_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007158_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007149_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007148_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007139_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007138_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007168_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___007185_)))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h4954f743__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d 
            = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                     & (0xeU >> (IData)(__VdfgTmp_h57c36911__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h3be775f9__0))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d 
            = (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                << 2U) | (IData)(__VdfgTmp_h35fc6168__0))));
    }
    __VdfgTmp_hf115889b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007126_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007127_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007128_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014545_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___014542_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___014543_)))))))));
    __VdfgTmp_h7fda4de5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007168_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007169_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007170_)));
    __VdfgTmp_h859eb527__0 = (((IData)(vlSelf->wasmetal_core__DOT___007186_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___007185_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007187_)));
    vlSelf->__VdfgTmp_h2ddde49a__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058098_));
    vlSelf->__VdfgTmp_hf4c0ee7d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->__VdfgTmp_h283c0448__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->__VdfgTmp_h187f5418__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058095_));
    vlSelf->wasmetal_core__DOT___058096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035708_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035683_));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d));
    vlSelf->__VdfgTmp_h39f326f7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbca0145a__0))))));
    vlSelf->__VdfgTmp_h375bf609__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h493bd629__0))))));
    vlSelf->wasmetal_core__DOT___059231_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059229_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014966_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015030_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014979_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014878_)))))))));
    vlSelf->wasmetal_core__DOT___058396_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h00939515__0)) 
                                                          << 2U)) 
                                                      | (IData)(__VdfgTmp_h38f8e813__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d 
        = (1U & (IData)((0xf0feeee00ff00ffULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                   << 5U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 4U) 
                                                     | (((IData)(wasmetal_core__DOT___015117_) 
                                                         << 3U) 
                                                        | ((4U 
                                                            & ((IData)(
                                                                       (0xccccaaaa000f000fULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058384_) 
                                                                                << 3U) 
                                                                               | ((4U 
                                                                                & ((0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc8c3f180__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058382_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058381_)))))))) 
                                                               << 2U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha7c43d57__0))))))));
    vlSelf->__VdfgTmp_hb48763c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015117_));
    vlSelf->__VdfgTmp_h22db4e96__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h13456aa5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | ((4U & ((1U 
                                                >> 
                                                ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h4a9651b8__0))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xe0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h06108119__0)))))) 
                                               << 2U)) 
                                        | ((2U & ((0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014526_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___014527_)))) 
                                                  << 1U)) 
                                           | (1U & (IData)(
                                                           (0xf1f100ff00000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058408_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xccaa0f0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0x7fff0000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058397_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___058382_))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d 
        = (1U & (IData)((0xeeee0000fff00000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014531_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h06108119__0))))))));
    vlSelf->wasmetal_core__DOT___058419_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014545_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014544_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h57c36911__0))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d));
    vlSelf->__VdfgTmp_hd148b96b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014712_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h783c16d6__0))))));
    vlSelf->__VdfgTmp_hf41b4843__0 = (((IData)(wasmetal_core__DOT___015154_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___014464_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014465_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff4f400000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058376_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0x305U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h19cea986__0)))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___058374_)))))))))));
    vlSelf->__VdfgTmp_h52595424__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015154_));
    vlSelf->__VdfgTmp_h7bf425d4__0 = (((IData)(vlSelf->wasmetal_core__DOT___014631_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014632_));
    vlSelf->__VdfgTmp_hc1e22c7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                       << 1U) | (1U 
                                                 & (0x110fU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007180_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h3be775f9__0))))));
    vlSelf->__VdfgTmp_h7328e0ec__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcdd8cada__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->wasmetal_core__DOT___014658_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h385c50c6__0)))));
    vlSelf->__VdfgTmp_he7d53082__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h152c16b5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT___014826_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h3a48ed75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014756_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014757_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d 
        = (1U & (IData)((0xff0f0feeeeeeeeULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050081_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_he4917e71__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xeU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                    << 2U) 
                                                                   | (IData)(__VdfgTmp_h13ac9eb3__0))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xe0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___014559_)))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (IData)(__VdfgTmp_h13ac9eb3__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d 
        = (1U & (IData)((0xfff00000eeee0000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014559_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014558_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_h13ac9eb3__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d 
        = (1U & (IData)((0xff00ffeeee0f0fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                  << 5U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                     << 4U) 
                                                    | (((IData)(wasmetal_core__DOT___058422_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((1U 
                                                               >> (IData)(__VdfgTmp_h35fc6168__0)) 
                                                              << 2U)) 
                                                          | (IData)(__VdfgTmp_h1c23bbd1__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->wasmetal_core__DOT___014791_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hf115889b__0)))));
    vlSelf->__VdfgTmp_h8020f35b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hd6af8d62__0))))));
    vlSelf->__VdfgTmp_h5b0d2f75__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc3641189__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->wasmetal_core__DOT___014745_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7fda4de5__0)))));
    vlSelf->__VdfgTmp_h023f0a12__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h6673ab20__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d 
        = (1U & (0xfcaa0000U >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                             << 3U) 
                                            | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___014601_ = (1U & (0xfc00aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h859eb527__0)))));
    vlSelf->wasmetal_core__DOT___058107_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))));
    vlSelf->__VdfgTmp_hc2843286__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h6a8cbae2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))));
    vlSelf->__VdfgTmp_h8e2d1d0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h283c0448__0));
    vlSelf->__VdfgTmp_h9949a0e3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h187f5418__0))));
    vlSelf->wasmetal_core__DOT___058106_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058098_))));
    vlSelf->__VdfgTmp_hb1419641__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h187f5418__0));
    vlSelf->__VdfgTmp_h786a2bba__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058096_));
    vlSelf->wasmetal_core__DOT___058099_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058096_))));
    vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035709_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035709_))));
    vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058395_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058394_))))));
    vlSelf->__VdfgTmp_h7410d216__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h05032e00__0))))));
    vlSelf->__VdfgTmp_h3c2f1975__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc1ac3ed9__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058417_))))));
    vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d 
        = (1U & (0xee0fU >> (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                              << 3U) | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))));
    vlSelf->__VdfgTmp_hcd6303e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc9bde5b5__0))))));
    vlSelf->wasmetal_core__DOT___058205_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7328e0ec__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014658_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014659_))));
    vlSelf->wasmetal_core__DOT___058207_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7d53082__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014826_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014827_))));
    vlSelf->wasmetal_core__DOT___059242_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (7U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))))));
}
