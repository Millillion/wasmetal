#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__29(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__29\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___040003_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___040002_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___040038_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___040037_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___040032_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___040031_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128720___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___040036_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___040035_ = (1U & (IData)(
                                                         (0xa2aea2a2a2a2a2a2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edividend__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___040034_ = (1U & (IData)(
                                                         (0xa2a2aeaeaea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___040033_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128721___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((7U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___039884_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039885_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039886_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039893_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039909_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034643_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039898_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039897_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039896_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039895_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039877_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034649_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039894_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034650_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039891_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039890_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039889_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039888_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039899_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039900_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039901_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034657_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039908_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034659_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039924_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034660_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039913_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034661_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039912_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034662_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039911_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039910_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039892_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034665_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039887_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039906_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034667_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039905_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034668_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039904_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039903_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039914_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039915_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034673_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___039916_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039923_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034675_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039940_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034676_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039928_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034677_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039927_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034678_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039926_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039925_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034681_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039907_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034682_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039902_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034683_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039921_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034684_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039920_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034685_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039919_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034686_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039918_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039929_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___039930_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___039931_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___039939_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034692_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___039955_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___039944_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d)))))));
    vlSelf->wasmetal_core__DOT___039943_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___053573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050448_))));
    vlSelf->wasmetal_core__DOT___050452_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050448_)))));
    vlSelf->wasmetal_core__DOT___063399_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063398_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063370_)))));
    vlSelf->wasmetal_core__DOT___063414_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053567_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9c6bfb0c__0))))))));
    vlSelf->wasmetal_core__DOT___053363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050365_))));
    vlSelf->wasmetal_core__DOT___053163_ = (1U & (0xb000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052906_))))));
    vlSelf->wasmetal_core__DOT___053440_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))));
    vlSelf->wasmetal_core__DOT___053248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___019787_ = (1U & (IData)(
                                                         (0x770f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053247_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)))))))))));
    vlSelf->wasmetal_core__DOT___002636_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002925_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002923_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002922_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002924_))))));
    vlSelf->wasmetal_core__DOT___055112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___062185_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055935_))));
    vlSelf->wasmetal_core__DOT___061221_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7e30f70e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061217_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8565eee7__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061260_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd96a7b90__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061155_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h93fbfa25__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061151_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ce8c3b1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061178_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haaeadd36__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061075_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h29bca591__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061070_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h34f2d08e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060985_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9cbd3d8a__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060981_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h31aacdc1__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061012_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68f6955f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060887_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3fcf358e__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060929_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1732b67__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060889_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb372eb0f__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060866_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h67f18e55__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___060852_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he43dd87d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060807_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7da5f58__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060779_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___019242_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h83053a2d__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019242_)))))))));
    vlSelf->wasmetal_core__DOT___060848_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he7f579a2__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___060717_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h69457925__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061322_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055935_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd8562240__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061329_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h567d9bb7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061307_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd3c93d4d__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___061303_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92b02c04__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___019282_ = ((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                            & (IData)(
                                                      (0xfffefff0ff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xac00U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hb23bd85a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___061332_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xac00U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2225d234__0)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019240_)))))))));
    vlSelf->wasmetal_core__DOT___055714_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055712_))));
    vlSelf->wasmetal_core__DOT___050493_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049867_))));
    vlSelf->wasmetal_core__DOT___049868_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049867_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051271_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050485_))));
    vlSelf->wasmetal_core__DOT___050487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050485_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049917_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049865_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___049944_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0))))));
    vlSelf->wasmetal_core__DOT___050484_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049924_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___049921_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1ac2f982__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___061252_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055928_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf0027c26__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001678_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001677_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd9c0d0dd__0)))))));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001901_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001900_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001899_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001898_))))))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002243_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h51461c8e__0))))));
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001950_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001949_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001948_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001947_))))))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002280_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85a07a94__0))))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002355_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002354_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002353_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002352_))))))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001995_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000155_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h91cc03bd__0))))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002198_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002197_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002196_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002195_))))))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001253_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001252_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001250_))))))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002078_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002077_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002076_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002075_))))))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002518_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002517_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002516_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002515_))))))));
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002433_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002432_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002431_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002430_))))))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001810_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001809_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001808_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001807_))))))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002040_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf699b114__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___000143_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001679_))));
        vlSelf->wasmetal_core__DOT___001797_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001902_))));
        vlSelf->wasmetal_core__DOT___002188_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002244_))));
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001951_))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002281_))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002356_))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001996_))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___000156_))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002199_))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001254_))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002079_))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002519_))));
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002434_))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001811_))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002041_))));
    }
    vlSelf->wasmetal_core__DOT___002472_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002595_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002593_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002592_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_))))));
    vlSelf->wasmetal_core__DOT___061170_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055917_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7ef390f7__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___002193_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002318_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002316_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002315_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_))))));
    vlSelf->wasmetal_core__DOT___061088_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ba8d2dd__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___055912_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055910_))));
    vlSelf->wasmetal_core__DOT___060999_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055903_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0cb45e24__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___060918_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055891_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7321d4d__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___061724_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055878_))));
    vlSelf->wasmetal_core__DOT___060833_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019205_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019202_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaccf0f000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055878_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2c8d302e__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___019201_)))))));
    vlSelf->wasmetal_core__DOT___049567_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049088_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049090_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049088_))));
    vlSelf->wasmetal_core__DOT___048979_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048977_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048977_))));
    vlSelf->wasmetal_core__DOT___062067_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062062_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae784e62__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007361_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007366_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061941_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007462_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054864_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28d1a2cd__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc04b3f0__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfcd73105__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062123_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___062118_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007489_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054999_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d11eb70__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007387_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061877_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061873_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007453_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054819_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h98124bc4__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007275_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05777dd7__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061990_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb6cab41b__0))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc5a57f40__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007341_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07c00df2__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061805_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061711_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3333555500ff0f0fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___061801_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xf0f0ccccff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6995c07d__0))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha1697357__0))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1275c5a__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019200_))));
    vlSelf->wasmetal_core__DOT___049564_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049106_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049107_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049106_))));
    vlSelf->wasmetal_core__DOT___048970_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048966_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049254_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048966_))));
    vlSelf->wasmetal_core__DOT___055201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055196_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___049565_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049105_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049108_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049105_))));
    vlSelf->wasmetal_core__DOT___048971_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048969_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049255_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048969_))));
    vlSelf->wasmetal_core__DOT___049554_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049102_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049102_))));
    vlSelf->wasmetal_core__DOT___048996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048995_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049256_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048995_))));
    vlSelf->wasmetal_core__DOT___049555_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049101_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049101_))));
    vlSelf->wasmetal_core__DOT___048997_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048992_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049257_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048992_))));
    vlSelf->wasmetal_core__DOT___049552_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049201_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049202_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049201_))));
    vlSelf->wasmetal_core__DOT___048988_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048987_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048987_))));
    vlSelf->wasmetal_core__DOT___049553_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049200_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049203_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049200_))));
    vlSelf->wasmetal_core__DOT___048989_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048984_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049306_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048984_))));
    vlSelf->wasmetal_core__DOT___049560_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049194_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049198_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049194_))));
    vlSelf->wasmetal_core__DOT___050506_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049303_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049301_))));
    vlSelf->wasmetal_core__DOT___049561_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049197_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049199_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049197_))));
    vlSelf->wasmetal_core__DOT___050507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049304_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049302_))));
    vlSelf->wasmetal_core__DOT___049558_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049184_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049188_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049184_))));
    vlSelf->wasmetal_core__DOT___050504_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049295_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049297_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049295_))));
    vlSelf->wasmetal_core__DOT___049559_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049187_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049189_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049187_))));
    vlSelf->wasmetal_core__DOT___050505_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049296_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049298_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049296_))));
    vlSelf->wasmetal_core__DOT___049570_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049179_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049179_))));
    vlSelf->wasmetal_core__DOT___050512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049292_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049293_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049292_))));
    vlSelf->wasmetal_core__DOT___049571_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049176_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049181_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049176_))));
    vlSelf->wasmetal_core__DOT___050513_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049291_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049294_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049291_))));
    vlSelf->wasmetal_core__DOT___059206_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051509_))));
    vlSelf->__VdfgTmp_h9e4ff193__0 = (((IData)(vlSelf->wasmetal_core__DOT___006972_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016296_));
    vlSelf->wasmetal_core__DOT___049573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049169_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049167_))));
    vlSelf->wasmetal_core__DOT___050511_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049315_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049318_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049315_))));
    vlSelf->wasmetal_core__DOT___063372_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063365_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063364_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063363_)))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028102_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 1U)));
    vlSelf->wasmetal_core__DOT___061929_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061919_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x555533330f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061912_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h883d5f24__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e79b823__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habef704b__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061916_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha87b9f86__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056447_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010182_)))));
    vlSelf->wasmetal_core__DOT___056931_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011658_)))));
    vlSelf->wasmetal_core__DOT___061868_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061849_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaacccc0f0f00ffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061842_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6b40768b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h107cea9f__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcd50fd36__0))))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x3333555500ff0f0fULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061846_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d87626c__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050476_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049159_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049161_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049159_))));
    vlSelf->wasmetal_core__DOT___051895_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049312_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->wasmetal_core__DOT___049314_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049312_))));
    vlSelf->wasmetal_core__DOT___065622_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065621_)))));
    vlSelf->wasmetal_core__DOT___066659_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066653_)))))))));
    vlSelf->wasmetal_core__DOT___065932_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065076_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065931_)))));
    vlSelf->wasmetal_core__DOT___066537_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065811_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066531_)))))))));
    vlSelf->wasmetal_core__DOT___065812_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064741_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065811_)))));
    vlSelf->wasmetal_core__DOT___066134_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065309_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066133_)))));
    vlSelf->wasmetal_core__DOT___063849_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042451_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048377_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___042199_)))))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001382_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028868_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT____Vcellout___128077___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028490_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028489_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028488_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028487_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028454_)))));
    vlSelf->wasmetal_core__DOT___028458_ = ((IData)(vlSelf->wasmetal_core__DOT___028490_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028665_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029065_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028977_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128435___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128435___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032283_)))));
    vlSelf->wasmetal_core__DOT___032287_ = ((IData)(vlSelf->wasmetal_core__DOT___001487_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001487_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028768_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___044906_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026480_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026447_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d));
    vlSelf->wasmetal_core__DOT___045002_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054039_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)))))))))));
    vlSelf->wasmetal_core__DOT___045026_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8134fe6e__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054043_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054039_)))))))));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026718_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___070681_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071867_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027188_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127859___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026587_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026584_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026573_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026562_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026529_ = ((IData)(vlSelf->wasmetal_core__DOT___026587_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001887_));
    vlSelf->wasmetal_core__DOT___070784_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071886_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026988_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->wasmetal_core__DOT___066327_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O)))));
    vlSelf->wasmetal_core__DOT___034569_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001487_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128663___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128435___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->__VdfgTmp_hf16ebcc9__0) 
                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT____Vcellout___134217___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h5ad60c71__0) 
           ^ (8U | (((IData)(vlSelf->__VdfgTmp_hf16ebcc9__0) 
                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034541_))));
    vlSelf->wasmetal_core__DOT___065317_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065313_)))));
    vlSelf->wasmetal_core__DOT___066140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065314_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065815_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064759_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064754_)))))))));
    vlSelf->wasmetal_core__DOT___064761_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064754_)))));
    vlSelf->wasmetal_core__DOT___065950_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065081_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065078_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065077_)))));
    vlSelf->wasmetal_core__DOT___065625_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063995_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063982_)))))))));
    vlSelf->wasmetal_core__DOT___063997_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063983_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063982_)))));
    vlSelf->wasmetal_core__DOT___065911_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064929_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064923_)))))))));
    vlSelf->wasmetal_core__DOT___064931_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064924_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064923_)))));
    vlSelf->wasmetal_core__DOT___066271_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065423_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065419_)))));
    vlSelf->wasmetal_core__DOT___065198_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065194_)))));
    vlSelf->wasmetal_core__DOT___066095_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065195_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___065713_ = (1U & (IData)(
                                                         (0x550f3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064511_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064498_)))))))));
    vlSelf->wasmetal_core__DOT___064513_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064499_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064498_)))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030104_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030232_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___068792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068600_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068791_)))));
    vlSelf->wasmetal_core__DOT___068847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068650_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068846_)))));
    vlSelf->wasmetal_core__DOT___068699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068474_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068698_)))));
    vlSelf->wasmetal_core__DOT___068601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068397_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068600_)))));
    vlSelf->wasmetal_core__DOT___068748_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068548_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068747_)))));
    vlSelf->wasmetal_core__DOT___068475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068288_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068474_)))));
    vlSelf->wasmetal_core__DOT___068651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068421_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068650_)))));
    vlSelf->wasmetal_core__DOT___068398_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068150_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068397_)))));
    vlSelf->wasmetal_core__DOT___068549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068342_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068548_)))));
    vlSelf->wasmetal_core__DOT___068289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068074_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068288_)))));
    vlSelf->wasmetal_core__DOT___068422_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068235_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068421_)))));
    vlSelf->wasmetal_core__DOT___068343_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068099_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068342_)))));
    vlSelf->wasmetal_core__DOT___068075_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067816_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068074_)))));
    vlSelf->wasmetal_core__DOT___068151_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068150_)))));
    vlSelf->wasmetal_core__DOT___068236_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068026_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068235_)))));
    vlSelf->wasmetal_core__DOT___068027_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068026_)))));
    vlSelf->wasmetal_core__DOT___068100_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068099_)))));
    vlSelf->wasmetal_core__DOT___067970_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067969_)))));
    vlSelf->wasmetal_core__DOT___067817_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067816_)))));
    vlSelf->wasmetal_core__DOT___067904_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067665_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067903_)))));
    vlSelf->wasmetal_core__DOT___067732_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067448_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067731_)))));
    vlSelf->wasmetal_core__DOT___067594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067301_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067593_)))));
    vlSelf->wasmetal_core__DOT___067449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067146_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067448_)))));
    vlSelf->wasmetal_core__DOT___067302_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066963_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067301_)))));
    vlSelf->wasmetal_core__DOT___067147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066844_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067146_)))));
    vlSelf->wasmetal_core__DOT___066964_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066639_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066963_)))));
    vlSelf->wasmetal_core__DOT___067756_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067755_)))));
    vlSelf->wasmetal_core__DOT___066845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066517_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066844_)))));
    vlSelf->wasmetal_core__DOT___067666_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067331_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067665_)))));
    vlSelf->wasmetal_core__DOT___066640_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066305_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066639_)))));
    vlSelf->wasmetal_core__DOT___067498_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067187_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067497_)))));
    vlSelf->wasmetal_core__DOT___067332_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067068_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067331_)))));
    vlSelf->wasmetal_core__DOT___066518_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066117_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066517_)))));
    vlSelf->wasmetal_core__DOT___067188_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066885_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067187_)))));
    vlSelf->wasmetal_core__DOT___067069_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067068_)))));
    vlSelf->wasmetal_core__DOT___066306_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066305_)))));
    vlSelf->wasmetal_core__DOT___066886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066885_)))));
    vlSelf->wasmetal_core__DOT___066118_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065794_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066117_)))));
    vlSelf->wasmetal_core__DOT___066762_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066391_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066761_)))));
    vlSelf->wasmetal_core__DOT___066595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066261_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066594_)))));
    vlSelf->wasmetal_core__DOT___065927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065596_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065926_)))));
    vlSelf->wasmetal_core__DOT___065795_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065292_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065794_)))));
    vlSelf->wasmetal_core__DOT___066392_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066391_)))));
    vlSelf->wasmetal_core__DOT___066262_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066261_)))));
    vlSelf->wasmetal_core__DOT___066072_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066071_)))));
    vlSelf->wasmetal_core__DOT___065891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065405_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065890_)))));
    vlSelf->wasmetal_core__DOT___065597_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065071_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065596_)))));
    vlSelf->wasmetal_core__DOT___065693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065176_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065692_)))));
    vlSelf->wasmetal_core__DOT___065406_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065405_)))));
    vlSelf->wasmetal_core__DOT___064892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064891_))));
    vlSelf->wasmetal_core__DOT___065177_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064483_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065176_)))));
    vlSelf->wasmetal_core__DOT___064484_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064483_))));
    vlSelf->wasmetal_core__DOT___065293_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064724_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065292_)))));
    vlSelf->wasmetal_core__DOT___064725_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064724_))));
    vlSelf->wasmetal_core__DOT___065072_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065071_)))));
    vlSelf->wasmetal_core__DOT___063831_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063829_))));
    vlSelf->wasmetal_core__DOT___053498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053496_))));
    vlSelf->wasmetal_core__DOT___063366_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052843_))));
    vlSelf->__VdfgTmp_h554fca93__0 = ((2U & ((IData)(
                                                     (0x7770fff0fffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052844_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052843_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)))))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xff40404000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___053019_))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128058___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028310_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028307_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028296_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028285_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028278_ = ((IData)(vlSelf->wasmetal_core__DOT___028310_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028245_));
    vlSelf->wasmetal_core__DOT___051460_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))))))));
    vlSelf->wasmetal_core__DOT___051696_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))))))));
    vlSelf->wasmetal_core__DOT___066412_ = (1U & (IData)(
                                                         (0x3300f00055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066405_)))))))));
    vlSelf->wasmetal_core__DOT___065710_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064478_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065709_)))));
    vlSelf->wasmetal_core__DOT___066781_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066076_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066775_)))))))));
    vlSelf->wasmetal_core__DOT___066077_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065201_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066076_)))));
    vlSelf->wasmetal_core__DOT___066905_ = (1U & (IData)(
                                                         (0x33000f0055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066268_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066899_)))))))));
    vlSelf->wasmetal_core__DOT___066269_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065426_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066268_)))));
    vlSelf->wasmetal_core__DOT___065908_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065907_)))));
    vlSelf->wasmetal_core__DOT___064904_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064903_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___063864_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063835_))));
    vlSelf->wasmetal_core__DOT___063842_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___042072_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048381_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___042272_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048317_)))))));
    vlSelf->wasmetal_core__DOT___063839_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042106_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048367_)))));
    vlSelf->wasmetal_core__DOT___063847_ = (1U & (IData)(
                                                         (0x777ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___042403_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___042307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))))));
    vlSelf->wasmetal_core__DOT___063845_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042391_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048371_))));
    vlSelf->wasmetal_core__DOT___063844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042212_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048363_))));
    vlSelf->wasmetal_core__DOT___064774_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064771_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4fff00ff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064748_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063902_)))))));
    vlSelf->wasmetal_core__DOT___065055_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0))))));
    vlSelf->wasmetal_core__DOT___064911_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h00f9b844__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063880_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)))));
    vlSelf->wasmetal_core__DOT___063929_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hbbb75ece__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5a2cc5a2__0))))));
    vlSelf->__VdfgTmp_h2f60644c__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(vlSelf->__VdfgTmp_h826c8569__0))));
    vlSelf->wasmetal_core__DOT___036636_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)))))));
    vlSelf->wasmetal_core__DOT___036635_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))))));
    vlSelf->__VdfgTmp_h79b76beb__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127944___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027366_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027355_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027344_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027301_ = ((IData)(vlSelf->wasmetal_core__DOT___027366_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___023238_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffde1553__0))));
    vlSelf->wasmetal_core__DOT___023239_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005731_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcf316312__0)))));
    vlSelf->wasmetal_core__DOT___023237_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hba4cc4c7__0))));
    vlSelf->wasmetal_core__DOT___023236_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fccfed0__0))));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128141___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029153_)))));
    vlSelf->wasmetal_core__DOT___029126_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128324___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031044_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031043_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031073_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031072_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031039_)))));
    vlSelf->wasmetal_core__DOT___031012_ = ((IData)(vlSelf->wasmetal_core__DOT___031044_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___050526_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050523_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050522_))));
    vlSelf->wasmetal_core__DOT___049658_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049284_))));
    vlSelf->wasmetal_core__DOT___053210_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->wasmetal_core__DOT___049624_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049073_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049084_))));
    vlSelf->wasmetal_core__DOT___049044_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049041_))));
    vlSelf->wasmetal_core__DOT___050585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049024_))));
    vlSelf->wasmetal_core__DOT___051402_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050519_))));
    vlSelf->wasmetal_core__DOT___049689_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049451_))));
    vlSelf->wasmetal_core__DOT___049454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049450_))));
    vlSelf->wasmetal_core__DOT___049285_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049283_))));
    vlSelf->wasmetal_core__DOT___050053_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___049364_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0))))));
    vlSelf->wasmetal_core__DOT___051428_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___049493_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049490_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0))))));
    vlSelf->wasmetal_core__DOT___049706_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049490_))));
    vlSelf->wasmetal_core__DOT___049085_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049083_))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010961_)));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010546_)));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010925_)));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0)));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010735_)));
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010854_)));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010741_)));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010860_)));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_))));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010969_))));
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
    } else {
        vlSelf->wasmetal_core__DOT___013095_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hf222e899__0)))));
        vlSelf->wasmetal_core__DOT___011413_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0))));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? 
                                                   (0xfeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))
                                                    : 
                                                   (0xf1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1841993__0)));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7fb5afda__0))));
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h658ce6a4__0))));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf8199cb0__0))));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb9280dfa__0))));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010770_)));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011020_)));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010972_)));
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
    }
    vlSelf->wasmetal_core__DOT___010197_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010206_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1a6962a9__0))));
    vlSelf->wasmetal_core__DOT___012990_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010513_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he13bfe6a__0)))))));
    vlSelf->wasmetal_core__DOT___056350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)) 
                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)) 
                                                           & (IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)))))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1000000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hfe9a1cba__0)))))))))));
    vlSelf->wasmetal_core__DOT___011182_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))));
    vlSelf->__VdfgTmp_hee8b18a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___056920_ = vlSelf->wasmetal_core__DOT___010186_;
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011197_));
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d))))));
        vlSelf->wasmetal_core__DOT___012983_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012028_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012027_))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011992_))))));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___011194_;
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d))))));
    } else {
        vlSelf->wasmetal_core__DOT___056920_ = vlSelf->wasmetal_core__DOT___011973_;
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))));
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))));
        vlSelf->wasmetal_core__DOT___012983_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012029_))
                                                    : 
                                                   (0xbU 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc9e45bda__0))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d))))));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___010187_;
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011194_));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012042_));
    }
    vlSelf->wasmetal_core__DOT___050521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050518_))));
    vlSelf->wasmetal_core__DOT___051401_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050518_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___049252_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049251_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___049657_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049251_))));
    vlSelf->wasmetal_core__DOT___052590_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___049623_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049083_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0))))));
    vlSelf->wasmetal_core__DOT___049043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049024_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049023_))));
    vlSelf->wasmetal_core__DOT___049688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049447_))));
    vlSelf->wasmetal_core__DOT___052600_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           ((2U 
                                                             & ((0xacU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))))))));
    vlSelf->wasmetal_core__DOT___050059_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0))))));
    vlSelf->__VdfgTmp_h7f4141b2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)))))));
    vlSelf->wasmetal_core__DOT___049363_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0))))));
    vlSelf->wasmetal_core__DOT___051427_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0))))));
    vlSelf->wasmetal_core__DOT___052591_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___051918_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))));
    vlSelf->__VdfgTmp_h10726817__0 = ((4U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xacU 
                                                 >> 
                                                 ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))) 
                                                << 1U)) 
                                         | (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))))));
    vlSelf->wasmetal_core__DOT___049505_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049501_))));
    vlSelf->wasmetal_core__DOT___049705_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049502_))));
    vlSelf->wasmetal_core__DOT___049145_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049132_))));
    vlSelf->wasmetal_core__DOT___049618_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049132_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))))));
    vlSelf->wasmetal_core__DOT___062173_ = (1U & (0xfafc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062171_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))));
    vlSelf->wasmetal_core__DOT___011912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010302_))));
    vlSelf->wasmetal_core__DOT___011771_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010302_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))))));
    vlSelf->wasmetal_core__DOT___011206_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011666_)))));
    vlSelf->__VdfgTmp_hb44ad26b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h362b458b__0));
    vlSelf->__VdfgTmp_h450c5ec1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha569c0f1__0));
    vlSelf->wasmetal_core__DOT___055108_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0))))));
    vlSelf->wasmetal_core__DOT___062068_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062058_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062057_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___053646_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051706_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___010220_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))))));
    vlSelf->wasmetal_core__DOT___055277_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h8b4e795d__0 = ((2U & ((0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___010413_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2133c371__0)))));
    vlSelf->wasmetal_core__DOT___056895_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h479e0c47__0)))))));
    vlSelf->wasmetal_core__DOT___012182_ = (1U & (IData)(
                                                         (0x55330000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056325_)))))))));
    vlSelf->__VdfgTmp_hede7bfa8__0 = (((IData)(vlSelf->wasmetal_core__DOT___012729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011389_));
    vlSelf->__VdfgTmp_h7bcb9cab__0 = (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011388_));
    vlSelf->wasmetal_core__DOT___011722_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___057050_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)))))))));
    vlSelf->__VdfgTmp_hb1f92188__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)));
    vlSelf->wasmetal_core__DOT___056341_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))));
    vlSelf->__VdfgTmp_hdcd859be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011527_)));
    vlSelf->__VdfgTmp_he9d803b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010222_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___011032_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010222_)) 
                                                  & (IData)(
                                                            (0xff00ffddff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h362b458b__0)))))))));
    vlSelf->wasmetal_core__DOT___055199_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055122_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___055194_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___013142_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011379_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0))))))));
    vlSelf->__VdfgTmp_hf4d8b80a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___011973_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___011197_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                 & (IData)(
                                                           (0xff00ffaaf0f0fcfcULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))))));
    vlSelf->wasmetal_core__DOT___010849_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8f305c7__0)))));
    vlSelf->__VdfgTmp_h14d4af94__0 = (((IData)(vlSelf->wasmetal_core__DOT___011380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011379_));
    vlSelf->__VdfgTmp_h2790f0bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011898_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010530_));
    vlSelf->__VdfgTmp_hf996b543__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h146131dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056381_));
    vlSelf->wasmetal_core__DOT___057102_ = (1U & (IData)(
                                                         (0xa0c000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->wasmetal_core__DOT___011205_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ff0faaaaccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->__VdfgTmp_h95d3d0ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h88263545__0));
    vlSelf->wasmetal_core__DOT___013099_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbc86843d__0)))))));
    vlSelf->wasmetal_core__DOT___053368_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053367_)))));
    vlSelf->wasmetal_core__DOT___012804_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010721_))));
    vlSelf->wasmetal_core__DOT___012184_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056375_)))))))));
    vlSelf->__VdfgTmp_h1055e951__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056368_)));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010103_)));
        vlSelf->wasmetal_core__DOT___010125_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010123_)));
    } else {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010103_))
                                                    : (IData)(
                                                              (0x11010000ff0fULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010103_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hb67d963d__0)))))));
        vlSelf->wasmetal_core__DOT___010125_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010123_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h39adae05__0)))))));
    }
    vlSelf->__VdfgTmp_h16c112d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb67d963d__0));
    vlSelf->__VdfgTmp_h7e112ed5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___056380_))));
    vlSelf->wasmetal_core__DOT___056829_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)))))))));
    vlSelf->__VdfgTmp_h0931b472__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___056616_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011503_))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___010374_))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a02124a__0))))))));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010045_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6af19a3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0));
    vlSelf->wasmetal_core__DOT___011906_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011537_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011519_)))))))));
    vlSelf->__VdfgTmp_hf6c0bd72__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011537_));
    vlSelf->wasmetal_core__DOT___011207_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010298_)))))))));
    vlSelf->__VdfgTmp_h493dc6bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->__VdfgTmp_h2994a26e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                               ? (0x305U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf1841993__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                         & (IData)(
                                                   (0x333355550f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0)))));
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
    } else {
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xceU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
    }
    vlSelf->__VdfgTmp_he09ec1d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hee315f88__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d));
    vlSelf->wasmetal_core__DOT___062007_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062001_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061995_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061994_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061708_)))))))));
    vlSelf->wasmetal_core__DOT___061985_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___054930_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054920_))));
    vlSelf->wasmetal_core__DOT___050675_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h40926396__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))));
    vlSelf->wasmetal_core__DOT___049487_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049483_))));
    vlSelf->wasmetal_core__DOT___050599_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049843_))));
    vlSelf->wasmetal_core__DOT___049460_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049458_))));
    vlSelf->wasmetal_core__DOT___053209_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051429_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->__VdfgTmp_h28b05b3d__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)))))));
    vlSelf->wasmetal_core__DOT___050542_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0))))));
    vlSelf->wasmetal_core__DOT___050674_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0))))));
    vlSelf->wasmetal_core__DOT___049857_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0))))));
    vlSelf->wasmetal_core__DOT___049494_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049491_))));
    vlSelf->wasmetal_core__DOT___049703_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049483_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))))));
    vlSelf->wasmetal_core__DOT___049621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049074_))));
    vlSelf->wasmetal_core__DOT___049086_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049074_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049073_))));
    vlSelf->wasmetal_core__DOT___049844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049842_))));
    vlSelf->wasmetal_core__DOT___050598_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049042_))));
    vlSelf->wasmetal_core__DOT___050527_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050524_))));
    vlSelf->wasmetal_core__DOT___051410_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050523_))));
    vlSelf->wasmetal_core__DOT___049588_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049458_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049453_))));
    vlSelf->wasmetal_core__DOT___049455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049453_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049452_))));
    vlSelf->wasmetal_core__DOT___049286_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049277_))));
    vlSelf->wasmetal_core__DOT___049655_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049278_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7fb5afda__0)))));
    vlSelf->wasmetal_core__DOT___056826_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___010389_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h658ce6a4__0)))));
    vlSelf->__VdfgTmp_ha5884336__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012124_));
    vlSelf->__VdfgTmp_h99697672__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0));
    vlSelf->wasmetal_core__DOT___057049_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012043_)))));
    vlSelf->wasmetal_core__DOT___056280_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hf8199cb0__0)))));
    vlSelf->wasmetal_core__DOT___012422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010718_))));
    vlSelf->__VdfgTmp_hdeb472fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010717_));
    vlSelf->wasmetal_core__DOT___010392_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___056825_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___056641_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056286_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hb9280dfa__0)))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010302_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))));
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010339_))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                   | (0xf010U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
    } else {
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010299_))));
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010342_)) 
                                                   & (0xf0feU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011658_))));
    }
    vlSelf->wasmetal_core__DOT___012632_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056553_)))));
    vlSelf->__VdfgTmp_h3fe4e0c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3820fb89__0)));
    vlSelf->wasmetal_core__DOT___012175_ = (1U & (IData)(
                                                         (0xf0f000bb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->wasmetal_core__DOT___061946_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061882_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055510_)))))))));
    vlSelf->wasmetal_core__DOT___054892_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033390_)))))))));
    vlSelf->wasmetal_core__DOT___010577_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010575_))
                                                   : 
                                                  (0xf4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha620249b__0))));
    vlSelf->wasmetal_core__DOT___056369_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010770_)));
    vlSelf->wasmetal_core__DOT___011478_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39adae05__0)))));
    vlSelf->wasmetal_core__DOT___010260_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010282_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c968075__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hffef1e62__0)))))));
    vlSelf->__VdfgTmp_hb211d2c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d));
    vlSelf->wasmetal_core__DOT___061806_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055411_)))))))));
    vlSelf->wasmetal_core__DOT___056636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))));
    vlSelf->wasmetal_core__DOT___057067_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))))))));
    vlSelf->wasmetal_core__DOT___011939_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h375c9c07__0))))))));
    vlSelf->wasmetal_core__DOT___056347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb18a766__0)))));
    vlSelf->__VdfgTmp_hc9438d71__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h51371d7f__0)))));
    vlSelf->__VdfgTmp_h6cc2c965__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51371d7f__0));
    vlSelf->__VdfgTmp_h336e35bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012980_));
    vlSelf->__VdfgTmp_h4284cb76__0 = (((IData)(vlSelf->wasmetal_core__DOT___011920_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011919_));
    vlSelf->__VdfgTmp_h42ead4cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0));
    vlSelf->wasmetal_core__DOT___010198_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___011697_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___056440_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011020_)));
    vlSelf->__VdfgTmp_h25f5437e__0 = (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)));
    vlSelf->wasmetal_core__DOT___056499_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->wasmetal_core__DOT___056593_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->__VdfgTmp_h08c644ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xfef0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___012845_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011539_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011530_)))))))));
    vlSelf->wasmetal_core__DOT___011998_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___012287_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___011602_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010972_)));
    vlSelf->wasmetal_core__DOT___072006_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb25114eb__0)))));
    vlSelf->__VdfgTmp_h4cd16820__0 = (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb25114eb__0));
    vlSelf->wasmetal_core__DOT___053640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___053652_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051719_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051779_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051631_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___053902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053663_))));
    vlSelf->wasmetal_core__DOT___053634_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051651_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051526_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050828_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___056899_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056897_)))))));
    vlSelf->wasmetal_core__DOT___019292_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h058d1256__0))));
    vlSelf->wasmetal_core__DOT___057687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048453_))));
    vlSelf->wasmetal_core__DOT___055734_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___055063_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010044_)))))))));
    vlSelf->wasmetal_core__DOT___002633_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002801_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002799_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002798_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_))))));
    vlSelf->wasmetal_core__DOT___001741_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h07469665__0)))))));
    vlSelf->wasmetal_core__DOT___002473_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002556_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002554_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002553_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_))))));
    vlSelf->wasmetal_core__DOT___064936_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))));
    vlSelf->wasmetal_core__DOT___012176_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0))))));
    vlSelf->__VdfgTmp_h88f91f2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0));
    vlSelf->wasmetal_core__DOT___012377_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010187_)
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010186_)) 
                                                    << 1U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      & (IData)(
                                                                (0xff00ffaaf0f0fcfcULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))))))))));
    vlSelf->__VdfgTmp_h00eaf9c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___018278_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058931_))));
    vlSelf->wasmetal_core__DOT___050064_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049530_)))));
    vlSelf->wasmetal_core__DOT___051763_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051614_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> 
                                                              (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT___050255_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051301_))));
    vlSelf->wasmetal_core__DOT___051307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050176_))));
    vlSelf->wasmetal_core__DOT___050272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050176_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051311_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051303_))));
    vlSelf->wasmetal_core__DOT___051304_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051303_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050261_))));
    vlSelf->wasmetal_core__DOT___050262_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050261_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051312_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051309_))));
    vlSelf->wasmetal_core__DOT___051530_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051309_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050265_))));
    vlSelf->wasmetal_core__DOT___050266_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050265_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050139_))));
    vlSelf->wasmetal_core__DOT___051306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050139_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050275_))));
    vlSelf->wasmetal_core__DOT___050276_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050166_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050165_))));
    vlSelf->wasmetal_core__DOT___051308_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050165_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050277_))));
    vlSelf->wasmetal_core__DOT___050278_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050277_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050155_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050154_))));
    vlSelf->wasmetal_core__DOT___051310_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050154_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051284_))));
    vlSelf->wasmetal_core__DOT___051285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051284_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050274_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050168_))));
    vlSelf->wasmetal_core__DOT___050268_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050168_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051299_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051281_))));
    vlSelf->wasmetal_core__DOT___051282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051281_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050143_))));
    vlSelf->wasmetal_core__DOT___051380_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050143_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013805_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003056_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003054_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003053_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003055_))))));
    vlSelf->__VdfgTmp_h1e702231__0 = (((IData)(vlSelf->wasmetal_core__DOT___002469_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002468_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000158_)));
    vlSelf->wasmetal_core__DOT___051751_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051582_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051689_))))));
    vlSelf->wasmetal_core__DOT___002631_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002721_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002718_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_))))));
    vlSelf->wasmetal_core__DOT___002883_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he03432df__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))));
    vlSelf->__VdfgTmp_h3fe5e3ea__0 = ((2U & ((IData)(
                                                     (0xff00ff00ff000eULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___048829_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1111fff000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048828_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? 
                                                                      (0xc0aU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002106_)) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))))));
    vlSelf->__VdfgTmp_haf508d85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010300_));
    vlSelf->__VdfgTmp_h6f308c91__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010340_))))));
    vlSelf->wasmetal_core__DOT___056961_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056552_)))))))));
    vlSelf->__VdfgTmp_ha429fd09__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011660_))))));
    vlSelf->__VdfgTmp_h98e4ab16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011659_));
    vlSelf->wasmetal_core__DOT___011899_ = (1U & (0x50cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))));
    vlSelf->wasmetal_core__DOT___050709_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049926_))));
    vlSelf->wasmetal_core__DOT___051741_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051550_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051650_))))));
    vlSelf->wasmetal_core__DOT___049901_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049898_))));
    vlSelf->wasmetal_core__DOT___051720_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051719_))));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006226_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___051707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051706_))));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013918_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___049768_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051347_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051690_))));
    vlSelf->wasmetal_core__DOT___061517_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048384_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061514_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061504_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061491_)))))));
    vlSelf->wasmetal_core__DOT___061518_ = (1U & (IData)(
                                                         (0xfefffefffeffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061513_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061512_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061511_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf56802d2__0))))))));
    vlSelf->__VdfgTmp_h9c39d480__0 = (((IData)(vlSelf->wasmetal_core__DOT___010715_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010716_));
    vlSelf->wasmetal_core__DOT___010727_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010715_))));
    vlSelf->wasmetal_core__DOT___071991_ = (1U & (IData)(
                                                         (0xff00ff00eeee0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xccccaaaaf0f0ff00ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)))))))))));
    vlSelf->wasmetal_core__DOT___056281_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))))));
    vlSelf->wasmetal_core__DOT___056923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010221_)))));
    vlSelf->wasmetal_core__DOT___055200_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT___049721_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049383_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___051652_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051651_))));
    vlSelf->wasmetal_core__DOT___062182_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055712_)))))))));
    vlSelf->wasmetal_core__DOT___048680_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84446dc0__0))));
    vlSelf->wasmetal_core__DOT___049531_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049526_))));
    vlSelf->wasmetal_core__DOT___051989_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050787_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050789_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049815_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xff55ccf0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___049814_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h951148c2__0))))))));
    vlSelf->wasmetal_core__DOT___050791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050789_))));
    vlSelf->wasmetal_core__DOT___049927_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047952_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047950_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___047949_)))))));
    vlSelf->wasmetal_core__DOT___049384_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047950_))));
    vlSelf->__VdfgTmp_ha128d41e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___051433_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___050849_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009520_));
    vlSelf->wasmetal_core__DOT___050855_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050849_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050848_)))))));
    vlSelf->__VdfgTmp_he62a830e__0 = ((2U & ((IData)(
                                                     (0xf0f0aaaaccccff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049644_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))) 
                                             << 1U)) 
                                      | (1U & (0x10U 
                                               >> (4U 
                                                   & ((4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                             << 1U)) 
                                                           << 1U))) 
                                                      << 2U)))));
    vlSelf->wasmetal_core__DOT___050829_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))));
    vlSelf->__VdfgTmp_had82d15e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049054_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049440_)))))) 
                                             << 1U)) 
                                      | (1U & (0xff55ccf0U 
                                               >> (IData)(vlSelf->__VdfgTmp_h35851421__0))));
    vlSelf->wasmetal_core__DOT___050543_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049054_)))))));
    vlSelf->wasmetal_core__DOT___049241_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049226_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___051907_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049226_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051905_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051904_)))))));
    vlSelf->wasmetal_core__DOT___051057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049748_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051056_))));
    vlSelf->wasmetal_core__DOT___049749_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049748_))));
    vlSelf->wasmetal_core__DOT___049886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049615_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049885_))));
    vlSelf->wasmetal_core__DOT___051289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049885_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051288_))));
    vlSelf->wasmetal_core__DOT___049797_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049796_))));
    vlSelf->wasmetal_core__DOT___051114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051113_))));
    vlSelf->wasmetal_core__DOT___049701_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049699_))));
    vlSelf->wasmetal_core__DOT___050693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049699_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050692_))));
    vlSelf->wasmetal_core__DOT___057922_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013692_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002029_))));
    vlSelf->wasmetal_core__DOT___017384_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013648_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048788_))));
    vlSelf->wasmetal_core__DOT___017425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_hd5565504__0 = (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002629_));
    vlSelf->wasmetal_core__DOT___017426_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___050457_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7fff00007fff7fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050450_))))))))))));
    vlSelf->wasmetal_core__DOT___053369_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053163_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053088_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053092_)))))))));
    vlSelf->wasmetal_core__DOT___019803_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbbbU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___052988_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT___039820_ = (1U & (IData)(
                                                         (0xeaea2aea2a2a2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfdf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050451_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__check_type)))))))));
    vlSelf->wasmetal_core__DOT___053249_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053248_))));
    vlSelf->wasmetal_core__DOT___017409_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___055126_ = (1U & (IData)(
                                                         (0xffff000000fe0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055118_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054758_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054760_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054759_))))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1111000f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf800U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055122_))))))))))))));
    vlSelf->wasmetal_core__DOT___056088_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___056095_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000980_)))));
    vlSelf->wasmetal_core__DOT___056098_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000992_)))));
    vlSelf->wasmetal_core__DOT___056101_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001014_)))));
    vlSelf->wasmetal_core__DOT___056118_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001102_)))));
    vlSelf->wasmetal_core__DOT___056128_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001146_)))));
    vlSelf->wasmetal_core__DOT___056132_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001168_)))));
    vlSelf->wasmetal_core__DOT___056017_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___056025_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___056029_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___056033_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___056037_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___056041_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___056047_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___056055_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___056060_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___056065_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___056069_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___056073_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___056077_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___056082_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___056085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___056007_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___056013_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050493_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050493_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049868_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049868_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051271_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051271_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050487_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050487_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             >> 2U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O))))));
    vlSelf->wasmetal_core__DOT___049918_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___050492_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049865_))));
    vlSelf->wasmetal_core__DOT___049913_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049865_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
}
