#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__23(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__23\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___063168_;
    wasmetal_core__DOT___063168_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063174_;
    wasmetal_core__DOT___063174_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063180_;
    wasmetal_core__DOT___063180_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063186_;
    wasmetal_core__DOT___063186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063490_;
    wasmetal_core__DOT___063490_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063498_;
    wasmetal_core__DOT___063498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063506_;
    wasmetal_core__DOT___063506_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063514_;
    wasmetal_core__DOT___063514_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h7baa8c24__0;
    __VdfgTmp_h7baa8c24__0 = 0;
    CData/*2:0*/ __VdfgTmp_ha1bf32a7__0;
    __VdfgTmp_ha1bf32a7__0 = 0;
    CData/*2:0*/ __VdfgTmp_hfc0d441b__0;
    __VdfgTmp_hfc0d441b__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6ec4eab1__0;
    __VdfgTmp_h6ec4eab1__0 = 0;
    CData/*1:0*/ __VdfgTmp_h635c29e2__0;
    __VdfgTmp_h635c29e2__0 = 0;
    CData/*1:0*/ __VdfgTmp_h986ee838__0;
    __VdfgTmp_h986ee838__0 = 0;
    // Body
    if (vlSelf->wasmetal_core__DOT___011103_) {
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0xf030f05U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011098_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (0xf011U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51371d7f__0))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011109_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0)))))))))))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0xf050f03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011954_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011099_))))));
        vlSelf->wasmetal_core__DOT___011950_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011957_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011955_))))));
    }
    vlSelf->__VdfgTmp_hedaab00c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011098_));
    vlSelf->wasmetal_core__DOT___056479_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056478_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x11f00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___012459_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057169_)))));
    vlSelf->wasmetal_core__DOT___065290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065289_))));
    vlSelf->wasmetal_core__DOT___066145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012941_))));
    vlSelf->wasmetal_core__DOT___012001_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3816fa33__0))));
    vlSelf->__VdfgTmp_he1977acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___056787_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3816fa33__0));
    vlSelf->wasmetal_core__DOT___057028_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012240_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___013184_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3478584b__0))))));
    vlSelf->wasmetal_core__DOT___013168_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3478584b__0))));
    vlSelf->wasmetal_core__DOT___056835_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xdddd000f000fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056803_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056703_)))));
    vlSelf->wasmetal_core__DOT___012002_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfdfU 
                                                           >> 
                                                           ((0x10U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056787_)))));
    vlSelf->wasmetal_core__DOT___012052_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))))))))));
    vlSelf->__VdfgTmp_hf2cfe231__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056825_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056826_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))));
    vlSelf->__VdfgTmp_h7487032b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010396_));
    vlSelf->wasmetal_core__DOT___011764_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT___056648_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT___057030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaaff0f0c0f0cULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___057025_))))))))))));
    vlSelf->wasmetal_core__DOT___072167_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___072148_))));
    vlSelf->wasmetal_core__DOT___072165_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072148_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134220___A 
        = ((0x3fffe000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039092_))) 
                           << 0xdU)) | ((0x1000U & 
                                         ((0xf8U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___039092_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))) 
                                          << 0xcU)) 
                                        | ((0x800U 
                                            & ((IData)(
                                                       (0xfffffff8ffff8888ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055308_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                               << 0xbU)) 
                                           | ((0x400U 
                                               & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055307_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((IData)(
                                                             (0xfffffff8ffff8888ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055306_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((IData)(
                                                                (0xfffffff8ffff8888ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055305_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((IData)(
                                                                   (0xfffffff8ffff8888ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055304_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((IData)(
                                                                      (0xfffffff8ffff8888ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055303_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                              << 6U)) 
                                                          | ((0x20U 
                                                              & ((IData)(
                                                                         (0xfffffff8ffff8888ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055302_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                 << 5U)) 
                                                             | ((0x10U 
                                                                 & ((IData)(
                                                                            (0xfffffff8ffff8888ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                    << 4U)) 
                                                                | ((8U 
                                                                    & ((IData)(
                                                                               (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055300_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                       << 3U)) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055299_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055298_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055297_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056388_ = (1U & (IData)(
                                                         (0xff00fff8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056374_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056371_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056372_)))))))));
    vlSelf->wasmetal_core__DOT___056480_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011103_)))));
    vlSelf->wasmetal_core__DOT___012928_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? (IData)(
                                                                (0xf0f0fcfcf0fff0faULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012934_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012933_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012804_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___012931_))))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___012933_)))));
    vlSelf->__VdfgTmp_h39564552__0 = ((4U & ((0x17U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))) 
                                             << 2U)) 
                                      | ((2U & ((0x69969669U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)) 
                                                << 1U)) 
                                         | (1U & (0x7117U 
                                                  >> 
                                                  ((8U 
                                                    & ((0x96U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072175_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))));
    vlSelf->wasmetal_core__DOT___072180_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))))));
    vlSelf->__VdfgTmp_he54a047f__0 = ((4U & ((0xca000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056730_)))))) 
                                             << 2U)) 
                                      | ((2U & ((1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xfafcULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4aad360c__0))))))) 
                                                << 1U)) 
                                         | ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ffaaff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011853_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012798_))))))))))))))));
    vlSelf->wasmetal_core__DOT___056985_ = (1U & (0xc500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056903_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xf0f555500ff3333ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0)) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056910_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0)))))))))))));
    vlSelf->wasmetal_core__DOT___067171_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012023_)))));
    vlSelf->__VdfgTmp_h4364218e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012023_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xccccaaaa00f000ffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xf011U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012983_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))))))));
    vlSelf->wasmetal_core__DOT___057504_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012879_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c1422ca__0))));
    vlSelf->wasmetal_core__DOT___057118_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057114_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeee0000fff00000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf00eeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010392_)))))))))))))));
    vlSelf->wasmetal_core__DOT___057105_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heaf10b4b__0))));
    vlSelf->__VdfgTmp_h4448f15c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010082_));
    vlSelf->__VdfgTmp_h9167c706__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010081_)));
    vlSelf->__VdfgTmp_hd6fa80fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010896_));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030096_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030063_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030224_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030159_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->__VdfgTmp_h45f0a758__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> (IData)(vlSelf->__VdfgTmp_hca11f007__0))));
    vlSelf->__VdfgTmp_h1ffb08a2__0 = ((4U & ((1U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hca11f007__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)))));
    vlSelf->__VdfgTmp_h5ffdcb06__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->__VdfgTmp_h9a02691e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128182___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029612_)))));
    vlSelf->wasmetal_core__DOT___029585_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128284___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128182___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128285___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030656_)))));
    vlSelf->wasmetal_core__DOT___019779_ = (1U & (IData)(
                                                         (0x7770000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053368_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3eb9c9bf__0))))))));
    vlSelf->wasmetal_core__DOT___019797_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051228_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051227_)))))))));
    vlSelf->wasmetal_core__DOT___018278_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058931_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT___050255_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051301_))));
    vlSelf->wasmetal_core__DOT___051307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050176_))));
    vlSelf->wasmetal_core__DOT___050272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050176_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051311_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051303_))));
    vlSelf->wasmetal_core__DOT___051304_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051303_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050261_))));
    vlSelf->wasmetal_core__DOT___050262_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050261_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051312_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051309_))));
    vlSelf->wasmetal_core__DOT___051530_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051309_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050265_))));
    vlSelf->wasmetal_core__DOT___050266_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050265_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050139_))));
    vlSelf->wasmetal_core__DOT___051306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050139_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050275_))));
    vlSelf->wasmetal_core__DOT___050276_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050166_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050165_))));
    vlSelf->wasmetal_core__DOT___051308_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050165_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050277_))));
    vlSelf->wasmetal_core__DOT___050278_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050277_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050155_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050154_))));
    vlSelf->wasmetal_core__DOT___051310_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050154_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051284_))));
    vlSelf->wasmetal_core__DOT___051285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051284_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050274_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050168_))));
    vlSelf->wasmetal_core__DOT___050268_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050168_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051299_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051281_))));
    vlSelf->wasmetal_core__DOT___051282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051281_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050143_))));
    vlSelf->wasmetal_core__DOT___051380_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050143_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffffff007f7f0000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)))))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0)))))))))));
    vlSelf->wasmetal_core__DOT___058550_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT___051510_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))))));
    vlSelf->wasmetal_core__DOT___018080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___017927_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___019006_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058693_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)))))))));
    vlSelf->wasmetal_core__DOT___058677_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017414_))));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013918_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050493_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050493_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049868_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049868_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051271_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051271_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050487_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050487_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             >> 2U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O))))));
    vlSelf->wasmetal_core__DOT___049918_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___050492_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049865_))));
    vlSelf->wasmetal_core__DOT___049913_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049865_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049944_))));
    vlSelf->wasmetal_core__DOT___049945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050484_))));
    vlSelf->wasmetal_core__DOT___050486_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050484_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049924_))));
    vlSelf->wasmetal_core__DOT___051274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049924_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049921_))));
    vlSelf->wasmetal_core__DOT___050494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049921_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006226_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128411___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128283___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032026_)))));
    vlSelf->wasmetal_core__DOT___032030_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128411___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044907_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O))))))))));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026457_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026423_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d));
    wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036765_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfd696a08__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128061___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028291_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028290_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028289_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028288_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028254_)))));
    vlSelf->wasmetal_core__DOT___028258_ = ((IData)(vlSelf->wasmetal_core__DOT___028291_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028226_));
    vlSelf->wasmetal_core__DOT___045493_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071350_))))))));
    vlSelf->wasmetal_core__DOT___045517_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071350_)))))))));
    vlSelf->wasmetal_core__DOT___045289_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071413_))))))));
    vlSelf->wasmetal_core__DOT___045313_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071413_)))))))));
    vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026565_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026498_)
            : (IData)(vlSelf->wasmetal_core__DOT___001525_));
    vlSelf->wasmetal_core__DOT____Vcellout___128349___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031336_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031335_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031334_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031333_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031300_)))));
    vlSelf->wasmetal_core__DOT___031304_ = ((IData)(vlSelf->wasmetal_core__DOT___031336_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128349___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034326_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034493_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127953___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027335_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027334_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027396_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027395_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027330_)))));
    vlSelf->wasmetal_core__DOT___027270_ = ((IData)(vlSelf->wasmetal_core__DOT___027335_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b11__05d));
    wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x18U) & (IData)(vlSelf->wasmetal_core__DOT___027944_));
    wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x1000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x18U)
                  : (IData)(vlSelf->wasmetal_core__DOT___030479_)));
    wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032880_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027815_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d));
    vlSelf->wasmetal_core__DOT___066647_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066769_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066893_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066852_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128055___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x18U) & (IData)(vlSelf->wasmetal_core__DOT___028170_));
    vlSelf->wasmetal_core__DOT____Vcellout___128046___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028101_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028100_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028099_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028098_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028065_)))));
    vlSelf->wasmetal_core__DOT___028069_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028101_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128046___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x13U)));
    vlSelf->wasmetal_core__DOT___044765_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0xfU)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x15U)))))))));
    vlSelf->wasmetal_core__DOT___044777_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x12U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x14U))))))))));
    wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x18U)) & (IData)(vlSelf->wasmetal_core__DOT___030961_));
    vlSelf->wasmetal_core__DOT___044810_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___044798_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070649_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134212___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032688_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037198_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbc3091a9__0))));
    vlSelf->wasmetal_core__DOT___063589_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063584_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b16__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O))))))));
    vlSelf->wasmetal_core__DOT___063597_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063592_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063605_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063600_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b18__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063613_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063608_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b19__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128494___O) 
                                                                  >> 3U))))))));
    wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026371_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d));
    wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b14__05d) {
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b14__05d;
    } else {
        wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b15__05d) {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___030695_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
        vlSelf->wasmetal_core__DOT___031941_ = vlSelf->wasmetal_core__DOT__sp__05b15__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030660_ = vlSelf->wasmetal_core__DOT___128285___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030695_ = wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031941_ = wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___012608_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff3355550f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___057381_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h417b846d__0))))))));
    vlSelf->wasmetal_core__DOT___011093_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->wasmetal_core__DOT___011296_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))))));
    vlSelf->wasmetal_core__DOT___011792_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011305_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011799_)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___011798_))));
    vlSelf->wasmetal_core__DOT___012072_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___011798_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011799_)
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010789_)))))));
    vlSelf->wasmetal_core__DOT___011088_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010789_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010794_))));
    vlSelf->wasmetal_core__DOT___011432_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010794_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011315_)));
    vlSelf->wasmetal_core__DOT___011791_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011315_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011804_)));
    vlSelf->wasmetal_core__DOT___012071_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011804_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010822_)));
    vlSelf->wasmetal_core__DOT___011431_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010821_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010816_))))))));
    vlSelf->wasmetal_core__DOT___011087_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010822_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010821_)));
    vlSelf->wasmetal_core__DOT___012070_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010671_))));
    vlSelf->wasmetal_core__DOT___056366_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010671_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010670_)));
    vlSelf->wasmetal_core__DOT___056592_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010670_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011323_)));
    vlSelf->wasmetal_core__DOT___056715_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011323_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011812_)));
    vlSelf->wasmetal_core__DOT___056890_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011812_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010696_)));
    vlSelf->wasmetal_core__DOT___056591_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010695_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010690_))))))));
    vlSelf->wasmetal_core__DOT___056365_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010696_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010695_)));
    vlSelf->wasmetal_core__DOT___013057_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010428_))));
    vlSelf->wasmetal_core__DOT___010406_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010428_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010427_)));
    vlSelf->wasmetal_core__DOT___011332_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010427_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011339_)));
    vlSelf->wasmetal_core__DOT___012780_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011339_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011820_)));
    vlSelf->wasmetal_core__DOT___013056_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011820_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010456_)));
    vlSelf->wasmetal_core__DOT___010405_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010456_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010455_)));
    vlSelf->wasmetal_core__DOT___011331_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010455_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011343_)));
    vlSelf->wasmetal_core__DOT___012779_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011343_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011824_)));
    vlSelf->wasmetal_core__DOT___013055_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011824_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010484_)));
    vlSelf->wasmetal_core__DOT___010404_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010484_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010483_)));
    vlSelf->wasmetal_core__DOT___011330_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___010483_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011347_)));
    vlSelf->wasmetal_core__DOT___012778_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011347_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___011828_)));
    vlSelf->wasmetal_core__DOT___057389_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xefffffffecccccccULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))))))));
    vlSelf->__VdfgTmp_hfce8a752__0 = (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hb5646ca1__0)))));
    vlSelf->wasmetal_core__DOT___012531_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? (IData)(
                                                                (0xfcfcfafafff0fff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010423_))))));
    vlSelf->wasmetal_core__DOT___011329_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & (IData)(
                                                            (0xffccffaafff0fff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h025488dc__0)))))))));
    vlSelf->wasmetal_core__DOT___010403_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010512_)
                                                      : 
                                                     (0xfafcU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010506_))))))));
    vlSelf->wasmetal_core__DOT___012105_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___011828_)
                                                : (IData)(vlSelf->wasmetal_core__DOT___010512_)));
    vlSelf->wasmetal_core__DOT___069249_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___011743_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012559_))));
    vlSelf->wasmetal_core__DOT___012106_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010604_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___010407_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8dc7649__0))));
    vlSelf->wasmetal_core__DOT___011783_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff0f33335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___011910_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056744_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011788_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))));
    vlSelf->wasmetal_core__DOT___011081_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011084_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011046_)))))))));
    vlSelf->__VdfgTmp_he19177ad__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011045_)))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011044_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf110000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf000f33335555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056447_) 
                                                                              << 3U) 
                                                                             | ((((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                & (IData)(
                                                                                (0x333355550f0fff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab155f14__0)))))))) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011085_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011084_))))))));
    vlSelf->wasmetal_core__DOT___012216_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff00ff550f0f3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h358fed79__0)))))));
    vlSelf->__VdfgTmp_h95aabd6f__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                               ? (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0))))
                                               : (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011301_)))))) 
                                             << 1U)) 
                                      | (1U & (0xf10000U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011557_))))))));
    vlSelf->wasmetal_core__DOT___056316_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___056492_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf400U 
                                                         >> (IData)(vlSelf->__VdfgTmp_heef7d961__0))))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033480_));
    vlSelf->wasmetal_core__DOT___067824_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hef87eb38__0))));
    vlSelf->wasmetal_core__DOT___056747_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011956_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x1f00U 
                                                                 >> 
                                                                 ((8U 
                                                                   & (((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                                       & (IData)(
                                                                                (0xfffff8f8ffffff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011900_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011899_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011898_))))))))) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xac00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h1d24e3fc__0)))))))))));
    vlSelf->wasmetal_core__DOT___012315_ = (1U & (IData)(
                                                         (0xaaaacccc000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___012329_ = (1U & (IData)(
                                                         (0xff00aa0c0c0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057068_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdb922d45__0))))))));
    vlSelf->wasmetal_core__DOT___013076_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))));
    vlSelf->wasmetal_core__DOT___012895_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057445_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057444_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011101_))))));
    vlSelf->wasmetal_core__DOT___012811_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057390_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               & (IData)(
                                                                         (0xf0f3333ff005555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012793_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011889_))))))))) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h03a652de__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012799_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___012845_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_haddc65cd__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012828_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012826_))))))));
    vlSelf->__VdfgTmp_hbeb24dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___056779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056780_));
    vlSelf->__VdfgTmp_h2ddf0adc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 2U) | ((2U 
                                                  & ((0xcaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011954_)))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011103_)));
    vlSelf->__VdfgTmp_h5b3d01ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_he499e9e8__0))));
    vlSelf->wasmetal_core__DOT___057660_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x10U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057540_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___011102_)))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x33550f0f00000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013103_)))))))))))))));
    vlSelf->wasmetal_core__DOT___057633_ = (1U & (IData)(
                                                         (0xff00f8f800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057632_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1100f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013144_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013142_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013143_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057630_)))))))));
    vlSelf->wasmetal_core__DOT___072217_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->wasmetal_core__DOT___072212_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->wasmetal_core__DOT___066100_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057343_))));
    vlSelf->__VdfgTmp_hde86d559__0 = ((2U & ((IData)(
                                                     (0xa0a0f0f00ff00ccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((IData)(
                                                                            (0xfff00000eeeeULL 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                                                    << 1U) 
                                                                   | (1U 
                                                                      & (IData)(
                                                                                (0xaaaacccc00f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012991_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057264_)))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (IData)(vlSelf->__VdfgTmp_h6b93e166__0))));
    vlSelf->wasmetal_core__DOT___012316_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___056947_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca77b771__0))));
    vlSelf->wasmetal_core__DOT___012330_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca77b771__0))))))));
    vlSelf->wasmetal_core__DOT___057552_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))));
    vlSelf->__VdfgTmp_ha7d2f4a8__0 = ((2U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                             << 1U)) 
                                      | (1U & (0x71U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_))))));
    vlSelf->wasmetal_core__DOT___072199_ = (1U & (0x69U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_)))));
    vlSelf->wasmetal_core__DOT___012449_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057172_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057169_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xaa33f0f0U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012400_)))))))))))))));
    vlSelf->wasmetal_core__DOT___012165_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33aa0000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6365363__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056914_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x5550fff003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056964_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3a80e12__0))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056968_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012262_)))))))));
    vlSelf->wasmetal_core__DOT___012620_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057288_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xfcf5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012642_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   (0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___011631_))))
                                                                    : 
                                                                   (0xfeeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011632_) 
                                                                         << 2U) 
                                                                        | ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                             & (IData)(
                                                                                (0xccccaaaaf0f000ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h249647a6__0))))))) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xf0faf0f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011522_))
                                                                                 : (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___033411_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056425_)))))))))))))))))))
                                                      : 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_ha0e20209__0)))))));
    vlSelf->wasmetal_core__DOT___056626_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)
                                                   ? (IData)(
                                                             (0x33335555f0f0f0ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011460_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011458_))))))))
                                                   : 
                                                  (0xabU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011460_))))));
    vlSelf->wasmetal_core__DOT___056384_ = (1U & (IData)(
                                                         (0xccaa0000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056382_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))))));
    vlSelf->wasmetal_core__DOT___056462_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hedaab00c__0))))));
    vlSelf->__VdfgTmp_h187b70d7__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012392_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___012474_));
    vlSelf->wasmetal_core__DOT___012448_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___011101_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012394_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___012395_))))))
                                                   : 
                                                  (0x33550f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0xcaU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h224cdee6__0))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012459_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xaaaaf0f000ffccccULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h30784950__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056431_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010949_))))))))))))))));
    vlSelf->wasmetal_core__DOT___065320_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065290_))));
    vlSelf->wasmetal_core__DOT___056790_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf077U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))))));
    vlSelf->wasmetal_core__DOT___012054_ = (1U & (0xf0088U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he1977acf__0)))));
    vlSelf->wasmetal_core__DOT___065917_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___057031_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057028_)))));
    vlSelf->wasmetal_core__DOT___013159_ = ((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                            & (IData)(
                                                      (0xff00ff33f5f5f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h638ad0d9__0))))))));
    vlSelf->wasmetal_core__DOT___057559_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013168_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->__VdfgTmp_h7a970221__0 = (((IData)(vlSelf->wasmetal_core__DOT___012941_) 
                                       << 2U) | ((2U 
                                                  & ((0xf400U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xfff00000eeeeULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb67239de__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xfff1ff00ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                                          << 3U)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0)))))))));
    vlSelf->__VdfgTmp_hb6e1260e__0 = ((4U & ((IData)(
                                                     (0xf0fff4400000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((IData)(
                                                                         (0xfff00000eeeeULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                                 << 3U)) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                                            ? 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (0xbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012990_)))
                                                                            : 
                                                                           ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                             ? 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012992_))
                                                                             : 
                                                                            (2U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___012991_))))))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012983_))
                                                                       : 
                                                                      (1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))) 
                                                                    << 2U)) 
                                                                | (IData)(vlSelf->__VdfgTmp_hb67239de__0))))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___012969_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010084_)));
    vlSelf->__VdfgTmp_ha5e2ba13__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((IData)(
                                                                (0xfff00000eeee0000ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf2cfe231__0))) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_hbb125bb5__0))));
    vlSelf->wasmetal_core__DOT___012602_ = (1U & (0xccaa0f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057306_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h7487032b__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012685_)))))));
    vlSelf->wasmetal_core__DOT___057257_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057255_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeee0000ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h00c406e7__0))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xf00eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7487032b__0))))))));
    vlSelf->wasmetal_core__DOT___067676_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011764_))))));
    vlSelf->wasmetal_core__DOT___011732_ = (1U & (IData)(
                                                         (0xccccaaaa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011764_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011763_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056645_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056647_)))))))));
    vlSelf->wasmetal_core__DOT___011684_ = (1U & (IData)(
                                                         (0xccccaaaa00f000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056648_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056647_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f11111111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056636_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056635_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056634_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056645_)))))))));
    vlSelf->wasmetal_core__DOT___056689_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056647_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056648_)))))))));
    vlSelf->wasmetal_core__DOT___036627_ = (1U & (0xd400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0))))))));
    vlSelf->__VdfgTmp_hf72e2656__0 = (((IData)(vlSelf->wasmetal_core__DOT___056481_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056480_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056479_)));
    vlSelf->wasmetal_core__DOT___072201_ = (1U & (IData)(
                                                         (0xb22b2bb22bb2b22bULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072180_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->__VdfgTmp_h1399f995__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x9669699669969669ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___072180_)))))))))));
    vlSelf->wasmetal_core__DOT___072202_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072180_))))));
    vlSelf->wasmetal_core__DOT___012356_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x55fc0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012029_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012028_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))))))))))));
    vlSelf->wasmetal_core__DOT___067544_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4448f15c__0))));
    vlSelf->wasmetal_core__DOT___068071_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6fa80fa__0))));
    vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030097_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030225_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    __VdfgTmp_h635c29e2__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0))));
    __VdfgTmp_h986ee838__0 = ((2U & ((6U >> (IData)(vlSelf->__VdfgTmp_h45f0a758__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0))));
    __VdfgTmp_h6ec4eab1__0 = ((4U & ((0xe8U >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h1ffb08a2__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x2bU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)))));
    __VdfgTmp_hfc0d441b__0 = ((4U & ((0x69U >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                     << 2U)) | ((2U 
                                                 & ((0x69U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5ffdcb06__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (0x17U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    __VdfgTmp_ha1bf32a7__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                               << 2U) | ((2U & ((0x96U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                << 1U)) 
                                         | (1U & (0x96U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h9a02691e__0)))));
    vlSelf->wasmetal_core__DOT___063556_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___063564_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___063572_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___063580_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128150___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029585_));
    if (vlSelf->wasmetal_core__DOT__sp__05b16__05d) {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b16__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030660_;
        vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030695_;
    }
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050255_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050255_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051305_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051305_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051307_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051307_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050269_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050272_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051311_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051311_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051304_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051304_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050273_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050273_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050262_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050262_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051312_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051312_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051530_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051530_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050266_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050266_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050140_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050140_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051306_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051306_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051280_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051280_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050276_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050276_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050166_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050166_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b34__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051308_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051308_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051283_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051283_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050278_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050278_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050155_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050155_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051310_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051310_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051300_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051300_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051285_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051285_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050274_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050268_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050268_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051299_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051299_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051282_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051282_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___050144_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050144_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___051380_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051380_) 
                         << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127434___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7a338fa__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022537_)))));
    vlSelf->wasmetal_core__DOT___022565_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___060482_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060481_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017414_)))))));
    vlSelf->wasmetal_core__DOT___018279_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058930_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058550_))));
    vlSelf->wasmetal_core__DOT___058551_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051509_)))));
    vlSelf->wasmetal_core__DOT___019034_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___018274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___017184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___059112_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->wasmetal_core__DOT___059106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___059153_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___059156_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006215_))))));
    vlSelf->wasmetal_core__DOT___059113_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006085_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049918_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049918_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050492_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050492_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049913_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049913_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051269_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051269_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049945_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049945_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051270_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051270_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050486_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050486_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049925_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049925_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051274_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051274_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051272_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051272_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050494_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050494_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127463___O 
        = (((8U & ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h13976eb2__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022737_)))));
    vlSelf->wasmetal_core__DOT___022741_ = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006151_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127454___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006400_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003808_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022667_)))));
    vlSelf->wasmetal_core__DOT___022671_ = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___063490_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063498_ = (1U & (8U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063506_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063514_ = (1U & (8U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128411___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032030_));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026458_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134155___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036766_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036765_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036764_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036763_)))) 
           ^ (((IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134155___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036730_)))));
    vlSelf->wasmetal_core__DOT___036734_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036766_)
                                                   ? (IData)(wasmetal_core__DOT___134155___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h9473bd37__0))));
    wasmetal_core__DOT___063168_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063174_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063180_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063186_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128061___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028292_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028258_)
            : (IData)(vlSelf->wasmetal_core__DOT___028227_));
    wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026566_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001537_));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031304_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034328_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034494_) 
           & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127969___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O)) 
            | (IData)(vlSelf->wasmetal_core__DOT___027473_)) 
           ^ (((IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027436_)))));
    vlSelf->wasmetal_core__DOT___027466_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027336_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027270_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b12__05d));
    wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x19U) & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x2000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x19U)
                  : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128487___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032881_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032880_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032879_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032878_)))) 
           ^ (((IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128487___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032844_)))));
    vlSelf->wasmetal_core__DOT___032849_ = ((IData)(vlSelf->wasmetal_core__DOT___032881_)
                                             ? (IData)(wasmetal_core__DOT___128487___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128015___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027816_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027815_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027814_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027813_)))) 
           ^ (((IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128015___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027779_)))));
    vlSelf->wasmetal_core__DOT___027784_ = ((IData)(vlSelf->wasmetal_core__DOT___027816_)
                                             ? (IData)(wasmetal_core__DOT___128015___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d));
    vlSelf->wasmetal_core__DOT___066650_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054115_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x13U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066772_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066769_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054119_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x14U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066896_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066893_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054127_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066855_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054123_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x15U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x19U) & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028103_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028069_)
                  : (vlSelf->insn_x >> 0x14U)));
    wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x19U)) & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128471___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032689_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032688_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032687_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032686_)))) 
           ^ (((IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128471___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032652_)))));
    vlSelf->wasmetal_core__DOT___032657_ = ((IData)(vlSelf->wasmetal_core__DOT___032689_)
                                             ? (IData)(wasmetal_core__DOT___128471___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134213___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037199_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037198_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037197_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037196_)))) 
           ^ (((IData)(wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134213___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037163_)))));
    vlSelf->wasmetal_core__DOT___037168_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037199_)
                                                   ? (IData)(wasmetal_core__DOT___134213___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h5a255a66__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127847___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026372_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026371_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026370_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026369_)))) 
           ^ (((IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127847___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026335_)))));
    vlSelf->wasmetal_core__DOT___026340_ = ((IData)(vlSelf->wasmetal_core__DOT___026372_)
                                             ? (IData)(wasmetal_core__DOT___127847___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128173___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
           ^ (((IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128173___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029506_)))));
    vlSelf->wasmetal_core__DOT___029479_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128173___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128293___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128293___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128293___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030691_)))));
    vlSelf->__VdfgTmp_hc60fc2d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011792_))));
    vlSelf->wasmetal_core__DOT___056767_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011792_)))));
    vlSelf->__VdfgTmp_h75e79c91__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012072_)))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012219_))))));
    vlSelf->wasmetal_core__DOT___057163_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011044_)))));
    vlSelf->wasmetal_core__DOT___011572_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011432_))))));
    vlSelf->wasmetal_core__DOT___057454_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h417b846d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011791_)))))))));
    vlSelf->wasmetal_core__DOT___011795_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011791_))))));
    vlSelf->wasmetal_core__DOT___057663_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012219_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012071_)))))))));
    vlSelf->wasmetal_core__DOT___012224_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012071_))))));
    vlSelf->wasmetal_core__DOT___011428_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011431_)))))))));
    vlSelf->wasmetal_core__DOT___011130_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011087_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->__VdfgTmp_hca83bd04__0 = (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011087_));
    vlSelf->wasmetal_core__DOT___056892_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012070_)))))))));
    vlSelf->wasmetal_core__DOT___012607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056592_)))))))));
    vlSelf->wasmetal_core__DOT___057380_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056715_)))))))));
    vlSelf->wasmetal_core__DOT___011908_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012781_)))))))));
    vlSelf->wasmetal_core__DOT___057627_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056890_)))))))));
    vlSelf->wasmetal_core__DOT___011293_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056591_)))))))));
    vlSelf->wasmetal_core__DOT___012256_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013057_)))))))));
    vlSelf->wasmetal_core__DOT___012387_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011087_)))))))));
    vlSelf->wasmetal_core__DOT___012558_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011332_)))))))));
    vlSelf->wasmetal_core__DOT___012808_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012780_)))))))));
    vlSelf->wasmetal_core__DOT___013034_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013056_)))))))));
    vlSelf->wasmetal_core__DOT___011079_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->wasmetal_core__DOT___011425_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011331_)))))))));
    vlSelf->wasmetal_core__DOT___011780_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012779_)))))))));
    vlSelf->wasmetal_core__DOT___012213_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))))));
    vlSelf->wasmetal_core__DOT___012405_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->__VdfgTmp_h2fb7cfc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011330_));
    vlSelf->__VdfgTmp_h3c43f86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___012779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012778_));
    vlSelf->wasmetal_core__DOT___012782_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010508_)
                                                      ? (IData)(
                                                                (0xefffffffffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0)))
                                                      : (IData)(
                                                                (0xecccccccccccccccULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0))))));
    if (vlSelf->wasmetal_core__DOT___010085_) {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010082_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xfa330000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xfff00000eeeeULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8262dffe__0)))))))))))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xeef0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012599_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012597_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012596_)))))));
        vlSelf->wasmetal_core__DOT___012926_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                    ? 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012779_))))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012778_))))));
    } else {
        vlSelf->wasmetal_core__DOT___056299_ = (1U 
                                                & (0xc5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010083_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010081_)))));
        vlSelf->wasmetal_core__DOT___057295_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012598_))));
        vlSelf->wasmetal_core__DOT___012926_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012782_)));
    }
    vlSelf->__VdfgTmp_h140002d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___011330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011329_));
    vlSelf->__VdfgTmp_hb3a32b8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010403_));
    vlSelf->__VdfgTmp_hdaecee48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012105_));
    vlSelf->wasmetal_core__DOT___057246_ = (1U & (0xcaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___010396_))))))))));
    vlSelf->wasmetal_core__DOT___012407_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010403_)))))))));
    vlSelf->wasmetal_core__DOT___012214_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012105_)))))))));
    vlSelf->wasmetal_core__DOT___011781_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012778_)))))))));
    vlSelf->__VdfgTmp_hd9ebd9b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012531_)));
    vlSelf->wasmetal_core__DOT___057090_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010403_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___056891_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012105_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))));
    vlSelf->wasmetal_core__DOT___056771_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012778_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___011294_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011330_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011329_))))))));
    vlSelf->wasmetal_core__DOT___011091_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010404_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010403_))))))));
    vlSelf->wasmetal_core__DOT___057577_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012105_))))))));
    vlSelf->wasmetal_core__DOT___010377_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_had4ae229__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa0033U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))))))))))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hc7be7ce5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056749_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056747_)));
    vlSelf->wasmetal_core__DOT___069149_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde86d559__0)))));
    vlSelf->wasmetal_core__DOT___056951_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056947_))))));
    vlSelf->wasmetal_core__DOT___012280_ = (1U & (IData)(
                                                         (0x1111ff000f0fffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057014_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057012_)))))))));
    vlSelf->wasmetal_core__DOT___056938_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012330_))));
    vlSelf->wasmetal_core__DOT___013081_ = (1U & (IData)(
                                                         (0xff00bbbbf0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057587_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))))))));
    vlSelf->wasmetal_core__DOT___057554_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013184_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    __VdfgTmp_h7baa8c24__0 = ((2U & ((0x2bU >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)))));
    vlSelf->__VdfgTmp_h84670069__0 = (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h39564552__0)))));
    vlSelf->__VdfgTmp_hcb4b0ef5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056463_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056462_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056461_)));
    vlSelf->wasmetal_core__DOT___066292_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->wasmetal_core__DOT___013077_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->__VdfgTmp_hcfb94f0b__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057558_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_))))));
    vlSelf->wasmetal_core__DOT___067960_ = (1U & (0xf1U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff00fff100000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h18f44539__0))));
    vlSelf->__VdfgTmp_h90d51bf1__0 = (((IData)(vlSelf->wasmetal_core__DOT___057504_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057468_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012980_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xff00fff1ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))))));
    vlSelf->wasmetal_core__DOT___036841_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x69U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))))));
    wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030098_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030226_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    vlSelf->__VdfgTmp_h0bfb68a4__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                      | (1U & (8U >> (IData)(__VdfgTmp_h635c29e2__0))));
    vlSelf->__VdfgTmp_h935fcb03__0 = ((2U & ((6U >> (IData)(__VdfgTmp_h635c29e2__0)) 
                                             << 1U)) 
                                      | (1U & (4U >> (IData)(__VdfgTmp_h986ee838__0))));
    vlSelf->__VdfgTmp_hab776b02__0 = ((2U & ((9U >> (IData)(__VdfgTmp_h986ee838__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (IData)(__VdfgTmp_h6ec4eab1__0))));
    vlSelf->wasmetal_core__DOT___036652_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xe8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bU 
                                                            >> (IData)(__VdfgTmp_hfc0d441b__0)))))));
    vlSelf->wasmetal_core__DOT___036651_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(__VdfgTmp_ha1bf32a7__0)))))));
    vlSelf->__VdfgTmp_h009676e6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(__VdfgTmp_ha1bf32a7__0)))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058816_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005962_))));
    vlSelf->wasmetal_core__DOT___058832_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___058841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005875_))));
    vlSelf->wasmetal_core__DOT___058854_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___058842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->wasmetal_core__DOT___058862_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b45__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006226_))))));
    vlSelf->wasmetal_core__DOT___058848_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___058828_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006159_))));
    vlSelf->wasmetal_core__DOT___058853_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006171_))));
    vlSelf->__VdfgTmp_hc26f8061__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d));
    vlSelf->wasmetal_core__DOT___058845_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005738_))));
    vlSelf->wasmetal_core__DOT___058817_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___058824_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b38__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b42__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006058_))))));
    vlSelf->wasmetal_core__DOT___058834_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006274_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___058838_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___058860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005935_))));
    vlSelf->wasmetal_core__DOT___058822_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006085_))));
    vlSelf->wasmetal_core__DOT___058861_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005816_))))));
    vlSelf->wasmetal_core__DOT___058827_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006051_))));
    vlSelf->wasmetal_core__DOT___058847_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006092_))));
    vlSelf->wasmetal_core__DOT___058855_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b14__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006400_))))));
    vlSelf->wasmetal_core__DOT___058851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005795_))));
    vlSelf->wasmetal_core__DOT___058850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006029_))));
    vlSelf->wasmetal_core__DOT___058823_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005982_))))));
    vlSelf->wasmetal_core__DOT___058833_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005823_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005903_))))));
    vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) {
        vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d;
        vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d;
        vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__;
    }
    vlSelf->__VdfgTmp_h2a29372f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h2bad41f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O)))))));
    vlSelf->__VdfgTmp_hfaf781e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->__VdfgTmp_h38639508__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hc23424b0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_h2a096466__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127434___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022565_));
    vlSelf->wasmetal_core__DOT___040087_ = (1U & (0xf220022U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058549_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048949_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___018498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___060246_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017940_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127574___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013739_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc3924088__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023601_)))));
    vlSelf->wasmetal_core__DOT___023618_ = ((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___059109_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___059107_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___059148_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005921_))));
    vlSelf->wasmetal_core__DOT___059116_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003809_))));
    vlSelf->wasmetal_core__DOT___059152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___059110_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___059154_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->wasmetal_core__DOT___059115_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003807_))));
    vlSelf->wasmetal_core__DOT___059147_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___059117_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059113_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059112_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003811_)))))))));
    vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) {
        vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d;
        vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d;
        vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___013683_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___002193_)))) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))))))))));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022741_));
    vlSelf->wasmetal_core__DOT____Vcellout___127557___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006178_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8744bfbd__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023480_)))));
    vlSelf->wasmetal_core__DOT___023497_ = ((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050145_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003807_))));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022671_));
    vlSelf->wasmetal_core__DOT___063491_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063490_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063489_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063499_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063507_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063506_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063505_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063515_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063514_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063513_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026459_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036768_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036734_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h1872cc15__0))));
    vlSelf->wasmetal_core__DOT___063171_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063168_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063167_)))))));
    vlSelf->wasmetal_core__DOT___063177_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063174_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063173_)))))));
    vlSelf->wasmetal_core__DOT___063183_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063180_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063179_)))))));
    vlSelf->wasmetal_core__DOT___063189_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063186_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063185_)))))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028293_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028228_));
    wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026567_)
            ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001569_));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128643___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034329_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034328_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034326_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034325_)))) 
           ^ (((IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128643___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034388_)))));
    vlSelf->wasmetal_core__DOT___034393_ = ((IData)(vlSelf->wasmetal_core__DOT___034329_) 
                                            & (IData)(wasmetal_core__DOT___128643___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128659___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034495_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034494_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034493_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034492_)))) 
           ^ (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034549_)))));
    vlSelf->wasmetal_core__DOT___034554_ = ((IData)(vlSelf->wasmetal_core__DOT___034495_) 
                                            & (IData)(wasmetal_core__DOT___128659___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044881_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       >> 1U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027466_));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027337_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b13__05d));
    wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 0x1aU) & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x4000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1aU)
                  : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032882_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032849_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___062837_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x14U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062829_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O))))))));
    vlSelf->wasmetal_core__DOT___062848_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x15U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062840_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062859_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x16U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062851_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062870_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128015___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x17U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062862_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128168___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128023___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027817_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027784_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d));
    wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_x >> 0x1aU) & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028104_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x15U)));
    wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__ 
        = ((~ (vlSelf->function_params >> 0x1aU)) & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___070652_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032690_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032657_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037200_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037168_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h590821b5__0))));
    vlSelf->wasmetal_core__DOT___054517_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054519_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054521_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054523_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128598___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127839___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063615_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063623_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063631_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063639_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026373_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026340_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128405___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
           ^ (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128405___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128405___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031937_)))));
    vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029479_));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011793_))))));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012224_));
    } else {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011790_))))));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012070_))))));
    }
    vlSelf->wasmetal_core__DOT___011951_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___056772_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011790_)))))))));
    vlSelf->wasmetal_core__DOT___056909_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))));
    vlSelf->__VdfgTmp_h7d32537f__0 = (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h1c56b6c5__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011087_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h07056034__0 = ((2U & ((IData)(
                                                     (0xf0f0ff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012632_))
                                                                       : 
                                                                      (0xdU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___012632_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___012631_))))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0))
                                                                       : 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h796615cc__0)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011300_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011299_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011572_))));
    vlSelf->__VdfgTmp_haf8803a1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0xfff0fff033335555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011557_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___011572_)
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011431_))))))));
    vlSelf->__VdfgTmp_h8088f5ad__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0x111111110f0f00ffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((0xf0110000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012631_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___012630_)))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xf00001111ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011566_))))))))))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012219_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___012224_))));
    vlSelf->wasmetal_core__DOT___011080_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                   ? 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hde352602__0))))
                                                   : 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))));
    vlSelf->wasmetal_core__DOT___011024_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))))));
    vlSelf->__VdfgTmp_h5d9b5f2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___057453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012808_))));
    vlSelf->wasmetal_core__DOT___057664_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013034_))));
    vlSelf->__VdfgTmp_h4aee2d94__0 = (((IData)(vlSelf->wasmetal_core__DOT___013034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hac971038__0 = (((IData)(vlSelf->wasmetal_core__DOT___011079_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hdab8ca95__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011079_));
    vlSelf->__VdfgTmp_hc7461e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___011425_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h11d85c9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011780_));
    vlSelf->__VdfgTmp_heceb31a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012213_));
    vlSelf->__VdfgTmp_h3659b78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012213_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h745845c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012405_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___012574_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0))))))));
    vlSelf->__VdfgTmp_h4fcaab62__0 = (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0));
    vlSelf->wasmetal_core__DOT___012818_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057389_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___012957_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057389_)))))));
    vlSelf->__VdfgTmp_h3b7e1022__0 = (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0));
    vlSelf->wasmetal_core__DOT___057447_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___011426_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h140002d8__0)))))))));
    vlSelf->wasmetal_core__DOT___011550_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011656_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0)))))))));
    vlSelf->wasmetal_core__DOT___011082_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0))))))));
    vlSelf->__VdfgTmp_hfde06fd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0));
    vlSelf->wasmetal_core__DOT___013035_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))))))));
    vlSelf->wasmetal_core__DOT___057537_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->__VdfgTmp_h25b48e48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hdaecee48__0));
    vlSelf->wasmetal_core__DOT___065822_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011780_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___012707_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0)))))));
    vlSelf->wasmetal_core__DOT___012576_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0))));
    vlSelf->wasmetal_core__DOT___057098_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_he11b9fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->__VdfgTmp_ha6c246b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___066419_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011293_)))))))));
    vlSelf->wasmetal_core__DOT___056668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___056334_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_hf218f314__0 = (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h358fed79__0))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057627_))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___036846_ = (1U & (IData)(
                                                         (0xff7f7f1717010100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h7baa8c24__0))))))));
    vlSelf->__VdfgTmp_h15cdecdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                       << 2U) | (IData)(__VdfgTmp_h7baa8c24__0));
    vlSelf->wasmetal_core__DOT___036629_ = (1U & (0x96696996U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072201_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x69U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))))));
    vlSelf->wasmetal_core__DOT___072213_ = (1U & (0xd4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x69U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___072214_ = (1U & (IData)(
                                                         (0xb24d4db24db2b24dULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xb2U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036841_)) 
                 & (0x69U >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128234___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030099_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030098_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030097_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030096_)))) 
           ^ (((IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128234___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030063_)))));
    vlSelf->wasmetal_core__DOT___030067_ = ((IData)(vlSelf->wasmetal_core__DOT___030099_)
                                             ? (IData)(wasmetal_core__DOT___128234___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128248___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030227_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030226_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030225_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030224_)))) 
           ^ (((IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128248___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030159_)))));
    vlSelf->wasmetal_core__DOT___030163_ = ((IData)(vlSelf->wasmetal_core__DOT___030227_)
                                             ? (IData)(wasmetal_core__DOT___128248___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT___036981_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT___036980_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    vlSelf->wasmetal_core__DOT___036979_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hab776b02__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(__VdfgTmp_h6ec4eab1__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf5f2577b__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(__VdfgTmp_hfc0d441b__0))))))));
    vlSelf->wasmetal_core__DOT___036978_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036652_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(__VdfgTmp_hfc0d441b__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7b621139__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(__VdfgTmp_ha1bf32a7__0))))))));
    vlSelf->wasmetal_core__DOT___036977_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036651_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    vlSelf->wasmetal_core__DOT___036976_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))))));
    vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___058846_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058842_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058841_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___058856_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058853_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc26f8061__0))))))));
    vlSelf->wasmetal_core__DOT___058839_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___058852_ = (1U & (IData)(
                                                         (0x5f13ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058848_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___058840_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058834_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058832_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005788_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005809_))))))))))));
    vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___023234_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfaf781e7__0))));
    vlSelf->wasmetal_core__DOT___023233_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005921_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))));
    vlSelf->wasmetal_core__DOT___023232_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc23424b0__0))));
    vlSelf->wasmetal_core__DOT___023231_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005875_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013783_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013737_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023618_));
    vlSelf->wasmetal_core__DOT___059111_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059107_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h83434591__0))))))));
    vlSelf->wasmetal_core__DOT___059158_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059154_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059153_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059152_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006144_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006015_))))))))))));
    vlSelf->wasmetal_core__DOT___059157_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005928_)))))))));
    vlSelf->wasmetal_core__DOT___059135_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059117_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059116_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059115_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013692_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050097_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006058_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023497_));
    vlSelf->wasmetal_core__DOT___050147_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006632_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050145_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003806_)))))))));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127853___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026460_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026459_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026458_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026457_)))) 
           ^ (((IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026423_)))));
    vlSelf->wasmetal_core__DOT___026427_ = ((IData)(vlSelf->wasmetal_core__DOT___026460_)
                                             ? (IData)(wasmetal_core__DOT___127853___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036769_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hed077be7__0))));
    vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028294_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028229_));
    vlSelf->wasmetal_core__DOT____Vcellout___127869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026568_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026567_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026566_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026565_)))) 
           ^ (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026498_)))));
    vlSelf->wasmetal_core__DOT___026502_ = ((IData)(vlSelf->wasmetal_core__DOT___026568_)
                                             ? (IData)(wasmetal_core__DOT___127869___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001581_));
    vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031339_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034330_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034393_));
    vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034496_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034554_));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027338_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128032___O 
        = (0xfU & ((vlSelf->insn_z >> 0x18U) ^ (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027944_))))));
    vlSelf->wasmetal_core__DOT___027948_ = ((vlSelf->insn_z 
                                             >> 0x1bU) 
                                            & (IData)(wasmetal_core__DOT___128032___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128272___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x1bU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x1aU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x19U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x18U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030479_)))));
    vlSelf->wasmetal_core__DOT___030483_ = (1U & ((0x8000000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x1bU)
                                                   : (IData)(wasmetal_core__DOT___128272___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032883_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027818_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128056___O 
        = (0xfU & ((vlSelf->insn_x >> 0x18U) ^ (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028170_))))));
    vlSelf->wasmetal_core__DOT___028174_ = ((vlSelf->insn_x 
                                             >> 0x1bU) 
                                            & (IData)(wasmetal_core__DOT___128056___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028105_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x16U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128320___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x1bU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x1aU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x19U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x18U)))))) 
           ^ (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030961_)))));
    vlSelf->wasmetal_core__DOT___030965_ = ((~ (vlSelf->function_params 
                                                >> 0x1bU)) 
                                            & (IData)(wasmetal_core__DOT___128320___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070654_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070652_)))))))));
    vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032691_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037201_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h137eceb9__0))));
    vlSelf->wasmetal_core__DOT___054518_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054517_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x12U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
}
