#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__8(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__8\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___001742_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d)))))));
    vlSelf->wasmetal_core__DOT___002197_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d)))))));
    vlSelf->wasmetal_core__DOT___002517_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3fcac4a1__0))))));
    vlSelf->wasmetal_core__DOT___002394_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d)))))));
    vlSelf->wasmetal_core__DOT___002922_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5fb0de62__0))))));
    vlSelf->wasmetal_core__DOT___002640_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048862_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048861_))))));
    vlSelf->wasmetal_core__DOT___002679_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048842_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048841_))))));
    vlSelf->wasmetal_core__DOT___002432_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))))));
    vlSelf->wasmetal_core__DOT___002798_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048860_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048859_))))));
    vlSelf->wasmetal_core__DOT___002840_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048685_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048684_))))));
    vlSelf->wasmetal_core__DOT___002354_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d)))))));
    vlSelf->wasmetal_core__DOT___002718_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048852_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048851_))))));
    vlSelf->wasmetal_core__DOT___002758_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048850_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048849_))))));
    vlSelf->wasmetal_core__DOT___003053_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048923_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048922_))))));
    vlSelf->wasmetal_core__DOT___002882_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048870_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048869_))))));
    vlSelf->wasmetal_core__DOT___002077_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d)))))));
    vlSelf->wasmetal_core__DOT___002114_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d)))))));
    vlSelf->wasmetal_core__DOT___002151_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d)))))));
    vlSelf->wasmetal_core__DOT___002478_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048730_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048729_))))));
    vlSelf->wasmetal_core__DOT___002315_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))))));
    vlSelf->wasmetal_core__DOT___002592_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8ae31ec8__0))))));
    vlSelf->wasmetal_core__DOT___002553_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d)))))));
    vlSelf->__VdfgTmp_h824f53a5__0 = (((IData)(vlSelf->wasmetal_core__DOT___064477_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___067810_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053928_))));
    vlSelf->wasmetal_core__DOT___026480_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053928_))));
    vlSelf->wasmetal_core__DOT___071927_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071922_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071926_)))));
    vlSelf->wasmetal_core__DOT___044355_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026977_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026988_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026993_)))));
    vlSelf->wasmetal_core__DOT___065056_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063857_))))));
    vlSelf->wasmetal_core__DOT___070507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d))));
    vlSelf->__VdfgTmp_h425ce738__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->__VdfgTmp_hca681a3f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->__VdfgTmp_h776ad714__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d));
    vlSelf->wasmetal_core__DOT___007908_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007907_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128435___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001487_)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001475_)) 
                                    << 2U)) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h5ad60c71__0)));
    vlSelf->wasmetal_core__DOT___063119_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT___028246_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT___048877_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b4__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT___005738_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b4__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004475_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h627c070d__0)))))));
    vlSelf->wasmetal_core__DOT___061994_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007334_))));
    vlSelf->wasmetal_core__DOT___010358_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007334_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007333_)))))))));
    vlSelf->wasmetal_core__DOT___045829_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               << 1U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4104a354__0))))))));
    vlSelf->wasmetal_core__DOT___044504_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84f9890b__0))))))));
    vlSelf->__VdfgTmp_hc7b853f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h84f9890b__0));
    vlSelf->wasmetal_core__DOT___067749_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053927_))));
    vlSelf->wasmetal_core__DOT___026479_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053927_))));
    vlSelf->wasmetal_core__DOT___071925_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071920_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071924_)))));
    vlSelf->wasmetal_core__DOT___001996_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048803_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___065074_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d)))));
    vlSelf->__VdfgTmp_hcc4a801d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___007895_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007894_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd3bfd495__0)))));
    vlSelf->wasmetal_core__DOT___063113_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT___028245_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b3__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT___005935_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b3__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004697_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hfcbc0180__0)))))));
    vlSelf->__VdfgTmp_h8d9b1452__0 = (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007300_));
    vlSelf->wasmetal_core__DOT___001846_ = (1U & (0xdcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001662_))))));
    vlSelf->wasmetal_core__DOT___002385_ = (1U & (0xdcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000574_))))));
    vlSelf->wasmetal_core__DOT___026476_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053926_))));
    vlSelf->wasmetal_core__DOT___026454_ = (1U & (0x7f0080ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053924_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x8000000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053945_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053944_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053939_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053938_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053933_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053932_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x8000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053941_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053937_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053947_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053927_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053925_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053953_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053952_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053935_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053934_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053929_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053928_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053942_))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___053954_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053951_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053950_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053949_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053948_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053923_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___071918_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h87854ac5__0))));
    vlSelf->wasmetal_core__DOT___071921_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071920_)))));
    vlSelf->wasmetal_core__DOT___071917_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071916_)))));
    vlSelf->wasmetal_core__DOT___044352_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026955_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026966_)))));
    vlSelf->wasmetal_core__DOT___001951_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048800_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___042296_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84f9890b__0))))))));
    vlSelf->__VdfgTmp_h11b4d04e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d));
    vlSelf->wasmetal_core__DOT___063934_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001886_))))));
    vlSelf->__VdfgTmp_hf4328824__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___007887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->__VdfgTmp_h0d1a9c72__0 = ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h78b443e9__0)) 
                                             << 2U)) 
                                      | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hc8dfb864__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h93039dba__0)))));
    vlSelf->wasmetal_core__DOT___007886_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h78b443e9__0)))));
    vlSelf->wasmetal_core__DOT___063107_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT___028242_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b2__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT___005716_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h989e4977__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b2__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004771_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd09f2908__0)))))));
    vlSelf->wasmetal_core__DOT___061449_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007301_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007274_))));
    vlSelf->__VdfgTmp_h5af86920__0 = (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007273_));
    vlSelf->__VdfgTmp_h0643d6d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000180_))));
    vlSelf->__VdfgTmp_he03432df__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000170_))));
    vlSelf->wasmetal_core__DOT___002231_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000720_))))));
    vlSelf->wasmetal_core__DOT___001289_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001285_))))));
    vlSelf->wasmetal_core__DOT___002147_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000820_))))));
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029153_));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031072_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031039_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___055423_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007798_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007281_)))))))));
    vlSelf->__VdfgTmp_ha44be0e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007281_))));
    vlSelf->__VdfgTmp_hfd8d7c51__0 = (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054807_));
    vlSelf->wasmetal_core__DOT___048599_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048597_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005389_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005390_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005387_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005388_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b58__05d)))))))));
    vlSelf->wasmetal_core__DOT___048728_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048597_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001080_))))));
    vlSelf->wasmetal_core__DOT___055428_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054820_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___010591_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___007549_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6ee5998b__0)))));
    vlSelf->wasmetal_core__DOT___054821_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ee5998b__0)))));
    vlSelf->wasmetal_core__DOT___055427_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007689_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7690c014__0)))));
    vlSelf->wasmetal_core__DOT___007453_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7690c014__0)))));
    vlSelf->wasmetal_core__DOT___002800_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048858_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4403b5cc__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h56116db4__0))))))))))))))));
    vlSelf->__VdfgTmp_h8be24d75__0 = (((IData)(vlSelf->wasmetal_core__DOT___054807_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054808_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054809_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054810_))));
    vlSelf->wasmetal_core__DOT___055424_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007545_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h01d6394a__0)))));
    vlSelf->wasmetal_core__DOT___007259_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h01d6394a__0)))));
    vlSelf->__VdfgTmp_h1e9537b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007280_))));
    vlSelf->__VdfgTmp_h78fd8e0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054808_));
    vlSelf->wasmetal_core__DOT___055426_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007547_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd1dc222f__0)))));
    vlSelf->wasmetal_core__DOT___054817_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1dc222f__0)))));
    vlSelf->wasmetal_core__DOT___061478_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007258_))));
    vlSelf->wasmetal_core__DOT___007469_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007308_))))));
    vlSelf->__VdfgTmp_hd70fe4ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051493_));
    vlSelf->wasmetal_core__DOT___054338_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc3b7ffa9__0)))));
    vlSelf->wasmetal_core__DOT___009846_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc3b7ffa9__0)))));
    vlSelf->wasmetal_core__DOT___048604_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048602_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9462500e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005399_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005400_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___048717_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048602_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001102_))))));
    vlSelf->wasmetal_core__DOT___055498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054865_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___010585_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007703_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___007570_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5ba532b7__0)))));
    vlSelf->wasmetal_core__DOT___054866_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h5ba532b7__0)))));
    vlSelf->wasmetal_core__DOT___007488_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007367_))))));
    vlSelf->__VdfgTmp_hbb17ca10__0 = (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054948_));
    vlSelf->wasmetal_core__DOT___048658_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048656_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005409_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005410_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005407_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005408_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___048712_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048656_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001124_))))));
    vlSelf->wasmetal_core__DOT___055791_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___007590_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h127745a0__0)))));
    vlSelf->wasmetal_core__DOT___007718_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h127745a0__0)))));
    vlSelf->wasmetal_core__DOT___048653_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048651_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005419_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005420_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005417_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005418_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___048714_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048651_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001146_))))));
    vlSelf->wasmetal_core__DOT___055594_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007604_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h2e0ea116__0)))));
    vlSelf->wasmetal_core__DOT___007729_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2e0ea116__0)))));
    vlSelf->wasmetal_core__DOT___048668_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048666_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005456_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005457_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005454_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005455_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b62__05d)))))))));
    vlSelf->wasmetal_core__DOT___019197_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048666_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001168_))))));
    vlSelf->wasmetal_core__DOT___063801_ = (1U & (0xd00d0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063795_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h136edfac__0))))));
    vlSelf->__VdfgTmp_h1f51ea8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___054995_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054996_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054998_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055000_))));
    vlSelf->wasmetal_core__DOT___055650_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007624_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->wasmetal_core__DOT___055001_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h855fc881__0)))));
    vlSelf->wasmetal_core__DOT___010753_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xff00aaaaf0f0ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007393_)))))))));
    vlSelf->__VdfgTmp_h02da39da__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007393_))));
    vlSelf->__VdfgTmp_h4d98d40a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054987_));
    vlSelf->wasmetal_core__DOT___055497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h009b2026__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h815644ec__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h41aaabca__0))))));
    vlSelf->wasmetal_core__DOT___007462_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h41aaabca__0)))));
    vlSelf->__VdfgTmp_h4ffde934__0 = (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054907_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054908_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054909_))));
    vlSelf->wasmetal_core__DOT___055517_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h4b751076__0 = (((IData)(vlSelf->wasmetal_core__DOT___007472_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054906_));
    vlSelf->__VdfgTmp_h2eb2dfca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054956_));
    vlSelf->__VdfgTmp_h2aa6a52e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hbda9acd7__0))))));
    vlSelf->wasmetal_core__DOT___007489_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbda9acd7__0)))));
    vlSelf->wasmetal_core__DOT___002842_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048868_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2d637bc4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___063784_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063779_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063778_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h51fc7bb2__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h6d3f2850__0)))))))))));
    vlSelf->__VdfgTmp_h4ab1d453__0 = (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___051491_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051498_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___051496_))));
    vlSelf->wasmetal_core__DOT___055494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007566_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h878f9978__0)))));
    vlSelf->wasmetal_core__DOT___007286_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h878f9978__0)))));
    vlSelf->__VdfgTmp_hf224ceca__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h6eb17b7a__0));
    vlSelf->wasmetal_core__DOT___055809_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055590_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055593_)))));
    vlSelf->wasmetal_core__DOT___007600_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h624c4f06__0)))));
    vlSelf->wasmetal_core__DOT___007346_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h624c4f06__0)))));
    vlSelf->wasmetal_core__DOT___055503_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___051493_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055492_)))));
    vlSelf->wasmetal_core__DOT___061480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007257_))));
    vlSelf->wasmetal_core__DOT___007584_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007307_))))));
    vlSelf->__VdfgTmp_h721400e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051491_));
    vlSelf->wasmetal_core__DOT___002884_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1867682__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h46733dea__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___063746_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063740_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h18ff28cf__0))))));
    vlSelf->wasmetal_core__DOT___055646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007628_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                     & (IData)(
                                                               (0xccaaf0f000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h40471efb__0))))) 
                                                    << 1U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                      & (IData)(
                                                                (0xccaa0000f0f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                                      << 4U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_haf65e04e__0)))))))));
    vlSelf->wasmetal_core__DOT___007372_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h40471efb__0)))));
    vlSelf->__VdfgTmp_h2014cd64__0 = (((IData)(vlSelf->wasmetal_core__DOT___054899_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054900_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054901_))));
    vlSelf->wasmetal_core__DOT___055512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054898_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___053918_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he34a288c__0)))));
    vlSelf->wasmetal_core__DOT___007471_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he34a288c__0)))));
    vlSelf->wasmetal_core__DOT___055599_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055588_)))));
    vlSelf->wasmetal_core__DOT___007618_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007366_))))));
    vlSelf->__VdfgTmp_h112f9280__0 = (((IData)(vlSelf->wasmetal_core__DOT___007344_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054949_));
    vlSelf->wasmetal_core__DOT___007568_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8f363e22__0)))));
    vlSelf->wasmetal_core__DOT___054862_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8f363e22__0)))));
    vlSelf->wasmetal_core__DOT___055644_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007639_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007392_))))));
    vlSelf->__VdfgTmp_h24bf73d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054988_));
    vlSelf->wasmetal_core__DOT___007588_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hffa75465__0)))));
    vlSelf->wasmetal_core__DOT___007720_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hffa75465__0)))));
    vlSelf->wasmetal_core__DOT___055597_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055592_)))));
    vlSelf->wasmetal_core__DOT___007602_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h40b73a73__0)))));
    vlSelf->wasmetal_core__DOT___007731_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h40b73a73__0)))));
    vlSelf->wasmetal_core__DOT___055653_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055649_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055648_)))));
    vlSelf->wasmetal_core__DOT___007622_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc57757c5__0)))));
    vlSelf->wasmetal_core__DOT___054997_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc57757c5__0)))));
    vlSelf->wasmetal_core__DOT___002281_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048763_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22b2afd4__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___010588_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0ccccff00aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007257_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007280_)))))))));
    vlSelf->__VdfgTmp_h7b8e4425__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007258_))));
    vlSelf->__VdfgTmp_hc5dd9afa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054809_));
    vlSelf->wasmetal_core__DOT___061863_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061861_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056769_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010537_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010590_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010880_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010932_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011503_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011014_)))))))))))))))));
    vlSelf->__VdfgTmp_h1d87626c__0 = (((IData)(vlSelf->wasmetal_core__DOT___054815_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054816_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054818_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054820_))));
    vlSelf->wasmetal_core__DOT___055429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054818_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007690_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h15014ab6__0)))));
    vlSelf->wasmetal_core__DOT___054819_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h15014ab6__0)))));
    vlSelf->__VdfgTmp_hcd9d6cde__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007254_))));
    vlSelf->__VdfgTmp_he2e8a11a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054767_));
    vlSelf->wasmetal_core__DOT___048616_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048614_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hcea60642__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005446_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005447_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___048711_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048614_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001058_))))));
    vlSelf->__VdfgTmp_h3e487a94__0 = (((IData)(vlSelf->wasmetal_core__DOT___054775_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054777_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054779_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054781_))));
    vlSelf->wasmetal_core__DOT___055373_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054781_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___011713_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___007529_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h88de5544__0)))));
    vlSelf->wasmetal_core__DOT___054782_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h88de5544__0)))));
    vlSelf->wasmetal_core__DOT___007526_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3f534570__0))))));
    vlSelf->__VdfgTmp_hc18298c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h3f534570__0));
    vlSelf->wasmetal_core__DOT___055378_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___055316_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055367_)))));
    vlSelf->__VdfgTmp_h65d58b23__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007253_))));
    vlSelf->__VdfgTmp_ha7d64f39__0 = (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054768_));
    vlSelf->__VdfgTmp_h84babf9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054767_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054768_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054769_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054770_))));
    vlSelf->wasmetal_core__DOT___055369_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hee719ca8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h5a84499c__0));
    vlSelf->wasmetal_core__DOT___055376_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055371_)))));
    vlSelf->wasmetal_core__DOT___060795_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff6b6a1f__0)))));
    vlSelf->wasmetal_core__DOT___055135_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc86399cc__0))))));
    vlSelf->wasmetal_core__DOT___007527_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc86399cc__0))))));
    vlSelf->wasmetal_core__DOT___062001_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061999_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057094_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057128_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057130_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010533_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010546_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010854_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010911_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011508_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011124_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010961_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055792_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055516_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055519_)))));
    vlSelf->wasmetal_core__DOT___055520_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055519_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055518_)))));
    vlSelf->__VdfgTmp_hc98b4d16__0 = (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007472_));
    vlSelf->__VdfgTmp_hf21032c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054908_));
    vlSelf->__VdfgTmp_hee831718__0 = (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054957_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054958_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054959_))));
    vlSelf->wasmetal_core__DOT___055595_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054958_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h13d2f137__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007484_));
    vlSelf->__VdfgTmp_hd27b8df6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054958_));
    vlSelf->wasmetal_core__DOT___062114_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057442_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057450_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010528_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010559_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010755_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010868_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010925_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010958_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010969_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055830_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055648_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055651_)))));
    vlSelf->wasmetal_core__DOT___007743_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7146d025__0)))));
    vlSelf->wasmetal_core__DOT___054999_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7146d025__0)))));
    vlSelf->wasmetal_core__DOT___055782_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055492_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055495_)))));
    vlSelf->wasmetal_core__DOT___061484_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007260_))));
    vlSelf->wasmetal_core__DOT___007834_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007284_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007307_)))))))));
    vlSelf->wasmetal_core__DOT___007717_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007285_))))));
    vlSelf->__VdfgTmp_he6aadab7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051498_));
    vlSelf->__VdfgTmp_ha87b9f86__0 = (((IData)(vlSelf->wasmetal_core__DOT___054860_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054861_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054863_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054865_))));
    vlSelf->wasmetal_core__DOT___055499_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054863_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007706_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4fcd3c01__0)))));
    vlSelf->wasmetal_core__DOT___054864_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4fcd3c01__0)))));
    vlSelf->wasmetal_core__DOT___002317_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048748_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h63a6348e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___055522_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055515_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055514_)))));
    vlSelf->wasmetal_core__DOT___007585_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0))))));
    vlSelf->__VdfgTmp_h6ab1a2ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0));
    vlSelf->wasmetal_core__DOT___063756_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063748_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_ha853ba7f__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003449_)))))))));
    vlSelf->wasmetal_core__DOT___002594_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048745_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9eae91ba__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))))))))))))))));
    vlSelf->__VdfgTmp_hebd182eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054949_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054950_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054951_))));
    vlSelf->wasmetal_core__DOT___055591_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___061193_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007484_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054956_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054958_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054948_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054950_))))))))))))));
    vlSelf->wasmetal_core__DOT___007739_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007345_))))));
    vlSelf->wasmetal_core__DOT___027489_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007730_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007367_)))))))));
    vlSelf->__VdfgTmp_h642b0391__0 = (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054950_));
    vlSelf->wasmetal_core__DOT___002555_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048534_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h76527ded__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))))))))))))))));
    vlSelf->__VdfgTmp_h401bf3cf__0 = (((IData)(vlSelf->wasmetal_core__DOT___054987_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054988_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054989_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054990_))));
    vlSelf->wasmetal_core__DOT___055647_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h79c46d44__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___007740_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___007234_))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007370_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007392_))))))))));
    vlSelf->wasmetal_core__DOT___007754_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007371_))))));
    vlSelf->__VdfgTmp_h597612ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054989_));
    vlSelf->wasmetal_core__DOT___055752_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055370_)))));
    vlSelf->wasmetal_core__DOT___011712_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0ccccff00aaaaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007230_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007253_)))))))));
    vlSelf->__VdfgTmp_h3297ffb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007231_))));
    vlSelf->__VdfgTmp_h5e3b944f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054769_));
    vlSelf->wasmetal_core__DOT___061774_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061771_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056598_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056600_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056622_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010540_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056327_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010773_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010892_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011537_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056427_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011011_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055750_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055371_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055374_)))));
    vlSelf->wasmetal_core__DOT___010215_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007235_)
                                                   ? 
                                                  (0xf1111U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007678_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd5802a9c__0)))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007679_)))));
    vlSelf->wasmetal_core__DOT___007528_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0))))));
    vlSelf->__VdfgTmp_hc52c52a3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0));
    vlSelf->__VdfgTmp_h73281823__0 = (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hffdded68__0)));
    vlSelf->wasmetal_core__DOT___054895_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007523_));
    vlSelf->wasmetal_core__DOT___054739_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007523_));
    vlSelf->wasmetal_core__DOT___053784_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8893fd49__0))))));
    vlSelf->wasmetal_core__DOT___054149_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h8893fd49__0))))));
    vlSelf->wasmetal_core__DOT___048611_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048609_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc3acb233__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005436_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005437_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___048713_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048609_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001036_))))));
    vlSelf->wasmetal_core__DOT___053789_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha292c154__0))))));
    vlSelf->wasmetal_core__DOT___007664_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_ha292c154__0))))));
    vlSelf->wasmetal_core__DOT___007660_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007519_));
    vlSelf->wasmetal_core__DOT___007510_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007519_));
    vlSelf->wasmetal_core__DOT___053788_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7780ec55__0))))));
    vlSelf->wasmetal_core__DOT___054141_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h7780ec55__0))))));
    vlSelf->__VdfgTmp_h3265141f__0 = (((IData)(vlSelf->wasmetal_core__DOT___054706_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054705_));
    vlSelf->wasmetal_core__DOT___055326_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___054893_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007522_));
    vlSelf->wasmetal_core__DOT___054738_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007522_));
    vlSelf->wasmetal_core__DOT___053783_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2814f082__0))))));
    vlSelf->wasmetal_core__DOT___054140_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2814f082__0))))));
    vlSelf->wasmetal_core__DOT___055727_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055328_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055331_)))));
    vlSelf->wasmetal_core__DOT___060689_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060656_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007190_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha89e6386__0)))));
    vlSelf->wasmetal_core__DOT___007661_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007520_));
    vlSelf->wasmetal_core__DOT___007507_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007520_));
    vlSelf->wasmetal_core__DOT___053785_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h42498a1f__0))))));
    vlSelf->wasmetal_core__DOT___054142_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h42498a1f__0))))));
    vlSelf->__VdfgTmp_h705cf6e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054688_));
    vlSelf->wasmetal_core__DOT___055330_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007662_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007518_));
    vlSelf->wasmetal_core__DOT___007509_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007518_));
    vlSelf->wasmetal_core__DOT___053787_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0))))));
    vlSelf->wasmetal_core__DOT___054152_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0))))));
    vlSelf->__VdfgTmp_h2142849a__0 = (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054705_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054701_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054698_))));
    vlSelf->__VdfgTmp_hbbe663c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054701_));
    vlSelf->wasmetal_core__DOT___055329_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___054894_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007521_));
    vlSelf->wasmetal_core__DOT___007508_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007521_));
    vlSelf->wasmetal_core__DOT___053786_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0))))));
    vlSelf->wasmetal_core__DOT___054139_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0))))));
    vlSelf->wasmetal_core__DOT___061661_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061659_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056331_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056335_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056371_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056382_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056326_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056367_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056381_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011519_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056428_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011004_)))))))))))))))));
    vlSelf->__VdfgTmp_h6ef442fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054688_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054682_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___054674_))));
    vlSelf->wasmetal_core__DOT___060776_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060773_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019222_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0x555533330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054691_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054682_)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x555533330f0f00ffULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___019221_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054709_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054702_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054708_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054701_))))))))))))));
    vlSelf->__VdfgTmp_hebcfe313__0 = (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054682_));
    vlSelf->wasmetal_core__DOT___055333_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___061627_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))));
    vlSelf->wasmetal_core__DOT___054735_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h73cf3648__0))))));
    vlSelf->wasmetal_core__DOT___007663_ = ((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007517_));
    vlSelf->wasmetal_core__DOT___007506_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___007204_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___007517_));
    vlSelf->wasmetal_core__DOT___053790_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0))))));
    vlSelf->wasmetal_core__DOT___054151_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0))))));
    vlSelf->wasmetal_core__DOT___055859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055319_))));
    vlSelf->wasmetal_core__DOT___010569_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007755_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007234_)))));
    vlSelf->wasmetal_core__DOT___007645_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->wasmetal_core__DOT___055047_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1fccf85f__0)))));
    vlSelf->__VdfgTmp_hce1a9eab__0 = (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055035_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055036_))));
    vlSelf->wasmetal_core__DOT___055672_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___061479_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007371_))));
    vlSelf->wasmetal_core__DOT___007504_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007420_))))));
    vlSelf->__VdfgTmp_h064a3607__0 = (((IData)(vlSelf->wasmetal_core__DOT___007397_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055033_));
    vlSelf->wasmetal_core__DOT___045636_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050411_))));
    vlSelf->wasmetal_core__DOT___135372___DOT__CO__BRA__1__KET__ 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050411_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d))));
    vlSelf->__VdfgTmp_h0fc2ac4f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                        & (IData)((0xccaa0000f0f0ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0)))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                 & (IData)(
                                                           (0xccaaf0f000000000ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                              << 5U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h62d1863a__0))))));
    vlSelf->wasmetal_core__DOT___007497_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h62d1863a__0)))));
    vlSelf->wasmetal_core__DOT___003055_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048926_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h67e9fb36__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___055861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055673_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055676_)))));
    vlSelf->wasmetal_core__DOT___007641_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h69484b9c__0)))));
    vlSelf->wasmetal_core__DOT___007398_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h69484b9c__0)))));
    vlSelf->wasmetal_core__DOT___061995_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007396_))));
    vlSelf->wasmetal_core__DOT___061481_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007370_))));
    vlSelf->wasmetal_core__DOT___007659_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007419_))))));
    vlSelf->__VdfgTmp_he97c005b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055034_));
    vlSelf->wasmetal_core__DOT___050433_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050411_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050410_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050409_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3a53928b__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))))))));
    vlSelf->wasmetal_core__DOT___062170_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062169_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057536_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057539_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057573_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010529_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010568_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010749_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010874_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011527_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011518_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011867_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010976_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___055680_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055676_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055675_)))));
    vlSelf->wasmetal_core__DOT___007643_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4a43ab44__0)))));
    vlSelf->wasmetal_core__DOT___055043_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h4a43ab44__0)))));
    vlSelf->__VdfgTmp_h0e8d73de__0 = ((2U & ((0x40U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050410_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___050407_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___050421_)))));
    vlSelf->wasmetal_core__DOT___048628_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff000b0bffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048626_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xeU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he5858a3c__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005497_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___048727_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x5533f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048626_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001014_))))));
    vlSelf->__VdfgTmp_h703df812__0 = (((IData)(vlSelf->wasmetal_core__DOT___055041_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055044_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___055046_))));
    vlSelf->wasmetal_core__DOT___055678_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007758_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaaf0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6127a0a0__0)))));
    vlSelf->wasmetal_core__DOT___055045_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6127a0a0__0)))));
    vlSelf->wasmetal_core__DOT___055681_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055674_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055673_)))));
    vlSelf->wasmetal_core__DOT___055862_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055671_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055674_)))));
    vlSelf->wasmetal_core__DOT___061485_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007373_))));
    vlSelf->wasmetal_core__DOT___007769_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007397_))))));
    vlSelf->__VdfgTmp_h72b22246__0 = (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055035_));
    vlSelf->wasmetal_core__DOT___002390_ = (1U & (0xacc0cccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb5b904ce__0)))));
    vlSelf->wasmetal_core__DOT___002235_ = (1U & (IData)(
                                                         (0xacccc000cccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb5b904ce__0)))))));
    vlSelf->wasmetal_core__DOT___055665_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008469_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hb23bd85a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008469_));
    vlSelf->wasmetal_core__DOT___048663_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048661_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he9d835d5__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___017194_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048661_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))));
    vlSelf->__VdfgTmp_h2926b28a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d));
    vlSelf->wasmetal_core__DOT___069240_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___070500_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->wasmetal_core__DOT___063903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d))));
    vlSelf->__VdfgTmp_h0410a6dd__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d));
    vlSelf->wasmetal_core__DOT___010414_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008470_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027392_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b63__05d))));
    vlSelf->wasmetal_core__DOT___005713_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048002_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048001_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he9d835d5__0))))))));
    vlSelf->__VdfgTmp_h68f6955f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008357_));
    vlSelf->wasmetal_core__DOT___047926_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047924_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde5a6edf__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d 
        = (1U & (IData)((0xffff0000ffffff10ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048903_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048902_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___047924_)))))))));
    vlSelf->wasmetal_core__DOT___068660_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010444_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068648_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008358_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027379_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b51__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                  ? (0xceU >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b51__05d))))
                  : (0xf0f0fef0U >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde5a6edf__0)))))));
    vlSelf->wasmetal_core__DOT___055419_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hb1732b67__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008349_));
    vlSelf->wasmetal_core__DOT___047919_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047917_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005545_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005546_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___014245_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048920_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048919_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047917_)))))))));
    vlSelf->wasmetal_core__DOT___068611_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h9c2489b5__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d));
    vlSelf->wasmetal_core__DOT___010439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008350_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027378_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b50__05d))));
    vlSelf->__VdfgTmp_he7f579a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008341_));
    vlSelf->wasmetal_core__DOT___044413_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed1a6099__0))))))));
    vlSelf->wasmetal_core__DOT___044437_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063329_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063327_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063325_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT___047936_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005537_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005538_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b49__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047933_))))))))))));
    vlSelf->wasmetal_core__DOT___013778_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048921_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047933_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068559_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042172_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___010434_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008342_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027376_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b49__05d))));
    vlSelf->__VdfgTmp_hab846b7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___047944_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005655_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005656_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b48__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047941_))))))))))));
    vlSelf->wasmetal_core__DOT___013780_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048918_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047941_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068483_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h1e5c31ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->__VdfgTmp_h4a43881d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d));
    vlSelf->wasmetal_core__DOT___010429_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008334_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027375_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b48__05d))));
    vlSelf->wasmetal_core__DOT___007772_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc859778d__0)))));
    vlSelf->wasmetal_core__DOT___055663_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h92b02c04__0 = (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008318_));
    vlSelf->wasmetal_core__DOT___047867_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047862_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047861_))))));
    vlSelf->wasmetal_core__DOT___068430_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h503e9cd3__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d));
    vlSelf->wasmetal_core__DOT___010710_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008319_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027374_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b47__05d))));
    vlSelf->wasmetal_core__DOT___002111_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))));
    if (vlSelf->wasmetal_core__DOT___007204_) {
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007422_));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007395_));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007369_));
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007310_));
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___007283_));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf8957689__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010309_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007418_))))));
        vlSelf->wasmetal_core__DOT___010330_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007391_))))));
        vlSelf->wasmetal_core__DOT___010320_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007365_))))));
        vlSelf->wasmetal_core__DOT___010349_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007306_))))));
        vlSelf->wasmetal_core__DOT___010368_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___007279_))))));
        vlSelf->wasmetal_core__DOT___056183_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3a577ede__0)));
    }
    vlSelf->__VdfgTmp_h8565eee7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008310_));
    vlSelf->wasmetal_core__DOT___055638_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___044412_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h79eb8028__0))))))));
    vlSelf->wasmetal_core__DOT___044436_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063319_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))))));
    vlSelf->wasmetal_core__DOT___047860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005521_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005522_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b46__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047857_))))))))))));
    vlSelf->wasmetal_core__DOT___013918_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047857_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068406_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___063914_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d))));
    vlSelf->wasmetal_core__DOT___042171_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___010705_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008311_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027373_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b46__05d))));
    vlSelf->__VdfgTmp_ha45fb011__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h8744bfbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006274_));
    vlSelf->__VdfgTmp_h4ce8c3b1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008302_));
    vlSelf->wasmetal_core__DOT___047842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005561_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005562_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047839_))))))))))));
    vlSelf->wasmetal_core__DOT___013738_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048904_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047839_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068351_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068340_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008303_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027372_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b45__05d))));
    vlSelf->wasmetal_core__DOT___001780_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001287_))))));
    vlSelf->wasmetal_core__DOT___002110_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))));
    vlSelf->wasmetal_core__DOT___047850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005517_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005518_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047847_))))))))))));
    vlSelf->__VdfgTmp_ha2b229ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___047847_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_phase));
    vlSelf->wasmetal_core__DOT___068297_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h22bd1162__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d));
    vlSelf->wasmetal_core__DOT___010113_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008295_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027371_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b44__05d))));
    vlSelf->wasmetal_core__DOT___002272_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000720_)))))))));
    vlSelf->wasmetal_core__DOT___000168_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000819_)))))))));
    vlSelf->wasmetal_core__DOT___001705_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000719_))))));
    vlSelf->wasmetal_core__DOT___002387_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000819_))))));
    vlSelf->__VdfgTmp_h34f2d08e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008294_));
    vlSelf->__VdfgTmp_hbacebd3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055785_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008357_))))));
    vlSelf->__VdfgTmp_h31aacdc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008281_));
    vlSelf->wasmetal_core__DOT___044411_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179c0c32__0))))))));
    vlSelf->wasmetal_core__DOT___044435_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063317_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063315_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063313_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))))));
    vlSelf->wasmetal_core__DOT___047900_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005508_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005509_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b43__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047897_))))))))))));
    vlSelf->wasmetal_core__DOT___013737_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048894_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047897_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068244_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042170_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___010123_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068233_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027370_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b43__05d))));
    vlSelf->wasmetal_core__DOT___002069_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001287_)))))))));
    vlSelf->wasmetal_core__DOT___002289_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001288_)))))))));
    vlSelf->wasmetal_core__DOT___002465_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001288_))))));
    vlSelf->wasmetal_core__DOT___055416_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h3fcf358e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008273_));
    vlSelf->wasmetal_core__DOT___047908_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005504_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005505_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b42__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047905_))))))))))));
    vlSelf->wasmetal_core__DOT___013740_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048897_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047905_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068159_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___063912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d))));
    vlSelf->__VdfgTmp_he0af74c9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d)));
    vlSelf->wasmetal_core__DOT___010091_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068148_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027369_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b42__05d))));
    vlSelf->__VdfgTmp_h0283b263__0 = (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055755_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008265_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008341_))))));
    vlSelf->__VdfgTmp_h9d165bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008265_));
    vlSelf->wasmetal_core__DOT___047890_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005529_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005530_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b41__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047887_))))))))))));
    vlSelf->wasmetal_core__DOT___013786_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048895_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047887_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068108_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_hae598e91__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d));
    vlSelf->wasmetal_core__DOT___010103_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068097_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008266_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027368_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b41__05d))));
    vlSelf->__VdfgTmp_hd64632c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055317_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___044410_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df568d0__0))))))));
    vlSelf->wasmetal_core__DOT___044434_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063311_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063309_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063307_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054201_)))))))));
    vlSelf->wasmetal_core__DOT___047882_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005533_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005534_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b40__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047879_))))))))))));
    vlSelf->wasmetal_core__DOT___013787_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047879_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___068083_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_ha5696d37__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d));
    vlSelf->wasmetal_core__DOT___042169_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___010672_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068072_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008258_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027367_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b40__05d))));
    vlSelf->wasmetal_core__DOT___061467_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->__VdfgTmp_h5ad8b1f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007432_));
    vlSelf->__VdfgTmp_hb9d2a0bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007770_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008257_));
    vlSelf->__VdfgTmp_h9fed8b62__0 = (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hd3c93d4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008243_));
    vlSelf->wasmetal_core__DOT___047822_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005566_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b39__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047819_))))))))))));
    vlSelf->wasmetal_core__DOT___013785_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048905_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047819_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___019404_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___063961_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d))));
    vlSelf->wasmetal_core__DOT___010836_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068024_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027365_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b39__05d))));
    vlSelf->__VdfgTmp_hca6242ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001285_));
    vlSelf->wasmetal_core__DOT___001290_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001286_))))));
    vlSelf->__VdfgTmp_h3cb929d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h7e30f70e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008235_));
    vlSelf->wasmetal_core__DOT___047830_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005549_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005550_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b38__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047827_))))))))))));
    vlSelf->wasmetal_core__DOT___013788_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048912_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047827_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___067972_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h46a92a2b__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d));
    vlSelf->wasmetal_core__DOT___010831_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008236_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027364_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b38__05d))));
    vlSelf->wasmetal_core__DOT___000722_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000718_))))));
    vlSelf->__VdfgTmp_hfa88dfaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055602_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008302_))))));
    vlSelf->__VdfgTmp_h93fbfa25__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008227_));
    vlSelf->wasmetal_core__DOT___044409_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e211f59__0))))))));
    vlSelf->wasmetal_core__DOT___044433_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063305_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063303_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063301_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))))));
    vlSelf->wasmetal_core__DOT___047812_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005541_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005542_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b37__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047809_))))))))))));
    vlSelf->wasmetal_core__DOT___013796_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048907_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047809_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___067906_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010142_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067901_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008228_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027363_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b37__05d))));
    vlSelf->wasmetal_core__DOT___055526_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008219_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008294_))))));
    vlSelf->__VdfgTmp_h29bca591__0 = (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008219_));
    vlSelf->wasmetal_core__DOT___047804_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005557_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005558_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b36__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___047800_))))))))))));
    vlSelf->wasmetal_core__DOT___013797_ = (1U & (IData)(
                                                         (0xfff0fff00000bbbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048906_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___047800_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___019399_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h101b2914__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d));
    vlSelf->__VdfgTmp_ha0d25e26__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d)));
    vlSelf->wasmetal_core__DOT___010152_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067814_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008220_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027362_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b36__05d))));
    vlSelf->wasmetal_core__DOT___000721_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000717_))))));
    vlSelf->__VdfgTmp_h0fd3d582__0 = (((IData)(vlSelf->wasmetal_core__DOT___000718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000717_));
    vlSelf->__VdfgTmp_hec35f81b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000717_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000574_));
    vlSelf->__VdfgTmp_h89d79bf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___055506_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008281_))))));
    vlSelf->__VdfgTmp_h9cbd3d8a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008206_));
    vlSelf->wasmetal_core__DOT___048688_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048686_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005648_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___013795_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048914_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048686_)))))))));
    vlSelf->wasmetal_core__DOT___067758_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h8c76b9e6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d));
    vlSelf->wasmetal_core__DOT___010810_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027361_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b35__05d))));
    vlSelf->__VdfgTmp_hf7ef4e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hb372eb0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008198_));
    vlSelf->wasmetal_core__DOT___044408_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c632a11__0))))))));
    vlSelf->wasmetal_core__DOT___044432_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063297_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063295_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054189_)))))))));
    vlSelf->wasmetal_core__DOT___049138_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0ff11ffU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048915_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005659_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005660_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___013798_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048915_)))))))));
    vlSelf->wasmetal_core__DOT___067734_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___063918_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d))));
    vlSelf->wasmetal_core__DOT___042167_ = (1U & (0x9000U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((9U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d))))));
    vlSelf->wasmetal_core__DOT___010805_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067729_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008199_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027360_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b34__05d))));
    vlSelf->__VdfgTmp_h13911493__0 = (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___063800_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063791_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h483290db__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((6U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h0f13542d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___026819_)))))))));
    vlSelf->wasmetal_core__DOT___055381_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008190_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008265_))))));
    vlSelf->__VdfgTmp_ha7da5f58__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008190_));
    vlSelf->wasmetal_core__DOT___013771_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048910_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___067668_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___011995_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067663_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008191_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027359_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[1U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b33__05d))));
    vlSelf->wasmetal_core__DOT___005889_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005653_)) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005652_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005651_))))))))));
    vlSelf->wasmetal_core__DOT___049136_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048910_))))))))))));
    vlSelf->__VdfgTmp_h69457925__0 = (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008182_));
    vlSelf->wasmetal_core__DOT___049129_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005553_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005554_)))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b32__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048908_))))))))))));
    vlSelf->wasmetal_core__DOT___013770_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355ffff0f0f0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048908_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___067601_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h7c266aa9__0 = (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d));
    vlSelf->wasmetal_core__DOT___063964_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d))))));
    vlSelf->wasmetal_core__DOT___010173_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___067591_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008183_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027358_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b32__05d))));
    vlSelf->wasmetal_core__DOT___002562_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001285_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001661_)))))))));
    vlSelf->wasmetal_core__DOT___002181_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001661_))))));
    vlSelf->wasmetal_core__DOT___061468_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061465_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061464_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007339_)))))))));
    vlSelf->__VdfgTmp_hc6c88546__0 = (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048701_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___055855_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008168_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008243_))))));
    vlSelf->__VdfgTmp_h567d9bb7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008168_));
    vlSelf->wasmetal_core__DOT___028309_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028244_))));
    vlSelf->wasmetal_core__DOT___044407_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h561bfeb8__0))))))));
    vlSelf->wasmetal_core__DOT___044431_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063293_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063287_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054182_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))))));
    vlSelf->wasmetal_core__DOT___063867_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d))));
    vlSelf->__VdfgTmp_ha04cce4c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    vlSelf->wasmetal_core__DOT___070494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->__VdfgTmp_he88617ec__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d));
    vlSelf->__VdfgTmp_hf0c7a5d6__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)));
    vlSelf->wasmetal_core__DOT___012286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___010424_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010423_))));
    vlSelf->wasmetal_core__DOT___008169_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027357_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b31__05d))));
    vlSelf->wasmetal_core__DOT___059198_ = (1U & (0x41U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___006247_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005711_))));
    vlSelf->wasmetal_core__DOT___010531_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128506___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___008974_))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->__VdfgTmp_ha9869a20__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007870_));
    vlSelf->wasmetal_core__DOT___028296_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028231_))));
    vlSelf->wasmetal_core__DOT___048808_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048805_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))))))));
    vlSelf->wasmetal_core__DOT___064480_ = (1U & (0x4f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063855_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___063857_))))));
    vlSelf->wasmetal_core__DOT___042352_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87854ac5__0))))))));
    vlSelf->wasmetal_core__DOT___042151_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87854ac5__0))))))));
    vlSelf->__VdfgTmp_h769a413d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___063930_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___010341_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___007873_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027344_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_imm[0U]) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b1__05d))));
    vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028659_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004818_));
    vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028971_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128434___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001874_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032283_ = ((IData)(vlSelf->wasmetal_core__DOT___001886_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001886_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128085___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026674_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127876___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027144_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b1__05d));
    vlSelf->wasmetal_core__DOT___071915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071914_))));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026562_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___003189_));
    vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026944_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128067___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hc8dfb864__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___127893___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___010530_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056274_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___010124_ = (1U & (0xfbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007882_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056274_))))));
    vlSelf->__VdfgTmp_h014e1215__0 = (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007882_));
    vlSelf->wasmetal_core__DOT___034541_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128656___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001886_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001874_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___044405_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063095_))));
    vlSelf->wasmetal_core__DOT___044429_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053990_))));
    vlSelf->wasmetal_core__DOT___028285_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028220_))));
    vlSelf->wasmetal_core__DOT___048797_ = (1U & (IData)(
                                                         (0xf0c0f0c0000aaffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xac00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048794_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))))))));
    vlSelf->__VdfgTmp_h78ac86a2__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___042140_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->__VdfgTmp_hdd7e24a1__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->__VdfgTmp_hab155f14__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d));
    vlSelf->wasmetal_core__DOT___007883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___027333_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b0__05d))));
    vlSelf->wasmetal_core__DOT___017175_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->__VdfgTmp_h76ba8332__0 = (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->__VdfgTmp_h2b3c1bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___001286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbbf7a95__0));
    vlSelf->wasmetal_core__DOT___006215_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b30__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0)))))));
    vlSelf->__VdfgTmp_hb79381c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008461_));
    vlSelf->wasmetal_core__DOT___055640_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___027391_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b62__05d))));
    vlSelf->wasmetal_core__DOT___006238_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006144_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b29__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0)))))));
    vlSelf->wasmetal_core__DOT___001711_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))))));
    vlSelf->wasmetal_core__DOT___002234_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4f90e104__0)))));
    vlSelf->wasmetal_core__DOT___044418_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haaf717df__0))))))));
    vlSelf->wasmetal_core__DOT___044442_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063353_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063351_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063349_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))))));
    vlSelf->wasmetal_core__DOT___055812_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008453_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054948_))))));
    vlSelf->__VdfgTmp_hdf1f98b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->wasmetal_core__DOT___027390_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b61__05d))));
    vlSelf->wasmetal_core__DOT___006155_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006171_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b28__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0)))))));
    vlSelf->__VdfgTmp_h8eb0ad88__0 = (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8f6175c0__0));
    vlSelf->__VdfgTmp_h4f306e5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___069133_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069084_));
    vlSelf->wasmetal_core__DOT___055796_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008445_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054899_))))));
    vlSelf->wasmetal_core__DOT___027389_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b60__05d))));
    vlSelf->wasmetal_core__DOT___006159_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006112_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048166_)))))));
    vlSelf->wasmetal_core__DOT___007340_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h504ea901__0)))));
    vlSelf->wasmetal_core__DOT___001710_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->wasmetal_core__DOT___002233_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd5d1004a__0))))));
    vlSelf->__VdfgTmp_h8025ed93__0 = (((IData)(vlSelf->wasmetal_core__DOT___069084_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___069033_));
    vlSelf->wasmetal_core__DOT___055784_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008432_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051493_))))));
    vlSelf->__VdfgTmp_hf10e2308__0 = (((IData)(vlSelf->wasmetal_core__DOT___008357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->__VdfgTmp_h2577a83c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008432_));
    vlSelf->wasmetal_core__DOT___027387_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b59__05d))));
    vlSelf->wasmetal_core__DOT___005996_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___057083_ = (1U & (0x3f5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfcd73105__0))))));
    vlSelf->__VdfgTmp_h4ae2b9ea__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h37472320__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)))));
    vlSelf->__VdfgTmp_h5e79b823__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb4c136ee__0)));
    vlSelf->wasmetal_core__DOT___006099_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b26__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0)))))));
    vlSelf->wasmetal_core__DOT___001315_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->wasmetal_core__DOT___001785_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hfe7af35a__0))))));
    vlSelf->wasmetal_core__DOT___044417_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7fbee1d__0))))))));
    vlSelf->wasmetal_core__DOT___044441_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063343_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->__VdfgTmp_he719985b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008273_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008349_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008424_))));
    vlSelf->wasmetal_core__DOT___055418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_hd69bf43a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008424_));
    vlSelf->wasmetal_core__DOT___027386_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b58__05d))));
    vlSelf->wasmetal_core__DOT___006065_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048164_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006116_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048164_)))))));
    vlSelf->__VdfgTmp_hb587b232__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h05980b33__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h797b2590__0)))));
    vlSelf->__VdfgTmp_h107cea9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h797b2590__0)));
    vlSelf->wasmetal_core__DOT___001709_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))))));
    vlSelf->wasmetal_core__DOT___000923_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h131eee20__0)))));
    vlSelf->wasmetal_core__DOT___055754_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054767_))))));
    vlSelf->__VdfgTmp_h4d3bb7ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___008341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->__VdfgTmp_he43dd87d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008416_));
    vlSelf->wasmetal_core__DOT___027385_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b57__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005428_)))));
    vlSelf->__VdfgTmp_h422a580d__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h860ce20a__0))) 
                                             << 1U)) 
                                      | (1U & (0x53U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hca913760__0)))));
    vlSelf->__VdfgTmp_hfce0919b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hca913760__0)));
    vlSelf->wasmetal_core__DOT___063908_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe7af35a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0))))));
    vlSelf->__VdfgTmp_h78a92bf8__0 = (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h60f9d0d9__0));
    vlSelf->__VdfgTmp_hd4ed2ab6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008182_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008257_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008333_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008408_))));
    vlSelf->wasmetal_core__DOT___055320_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008408_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___027384_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b56__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005432_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005427_)))));
    vlSelf->wasmetal_core__DOT___006113_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005432_)) 
                                                  & (IData)(
                                                            (0xff80ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005427_))))))))));
    vlSelf->wasmetal_core__DOT___007771_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h528a2190__0)))));
    vlSelf->__VdfgTmp_h7b621139__0 = ((4U & ((0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h1811a1bb__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d)));
    vlSelf->wasmetal_core__DOT___001708_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->wasmetal_core__DOT___000922_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4fe6474e__0))))));
    vlSelf->wasmetal_core__DOT___044415_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7c7ad9a__0))))))));
    vlSelf->wasmetal_core__DOT___044439_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063341_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063339_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))))));
    vlSelf->__VdfgTmp_h92c59f9e__0 = (((IData)(vlSelf->wasmetal_core__DOT___008243_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008318_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008469_))));
    vlSelf->wasmetal_core__DOT___055666_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008394_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h2225d234__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008394_));
    vlSelf->wasmetal_core__DOT___027383_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b55__05d))));
    vlSelf->wasmetal_core__DOT___005962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->__VdfgTmp_h28180847__0 = (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007417_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2df8dd7f__0)));
    vlSelf->wasmetal_core__DOT___005770_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b22__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0)))))));
    vlSelf->wasmetal_core__DOT___001313_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->wasmetal_core__DOT___001783_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h67451104__0))))));
    vlSelf->__VdfgTmp_hf366d942__0 = (((IData)(vlSelf->wasmetal_core__DOT___008235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___008310_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___008461_))));
    vlSelf->__VdfgTmp_hd96a7b90__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008386_));
    vlSelf->wasmetal_core__DOT___055641_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008386_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___048623_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005486_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005487_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005484_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005485_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b54__05d)))))))));
    vlSelf->wasmetal_core__DOT___048726_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048621_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000992_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000992_))))));
    vlSelf->wasmetal_core__DOT___027382_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b54__05d))));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__ 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                           << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048049_) 
                                      << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006115_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048049_)))))));
    vlSelf->__VdfgTmp_h99d3b9a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h447558a7__0)));
    vlSelf->wasmetal_core__DOT___005855_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b21__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0)))))));
    vlSelf->wasmetal_core__DOT___001707_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))))));
    vlSelf->wasmetal_core__DOT___000921_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4575751b__0)))));
    vlSelf->wasmetal_core__DOT___063810_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063807_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063806_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063805_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___026816_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___026815_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (6U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___026856_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___026855_))))))))))));
    vlSelf->wasmetal_core__DOT___055813_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008378_))))));
    vlSelf->__VdfgTmp_h8de67bd6__0 = (((IData)(vlSelf->wasmetal_core__DOT___008378_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008453_));
    vlSelf->__VdfgTmp_haaeadd36__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008378_));
    vlSelf->wasmetal_core__DOT___048640_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005477_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005474_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005475_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___048725_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048638_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___000980_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000980_))))));
    vlSelf->wasmetal_core__DOT___027381_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b53__05d))));
    vlSelf->wasmetal_core__DOT___005896_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->__VdfgTmp_h90c7fdf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h372c3d93__0)));
    vlSelf->wasmetal_core__DOT___003806_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8476215a__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b20__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0)))))));
    vlSelf->wasmetal_core__DOT___063902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h67451104__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0))))));
    vlSelf->__VdfgTmp_had66fb55__0 = (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h1a9e6a0c__0));
    vlSelf->wasmetal_core__DOT___055797_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008294_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008370_))))));
    vlSelf->__VdfgTmp_hb8ee9e15__0 = (((IData)(vlSelf->wasmetal_core__DOT___008370_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008445_));
    vlSelf->wasmetal_core__DOT___044414_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h351f56c5__0))))))));
    vlSelf->wasmetal_core__DOT___044438_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063335_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063333_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063331_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))))));
    vlSelf->wasmetal_core__DOT___048635_ = (1U & (IData)(
                                                         (0xaa33f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f0ccaaffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005466_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005467_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005464_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005465_))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___048718_ = (1U & (0x7770U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x3355f0f0ffffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048633_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001327_))))));
    vlSelf->wasmetal_core__DOT___027380_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[1U] 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b52__05d))));
    vlSelf->wasmetal_core__DOT___002148_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))));
    vlSelf->wasmetal_core__DOT___005830_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048051_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006114_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048051_)))))));
    vlSelf->wasmetal_core__DOT___007341_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3c09d3eb__0)))));
    vlSelf->wasmetal_core__DOT___028308_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028243_))));
    vlSelf->wasmetal_core__DOT___055832_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008160_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008235_))))));
    vlSelf->__VdfgTmp_h7102b895__0 = (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008160_));
    vlSelf->wasmetal_core__DOT___027356_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b30__05d))));
    vlSelf->wasmetal_core__DOT___071972_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071971_)))));
    vlSelf->wasmetal_core__DOT___049019_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_)))))))));
    vlSelf->wasmetal_core__DOT___000573_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2bd8c9ed__0))))));
    vlSelf->wasmetal_core__DOT___028306_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028241_))));
    vlSelf->wasmetal_core__DOT___055811_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008152_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008227_))))));
    vlSelf->__VdfgTmp_h584cbf3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008152_));
    vlSelf->wasmetal_core__DOT___027354_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b29__05d))));
    vlSelf->wasmetal_core__DOT___049016_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_)))))))));
    vlSelf->wasmetal_core__DOT___042342_ = (1U & (IData)(
                                                         (0xbb2bffff2b220000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0f13542d__0))))))));
    vlSelf->wasmetal_core__DOT___067336_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha86315e0__0))));
    vlSelf->wasmetal_core__DOT___042141_ = (1U & (IData)(
                                                         (0xf571ffff71500000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3b20cbca__0))))))));
    vlSelf->wasmetal_core__DOT___042165_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h4b9b5b32__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063937_)))));
    vlSelf->wasmetal_core__DOT___001660_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h717e9861__0))))));
    vlSelf->wasmetal_core__DOT___044406_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3a468d3__0))))))));
    vlSelf->wasmetal_core__DOT___044430_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063269_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063263_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054166_)))))))));
    vlSelf->wasmetal_core__DOT___028305_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___028240_))));
    vlSelf->wasmetal_core__DOT___055795_ = (1U & (0xf5f3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055319_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055316_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___008144_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___008219_))))));
    vlSelf->__VdfgTmp_h169cd931__0 = (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008144_));
    vlSelf->wasmetal_core__DOT___027353_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_imm[0U] 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_base__05b28__05d))));
    vlSelf->wasmetal_core__DOT___052577_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052576_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052575_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052574_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052114_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x7fffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052109_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052108_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052107_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052103_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h128bed99__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052101_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052100_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052099_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052089_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e2ba734__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052091_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0352b565__0)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052087_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7762895e__0)))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052085_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052084_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052083_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052071_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h587b33f1__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052069_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052068_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052067_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8fdf3668__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc4d9060a__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7fff7fff7fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052371_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052370_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052369_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052365_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052364_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6e2b8153__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11abcf6d__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9174715__0))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052314_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052313_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052312_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha0b12c43__0))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052300_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005205_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005273_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h36fcb829__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hce3a0449__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8888f00000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052305_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005069_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005589_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9ff07be6__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfb9f47b1__0)))))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052326_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052325_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052324_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6806bd5e__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___042092_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h22be3b3b__0)))))));
}
