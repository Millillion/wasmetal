#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__2(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__2\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044717_;
    wasmetal_core__DOT___044717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044724_;
    wasmetal_core__DOT___044724_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044725_;
    wasmetal_core__DOT___044725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048337_;
    wasmetal_core__DOT___048337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048436_;
    wasmetal_core__DOT___048436_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064043_;
    wasmetal_core__DOT___064043_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064044_;
    wasmetal_core__DOT___064044_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064054_;
    wasmetal_core__DOT___064054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064065_;
    wasmetal_core__DOT___064065_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064142_;
    wasmetal_core__DOT___064142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064143_;
    wasmetal_core__DOT___064143_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064152_;
    wasmetal_core__DOT___064152_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064153_;
    wasmetal_core__DOT___064153_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064165_;
    wasmetal_core__DOT___064165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064175_;
    wasmetal_core__DOT___064175_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064176_;
    wasmetal_core__DOT___064176_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064560_;
    wasmetal_core__DOT___064560_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064563_;
    wasmetal_core__DOT___064563_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064594_;
    wasmetal_core__DOT___064594_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064595_;
    wasmetal_core__DOT___064595_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064596_;
    wasmetal_core__DOT___064596_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064597_;
    wasmetal_core__DOT___064597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064608_;
    wasmetal_core__DOT___064608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064610_;
    wasmetal_core__DOT___064610_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064611_;
    wasmetal_core__DOT___064611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064951_;
    wasmetal_core__DOT___064951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___064980_;
    wasmetal_core__DOT___064980_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065090_;
    wasmetal_core__DOT___065090_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065121_;
    wasmetal_core__DOT___065121_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065256_;
    wasmetal_core__DOT___065256_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065268_;
    wasmetal_core__DOT___065268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065344_;
    wasmetal_core__DOT___065344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065355_;
    wasmetal_core__DOT___065355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065453_;
    wasmetal_core__DOT___065453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065462_;
    wasmetal_core__DOT___065462_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065536_;
    wasmetal_core__DOT___065536_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065677_;
    wasmetal_core__DOT___065677_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065775_;
    wasmetal_core__DOT___065775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065873_;
    wasmetal_core__DOT___065873_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065977_;
    wasmetal_core__DOT___065977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___065988_;
    wasmetal_core__DOT___065988_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066040_;
    wasmetal_core__DOT___066040_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066054_;
    wasmetal_core__DOT___066054_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066151_;
    wasmetal_core__DOT___066151_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066169_;
    wasmetal_core__DOT___066169_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066238_;
    wasmetal_core__DOT___066238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066250_;
    wasmetal_core__DOT___066250_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066347_;
    wasmetal_core__DOT___066347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066447_;
    wasmetal_core__DOT___066447_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066493_;
    wasmetal_core__DOT___066493_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066569_;
    wasmetal_core__DOT___066569_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066686_;
    wasmetal_core__DOT___066686_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066736_;
    wasmetal_core__DOT___066736_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066821_;
    wasmetal_core__DOT___066821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___066926_;
    wasmetal_core__DOT___066926_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067009_;
    wasmetal_core__DOT___067009_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067056_;
    wasmetal_core__DOT___067056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070579_;
    wasmetal_core__DOT___070579_ = 0;
    // Body
    wasmetal_core__DOT___064165_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064164_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064163_))));
    wasmetal_core__DOT___065977_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065860_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065976_))));
    wasmetal_core__DOT___064596_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064150_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064115_))));
    wasmetal_core__DOT___067056_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___067008_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___067055_))));
    wasmetal_core__DOT___064608_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064163_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064170_))));
    wasmetal_core__DOT___066040_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065976_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066039_))));
    wasmetal_core__DOT___064152_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064151_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064150_))));
    wasmetal_core__DOT___067009_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066925_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___067008_))));
    wasmetal_core__DOT___064175_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064174_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064173_))));
    wasmetal_core__DOT___066347_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066237_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066346_))));
    wasmetal_core__DOT___064611_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064169_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064174_))));
    wasmetal_core__DOT___064176_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064170_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064169_))));
    wasmetal_core__DOT___066238_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066168_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066237_))));
    wasmetal_core__DOT___066169_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066039_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066168_))));
    wasmetal_core__DOT___064597_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064146_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064151_))));
    wasmetal_core__DOT___066926_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066820_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066925_))));
    wasmetal_core__DOT___064610_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064173_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064137_))));
    wasmetal_core__DOT___066447_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066346_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066446_))));
    wasmetal_core__DOT___064142_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064141_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064140_))));
    wasmetal_core__DOT___066686_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066568_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066685_))));
    wasmetal_core__DOT___064594_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064140_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064147_))));
    wasmetal_core__DOT___064153_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064147_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064146_))));
    wasmetal_core__DOT___066736_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066685_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066735_))));
    wasmetal_core__DOT___066821_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066735_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066820_))));
    wasmetal_core__DOT___064595_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064136_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064141_))));
    wasmetal_core__DOT___064143_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064137_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064136_))));
    wasmetal_core__DOT___066569_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066492_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066568_))));
    wasmetal_core__DOT___066493_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066446_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066492_))));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027812_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d));
    vlSelf->wasmetal_core__DOT___064053_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064052_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064051_))));
    vlSelf->wasmetal_core__DOT___066360_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066249_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066359_))));
    vlSelf->wasmetal_core__DOT___064779_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064778_))));
    wasmetal_core__DOT___064980_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064778_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064979_))));
    wasmetal_core__DOT___064560_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064047_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064052_))));
    wasmetal_core__DOT___066250_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066150_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066249_))));
    vlSelf->wasmetal_core__DOT___064076_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064070_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064069_))));
    wasmetal_core__DOT___065090_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064979_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065089_))));
    wasmetal_core__DOT___064054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064048_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064047_))));
    wasmetal_core__DOT___066151_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___066053_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066150_))));
    wasmetal_core__DOT___065268_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065089_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065267_))));
    vlSelf->wasmetal_core__DOT___064557_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064048_))));
    wasmetal_core__DOT___066054_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065987_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___066053_))));
    wasmetal_core__DOT___064043_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064042_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064041_))));
    wasmetal_core__DOT___065988_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065872_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065987_))));
    vlSelf->wasmetal_core__DOT___064066_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064060_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064059_))));
    wasmetal_core__DOT___065355_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065267_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065354_))));
    vlSelf->wasmetal_core__DOT___064564_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064064_))));
    wasmetal_core__DOT___065462_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065354_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065461_))));
    vlSelf->wasmetal_core__DOT___064558_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064042_))));
    wasmetal_core__DOT___065873_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065774_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065872_))));
    wasmetal_core__DOT___064044_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064037_))));
    wasmetal_core__DOT___065775_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065676_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065774_))));
    wasmetal_core__DOT___064563_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064038_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___064065_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064064_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064063_))));
    wasmetal_core__DOT___065677_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065535_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065676_))));
    wasmetal_core__DOT___065536_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065461_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065535_))));
    vlSelf->wasmetal_core__DOT___064585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064575_))));
    vlSelf->wasmetal_core__DOT___064822_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064821_))));
    vlSelf->wasmetal_core__DOT___065460_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065458_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                                          << 1U)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                           << 1U))))))))));
    vlSelf->wasmetal_core__DOT___066941_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((4U 
                                                                  >> 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                                   << 1U)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064237_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064236_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064235_))));
    vlSelf->wasmetal_core__DOT___065547_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065452_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065546_))));
    wasmetal_core__DOT___064951_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064821_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___064950_))));
    vlSelf->__VdfgTmp_hd333e317__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064231_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064236_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               ((IData)(vlSelf->wasmetal_core__DOT___064235_) 
                                                << 1U))));
    wasmetal_core__DOT___065453_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065343_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065452_))));
    wasmetal_core__DOT___065344_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065255_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065343_))));
    vlSelf->wasmetal_core__DOT___064578_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064222_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064232_))));
    vlSelf->wasmetal_core__DOT___064228_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064223_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064222_))));
    wasmetal_core__DOT___065256_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___065120_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065255_))));
    wasmetal_core__DOT___065121_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___064950_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___065120_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128050___O 
        = (((0xeU & vlSelf->insn_x) | (1U & (~ vlSelf->insn_x))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & (vlSelf->insn_x 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___028180_ = ((vlSelf->insn_x 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___045805_ = ((IData)(vlSelf->wasmetal_core__DOT___045828_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045837_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045836_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___045835_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045834_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045833_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045832_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___045831_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045830_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045829_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___045827_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045815_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045817_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045818_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045819_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045820_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045821_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045822_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045823_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045824_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045825_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045816_));
    vlSelf->wasmetal_core__DOT___050394_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044280_))));
    vlSelf->__VdfgTmp_h301f8c5d__0 = (((IData)(vlSelf->wasmetal_core__DOT___044280_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    wasmetal_core__DOT___044725_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052867_))));
    wasmetal_core__DOT___044724_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___032689_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h42a8fe82__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128314___O 
        = (((8U & ((~ (vlSelf->function_params >> 3U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 2U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->function_params 
                                            >> 1U)) 
                                        << 1U)) | (1U 
                                                   & (~ vlSelf->function_params))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ vlSelf->function_params) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___030971_ = ((~ (vlSelf->function_params 
                                                >> 3U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044720_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032676_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))));
    wasmetal_core__DOT___044717_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052868_))));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032685_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___037195_)) 
                 & (9U >> (IData)(vlSelf->__VdfgTmp_h2cd56cce__0))));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d));
    vlSelf->wasmetal_core__DOT___048503_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xcU)))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048500_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044248_)))));
    vlSelf->wasmetal_core__DOT___043139_ = (1U & (0x8fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070577_)))));
    vlSelf->wasmetal_core__DOT___043583_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070577_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 8U))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0)))));
    vlSelf->wasmetal_core__DOT___043141_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070577_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___043131_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070577_))));
    vlSelf->wasmetal_core__DOT___043286_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070578_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 5U))))));
    wasmetal_core__DOT___070579_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 4U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070578_))));
    vlSelf->wasmetal_core__DOT___045646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070626_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___044096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070626_))));
    vlSelf->wasmetal_core__DOT___044076_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070624_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___044104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070624_))));
    vlSelf->wasmetal_core__DOT___045643_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070626_))));
    vlSelf->__VdfgTmp_h6ef8db86__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h71254871__0));
    vlSelf->wasmetal_core__DOT___045979_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_x 
                                                      >> 0x1aU))) 
                                            & ((IData)(
                                                       (1ULL 
                                                        >> 
                                                        (0x3fU 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U)))) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044249_) 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___044248_) 
                                                        & ((~ 
                                                            (4U 
                                                             >> 
                                                             (3U 
                                                              & vlSelf->insn_x))) 
                                                           & (~ 
                                                              (vlSelf->insn_x 
                                                               >> 1U))))))));
    if ((1U & (IData)((1ULL >> (vlSelf->insn_x >> 0x1aU))))) {
        if ((1U & (IData)((1ULL >> (0x3fU & (vlSelf->insn_x 
                                             >> 0x14U)))))) {
            if (vlSelf->wasmetal_core__DOT___044249_) {
                vlSelf->wasmetal_core__DOT___044604_ 
                    = (1U & ((1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)))
                              ? ((IData)(vlSelf->wasmetal_core__DOT___044248_)
                                  ? ((4U >> (3U & vlSelf->insn_x)) 
                                     | (8U >> (3U & vlSelf->insn_x)))
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___044248_)))
                              : (~ (1U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)))));
                vlSelf->wasmetal_core__DOT___044240_ 
                    = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)) 
                             | (IData)(vlSelf->wasmetal_core__DOT___044243_)));
            } else {
                vlSelf->wasmetal_core__DOT___044604_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044249_)));
                vlSelf->wasmetal_core__DOT___044240_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044249_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___044604_ = 
                (1U & (~ (IData)((1ULL >> (0x3fU & 
                                           (vlSelf->insn_x 
                                            >> 0x14U))))));
            vlSelf->wasmetal_core__DOT___044240_ = 
                (1U & (~ (IData)((1ULL >> (0x3fU & 
                                           (vlSelf->insn_x 
                                            >> 0x14U))))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___044604_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_x 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044240_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_x 
                                                               >> 0x1aU)))));
    }
    vlSelf->wasmetal_core__DOT___045777_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_x 
                                                      >> 0x1aU))) 
                                            & ((IData)(
                                                       (1ULL 
                                                        >> 
                                                        (0x3fU 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U)))) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044249_) 
                                                  & ((~ 
                                                      (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0))) 
                                                     & (1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0))))));
    vlSelf->wasmetal_core__DOT___048513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048303_))));
    vlSelf->wasmetal_core__DOT___050392_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048447_))));
    vlSelf->wasmetal_core__DOT___053775_ = (1U & (0x111fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f7c118b__0))))));
    vlSelf->wasmetal_core__DOT___053781_ = (1U & (0x111fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x1000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x4000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f7c118b__0))))));
    vlSelf->wasmetal_core__DOT___048469_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((8U 
                                                      & vlSelf->insn_op)
                                                      ? (IData)(
                                                                (0x5555ffff303f00ffULL 
                                                                 >> 
                                                                 ((0x30U 
                                                                   & (vlSelf->insn_op 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (vlSelf->insn_op 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002988_)))))))
                                                      : 
                                                     (0xd0f1555U 
                                                      >> 
                                                      ((0x18U 
                                                        & (vlSelf->insn_op 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (vlSelf->insn_op 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002994_))))))));
    wasmetal_core__DOT___048436_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___000358_ = ((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                            & ((1U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (vlSelf->insn_op 
                                                                         >> 0x1aU))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & (vlSelf->insn_op 
                                                                                >> 6U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U)))))))))))));
    vlSelf->wasmetal_core__DOT___000359_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x1000U 
                                                                >> 
                                                                (0xfU 
                                                                 & (vlSelf->insn_op 
                                                                    >> 0x10U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (1ULL 
                                                                              >> 
                                                                              (vlSelf->insn_op 
                                                                               >> 0x1aU))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048277_ = ((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048278_ = ((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048279_ = ((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048398_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048468_ = (1U & (0xe7ffffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h71254871__0)))));
    wasmetal_core__DOT___048337_ = (1U & (8U >> ((2U 
                                                  & ((8U 
                                                      >> 
                                                      (3U 
                                                       & (vlSelf->insn_op 
                                                          >> 2U))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___047969_ = (1U & (IData)(
                                                         (0x2ffeffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x4000U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & (vlSelf->insn_op 
                                                                       >> 4U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))));
    vlSelf->wasmetal_core__DOT___048365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___002981_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___048326_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048320_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___047781_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048343_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048327_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___010006_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_hc416787b__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___000353_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_)))));
    vlSelf->wasmetal_core__DOT___010007_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___070595_ = (1U & (0xc4ffffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x4000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 1U)) 
                                                         | (3U 
                                                            & vlSelf->insn_op))))));
    vlSelf->wasmetal_core__DOT___003010_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x100U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047955_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0xfff533ff3f3f3f3fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & vlSelf->insn_op) 
                                                                       | ((2U 
                                                                           & ((0x4000U 
                                                                               >> 
                                                                               (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___002988_))))))))));
    vlSelf->__VdfgTmp_h4e9e0a77__0 = ((2U & ((0x100U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___002966_ = (1U & (IData)(
                                                         (0x5dffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & vlSelf->insn_op) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & vlSelf->insn_op) 
                                                                       | (1U 
                                                                          & (0x4000U 
                                                                             >> 
                                                                             (0xfU 
                                                                              & (vlSelf->insn_op 
                                                                                >> 4U))))))))))));
    vlSelf->wasmetal_core__DOT___002965_ = (1U & (IData)(
                                                         (0xff0fff11ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))))));
    vlSelf->wasmetal_core__DOT___048283_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_h28012a28__0 = ((2U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___048328_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___007059_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8374813__0))))));
    vlSelf->__VdfgTmp_h84a34a18__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_ha8374813__0));
    vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001230_) 
           | (IData)(vlSelf->wasmetal_core__DOT___043130_));
    vlSelf->wasmetal_core__DOT___047968_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001230_))))));
    vlSelf->wasmetal_core__DOT___048314_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_hbcc95063__0 = (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___047983_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x4000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x100U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002985_))))));
    vlSelf->__VdfgTmp_hec761a3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002984_));
    vlSelf->wasmetal_core__DOT___070629_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___048467_ = (1U & (IData)(
                                                         (0x87fcffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | (0xfU 
                                                                 & vlSelf->insn_op))))));
    vlSelf->wasmetal_core__DOT___044083_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 3U)))))));
    vlSelf->__VdfgTmp_h7dabefa3__0 = ((4U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048336_)));
    vlSelf->wasmetal_core__DOT___045687_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___048474_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x53f0ff305fffffffULL 
                                                             >> 
                                                             ((0x20U 
                                                               & ((0x1000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                  << 5U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 3U)) 
                                                                 | ((0xcU 
                                                                     & vlSelf->insn_op) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007028_)))))))));
    vlSelf->wasmetal_core__DOT___048476_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x3fffffffdfffdULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & (vlSelf->insn_op 
                                                                           << 1U)) 
                                                                       | ((2U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))))));
    vlSelf->__VdfgTmp_h755be032__0 = (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___047964_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (0xfU 
                                                                   & (vlSelf->insn_op 
                                                                      >> 4U))))))))));
    vlSelf->wasmetal_core__DOT___002978_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))));
    vlSelf->wasmetal_core__DOT___002979_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((8U 
                                                      & vlSelf->insn_op)
                                                      ? 
                                                     (0xffffcf55U 
                                                      >> 
                                                      ((0x10U 
                                                        & (vlSelf->insn_op 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & (vlSelf->insn_op 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_op 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002988_))))))
                                                      : 
                                                     (0xffff153fU 
                                                      >> 
                                                      ((0x10U 
                                                        & (vlSelf->insn_op 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & (vlSelf->insn_op 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_op 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x4000U 
                                                                      >> 
                                                                      (0xfU 
                                                                       & (vlSelf->insn_op 
                                                                          >> 4U))))))))))));
    vlSelf->__VdfgTmp_h94b1bf18__0 = (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->insn_op 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___003012_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0xffff3ff5ff335f5fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x18U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))));
    vlSelf->wasmetal_core__DOT___047966_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x4000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047954_ = (1U & (0x1ffffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h87f36829__0))))));
    vlSelf->wasmetal_core__DOT___047976_ = (1U & (IData)(
                                                         (0xfa3fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_op) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_op)))))))));
    vlSelf->wasmetal_core__DOT___047794_ = (1U & (IData)(
                                                         (0xfff777777777777fULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->insn_op 
                                                               << 2U)) 
                                                           | ((8U 
                                                               & (vlSelf->insn_op 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))));
    vlSelf->wasmetal_core__DOT___003009_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x55f5f3ffffffff3fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & vlSelf->insn_op) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___053009_ = (1U & (0xff01ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001240_)))))));
    vlSelf->wasmetal_core__DOT___048005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xfffeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))));
    vlSelf->wasmetal_core__DOT___043674_ = (1U & (0x1ff0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___047795_ = (1U & (0xff15ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & ((0x4000U 
                                                              >> 
                                                              (0xfU 
                                                               & (vlSelf->insn_op 
                                                                  >> 4U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))))));
    vlSelf->wasmetal_core__DOT___047791_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x30fff5f5ffff30ffULL 
                                                             >> 
                                                             ((0x30U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((0x4000U 
                                                                      >> 
                                                                      (0xfU 
                                                                       & (vlSelf->insn_op 
                                                                          >> 4U))) 
                                                                     << 3U)) 
                                                                 | ((6U 
                                                                     & (vlSelf->insn_op 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))))))));
    vlSelf->wasmetal_core__DOT___048275_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x100U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xfffeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))));
    vlSelf->wasmetal_core__DOT___002980_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((IData)(vlSelf->wasmetal_core__DOT___001240_)
                                                      ? (IData)(
                                                                (0x700070007ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((0x1000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h6253e4f3__0)))))))
                                                      : 
                                                     (0x777U 
                                                      >> 
                                                      ((8U 
                                                        & ((0x1000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6253e4f3__0)))))));
    vlSelf->wasmetal_core__DOT___047985_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))));
    vlSelf->wasmetal_core__DOT___070596_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x100U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047977_ = (1U & (0xf5bbffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001234_))))));
    vlSelf->wasmetal_core__DOT___001246_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001241_))))));
    vlSelf->wasmetal_core__DOT___047793_ = (1U & (IData)(
                                                         (0xf53fffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & vlSelf->insn_op) 
                                                                 | ((2U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x4000U 
                                                                          >> 
                                                                          (0xfU 
                                                                           & (vlSelf->insn_op 
                                                                              >> 4U)))))))))));
    vlSelf->wasmetal_core__DOT___002968_ = (1U & (0xbfU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___001232_ = (IData)(
                                                   ((3U 
                                                     == 
                                                     (3U 
                                                      & vlSelf->insn_op)) 
                                                    & (0x1000000000000ULL 
                                                       >> 
                                                       ((0x30U 
                                                         & (vlSelf->insn_op 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h695ce273__0)))));
    vlSelf->wasmetal_core__DOT___048424_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xfffeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))));
    vlSelf->wasmetal_core__DOT___051563_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xfffeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))));
    vlSelf->__VdfgTmp_hdd61004f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 1U) | (1U 
                                                 & (0xfffeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->__VdfgTmp_h323e8784__0 = ((2U & (vlSelf->insn_op 
                                             >> 2U)) 
                                      | (1U & (0xfffeU 
                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___044158_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070615_))));
    vlSelf->wasmetal_core__DOT___045697_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070615_))));
    vlSelf->wasmetal_core__DOT___045694_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070615_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (vlSelf->insn_op 
                                                                >> 6U))))))));
    vlSelf->wasmetal_core__DOT___048001_ = (1U & (IData)(
                                                         (0xdfff7555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfffeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___047787_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))));
    vlSelf->wasmetal_core__DOT___048448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048447_))));
    vlSelf->wasmetal_core__DOT___048307_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048303_))));
    vlSelf->wasmetal_core__DOT___047792_ = (1U & ((~ 
                                                   (vlSelf->insn_op 
                                                    >> 3U)) 
                                                  | ((4U 
                                                      & vlSelf->insn_op)
                                                      ? 
                                                     (0xefbfU 
                                                      >> 
                                                      ((8U 
                                                        & (vlSelf->insn_op 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (vlSelf->insn_op 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xfffeU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))))
                                                      : 
                                                     (0xf7U 
                                                      >> 
                                                      ((4U 
                                                        & (vlSelf->insn_op 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((0x4000U 
                                                               >> 
                                                               (0xfU 
                                                                & (vlSelf->insn_op 
                                                                   >> 4U))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000368_)))))));
    vlSelf->wasmetal_core__DOT___003040_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h87f36829__0)))));
    vlSelf->__VdfgTmp_ha37d1f60__0 = (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                       << 1U) | (1U 
                                                 & (0xfffeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___043133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054454_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054455_))));
    vlSelf->wasmetal_core__DOT___044061_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 8U)))))));
    vlSelf->wasmetal_core__DOT___053367_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x10U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048515_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0x10U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___048516_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 0x10U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048515_))));
    vlSelf->wasmetal_core__DOT___052953_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->insn_valid) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & (vlSelf->insn_op 
                                                                        >> 8U)) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0xaU)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e88a732__0))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___057247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d))));
    vlSelf->wasmetal_core__DOT___057243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d))));
    vlSelf->wasmetal_core__DOT___057044_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d))));
    vlSelf->wasmetal_core__DOT___057077_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d))));
    vlSelf->wasmetal_core__DOT___056382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))));
    vlSelf->wasmetal_core__DOT___056371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))));
    vlSelf->wasmetal_core__DOT___056777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d))));
    vlSelf->wasmetal_core__DOT___057449_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d))));
    vlSelf->wasmetal_core__DOT___056428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d))));
    vlSelf->wasmetal_core__DOT___057205_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d))));
    vlSelf->wasmetal_core__DOT___056768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d))));
    vlSelf->wasmetal_core__DOT___056597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))));
    vlSelf->wasmetal_core__DOT___056501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))));
    vlSelf->wasmetal_core__DOT___057094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d))));
    vlSelf->wasmetal_core__DOT___057095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d))));
    vlSelf->wasmetal_core__DOT___056778_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d))));
    vlSelf->wasmetal_core__DOT___056600_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d))));
    vlSelf->wasmetal_core__DOT___056599_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d))));
    vlSelf->wasmetal_core__DOT___056335_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))));
    vlSelf->wasmetal_core__DOT___056336_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d))));
    vlSelf->wasmetal_core__DOT___057450_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d))));
    vlSelf->wasmetal_core__DOT___057092_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d))));
    vlSelf->wasmetal_core__DOT___056769_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d))));
    vlSelf->wasmetal_core__DOT___056598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d))));
    vlSelf->wasmetal_core__DOT___056331_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))));
    vlSelf->wasmetal_core__DOT___057384_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))));
    vlSelf->wasmetal_core__DOT___057385_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d))));
    vlSelf->wasmetal_core__DOT___057289_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d))));
    vlSelf->wasmetal_core__DOT___057290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d))));
    vlSelf->wasmetal_core__DOT___057130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d))));
    vlSelf->wasmetal_core__DOT___057129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))));
    vlSelf->wasmetal_core__DOT___056984_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d))));
    vlSelf->wasmetal_core__DOT___056983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))));
    vlSelf->wasmetal_core__DOT___056731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d))));
    vlSelf->wasmetal_core__DOT___056730_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d))));
    vlSelf->wasmetal_core__DOT___056622_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d))));
    vlSelf->wasmetal_core__DOT___056623_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))));
    vlSelf->wasmetal_core__DOT___057391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d))));
    vlSelf->wasmetal_core__DOT___057390_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))));
    vlSelf->wasmetal_core__DOT___057286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d))));
    vlSelf->wasmetal_core__DOT___057288_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))));
    vlSelf->wasmetal_core__DOT___057128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))));
    vlSelf->wasmetal_core__DOT___057127_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d))));
    vlSelf->wasmetal_core__DOT___056968_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d))));
    vlSelf->wasmetal_core__DOT___056967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d))));
    vlSelf->wasmetal_core__DOT___056746_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d))));
    vlSelf->wasmetal_core__DOT___056745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d))));
    vlSelf->wasmetal_core__DOT___011459_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d))));
    vlSelf->wasmetal_core__DOT___011458_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))));
    vlSelf->wasmetal_core__DOT___056427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))));
    vlSelf->wasmetal_core__DOT___057539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d))));
    vlSelf->wasmetal_core__DOT___057536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d))));
    vlSelf->wasmetal_core__DOT___057442_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d))));
    vlSelf->wasmetal_core__DOT___057443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d))));
    vlSelf->wasmetal_core__DOT___011503_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___011513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001886_))));
    vlSelf->wasmetal_core__DOT___057573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d))));
    vlSelf->wasmetal_core__DOT___057574_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))));
    vlSelf->wasmetal_core__DOT___057572_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))));
    vlSelf->wasmetal_core__DOT___057571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))));
    vlSelf->wasmetal_core__DOT___011508_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___056425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___011522_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___011518_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___011519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___011537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___010932_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___010939_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___010911_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    vlSelf->wasmetal_core__DOT___010918_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___010925_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___011527_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___010992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___010999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001624_))));
    vlSelf->wasmetal_core__DOT___010983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001646_))));
    vlSelf->wasmetal_core__DOT___010989_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___011124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000432_))));
    vlSelf->wasmetal_core__DOT___011125_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000464_))));
    vlSelf->wasmetal_core__DOT___010958_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___011867_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000498_))));
    vlSelf->wasmetal_core__DOT___011004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000520_))));
    vlSelf->wasmetal_core__DOT___011011_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000542_))));
    vlSelf->wasmetal_core__DOT___011014_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___011017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->wasmetal_core__DOT___010961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000613_))));
    vlSelf->wasmetal_core__DOT___056436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___010976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d))));
    vlSelf->wasmetal_core__DOT___056381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->wasmetal_core__DOT___010892_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->wasmetal_core__DOT___010880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___010886_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___010854_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___010860_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___010969_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___010868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___010874_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___056367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___010773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___010761_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___010767_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___010735_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___010741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___010755_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___010749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___056325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___010540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___010537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___010538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->wasmetal_core__DOT___010533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001327_))));
    vlSelf->wasmetal_core__DOT___056324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000980_))));
    vlSelf->wasmetal_core__DOT___010528_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000992_))));
    vlSelf->wasmetal_core__DOT___010529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___056326_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->wasmetal_core__DOT___056327_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___010590_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___010584_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___010546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->wasmetal_core__DOT___010552_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___010559_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___010568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->wasmetal_core__DOT___045735_ = (1U & (0xd00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001234_))))));
    vlSelf->wasmetal_core__DOT___047962_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x4000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x8000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->__VdfgTmp_h11a2e1d4__0 = ((2U & ((0x8000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___047780_));
    vlSelf->wasmetal_core__DOT___047789_ = (1U & (IData)(
                                                         (0x7ffffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047780_)))))))));
    vlSelf->__VdfgTmp_haec53eda__0 = ((2U & ((0x4000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___047780_));
    vlSelf->wasmetal_core__DOT___048315_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___044184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___070609_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047780_))));
    vlSelf->wasmetal_core__DOT___044111_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045705_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he33f1ed5__0))));
    vlSelf->wasmetal_core__DOT___044168_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044174_) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___044170_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (3U 
                                                     & (vlSelf->insn_op 
                                                        >> 0x18U))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___063407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063382_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00f1f100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052985_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->mem_fault))))))))))));
    vlSelf->wasmetal_core__DOT___052988_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052985_)))));
    vlSelf->wasmetal_core__DOT___070487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051227_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->cmd_kind)))));
    vlSelf->wasmetal_core__DOT___070489_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051227_))));
    vlSelf->wasmetal_core__DOT___053751_ = (1U & (IData)(
                                                         (0xf4ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053421_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_ready) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053002_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052986_)))))))));
    vlSelf->wasmetal_core__DOT___063417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063392_))));
    vlSelf->wasmetal_core__DOT___070264_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070263_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0xfU)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 4U) & (IData)(vlSelf->wasmetal_core__DOT___027954_));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 4U) : (IData)(vlSelf->wasmetal_core__DOT___030489_)));
    vlSelf->wasmetal_core__DOT___070326_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070325_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x14U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070300_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070299_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x12U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___070276_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070275_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[3U] 
                                                             >> 0x10U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[1U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___054476_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___051277_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___050454_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050438_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0))))));
    vlSelf->wasmetal_core__DOT___068124_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 6U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x17U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068447_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xcU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068378_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xbU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1cU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068182_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 7U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x18U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068209_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 8U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x19U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068316_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xaU)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1bU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068055_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x16U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068269_ = (1U & (IData)(
                                                         (0x8acf000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068051_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 9U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x1aU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h625a9757__0))))))));
    vlSelf->wasmetal_core__DOT___068539_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068537_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066456_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068777_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066808_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___068495_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0xeU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068580_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068576_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066479_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___068680_ = (1U & (IData)(
                                                         (0xd000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068675_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___066669_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065567_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[0U] 
                                                                             >> 0x1cU))))))))));
    vlSelf->wasmetal_core__DOT___068619_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->mem_rdata[0U]) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x11U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068716_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 2U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x13U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068816_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 4U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[0U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1936621__0))))))));
    vlSelf->wasmetal_core__DOT___068870_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068492_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065560_) 
                                                       << 1U) 
                                                      | (vlSelf->mem_rdata[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___065028_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064698_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065027_))));
    vlSelf->wasmetal_core__DOT___064840_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064836_))))))))));
    vlSelf->wasmetal_core__DOT___065145_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065144_))));
    vlSelf->wasmetal_core__DOT___065225_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065027_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065224_))));
    vlSelf->wasmetal_core__DOT___065382_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065144_))));
    vlSelf->wasmetal_core__DOT___065487_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065486_))));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032888_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___065511_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065510_))));
    vlSelf->wasmetal_core__DOT___065651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065486_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065650_))));
    vlSelf->wasmetal_core__DOT___064862_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064417_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064434_))));
    vlSelf->wasmetal_core__DOT___065763_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065510_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065762_))));
    vlSelf->wasmetal_core__DOT___065020_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064688_))));
    vlSelf->wasmetal_core__DOT___064429_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064417_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064416_))));
    vlSelf->wasmetal_core__DOT___065846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065650_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065845_))));
    vlSelf->wasmetal_core__DOT___065958_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065762_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065957_))));
    vlSelf->wasmetal_core__DOT___064687_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064682_))));
    vlSelf->wasmetal_core__DOT___066029_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065845_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066028_))));
    vlSelf->wasmetal_core__DOT___064861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064427_))));
    vlSelf->wasmetal_core__DOT___066182_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065957_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066181_))));
    vlSelf->wasmetal_core__DOT___065018_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064685_))));
    vlSelf->wasmetal_core__DOT___066227_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066226_))));
    vlSelf->wasmetal_core__DOT___064428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064427_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064426_))));
    vlSelf->wasmetal_core__DOT___066338_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066181_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066337_))));
    vlSelf->wasmetal_core__DOT___064686_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064685_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064684_))));
    vlSelf->wasmetal_core__DOT___066436_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066435_))));
    vlSelf->wasmetal_core__DOT___064860_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064426_))));
    vlSelf->wasmetal_core__DOT___066502_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066337_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066501_))));
    vlSelf->wasmetal_core__DOT___065017_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064684_))));
    vlSelf->wasmetal_core__DOT___066583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066435_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066582_))));
    vlSelf->wasmetal_core__DOT___064383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064370_))));
    vlSelf->wasmetal_core__DOT___066697_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066696_))));
    vlSelf->wasmetal_core__DOT___064673_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064669_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064668_))));
    vlSelf->wasmetal_core__DOT___066750_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066749_))));
    vlSelf->wasmetal_core__DOT___065373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdbf4091d__0))))));
    vlSelf->wasmetal_core__DOT___066832_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066696_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066831_))));
    vlSelf->wasmetal_core__DOT___065012_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064668_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064671_))));
    vlSelf->wasmetal_core__DOT___066916_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066749_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066915_))));
    vlSelf->wasmetal_core__DOT___064382_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdbf4091d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064380_))));
    vlSelf->wasmetal_core__DOT___067000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066831_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066999_))));
    vlSelf->wasmetal_core__DOT___064672_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064671_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064670_))));
    vlSelf->wasmetal_core__DOT___067045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066915_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067044_))));
    vlSelf->wasmetal_core__DOT___069958_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             (2U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                                 << 1U))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069193_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b62__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069191_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (2U 
                                                                             & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064354_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (2U 
                                                                              & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))));
    vlSelf->wasmetal_core__DOT___064858_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064380_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064393_))));
    vlSelf->wasmetal_core__DOT___067130_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067129_))));
    vlSelf->wasmetal_core__DOT___065011_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064670_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064675_))));
    vlSelf->wasmetal_core__DOT___067241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067240_))));
    vlSelf->wasmetal_core__DOT___069287_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069217_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064662_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064661_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___064405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064392_))));
    vlSelf->wasmetal_core__DOT___067280_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067129_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067279_))));
    vlSelf->wasmetal_core__DOT___064679_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064675_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064674_))));
    vlSelf->wasmetal_core__DOT___067385_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067384_))));
    vlSelf->wasmetal_core__DOT___069267_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069185_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069266_))));
    vlSelf->wasmetal_core__DOT___064356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064355_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064354_))));
    vlSelf->wasmetal_core__DOT___064856_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064392_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064403_))));
    vlSelf->wasmetal_core__DOT___067432_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067431_))));
    vlSelf->wasmetal_core__DOT___065014_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064674_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064677_))));
    vlSelf->wasmetal_core__DOT___067529_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067384_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067528_))));
    vlSelf->wasmetal_core__DOT___069218_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069217_))));
    vlSelf->wasmetal_core__DOT___065006_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064661_))));
    vlSelf->wasmetal_core__DOT___069186_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069070_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069185_))));
    vlSelf->wasmetal_core__DOT___064850_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064355_))));
    vlSelf->wasmetal_core__DOT___069119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069118_))));
    vlSelf->wasmetal_core__DOT___064663_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064659_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064658_))));
    vlSelf->wasmetal_core__DOT___064404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064402_))));
    vlSelf->wasmetal_core__DOT___067577_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067576_))));
    vlSelf->wasmetal_core__DOT___064678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064677_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064676_))));
    vlSelf->wasmetal_core__DOT___067643_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067528_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067642_))));
    vlSelf->wasmetal_core__DOT___069071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069070_))));
    vlSelf->wasmetal_core__DOT___064357_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064344_))));
    vlSelf->wasmetal_core__DOT___064855_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064402_))));
    vlSelf->wasmetal_core__DOT___067711_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067576_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067710_))));
    vlSelf->wasmetal_core__DOT___065013_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064639_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064676_))));
    vlSelf->wasmetal_core__DOT___067790_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067642_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067789_))));
    vlSelf->wasmetal_core__DOT___069024_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068925_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069023_))));
    vlSelf->wasmetal_core__DOT___065003_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064654_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064659_))));
    vlSelf->wasmetal_core__DOT___068993_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068876_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068992_))));
    vlSelf->wasmetal_core__DOT___064847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064332_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064345_))));
    vlSelf->wasmetal_core__DOT___064289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064276_))));
    vlSelf->wasmetal_core__DOT___067839_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067710_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067838_))));
    vlSelf->wasmetal_core__DOT___068926_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068829_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068925_))));
    vlSelf->wasmetal_core__DOT___064656_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064655_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064654_))));
    vlSelf->wasmetal_core__DOT___068830_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068729_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068829_))));
    vlSelf->wasmetal_core__DOT___068877_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068876_))));
    vlSelf->wasmetal_core__DOT___065004_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064655_))));
    vlSelf->wasmetal_core__DOT___064334_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064332_))));
    vlSelf->wasmetal_core__DOT___064643_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064639_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064638_))));
    vlSelf->wasmetal_core__DOT___067882_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067789_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067881_))));
    vlSelf->wasmetal_core__DOT___064842_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064287_))));
    vlSelf->wasmetal_core__DOT___067942_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067941_))));
    vlSelf->wasmetal_core__DOT___064998_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064638_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064641_))));
    vlSelf->wasmetal_core__DOT___068005_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068004_))));
    vlSelf->wasmetal_core__DOT___064288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064287_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064286_))));
    vlSelf->wasmetal_core__DOT___068058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067941_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068057_))));
    vlSelf->wasmetal_core__DOT___068780_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068682_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068779_))));
    vlSelf->wasmetal_core__DOT___064848_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064322_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064333_))));
    vlSelf->wasmetal_core__DOT___064642_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064641_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064640_))));
    vlSelf->wasmetal_core__DOT___068133_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068132_))));
    vlSelf->wasmetal_core__DOT___064997_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064640_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064645_))));
    vlSelf->wasmetal_core__DOT___064841_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064299_))));
    vlSelf->wasmetal_core__DOT___064311_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064298_))));
    vlSelf->wasmetal_core__DOT___068219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068132_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068218_))));
    vlSelf->wasmetal_core__DOT___068185_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068184_))));
    vlSelf->wasmetal_core__DOT___068272_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068184_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068271_))));
    vlSelf->wasmetal_core__DOT___064649_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064645_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064644_))));
    vlSelf->wasmetal_core__DOT___068325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068324_))));
    vlSelf->wasmetal_core__DOT___068730_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068729_))));
    vlSelf->wasmetal_core__DOT___064657_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064653_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064652_))));
    vlSelf->wasmetal_core__DOT___064844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064298_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064309_))));
    vlSelf->wasmetal_core__DOT___068381_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068271_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068380_))));
    vlSelf->wasmetal_core__DOT___064335_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064322_))));
    vlSelf->wasmetal_core__DOT___068683_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068582_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068682_))));
    vlSelf->wasmetal_core__DOT___065000_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064647_))));
    vlSelf->wasmetal_core__DOT___068456_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068455_))));
    vlSelf->wasmetal_core__DOT___064648_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064646_))));
    vlSelf->wasmetal_core__DOT___064999_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064646_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064653_))));
    vlSelf->wasmetal_core__DOT___064843_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064323_))));
    vlSelf->wasmetal_core__DOT___064310_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064308_))));
    vlSelf->wasmetal_core__DOT___068633_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068632_))));
    vlSelf->wasmetal_core__DOT___068519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068518_))));
    vlSelf->wasmetal_core__DOT___068583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068582_))));
    vlSelf->wasmetal_core__DOT___068501_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068380_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068500_))));
    vlSelf->wasmetal_core__DOT___064806_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064796_))))))))));
    vlSelf->wasmetal_core__DOT___064940_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064589_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064939_))));
    vlSelf->wasmetal_core__DOT___065104_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065103_))));
    vlSelf->wasmetal_core__DOT___067421_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064130_)) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                      << 1U))));
    vlSelf->wasmetal_core__DOT___065244_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065243_))));
    vlSelf->wasmetal_core__DOT___064604_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064603_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___067633_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067515_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065332_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065103_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065331_))));
    vlSelf->wasmetal_core__DOT___065443_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065243_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065442_))));
    vlSelf->wasmetal_core__DOT___064132_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064130_))));
    vlSelf->wasmetal_core__DOT___067549_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067548_))));
    vlSelf->wasmetal_core__DOT___064196_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064188_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064187_))));
    vlSelf->wasmetal_core__DOT___065527_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065526_))));
    vlSelf->wasmetal_core__DOT___064963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064603_))));
    vlSelf->wasmetal_core__DOT___067516_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067515_))));
    vlSelf->wasmetal_core__DOT___064605_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064600_))));
    vlSelf->wasmetal_core__DOT___064811_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064120_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064131_))));
    vlSelf->wasmetal_core__DOT___067372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067227_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067371_))));
    vlSelf->wasmetal_core__DOT___067414_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067413_))));
    vlSelf->wasmetal_core__DOT___064619_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064615_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064614_))));
    vlSelf->wasmetal_core__DOT___065667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065442_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065666_))));
    vlSelf->wasmetal_core__DOT___064133_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064121_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064120_))));
    vlSelf->wasmetal_core__DOT___067274_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067117_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067273_))));
    vlSelf->wasmetal_core__DOT___065862_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065666_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065861_))));
    vlSelf->wasmetal_core__DOT___065745_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065526_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065744_))));
    vlSelf->wasmetal_core__DOT___064178_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064166_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064165_))));
    vlSelf->wasmetal_core__DOT___065978_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065744_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065977_))));
    vlSelf->wasmetal_core__DOT___064960_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064601_))));
    vlSelf->wasmetal_core__DOT___067228_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067227_))));
    vlSelf->wasmetal_core__DOT___064613_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064609_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064608_))));
    vlSelf->wasmetal_core__DOT___066041_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065861_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066040_))));
    vlSelf->wasmetal_core__DOT___064808_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064152_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064121_))));
    vlSelf->wasmetal_core__DOT___067118_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___067009_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067117_))));
    vlSelf->wasmetal_core__DOT___064967_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064608_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064611_))));
    vlSelf->wasmetal_core__DOT___064815_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064165_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064176_))));
    vlSelf->wasmetal_core__DOT___064177_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064176_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064175_))));
    vlSelf->wasmetal_core__DOT___066239_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066040_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066238_))));
    vlSelf->wasmetal_core__DOT___066170_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065977_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066169_))));
    vlSelf->wasmetal_core__DOT___066348_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066169_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066347_))));
    vlSelf->wasmetal_core__DOT___064598_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064596_))));
    vlSelf->wasmetal_core__DOT___067057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066926_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___067056_))));
    vlSelf->wasmetal_core__DOT___064612_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064611_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064610_))));
    vlSelf->wasmetal_core__DOT___066448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066447_))));
    vlSelf->wasmetal_core__DOT___064961_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064594_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064597_))));
    vlSelf->wasmetal_core__DOT___064809_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064142_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064153_))));
    vlSelf->__VdfgTmp_he8a45048__0 = (((IData)(wasmetal_core__DOT___064153_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___064152_));
    vlSelf->wasmetal_core__DOT___066927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066736_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066926_))));
    vlSelf->wasmetal_core__DOT___066822_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066686_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066821_))));
    vlSelf->wasmetal_core__DOT___067010_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066821_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___067009_))));
    vlSelf->wasmetal_core__DOT___064599_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064595_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064594_))));
    vlSelf->wasmetal_core__DOT___064966_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064595_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064610_))));
    vlSelf->wasmetal_core__DOT___064814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064175_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064143_))));
    vlSelf->wasmetal_core__DOT___064154_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064143_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064142_))));
    vlSelf->wasmetal_core__DOT___066737_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066569_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066736_))));
    vlSelf->wasmetal_core__DOT___066570_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066447_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066569_))));
    vlSelf->wasmetal_core__DOT___066494_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066347_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066493_))));
    vlSelf->wasmetal_core__DOT___066687_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066493_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066686_))));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027823_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d));
    vlSelf->wasmetal_core__DOT___064787_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (4U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064779_))))))))));
    vlSelf->wasmetal_core__DOT___064981_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064544_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064980_))));
    vlSelf->wasmetal_core__DOT___064561_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064560_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___066427_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066250_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065091_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064779_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065090_))));
    vlSelf->wasmetal_core__DOT___064055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066151_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066360_))));
    vlSelf->wasmetal_core__DOT___065269_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064980_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065268_))));
    vlSelf->__VdfgTmp_h9d56b9e6__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064557_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064560_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___064051_) 
                                                     << 1U)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___066251_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___066054_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066250_))));
    vlSelf->__VdfgTmp_h23108600__0 = ((2U & ((0xacU 
                                              >> (((IData)(wasmetal_core__DOT___064043_) 
                                                   << 1U) 
                                                  | (IData)(wasmetal_core__DOT___064054_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064053_))));
    vlSelf->wasmetal_core__DOT___066152_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065988_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066151_))));
    vlSelf->wasmetal_core__DOT___065356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065090_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065355_))));
    vlSelf->wasmetal_core__DOT___065463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065268_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065462_))));
    vlSelf->wasmetal_core__DOT___066055_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065873_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___066054_))));
    vlSelf->wasmetal_core__DOT___064056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064043_))));
    vlSelf->wasmetal_core__DOT___065989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065775_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065988_))));
    vlSelf->wasmetal_core__DOT___064566_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064564_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064563_))));
    vlSelf->wasmetal_core__DOT___064989_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064558_))));
    vlSelf->wasmetal_core__DOT___064789_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064044_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___064077_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064066_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___064065_))));
    vlSelf->wasmetal_core__DOT___065678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065462_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065677_))));
    vlSelf->wasmetal_core__DOT___065874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065677_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065873_))));
    vlSelf->wasmetal_core__DOT___065537_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065355_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065536_))));
    vlSelf->wasmetal_core__DOT___065776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065536_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065775_))));
    vlSelf->wasmetal_core__DOT___064828_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064822_))))))));
    vlSelf->wasmetal_core__DOT___065352_ = (1U & (0x10U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                         << 1U)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064237_))));
    vlSelf->__VdfgTmp_ha92622e4__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064232_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064231_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064237_));
    vlSelf->wasmetal_core__DOT___066804_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065547_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___064952_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064571_)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___064951_))));
    vlSelf->wasmetal_core__DOT___065265_ = (1U & (IData)(
                                                         (0xf0ffe000f0fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065263_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> 
                                                                      ((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                       << 1U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0x5cU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd333e317__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                             << 1U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                              << 1U)))))))))));
    vlSelf->wasmetal_core__DOT___065639_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065453_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                          << 1U))))));
    vlSelf->wasmetal_core__DOT___065548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065547_))));
    vlSelf->wasmetal_core__DOT___065257_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___064951_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065256_))));
    vlSelf->wasmetal_core__DOT___065454_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065256_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065453_))));
    vlSelf->wasmetal_core__DOT___065122_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064822_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065121_))));
    vlSelf->wasmetal_core__DOT___065345_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___065121_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___065344_))));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 4U) & (IData)(vlSelf->wasmetal_core__DOT___028180_));
    vlSelf->wasmetal_core__DOT___028115_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1cU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h946ed16f__0)))));
    vlSelf->wasmetal_core__DOT___028114_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1bU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1dU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000657_))))));
    vlSelf->wasmetal_core__DOT___028112_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1aU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1cU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000635_))))));
    vlSelf->wasmetal_core__DOT___028111_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x19U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1bU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000613_))))));
    vlSelf->wasmetal_core__DOT___028110_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x18U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x1aU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000591_))))));
    vlSelf->wasmetal_core__DOT___028109_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x17U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h17df9f02__0)))));
    vlSelf->wasmetal_core__DOT___028108_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x16U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x18U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000542_))))));
    vlSelf->wasmetal_core__DOT___028107_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x15U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x17U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000520_))))));
    vlSelf->wasmetal_core__DOT___028106_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x14U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd5d86514__0)))));
    vlSelf->wasmetal_core__DOT___028105_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x13U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000476_))))));
    vlSelf->wasmetal_core__DOT___028104_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x12U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000464_))))));
    vlSelf->wasmetal_core__DOT___028103_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x11U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd7080d55__0)))));
    vlSelf->wasmetal_core__DOT___028101_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x10U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfe93be6e__0)))));
    vlSelf->wasmetal_core__DOT___028100_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x11U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001646_))))));
    vlSelf->wasmetal_core__DOT___028099_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xeU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0x10U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001624_))))));
    vlSelf->wasmetal_core__DOT___028098_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xdU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xfU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001612_))))));
    vlSelf->wasmetal_core__DOT___028097_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xcU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001580_))))));
    vlSelf->wasmetal_core__DOT___028096_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xbU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8243d19d__0)))));
    vlSelf->wasmetal_core__DOT___028095_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 0xaU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xcU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001536_))))));
    vlSelf->wasmetal_core__DOT___028094_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 9U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 0xbU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001524_))))));
    vlSelf->wasmetal_core__DOT___028093_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 8U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he8f67c93__0)))));
    vlSelf->wasmetal_core__DOT___028092_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 7U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haf096c00__0)))));
    vlSelf->wasmetal_core__DOT___028122_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 6U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 8U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001381_))))));
    vlSelf->wasmetal_core__DOT___028121_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 7U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001369_))))));
    vlSelf->wasmetal_core__DOT___028120_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 6U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001487_))))));
    vlSelf->wasmetal_core__DOT___028119_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 5U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001475_))))));
    vlSelf->wasmetal_core__DOT___028118_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfcd21fa2__0)))));
    vlSelf->wasmetal_core__DOT___028117_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 3U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001437_))))));
    vlSelf->wasmetal_core__DOT___028116_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & vlSelf->insn_x) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4104a354__0)))));
    vlSelf->wasmetal_core__DOT___028113_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_y 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001874_))))));
    vlSelf->wasmetal_core__DOT___028102_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & vlSelf->insn_y) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___028091_ = (1U & (0x53acU 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_x 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045805_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h521b28ea__0)))));
    vlSelf->wasmetal_core__DOT___052870_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___032681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052868_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052867_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044723_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___044724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___044722_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___044757_ = (1U & (0x2b22U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_locals 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                         | (1U 
                                                            & (vlSelf->function_locals 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___044769_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_locals 
                                                       << 2U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->function_locals)))));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 4U)) & (IData)(vlSelf->wasmetal_core__DOT___030971_));
    vlSelf->wasmetal_core__DOT___044693_ = ((IData)(vlSelf->wasmetal_core__DOT___044716_)
                                             ? ((IData)(wasmetal_core__DOT___044725_)
                                                 ? 
                                                ((IData)(wasmetal_core__DOT___044724_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044723_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044722_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044721_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044720_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044719_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044718_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___044717_)
                                                         ? 
                                                        ((~ 
                                                          (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___044703_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044705_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044706_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044707_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044708_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044709_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044710_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044711_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044712_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044713_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044704_));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032696_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037206_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h61cb7e30__0))));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026379_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d));
    vlSelf->wasmetal_core__DOT___043578_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070579_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___043284_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043131_))));
    vlSelf->wasmetal_core__DOT___043135_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 3U)) 
                                                   | (IData)(wasmetal_core__DOT___070579_))));
    vlSelf->wasmetal_core__DOT___044073_ = (1U & (0xeU 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044104_))));
    vlSelf->wasmetal_core__DOT___007061_ = (1U & (IData)(
                                                         (0xbf1ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))));
    vlSelf->wasmetal_core__DOT___048306_ = (1U & (0xfe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x1000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->wasmetal_core__DOT___047961_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x1000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)))))))));
    vlSelf->wasmetal_core__DOT___047967_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))))));
    vlSelf->wasmetal_core__DOT___003041_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))))));
    vlSelf->wasmetal_core__DOT___048321_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___053331_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044604_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053330_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x9009000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053314_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053313_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x13U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x11U))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x9009000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053326_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1dU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___053324_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053323_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053322_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x9009U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053318_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053317_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1aU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1001000000001001ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x10U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xeU)) 
                                                                                | ((2U 
                                                                                & ((6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 3U)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 2U)))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___054450_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___045219_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045243_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___044947_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___044971_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___054323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054331_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054348_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054354_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054366_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054372_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054384_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054390_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054402_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054420_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054426_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054438_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054444_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054342_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054360_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054378_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054396_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054432_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054321_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)))));
    vlSelf->wasmetal_core__DOT___054322_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054330_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054353_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054371_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054383_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054389_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054401_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054419_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054425_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054437_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054443_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054359_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054377_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054395_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054413_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054320_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054327_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054333_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054350_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054356_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054368_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054374_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054386_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054392_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054404_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054410_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054428_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054440_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054446_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054344_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054362_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054380_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054398_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054416_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054434_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054329_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054335_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127935___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054352_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127937___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054358_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054370_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127939___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054376_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127940___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054388_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054394_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127942___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054412_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127928___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054424_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127930___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054430_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054442_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054448_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054364_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127938___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054382_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127941___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054400_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127943___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054418_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127929___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054436_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127931___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054326_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054332_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054349_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054355_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054367_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054373_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054391_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054403_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054409_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054421_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054427_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054439_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054445_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054343_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054361_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054379_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054397_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054415_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054433_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054328_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054334_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127918___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054351_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127920___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054357_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054369_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127922___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054375_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127923___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054387_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054393_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127925___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054405_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054411_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127911___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054423_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127913___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054429_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054441_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054447_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054345_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054363_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127921___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054381_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127924___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054399_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127926___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054417_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127912___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054435_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127914___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054478_))));
    vlSelf->wasmetal_core__DOT___050403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048513_))));
    vlSelf->wasmetal_core__DOT___050404_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052578_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048513_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050392_)))));
    vlSelf->wasmetal_core__DOT___062976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___052891_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___025060_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___067477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d))));
    vlSelf->wasmetal_core__DOT___053091_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000359_))));
    vlSelf->__VdfgTmp_hf8819515__0 = (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___054478_));
    vlSelf->wasmetal_core__DOT___054481_ = (1U & (IData)(
                                                         (0xfcf3ff3ffffffff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___062493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048278_))));
    vlSelf->wasmetal_core__DOT___050397_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048398_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050392_)))));
    vlSelf->wasmetal_core__DOT___052693_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048398_))));
    vlSelf->wasmetal_core__DOT___048339_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | (((IData)(wasmetal_core__DOT___048337_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000354_))))));
    vlSelf->wasmetal_core__DOT___048434_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___048337_))));
    vlSelf->wasmetal_core__DOT___048432_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048337_))));
    vlSelf->wasmetal_core__DOT___052850_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048365_))));
    vlSelf->wasmetal_core__DOT___010005_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007028_)))));
    vlSelf->wasmetal_core__DOT___048367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048365_))));
    vlSelf->wasmetal_core__DOT___071778_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->wasmetal_core__DOT___056252_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___053753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048326_))));
    vlSelf->wasmetal_core__DOT___062175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048320_))));
    vlSelf->wasmetal_core__DOT___053495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048320_))));
    vlSelf->wasmetal_core__DOT___048322_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048320_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___053770_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___048351_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048383_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->wasmetal_core__DOT___048404_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->wasmetal_core__DOT___019280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->__VdfgTmp_h82d8a9a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048343_));
    vlSelf->wasmetal_core__DOT___052900_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048327_)))));
    vlSelf->wasmetal_core__DOT___048384_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048366_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048458_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___048414_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048417_ = (1U & (0xedf3ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h752c22b4__0))))));
    vlSelf->wasmetal_core__DOT___048376_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048319_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010006_)))));
    vlSelf->wasmetal_core__DOT___048440_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___048418_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___048446_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x100U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->wasmetal_core__DOT___048304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010006_))));
    vlSelf->wasmetal_core__DOT___050357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc416787b__0))))));
    vlSelf->wasmetal_core__DOT___051531_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc416787b__0))))));
    vlSelf->wasmetal_core__DOT___048270_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc416787b__0))));
    vlSelf->wasmetal_core__DOT___048407_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___063775_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_hc62a6006__0 = (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000354_));
    vlSelf->wasmetal_core__DOT___052904_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_hb92dbfd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000378_));
    vlSelf->wasmetal_core__DOT___007190_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->__VdfgTmp_h4a5b8c23__0 = ((4U & ((1U >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000353_)));
    vlSelf->wasmetal_core__DOT___048475_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047786_)))));
    vlSelf->wasmetal_core__DOT___007058_ = (1U & (0xbfU 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___048461_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x100U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->wasmetal_core__DOT___048460_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000353_))));
    vlSelf->wasmetal_core__DOT___048490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->wasmetal_core__DOT___048455_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___047781_)))));
    vlSelf->wasmetal_core__DOT___048324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->wasmetal_core__DOT___048316_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010007_))));
    vlSelf->__VdfgTmp_hc8342b84__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010006_));
    vlSelf->wasmetal_core__DOT___053769_ = (1U & (IData)(
                                                         (0xfff1f1f1f1ffffffULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->insn_op 
                                                               >> 2U)) 
                                                           | ((2U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___048326_))))));
    vlSelf->__VdfgTmp_h6d3657d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))));
    vlSelf->__VdfgTmp_haa5fc240__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___002988_));
    vlSelf->wasmetal_core__DOT___048368_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))))));
    vlSelf->wasmetal_core__DOT___048399_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))));
    vlSelf->wasmetal_core__DOT___048462_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)))))));
    vlSelf->wasmetal_core__DOT___048400_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0))))));
    vlSelf->wasmetal_core__DOT___048378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048363_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048283_)))));
    vlSelf->wasmetal_core__DOT___048334_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048326_))))));
    vlSelf->wasmetal_core__DOT___025061_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048444_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048438_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048283_))));
    vlSelf->wasmetal_core__DOT___048313_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))))));
    vlSelf->wasmetal_core__DOT___048364_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0))))));
    vlSelf->wasmetal_core__DOT___019304_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h28012a28__0))))));
    vlSelf->__VdfgTmp_haf8eec33__0 = ((2U & ((8U >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048320_));
    vlSelf->wasmetal_core__DOT___050447_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___053764_ = (1U & (0x1110fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047781_)))))));
    vlSelf->wasmetal_core__DOT___052878_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
}
