#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__33(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__33\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128105___O;
    wasmetal_core__DOT____Vcellout___128105___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->__VdfgTmp_h8e8edf3a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_h674d61dd__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_haa9bafe9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hc2de3b41__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___023904_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d) {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024031_;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___018857_ = (1U & (IData)(
                                                         (0xfffeffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059074_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5565504__0))))))));
    vlSelf->wasmetal_core__DOT___017414_ = ((0x80000000U 
                                             >> (((IData)(vlSelf->wasmetal_core__DOT___048930_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048929_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0x80000000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0x8000000000000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed5eddc9__0))))))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___000131_));
    vlSelf->wasmetal_core__DOT___012356_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x55fc0000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0aaaaff00ccccULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012029_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012028_)))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xeeee0000fff0ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))))))))))));
    vlSelf->wasmetal_core__DOT___067544_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4448f15c__0))));
    vlSelf->wasmetal_core__DOT___056316_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_heef7d961__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___056492_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xf400U 
                                                         >> (IData)(vlSelf->__VdfgTmp_heef7d961__0))))));
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006029_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013786_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h7e209046__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_he1214f4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_he2a95d7a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hae3fb8cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___022885_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022948_;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___051928_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051696_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->wasmetal_core__DOT___064460_ = (1U & (IData)(
                                                         (0xff00ff00ff007000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055082_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055081_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___049540_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049523_))))));
    vlSelf->wasmetal_core__DOT___051839_ = (1U & (IData)(
                                                         (0x33aa0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051833_)))))))));
    vlSelf->wasmetal_core__DOT___050831_ = (1U & (0xf0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050823_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050822_))))));
    vlSelf->wasmetal_core__DOT___051801_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051796_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051795_)))))));
    vlSelf->wasmetal_core__DOT___053820_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051797_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051796_)))));
    vlSelf->wasmetal_core__DOT___051332_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051330_)))));
    vlSelf->wasmetal_core__DOT___051802_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h36c85254__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf78fffffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                         | (2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                               << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___053823_ = (1U & (0x55cc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h36c85254__0))));
    vlSelf->wasmetal_core__DOT___051322_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049772_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051321_)))));
    vlSelf->wasmetal_core__DOT___050655_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049772_))));
    vlSelf->wasmetal_core__DOT___051792_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051781_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051780_)))))));
    vlSelf->wasmetal_core__DOT___053816_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051781_)))));
    vlSelf->wasmetal_core__DOT___066957_ = (1U & (IData)(
                                                         (0xbf00bfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050983_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050982_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050981_)))))))));
    vlSelf->wasmetal_core__DOT___051293_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051291_)))));
    vlSelf->wasmetal_core__DOT___051793_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xffaaffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h937c72cf__0)))))))))));
    vlSelf->wasmetal_core__DOT___009513_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0))));
    vlSelf->__VdfgTmp_h70db4808__0 = (((IData)(vlSelf->wasmetal_core__DOT___051297_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051295_)))));
    vlSelf->wasmetal_core__DOT___051873_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051867_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049524_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051866_)))))));
    vlSelf->wasmetal_core__DOT___066210_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xff55ccf0U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051995_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2966b870__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x30f0200030f030fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053628_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xa300U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0xf0f5533U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f0935bb__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h65c50ed7__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h40926396__0)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050060_))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049538_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051867_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xbfff0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054849_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049479_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051776_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051765_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051764_)))))));
    vlSelf->wasmetal_core__DOT___053810_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051766_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051765_)))));
    vlSelf->wasmetal_core__DOT___051119_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051117_)))));
    vlSelf->wasmetal_core__DOT___066876_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051104_))));
    vlSelf->__VdfgTmp_ha2491a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___051104_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051100_)))));
    vlSelf->wasmetal_core__DOT___051761_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051753_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051752_)))))));
    vlSelf->wasmetal_core__DOT___053528_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051753_)))));
    vlSelf->wasmetal_core__DOT___009523_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051062_)))));
    vlSelf->wasmetal_core__DOT___066803_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066798_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066797_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057736_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051048_))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->__VdfgTmp_h34f15f45__0 = (((IData)(vlSelf->wasmetal_core__DOT___051048_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051044_)))));
    vlSelf->wasmetal_core__DOT___053912_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053910_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x6eU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051617_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___051716_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051709_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051708_)))))));
    vlSelf->wasmetal_core__DOT___053712_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051709_)))));
    vlSelf->wasmetal_core__DOT___053729_ = (1U & (IData)(
                                                         (0x30f0200030f030fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> 
                                                                      (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 2U))) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x550f3300000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050895_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___049809_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0880000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)))))))))));
    vlSelf->wasmetal_core__DOT___049821_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049808_)))));
    vlSelf->wasmetal_core__DOT___051823_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050864_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051817_)))))));
    vlSelf->wasmetal_core__DOT___051660_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050864_)))));
    vlSelf->wasmetal_core__DOT___051373_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051369_)))));
    vlSelf->wasmetal_core__DOT___053904_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe0001ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___051854_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050873_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051849_)))))));
    vlSelf->wasmetal_core__DOT___050880_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050874_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050873_)))));
    vlSelf->wasmetal_core__DOT___051748_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051743_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051742_)))))));
    vlSelf->wasmetal_core__DOT___053798_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051744_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051743_)))));
    vlSelf->wasmetal_core__DOT___066713_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050705_))));
    vlSelf->wasmetal_core__DOT___050710_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050704_)))));
    vlSelf->wasmetal_core__DOT___051739_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051722_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051721_)))))));
    vlSelf->wasmetal_core__DOT___053720_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051722_)))));
    vlSelf->wasmetal_core__DOT___066627_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049896_))));
    vlSelf->wasmetal_core__DOT___049902_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049895_)))));
    vlSelf->wasmetal_core__DOT___051749_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07886821__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff7f80ffffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U))))))))))))))));
    vlSelf->wasmetal_core__DOT___053802_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h07886821__0))));
    vlSelf->wasmetal_core__DOT___050722_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050720_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050719_)))));
    vlSelf->wasmetal_core__DOT___053531_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050720_))));
    vlSelf->wasmetal_core__DOT___066011_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053387_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053385_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050874_)))))))));
    vlSelf->wasmetal_core__DOT___051855_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd604be0c__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xffe01fffffffffffULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))))))))));
    vlSelf->wasmetal_core__DOT___050879_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd604be0c__0))));
    vlSelf->wasmetal_core__DOT___051546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051543_)))));
    vlSelf->wasmetal_core__DOT___052610_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051544_))));
    vlSelf->wasmetal_core__DOT___051717_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa3fU 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h6af6bfd0__0))))))))))));
    vlSelf->wasmetal_core__DOT___053716_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0))));
    vlSelf->__VdfgTmp_hc6a436e7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049784_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049777_)))));
    vlSelf->wasmetal_core__DOT___065832_ = (1U & (IData)(
                                                         (0x5f13551100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065828_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0faaccU 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((4U 
                                                                              & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050637_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050601_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x7f7f7fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065823_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050865_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x20003fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065824_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050812_)))))))))))))))));
    vlSelf->__VdfgTmp_h6383fd4d__0 = (((IData)(vlSelf->wasmetal_core__DOT___050817_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050814_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049775_))))))));
    vlSelf->wasmetal_core__DOT___067183_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf3ffa200f3fff3ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067176_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067175_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051359_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000dd00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067179_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049526_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))))))))));
    vlSelf->__VdfgTmp_h56ff1f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051359_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049775_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051777_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((0xd0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xa300000U 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf722c8bb__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d)))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc485c507__0))))));
    vlSelf->wasmetal_core__DOT___053809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc485c507__0))));
    vlSelf->wasmetal_core__DOT___051874_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfd7fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h808d3d88__0))))))))));
    vlSelf->wasmetal_core__DOT___049482_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0))));
    vlSelf->wasmetal_core__DOT___053185_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051605_))));
    vlSelf->__VdfgTmp_h49696f4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051605_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___055205_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053722_))))));
    vlSelf->__VdfgTmp_h2cfc9ba7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049877_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049871_)))));
    vlSelf->wasmetal_core__DOT___065922_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053220_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053219_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff80ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053206_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xfef0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc489de0__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050837_))))))))))));
    vlSelf->__VdfgTmp_h0a242e26__0 = (((IData)(vlSelf->wasmetal_core__DOT___050837_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050834_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___049869_))))))));
    vlSelf->wasmetal_core__DOT___067261_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xbfbb3f333f33ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 5U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053654_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051985_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051513_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0aacc00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050829_))))))))))))));
    vlSelf->__VdfgTmp_h28bc3512__0 = (((IData)(vlSelf->wasmetal_core__DOT___051513_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049869_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128043___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028120_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028119_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028118_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028117_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028084_)))));
    vlSelf->wasmetal_core__DOT___028088_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028120_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 7U)));
    vlSelf->wasmetal_core__DOT___065636_ = (1U & (IData)(
                                                         (0x4f4f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053129_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7000000077ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053125_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049685_)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0faaccU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049846_))))))))))))));
    vlSelf->wasmetal_core__DOT___053702_ = (1U & ((4U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))
                                                   ? 
                                                  (0x800faffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009538_))))))
                                                   : 
                                                  (0x400055ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___009537_))))))));
    vlSelf->wasmetal_core__DOT___009509_ = (1U & (IData)(
                                                         (0xa0f00ff00ff33ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((8U 
                                                                      >> 
                                                                      ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049719_))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049833_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049720_)))))))))));
    vlSelf->wasmetal_core__DOT___049723_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049718_)))));
    vlSelf->wasmetal_core__DOT___053908_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053906_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf32aU 
                                                                         >> 
                                                                         ((0xcU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051584_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051587_)))))))));
    vlSelf->wasmetal_core__DOT___051862_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049211_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051857_)))))));
    vlSelf->wasmetal_core__DOT___049245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049211_)))));
    vlSelf->wasmetal_core__DOT___051703_ = (1U & (IData)(
                                                         (0x55cc0f0000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051460_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051692_)))))))));
    vlSelf->wasmetal_core__DOT___053704_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051460_)))));
    vlSelf->wasmetal_core__DOT___055414_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049761_))));
    vlSelf->wasmetal_core__DOT___049769_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049760_)))));
    vlSelf->wasmetal_core__DOT___051807_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051804_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051803_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 2U))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051350_)))))))));
    vlSelf->wasmetal_core__DOT___051355_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051349_)))));
    vlSelf->wasmetal_core__DOT___051814_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050804_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051809_)))))));
    vlSelf->wasmetal_core__DOT___065733_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065729_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x7f7f7fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___065725_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x20003fff00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052738_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050808_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0553300000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051898_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051591_))))))))))))));
    vlSelf->wasmetal_core__DOT___050858_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050805_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050804_)))));
    vlSelf->wasmetal_core__DOT___053396_ = (1U & (IData)(
                                                         (0xffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053392_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053391_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051634_)))))))));
    vlSelf->wasmetal_core__DOT___051638_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051633_)))));
    vlSelf->wasmetal_core__DOT___051886_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049636_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051880_)))))));
    vlSelf->wasmetal_core__DOT___009499_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049637_))));
    vlSelf->wasmetal_core__DOT___049651_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049637_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049636_)))));
    vlSelf->wasmetal_core__DOT___051656_ = (1U & (IData)(
                                                         (0x8000cfff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 1U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051641_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048562_)))))))));
    vlSelf->wasmetal_core__DOT___053579_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051641_))));
    vlSelf->__VdfgTmp_hc669ea30__0 = (((IData)(vlSelf->wasmetal_core__DOT___049694_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049691_)))));
    vlSelf->wasmetal_core__DOT___051887_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0f76403b__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h073e4ce8__0)))))))))));
    vlSelf->wasmetal_core__DOT___049676_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0f76403b__0))));
    vlSelf->__VdfgTmp_h4d7ec491__0 = (((IData)(vlSelf->wasmetal_core__DOT___051623_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051704_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2558491__0)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))))))));
    vlSelf->wasmetal_core__DOT___053708_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))));
    vlSelf->__VdfgTmp_hae9934f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___049740_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___049733_)))));
    vlSelf->wasmetal_core__DOT___051815_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45934da4__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfa3fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0))))))))));
    vlSelf->__VdfgTmp_hfed11520__0 = ((2U & ((0x55ccf0ffU 
                                              >> ((0x18U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 3U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h45934da4__0))) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0)))));
    vlSelf->__VdfgTmp_h19298f26__0 = (((IData)(vlSelf->wasmetal_core__DOT___051339_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049731_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051437_ = (1U & (0xfdf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051420_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051419_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___051418_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))))));
    vlSelf->wasmetal_core__DOT___053527_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))));
    vlSelf->wasmetal_core__DOT___066110_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->__VdfgTmp_h0de2f8d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049329_) 
                                       << 1U) | (1U 
                                                 & (0x5cU 
                                                    >> 
                                                    ((4U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 2U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049290_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (4U 
                                                              >> 
                                                              (2U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                                  << 1U)))))))));
    vlSelf->wasmetal_core__DOT___067404_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067403_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f010f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051574_))))))))))));
    vlSelf->__VdfgTmp_h0d8fe922__0 = (((IData)(vlSelf->wasmetal_core__DOT___051574_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128649___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001581_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001569_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001537_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001525_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034349_)))));
    vlSelf->wasmetal_core__DOT___034353_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001581_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028876_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028843_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028465_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->wasmetal_core__DOT___054068_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054072_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054071_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054076_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___054080_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128096___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053989_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052644_)))))))));
    vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028640_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028606_)
            : (IData)(vlSelf->wasmetal_core__DOT___004152_));
    vlSelf->wasmetal_core__DOT____Vcellout___128131___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___029083_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___029082_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___029081_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029080_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029047_)))));
    vlSelf->wasmetal_core__DOT___029051_ = ((IData)(vlSelf->wasmetal_core__DOT___029083_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->wasmetal_core__DOT___029056_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001425_))));
    vlSelf->wasmetal_core__DOT___029055_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___029085_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001381_))));
    vlSelf->wasmetal_core__DOT___029084_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128123___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001369_))));
    vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028952_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028918_)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b12__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001536_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001536_)
            : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT____Vcellout___128105___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028743_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028742_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028772_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028771_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028738_)))));
    vlSelf->wasmetal_core__DOT___028710_ = ((IData)(vlSelf->wasmetal_core__DOT___028743_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026455_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127885___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026665_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026664_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026726_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026725_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026660_)))));
    vlSelf->wasmetal_core__DOT___026600_ = ((IData)(vlSelf->wasmetal_core__DOT___026665_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___045241_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045217_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070684_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054325_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070683_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___045244_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045220_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070689_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054331_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070688_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127936___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027135_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027134_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027196_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027195_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027130_)))));
    vlSelf->wasmetal_core__DOT___027070_ = ((IData)(vlSelf->wasmetal_core__DOT___027135_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026593_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001382_));
    vlSelf->wasmetal_core__DOT___044969_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___044945_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070787_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054324_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070786_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___044972_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___044948_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070792_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054330_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070791_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127919___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026935_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026934_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026996_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026995_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026930_)))));
    vlSelf->wasmetal_core__DOT___026870_ = ((IData)(vlSelf->wasmetal_core__DOT___026935_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT____Vcellout___127902___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hce5538fe__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5011624a__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026795_)))));
    vlSelf->wasmetal_core__DOT___026735_ = ((1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hce5538fe__0)))
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___030095_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b36f4b3__0)))));
    vlSelf->wasmetal_core__DOT___030223_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3b36f4b3__0)))));
    vlSelf->wasmetal_core__DOT___030094_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf4f36877__0)))));
    vlSelf->wasmetal_core__DOT___030222_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf4f36877__0)))));
    vlSelf->wasmetal_core__DOT___030124_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0642a572__0)))));
    vlSelf->wasmetal_core__DOT___030284_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0642a572__0)))));
    vlSelf->wasmetal_core__DOT___030123_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071778_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25bc616c__0)))));
    vlSelf->wasmetal_core__DOT___030283_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h25bc616c__0)))));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001536_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128232___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030122_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030121_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030120_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030119_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030086_)))));
    vlSelf->wasmetal_core__DOT___030090_ = ((IData)(vlSelf->wasmetal_core__DOT___030122_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128246___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030282_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030281_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030276_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030265_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030190_)))));
    vlSelf->wasmetal_core__DOT___030218_ = ((IData)(vlSelf->wasmetal_core__DOT___030282_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT___063123_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063120_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063119_)))))));
    vlSelf->wasmetal_core__DOT___063129_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063126_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063125_)))))));
    vlSelf->wasmetal_core__DOT___063135_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063131_)))))));
    vlSelf->wasmetal_core__DOT___063141_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063138_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063137_)))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028316_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028251_));
    vlSelf->wasmetal_core__DOT____Vcellout___134173___O 
        = ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))) 
           ^ ((((4U >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                & (IData)(vlSelf->wasmetal_core__DOT___036894_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036894_)));
    vlSelf->wasmetal_core__DOT___064906_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064471_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___064736_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___063848_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063845_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063844_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042224_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048361_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048349_)))))))));
    vlSelf->__VdfgTmp_h60159710__0 = ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d)));
    vlSelf->wasmetal_core__DOT___044870_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127961___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027473_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027436_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027396_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127435___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hbc1c04e5__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022565_)))));
    vlSelf->wasmetal_core__DOT___022506_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031050_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___056626_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)
                                                   ? (IData)(
                                                             (0x33335555f0f0f0ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011460_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011458_))))))))
                                                   : 
                                                  (0xabU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011461_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011460_))))));
    vlSelf->__VdfgTmp_hc60fc2d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011792_))));
    vlSelf->wasmetal_core__DOT___056767_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011792_)))));
    vlSelf->__VdfgTmp_h75e79c91__0 = ((2U & ((0xcaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___012072_)))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012219_))))));
    vlSelf->wasmetal_core__DOT___057163_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011044_)))));
    vlSelf->wasmetal_core__DOT___011572_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011432_))))));
    vlSelf->wasmetal_core__DOT___057454_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h417b846d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011791_)))))))));
    vlSelf->wasmetal_core__DOT___011795_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011793_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011791_))))));
    vlSelf->wasmetal_core__DOT___057663_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___012219_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012071_)))))))));
    vlSelf->wasmetal_core__DOT___012224_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012071_))))));
    vlSelf->wasmetal_core__DOT___011428_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011431_)))))))));
    vlSelf->wasmetal_core__DOT___011130_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011087_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde352602__0))))))));
    vlSelf->__VdfgTmp_hca83bd04__0 = (((IData)(vlSelf->wasmetal_core__DOT___011088_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011087_));
    vlSelf->wasmetal_core__DOT___056892_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012070_)))))))));
    vlSelf->wasmetal_core__DOT___012607_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056592_)))))))));
    vlSelf->wasmetal_core__DOT___057380_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056715_)))))))));
    vlSelf->wasmetal_core__DOT___011908_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012781_)))))))));
    vlSelf->wasmetal_core__DOT___057627_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056890_)))))))));
    vlSelf->wasmetal_core__DOT___011293_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056591_)))))))));
    vlSelf->wasmetal_core__DOT___012256_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012071_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013057_)))))))));
    vlSelf->wasmetal_core__DOT___012387_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011087_)))))))));
    vlSelf->wasmetal_core__DOT___012558_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011431_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011332_)))))))));
    vlSelf->wasmetal_core__DOT___012808_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012780_)))))))));
    vlSelf->wasmetal_core__DOT___013034_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012070_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013056_)))))))));
    vlSelf->wasmetal_core__DOT___011079_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->wasmetal_core__DOT___011425_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056592_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011331_)))))))));
    vlSelf->wasmetal_core__DOT___011780_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056715_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012779_)))))))));
    vlSelf->wasmetal_core__DOT___012213_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056890_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))))));
    vlSelf->wasmetal_core__DOT___012405_ = (1U & (IData)(
                                                         (0xaaaaf0f0ff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056365_)))))))));
    vlSelf->__VdfgTmp_h2fb7cfc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011330_));
    vlSelf->__VdfgTmp_h3c43f86a__0 = (((IData)(vlSelf->wasmetal_core__DOT___012779_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012778_));
    vlSelf->wasmetal_core__DOT___012782_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010508_)
                                                      ? (IData)(
                                                                (0xefffffffffffffffULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0)))
                                                      : (IData)(
                                                                (0xecccccccccccccccULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfce8a752__0))))));
    vlSelf->__VdfgTmp_h140002d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___011330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011329_));
    vlSelf->__VdfgTmp_hb3a32b8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010404_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010403_));
    vlSelf->__VdfgTmp_hdaecee48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013055_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012105_));
    vlSelf->wasmetal_core__DOT___057246_ = (1U & (0xcaccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012559_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xdU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___010396_))))))))));
    vlSelf->wasmetal_core__DOT___012407_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010403_)))))))));
    vlSelf->wasmetal_core__DOT___012214_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012105_)))))))));
    vlSelf->wasmetal_core__DOT___011781_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012778_)))))))));
    vlSelf->__VdfgTmp_hd9ebd9b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012531_)));
    vlSelf->wasmetal_core__DOT___057090_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010403_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___056891_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ff0fffdfffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012105_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))));
    vlSelf->wasmetal_core__DOT___056771_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012778_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->wasmetal_core__DOT___011294_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011330_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011329_))))))));
    vlSelf->wasmetal_core__DOT___011091_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010404_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010403_))))))));
    vlSelf->wasmetal_core__DOT___057577_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                      ? 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013055_)))))
                                                      : 
                                                     (0xcfafU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012105_))))))));
    vlSelf->wasmetal_core__DOT___067960_ = (1U & (0xf1U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xff00fff100000000ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h18f44539__0))));
    vlSelf->__VdfgTmp_h90d51bf1__0 = (((IData)(vlSelf->wasmetal_core__DOT___057504_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057468_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf1111U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012980_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h7f7a7923__0)))))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xff00fff1ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha5e2ba13__0))))));
    vlSelf->wasmetal_core__DOT___066292_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->wasmetal_core__DOT___013077_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_)))));
    vlSelf->__VdfgTmp_hcfb94f0b__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057558_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057549_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3514b323__0))))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057560_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057559_))))));
    vlSelf->wasmetal_core__DOT___036627_ = (1U & (0xd400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0))))))));
    vlSelf->wasmetal_core__DOT___072217_ = (1U & (0xb2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->wasmetal_core__DOT___072212_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10754ee4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072208_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x2bb2b22bU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9816e297__0)))))));
    vlSelf->__VdfgTmp_ha7d2f4a8__0 = ((2U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                             << 1U)) 
                                      | (1U & (0x71U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_))))));
    vlSelf->wasmetal_core__DOT___072199_ = (1U & (0x69U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072196_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072195_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___072194_)))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033480_));
    vlSelf->__VdfgTmp_hcb4b0ef5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056463_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056462_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056461_)));
    vlSelf->wasmetal_core__DOT___056951_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056948_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056947_))))));
    vlSelf->wasmetal_core__DOT___012280_ = (1U & (IData)(
                                                         (0x1111ff000f0fffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056947_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057014_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_haa3334f5__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057012_)))))))));
    vlSelf->wasmetal_core__DOT___056938_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012330_))));
    vlSelf->wasmetal_core__DOT___013081_ = (1U & (IData)(
                                                         (0xff00bbbbf0f0ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057587_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056970_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))))))));
    vlSelf->wasmetal_core__DOT___057554_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013184_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057552_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    vlSelf->wasmetal_core__DOT___036841_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x69U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))))));
    vlSelf->__VdfgTmp_hc7be7ce5__0 = (((IData)(vlSelf->wasmetal_core__DOT___056749_) 
                                       << 2U) | ((2U 
                                                  & ((0xeU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2ddf0adc__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056747_)));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___069149_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde86d559__0)))));
    vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058863_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->wasmetal_core__DOT___023774_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___058900_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___023763_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d))));
    vlSelf->wasmetal_core__DOT___058914_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0))))));
    vlSelf->wasmetal_core__DOT___023752_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))));
    vlSelf->wasmetal_core__DOT___023741_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127455___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022671_)))));
    vlSelf->wasmetal_core__DOT___022652_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___018080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___017927_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___019006_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058693_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)))))))));
    vlSelf->wasmetal_core__DOT___058677_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017414_))));
    vlSelf->wasmetal_core__DOT___060482_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060481_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017414_)))))));
    vlSelf->wasmetal_core__DOT___010377_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_had4ae229__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa0033U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127558___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006051_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006058_)))) 
           ^ (((IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023497_)))));
    vlSelf->wasmetal_core__DOT___023449_ = ((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                            & (IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127575___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h097d2f7b__0))) 
           ^ (((IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023618_)))));
    vlSelf->wasmetal_core__DOT___023570_ = ((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                            & (IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___022810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))));
    vlSelf->wasmetal_core__DOT___059176_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022797_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))))));
    vlSelf->wasmetal_core__DOT___022786_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))));
    vlSelf->wasmetal_core__DOT___064721_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051928_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdf0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((0x7f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051700_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051460_))))))))))));
    vlSelf->wasmetal_core__DOT___053850_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053848_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7dU 
                                                                         >> 
                                                                         ((4U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049525_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___053825_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053822_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf807ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053820_)))))))));
    vlSelf->wasmetal_core__DOT___068093_ = (1U & (IData)(
                                                         (0x45000000cf00cfcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055140_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050798_))))))))))));
    vlSelf->wasmetal_core__DOT___053889_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053887_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe01ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___069489_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7f80000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0))))))))))));
    vlSelf->wasmetal_core__DOT___051334_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xa802aaaaaaaaaaaaULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 4U) 
                                                                    | ((0xcU 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051322_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009506_)))));
    vlSelf->wasmetal_core__DOT___067029_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050658_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050657_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050642_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050640_)))))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->wasmetal_core__DOT___053638_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe1fffffU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                           << 4U) 
                                                                          | (0xfU 
                                                                             & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O), 1U)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___053819_ = (1U & (IData)(
                                                         (0xee00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053817_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051780_))))))));
    vlSelf->wasmetal_core__DOT___066961_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066957_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(
                                                                                (0xffff01ffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x3700U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051297_))))))))))));
    vlSelf->wasmetal_core__DOT___069466_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051793_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051790_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___068038_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x45000000cf00cfcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___068034_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053815_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009513_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009512_)))))))));
    vlSelf->wasmetal_core__DOT___053585_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd52a210e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70db4808__0))))));
    vlSelf->__VdfgTmp_h47401135__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70db4808__0))) 
                                             << 1U)) 
                                      | (1U & (0x3aU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd52a210e__0)))));
    vlSelf->wasmetal_core__DOT___066881_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfffff44400000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066877_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___066876_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffffff40ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050069_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050068_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050067_)))))))))))));
    vlSelf->wasmetal_core__DOT___053556_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h72fb59a4__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))))));
    vlSelf->wasmetal_core__DOT___051110_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))));
    vlSelf->wasmetal_core__DOT___069413_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051761_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ebff551__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051758_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))))))))));
    vlSelf->wasmetal_core__DOT___053549_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h4b125034__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))))));
    vlSelf->__VdfgTmp_h37b9b4c8__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4b125034__0)))));
    vlSelf->wasmetal_core__DOT___066552_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053729_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ffb000f0fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053726_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049784_))))))))))));
    vlSelf->wasmetal_core__DOT___053897_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053895_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7cU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051371_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 2U)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051373_)))))))));
    vlSelf->wasmetal_core__DOT___053842_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053840_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffe0001fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___053804_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053800_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff80007fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___066717_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066713_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xf0fccaaU 
                                                                  >> 
                                                                  ((0x18U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___051466_))))))))))));
    vlSelf->wasmetal_core__DOT___053873_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053871_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff80007ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050710_)))))))));
    vlSelf->wasmetal_core__DOT___050724_ = (1U & (IData)(
                                                         (0x777000007770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050710_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf1ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___050707_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069362_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051739_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h53aec20d__0))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xffff7f7f00ffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051729_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049321_)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd698a5e2__0))))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051736_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070066_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053720_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051721_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053722_))))))))))));
    vlSelf->wasmetal_core__DOT___066637_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066627_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f8808ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066629_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049879_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009506_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x40U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049877_)))))))))))));
    vlSelf->wasmetal_core__DOT___069387_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051749_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                             << 1U) 
                                                            | (IData)(
                                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        >> 3U) 
                                                                       & (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))))))))));
    vlSelf->wasmetal_core__DOT___053921_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053802_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x807fffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___053538_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053533_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff807ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053531_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069582_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051854_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x1fffe00000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___050882_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050879_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xe01fffffU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)))))))));
    vlSelf->wasmetal_core__DOT___070412_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xfe01ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051546_)))))))));
    vlSelf->wasmetal_core__DOT___051556_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051546_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfe01ffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___067298_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfbbbf333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052608_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052610_)))))))));
    vlSelf->wasmetal_core__DOT___053668_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe01ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052610_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069336_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051717_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051716_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x3ab00000U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 1U)) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                         | ((2U 
                                                                             & ((0xa333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___050904_)))))))))))));
    vlSelf->wasmetal_core__DOT___070051_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053714_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051708_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___053715_)))))))))));
    vlSelf->wasmetal_core__DOT___054756_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053715_))))));
    vlSelf->wasmetal_core__DOT___052723_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h9b387498__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))))));
    vlSelf->wasmetal_core__DOT___049793_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))));
    vlSelf->wasmetal_core__DOT___069536_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfb07bbea__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050860_)))))))))))))));
    vlSelf->wasmetal_core__DOT___050819_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))));
    vlSelf->wasmetal_core__DOT___053650_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h228e0a62__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))))));
    vlSelf->wasmetal_core__DOT___051363_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))));
    vlSelf->wasmetal_core__DOT___069437_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051774_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___067955_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___053814_ = (1U & (0x7033U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___069627_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (0x4aU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___049542_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049482_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049481_))))));
    vlSelf->wasmetal_core__DOT___067473_ = (1U & (0xf0fb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfffff88800000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053186_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053185_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049048_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x3f203f3fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053194_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___053192_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xaaccf000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h454dd727__0)))))))))))));
    vlSelf->wasmetal_core__DOT___069971_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41349efa__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaa33f0f000000000ULL 
                                                                         >> 
                                                                         ((0x38U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053689_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x9f00bf00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053192_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___051610_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))));
    vlSelf->wasmetal_core__DOT___067807_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055205_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050546_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049606_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053720_)))))))));
    vlSelf->wasmetal_core__DOT___053523_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73a0c82f__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))))));
    vlSelf->wasmetal_core__DOT___049882_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))));
    vlSelf->wasmetal_core__DOT___051840_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb744a8fa__0)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))))));
    vlSelf->wasmetal_core__DOT___050842_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))));
    vlSelf->wasmetal_core__DOT___069908_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27becb7d__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xaa0a3303ff0fff0fULL 
                                                                       >> 
                                                                       ((0x30U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053658_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0faaccU 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051517_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028121_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028088_)
                  : (vlSelf->insn_x >> 8U)));
    vlSelf->wasmetal_core__DOT___066389_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0x8f8f8f8fff00ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009509_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009508_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xffcf0080ffcfffcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049848_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049694_))))))))))));
    vlSelf->wasmetal_core__DOT___053857_ = (1U & (IData)(
                                                         (0xbb00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051889_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___053797_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f773f333f33ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053703_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___066470_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055415_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055414_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x45cfcf00ffffffULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                               << 4U)) 
                                                                           | ((0x10U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067103_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf4ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051339_))))))))))));
    vlSelf->wasmetal_core__DOT___067542_ = (1U & (IData)(
                                                         (0xff8fff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053393_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051623_))))))))))));
    vlSelf->wasmetal_core__DOT___053916_ = (1U & (IData)(
                                                         (0xfff1ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053914_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053694_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___066303_ = (1U & ((1U 
                                                   & (0xa300U 
                                                      >> 
                                                      ((8U 
                                                        & ((1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | ((2U 
                                                              & ((0xf0f5533U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 4U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xacU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___053212_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___053209_))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053210_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049649_))))))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009497_))
                                                   : (IData)(
                                                             (0xcccccccccc40c0c0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U))) 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009499_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0x773f3f3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009497_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___009496_))))))))));
    vlSelf->wasmetal_core__DOT___069279_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051656_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051655_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051654_)))))))));
    vlSelf->wasmetal_core__DOT___070009_ = (1U & (IData)(
                                                         (0xf8f800ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053702_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053578_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053579_)))))))));
    vlSelf->wasmetal_core__DOT___067616_ = (1U & (0xb33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053579_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053578_))))));
    vlSelf->wasmetal_core__DOT___051894_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xa82aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))))));
    vlSelf->wasmetal_core__DOT___049696_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))));
    vlSelf->wasmetal_core__DOT___069650_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051887_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051884_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___070244_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053852_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051880_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049651_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___049674_)))))))))));
    vlSelf->wasmetal_core__DOT___068469_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049650_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049649_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049651_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049674_))))))))))));
    vlSelf->wasmetal_core__DOT___053699_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habfc584e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))))));
    vlSelf->wasmetal_core__DOT___051627_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))));
    vlSelf->wasmetal_core__DOT___069311_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051703_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051701_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051700_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053708_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053705_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051692_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053706_))))))))))));
    vlSelf->wasmetal_core__DOT___052637_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h37fa163f__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))))));
    vlSelf->wasmetal_core__DOT___049745_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))));
    vlSelf->wasmetal_core__DOT___069512_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051814_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xfa33f333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070156_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053828_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051809_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050858_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))))));
    vlSelf->wasmetal_core__DOT___068146_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x7077000070777077ULL 
                                                                              >> 
                                                                              ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf011fcfdU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050847_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))));
    vlSelf->wasmetal_core__DOT___053644_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h2290cda0__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h19298f26__0))))));
    vlSelf->wasmetal_core__DOT___051343_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19298f26__0))));
    vlSelf->wasmetal_core__DOT___065288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff001f1f0000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051438_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051437_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x5300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051432_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051318_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051317_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051424_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053528_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051752_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053526_))))))))))));
    vlSelf->wasmetal_core__DOT___053530_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053526_))))));
    vlSelf->wasmetal_core__DOT___066114_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x773f3f3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053731_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049212_))))))))))));
    vlSelf->wasmetal_core__DOT___069605_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051862_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e945c96__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051859_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___049336_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))));
    vlSelf->wasmetal_core__DOT___051578_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))));
    vlSelf->wasmetal_core__DOT___053687_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h03f43c88__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))))));
    vlSelf->wasmetal_core__DOT___054554_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001525_)))));
    vlSelf->wasmetal_core__DOT___054555_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001537_)))));
    vlSelf->wasmetal_core__DOT___054556_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001569_)))));
    vlSelf->wasmetal_core__DOT___054557_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001581_)))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001613_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034353_));
    vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028877_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028466_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028641_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004226_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029084_)
            ? (IData)(vlSelf->wasmetal_core__DOT___029051_)
            : (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028953_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b13__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001568_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001568_)
            : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045369_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128105___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___045381_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b43__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b42__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___128105___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045368_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___045380_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128105___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128104___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028744_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028710_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT____Vcellout___127852___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026456_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026455_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026451_)))));
    vlSelf->wasmetal_core__DOT___026423_ = ((IData)(vlSelf->wasmetal_core__DOT___026456_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d));
    vlSelf->wasmetal_core__DOT___045016_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054063_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)))))))))));
    vlSelf->wasmetal_core__DOT___045040_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h8a76b5de__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054067_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))))));
    vlSelf->__VdfgTmp_h77f7c585__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054071_)))));
    vlSelf->wasmetal_core__DOT___045335_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052138_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052506_)))))))));
    vlSelf->wasmetal_core__DOT___045347_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052506_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052138_)))))))));
    vlSelf->wasmetal_core__DOT___045334_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052416_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052137_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052417_)))))))));
    vlSelf->wasmetal_core__DOT___045346_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052137_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052417_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052416_)))))))));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026666_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026600_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___054348_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054342_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054344_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054346_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127936___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027136_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027070_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026563_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001414_));
    vlSelf->wasmetal_core__DOT___054347_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054341_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054343_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054345_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127919___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026936_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026870_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___045921_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052398_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052476_)))))))));
    vlSelf->wasmetal_core__DOT___045933_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052398_)))))))));
    vlSelf->wasmetal_core__DOT___045920_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052557_)))))))));
    vlSelf->wasmetal_core__DOT___045932_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052399_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052556_)))))))));
    vlSelf->wasmetal_core__DOT___045403_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had3e30f3__0)))))));
    vlSelf->wasmetal_core__DOT___045402_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf21c6828__0)))))));
    vlSelf->wasmetal_core__DOT___045415_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003646_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___045414_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004610_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003794_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___045085_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070991_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070990_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___070989_))))))));
    vlSelf->wasmetal_core__DOT___045109_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070991_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070990_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070989_)))))))));
    vlSelf->wasmetal_core__DOT___045084_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070979_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070978_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070977_)))))))));
    vlSelf->wasmetal_core__DOT___045108_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070979_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070978_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070977_)))))))));
    vlSelf->wasmetal_core__DOT___045875_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003484_))))))));
    vlSelf->wasmetal_core__DOT___045899_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003780_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003484_)))))))));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026735_)
            : (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001568_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___065053_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030123_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030090_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030283_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030218_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028286_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028221_));
    vlSelf->wasmetal_core__DOT___065180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___065052_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->__VdfgTmp_h48aaf6cb__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h60159710__0))));
    vlSelf->__VdfgTmp_hc8f262c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h60159710__0)))));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b10__05d));
    vlSelf->__VdfgTmp_hb514b790__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h41acf677__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hb6ef8d81__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)))))));
    vlSelf->__VdfgTmp_hc21b3046__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_h9fa4f51d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h41461f4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022506_));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031051_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011793_))))));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012224_));
    } else {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011790_))))));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012070_))))));
    }
    vlSelf->wasmetal_core__DOT___011951_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___056772_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011790_)))))))));
    vlSelf->wasmetal_core__DOT___056909_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))));
    vlSelf->__VdfgTmp_h7d32537f__0 = (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h1c56b6c5__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011087_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h07056034__0 = ((2U & ((IData)(
                                                     (0xf0f0ff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012632_))
                                                                       : 
                                                                      (0xdU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___012632_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___012631_))))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0))
                                                                       : 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h796615cc__0)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011300_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011299_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011572_))));
    vlSelf->__VdfgTmp_haf8803a1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0xfff0fff033335555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011557_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___011572_)
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011431_))))))));
    vlSelf->__VdfgTmp_h8088f5ad__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0x111111110f0f00ffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((0xf0110000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012631_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___012630_)))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xf00001111ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011566_))))))))))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012219_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___012224_))));
    vlSelf->wasmetal_core__DOT___011080_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                   ? 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hde352602__0))))
                                                   : 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))));
    vlSelf->wasmetal_core__DOT___011024_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))))));
    vlSelf->__VdfgTmp_h5d9b5f2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___057453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012808_))));
    vlSelf->wasmetal_core__DOT___057664_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013034_))));
    vlSelf->__VdfgTmp_h4aee2d94__0 = (((IData)(vlSelf->wasmetal_core__DOT___013034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hac971038__0 = (((IData)(vlSelf->wasmetal_core__DOT___011079_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hdab8ca95__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011079_));
    vlSelf->__VdfgTmp_hc7461e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___011425_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h11d85c9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011780_));
    vlSelf->__VdfgTmp_heceb31a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012213_));
    vlSelf->__VdfgTmp_h3659b78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012213_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h745845c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012405_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___012574_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0))))))));
    vlSelf->__VdfgTmp_h4fcaab62__0 = (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0));
    vlSelf->wasmetal_core__DOT___012818_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057389_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
}
