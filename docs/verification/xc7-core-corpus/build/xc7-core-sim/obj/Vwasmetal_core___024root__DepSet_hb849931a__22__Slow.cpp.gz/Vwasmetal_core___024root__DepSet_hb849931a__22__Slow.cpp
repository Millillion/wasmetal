#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__28(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__28\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___050523_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049840_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049040_))));
    vlSelf->wasmetal_core__DOT___049277_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049275_))));
    vlSelf->__VdfgTmp_h6ae5baa5__0 = (((IData)(vlSelf->wasmetal_core__DOT___049608_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049352_));
    vlSelf->wasmetal_core__DOT___049073_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049071_))));
    if (vlSelf->wasmetal_core__DOT___000170_) {
        if (vlSelf->wasmetal_core__DOT___000169_) {
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h7357dd51__0))));
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hd61aa5bc__0))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hb54a817c__0))));
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h5e317429__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0))));
        } else {
            vlSelf->wasmetal_core__DOT___002923_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002932_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002931_)))));
            vlSelf->wasmetal_core__DOT___002593_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001720_)))));
            vlSelf->wasmetal_core__DOT___002316_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___001336_)))));
            vlSelf->wasmetal_core__DOT___002799_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (IData)(vlSelf->__VdfgTmp_hae207145__0))));
            vlSelf->wasmetal_core__DOT___002554_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002563_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___002562_)))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___002923_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002933_)))));
        vlSelf->wasmetal_core__DOT___002593_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002601_)))));
        vlSelf->wasmetal_core__DOT___002316_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002324_)))));
        vlSelf->wasmetal_core__DOT___002799_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___002811_))));
        vlSelf->wasmetal_core__DOT___002554_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000169_)) 
                                                   & (1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002564_)))));
    }
    vlSelf->wasmetal_core__DOT___057679_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___055061_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055059_))));
    vlSelf->wasmetal_core__DOT___055935_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055934_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055681_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055680_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055679_)))))))));
    vlSelf->wasmetal_core__DOT___019202_ = (1U & (IData)(
                                                         (0x554400000f0cULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055683_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048405_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055684_)))))))));
    vlSelf->wasmetal_core__DOT___055712_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055684_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___055683_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127478___O 
        = ((1U & (~ (IData)(vlSelf->wasmetal_core__DOT___005989_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                | (IData)(vlSelf->wasmetal_core__DOT___022853_)) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022853_)));
    vlSelf->wasmetal_core__DOT___049867_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (3U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O)))))));
    vlSelf->wasmetal_core__DOT___050485_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 2U)))));
    vlSelf->__VdfgTmp_h1ac2f982__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___055928_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055653_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055652_)))))))));
    vlSelf->__VdfgTmp_hd9c0d0dd__0 = ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                              & (IData)(
                                                        (0xfff0ffff1111ffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001721_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001720_) 
                                                                    << 2U) 
                                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                         ? (IData)(vlSelf->wasmetal_core__DOT___001728_)
                                                                         : (IData)(vlSelf->wasmetal_core__DOT___001727_)) 
                                                                       << 1U) 
                                                                      | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                         & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001729_))))))))))))))))) 
                                             << 1U)) 
                                      | (1U & (0xf00011U 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he9d730e6__0))))));
    vlSelf->wasmetal_core__DOT___055917_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055598_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055597_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055596_)))))))));
    vlSelf->wasmetal_core__DOT___001251_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001337_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001336_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001344_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001343_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001495_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___061711_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061706_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048435_)))))));
    vlSelf->wasmetal_core__DOT___055910_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055909_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055522_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055521_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055520_)))))))));
    vlSelf->wasmetal_core__DOT___061951_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055558_))));
    vlSelf->wasmetal_core__DOT___055903_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055502_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055501_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055500_)))))))));
    vlSelf->wasmetal_core__DOT___001948_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001964_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                                        << 2U) 
                                                                       | ((((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                             ? (IData)(vlSelf->wasmetal_core__DOT___001343_)
                                                                             : (IData)(vlSelf->wasmetal_core__DOT___001859_)) 
                                                                           << 1U) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001342_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___055891_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055890_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055432_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055431_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055430_)))))))));
    vlSelf->wasmetal_core__DOT___001899_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001935_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000181_)
                                                                                ? 
                                                                               (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001723_)))))
                                                                                : 
                                                                               (0xecU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000666_)
                                                                                 ? (IData)(
                                                                                (0xf0055003300ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003269_))))))))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001726_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001725_))))))))))))))))));
    vlSelf->__VdfgTmp_h51461c8e__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h07a6aef0__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001934_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001935_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hdb0eb761__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___055878_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055877_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055377_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055376_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055375_)))))))));
    vlSelf->wasmetal_core__DOT___049088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___048977_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___001808_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                  & (IData)(
                                                            (0xfff0ffff1111ffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001854_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                                ? (IData)(vlSelf->wasmetal_core__DOT___001859_)
                                                                                : 
                                                                               (0xc05U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001339_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0ffccffaa000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003189_)))))))))))))) 
                                                                              << 1U)) 
                                                                          | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                             & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001496_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001495_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001342_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001341_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___062062_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007345_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007347_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf89db412__0))))))));
    vlSelf->wasmetal_core__DOT___061941_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007287_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf4e23b72__0))))))));
    vlSelf->wasmetal_core__DOT___062118_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007371_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007373_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb017232__0))))))));
    vlSelf->wasmetal_core__DOT___062179_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055045_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde31b2d5__0))))))));
    vlSelf->wasmetal_core__DOT___061873_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007258_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007260_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7c4aea26__0))))))));
    vlSelf->wasmetal_core__DOT___061990_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009846_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007470_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3226e594__0))))))));
    vlSelf->wasmetal_core__DOT___061686_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054692_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054689_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054683_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054675_)))))))));
    vlSelf->wasmetal_core__DOT___061801_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007231_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007233_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->wasmetal_core__DOT___019200_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055347_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055872_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x3500U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055339_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055325_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055337_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055336_))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055870_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055335_)))))))));
    vlSelf->wasmetal_core__DOT___049106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___048966_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___055196_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ccccf0f0aaaaULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055192_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055040_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055019_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055020_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055022_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055039_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055038_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055037_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055051_)))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84a7ba42__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___049105_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___048969_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___055186_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055183_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054982_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054979_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054993_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054992_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054991_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055005_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc6adb13e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___048995_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___055177_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055175_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x33330f0f00ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054941_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054955_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054954_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054953_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054952_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054963_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb52e5b74__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049101_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___048992_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___049201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->wasmetal_core__DOT___048987_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->wasmetal_core__DOT___055147_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055144_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054859_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054858_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054856_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054870_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a768dd6__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049200_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___048984_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___053516_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h8ecdfd77__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050365_)))));
    vlSelf->wasmetal_core__DOT___049194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___049301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___049197_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___049302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___049184_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___049295_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___002195_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048755_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000177_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000176_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001730_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002931_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002932_)))))))));
    vlSelf->wasmetal_core__DOT___049187_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___049296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___001740_ = (1U & (IData)(
                                                         (0x1111fff000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048888_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                      & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001654_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001498_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001497_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001496_))))))))) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002562_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002563_)))))))));
    vlSelf->wasmetal_core__DOT___049179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    vlSelf->wasmetal_core__DOT___049292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    vlSelf->wasmetal_core__DOT___012933_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012275_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056984_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012007_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012011_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___011752_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___013064_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057573_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))));
    vlSelf->wasmetal_core__DOT___012008_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056745_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___012012_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056730_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___011753_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011458_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___056374_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0)))));
    vlSelf->wasmetal_core__DOT___013040_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))));
    vlSelf->wasmetal_core__DOT___049176_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___049291_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___051509_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051506_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005663_)))))));
    vlSelf->wasmetal_core__DOT___016296_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005663_))));
    vlSelf->wasmetal_core__DOT___049167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___049315_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___063365_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e6b8024__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56f16561__0))));
    vlSelf->wasmetal_core__DOT___052844_ = (1U & (IData)(
                                                         (0xf888000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052836_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56f16561__0))))))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___028091_)) 
                 & vlSelf->insn_x));
    vlSelf->wasmetal_core__DOT___061928_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061688_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061907_)))));
    vlSelf->wasmetal_core__DOT___061919_ = (1U & (0xeee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061908_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061907_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaaaaccccf0f0ff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___061899_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061898_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ae2b9ea__0))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061653_)))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___010340_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___011658_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c506bbe__0)));
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010761_)));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010755_)));
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010749_)));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010989_)));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hcbffb3b6__0)));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010983_)));
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010892_)));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010999_)));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010552_)));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010958_)));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010590_)));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010584_)));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
        vlSelf->wasmetal_core__DOT___011539_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010939_)));
        vlSelf->wasmetal_core__DOT___011538_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010911_)));
        vlSelf->wasmetal_core__DOT___011530_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010918_)));
        vlSelf->wasmetal_core__DOT___010339_ = (1U 
                                                & (8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011659_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3c35c9c1__0)));
        vlSelf->wasmetal_core__DOT___011528_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010992_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___007693_) {
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h14ad002b__0)));
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h9c968075__0)));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_hc43f9106__0)));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (IData)(vlSelf->__VdfgTmp_h7edccd87__0)));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h0073f5c3__0)));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xff35U >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                    << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))));
        } else {
            vlSelf->wasmetal_core__DOT___010340_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___011658_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_h6df87d4d__0)));
            vlSelf->wasmetal_core__DOT___011539_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010281_)))));
            vlSelf->wasmetal_core__DOT___011538_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010272_)))));
            vlSelf->wasmetal_core__DOT___011530_ = 
                (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___010253_)))));
            vlSelf->wasmetal_core__DOT___010339_ = 
                (1U & (0xe0U >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
            vlSelf->wasmetal_core__DOT___011659_ = 
                (1U & (0xeU >> (IData)(vlSelf->__VdfgTmp_hbd75f801__0)));
            vlSelf->wasmetal_core__DOT___011528_ = 
                (1U & (0xdU >> (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010231_))));
        }
        vlSelf->wasmetal_core__DOT___011472_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_he4fe919e__0))));
        vlSelf->wasmetal_core__DOT___011388_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0))))));
        vlSelf->wasmetal_core__DOT___012729_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
        vlSelf->wasmetal_core__DOT___011389_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
        vlSelf->wasmetal_core__DOT___011379_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h1d2a78cf__0)))));
        vlSelf->wasmetal_core__DOT___056722_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___011920_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb37e0c87__0)));
        vlSelf->wasmetal_core__DOT___011380_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_haef445c6__0)))));
        vlSelf->wasmetal_core__DOT___011470_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1110fffU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                           << 3U) 
                                                          | ((4U 
                                                              & ((0xf011U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007679_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007677_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___007678_))))) 
                                                                 << 2U)) 
                                                             | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)))))));
        vlSelf->wasmetal_core__DOT___011858_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
        vlSelf->wasmetal_core__DOT___011381_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hd610ba85__0)))));
        vlSelf->wasmetal_core__DOT___012125_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h25073b9c__0))));
        vlSelf->wasmetal_core__DOT___011870_ = (1U 
                                                & (0xff11fff0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h034bd5a0__0)))));
        vlSelf->wasmetal_core__DOT___010574_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h97dd8594__0))));
        vlSelf->wasmetal_core__DOT___010575_ = (1U 
                                                & (0xff00ff1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                     << 4U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc09bd195__0))));
        vlSelf->wasmetal_core__DOT___056595_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011122_)));
    }
    vlSelf->wasmetal_core__DOT___011900_ = (1U & (IData)(
                                                         (0x33335555f0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011513_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011503_)))))))));
    vlSelf->wasmetal_core__DOT___050729_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->__VdfgTmp_hc497fe80__0 = (((IData)(vlSelf->wasmetal_core__DOT___049160_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050632_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___049465_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049313_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___061866_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061867_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061863_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061838_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0x77707770777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061855_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007274_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___007417_)))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061831_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061830_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb587b232__0))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___061653_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061687_)))))))));
    vlSelf->wasmetal_core__DOT___061849_ = (1U & (0x60U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061687_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___061838_)))));
    vlSelf->wasmetal_core__DOT___050458_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050406_)))));
    vlSelf->wasmetal_core__DOT___019785_ = (1U & (IData)(
                                                         (0xa03000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048518_)))))))));
    vlSelf->wasmetal_core__DOT___053502_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050446_)))));
    vlSelf->wasmetal_core__DOT___050464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050403_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050402_)))))))));
    vlSelf->wasmetal_core__DOT___053543_ = (1U & (IData)(
                                                         (0x4040ff4000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050403_)))))))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011719_));
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d))))));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___012039_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010462_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d))))));
    } else {
        vlSelf->wasmetal_core__DOT___056635_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d))))));
        vlSelf->wasmetal_core__DOT___056644_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
        vlSelf->wasmetal_core__DOT___012981_ = vlSelf->wasmetal_core__DOT___011719_;
        vlSelf->wasmetal_core__DOT___057065_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012039_));
    }
    vlSelf->wasmetal_core__DOT___049159_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___049312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___065621_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065075_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065620_)))));
    vlSelf->wasmetal_core__DOT___065076_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063833_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065075_)))));
    vlSelf->wasmetal_core__DOT___064741_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064735_))));
    vlSelf->wasmetal_core__DOT___065309_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064735_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065308_)))));
    if (vlSelf->wasmetal_core__DOT___042177_) {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___135006___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___134952___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___134970___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___134988___DOT__CO__BRA__0__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042427_ = vlSelf->wasmetal_core__DOT___042354_;
        vlSelf->wasmetal_core__DOT___042451_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042131_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042199_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042248_ = vlSelf->wasmetal_core__DOT___042153_;
        vlSelf->wasmetal_core__DOT___042272_ = vlSelf->wasmetal_core__DOT___042208_;
        vlSelf->wasmetal_core__DOT___042378_ = vlSelf->wasmetal_core__DOT___042387_;
        vlSelf->wasmetal_core__DOT___042332_ = vlSelf->wasmetal_core__DOT___042354_;
    }
    vlSelf->wasmetal_core__DOT___054546_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001438_)))));
    vlSelf->wasmetal_core__DOT___054547_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001444_)))));
    vlSelf->wasmetal_core__DOT___054548_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001476_)))));
    vlSelf->wasmetal_core__DOT___054549_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128647___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001488_)))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001370_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034408_));
    vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028857_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d));
    vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028489_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128077___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004448_));
    vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028664_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004374_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___029054_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028976_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d));
    vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001475_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001475_)
            : (IData)(vlSelf->wasmetal_core__DOT___128435___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045365_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6b18dcfd__0))))))));
    vlSelf->wasmetal_core__DOT___045377_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b34__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b33__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128103___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028734_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT____Vcellout___127850___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026479_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026476_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026465_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026454_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___026447_ = ((IData)(vlSelf->wasmetal_core__DOT___026479_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127850___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d));
    vlSelf->__VdfgTmp_h8134fe6e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___053990_)))));
    vlSelf->__VdfgTmp_h57cd27d4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                             >> 2U)) 
                                      | (1U & (4U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___054047_)))));
    vlSelf->wasmetal_core__DOT___045331_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052418_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052191_)))))))));
    vlSelf->wasmetal_core__DOT___045343_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052191_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052418_)))))))));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026707_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026631_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___054323_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054325_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054321_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O)))));
    vlSelf->wasmetal_core__DOT___054327_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127927___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027177_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027101_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d));
    vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026584_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127859___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001875_));
    vlSelf->wasmetal_core__DOT___054322_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054324_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054320_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054326_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127910___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026977_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026901_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___045917_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052254_))))))));
    vlSelf->wasmetal_core__DOT___045929_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052254_)))))))));
    vlSelf->wasmetal_core__DOT___045399_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdb6fbe09__0)))))));
    vlSelf->wasmetal_core__DOT___045411_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___004832_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003208_)))))))));
    vlSelf->wasmetal_core__DOT___045070_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070955_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070954_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___070953_))))))));
    vlSelf->wasmetal_core__DOT___045094_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070955_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070954_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070953_)))))))));
    vlSelf->wasmetal_core__DOT___045860_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003270_))))));
    vlSelf->wasmetal_core__DOT___045884_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003190_))))));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__0__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___026766_)
            : (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___064514_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___128663___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001475_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hf16ebcc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__1__KET__) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___135444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___064511_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064510_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064509_)))));
    vlSelf->wasmetal_core__DOT___063995_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063994_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063993_)))));
    vlSelf->wasmetal_core__DOT___064929_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064925_)))));
    vlSelf->wasmetal_core__DOT___064759_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064758_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064757_)))));
    vlSelf->wasmetal_core__DOT___065196_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064509_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064497_)))));
    vlSelf->wasmetal_core__DOT___065079_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063993_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063981_)))));
    vlSelf->wasmetal_core__DOT___065421_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064922_)))));
    vlSelf->wasmetal_core__DOT___065315_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064757_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064753_)))));
    vlSelf->wasmetal_core__DOT___064498_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064497_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064496_)))));
    vlSelf->wasmetal_core__DOT___063982_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063980_)))));
    vlSelf->wasmetal_core__DOT___064923_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064922_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064921_)))));
    vlSelf->wasmetal_core__DOT___064754_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064753_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064752_)))));
    vlSelf->wasmetal_core__DOT___065194_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064496_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___065077_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063980_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    vlSelf->wasmetal_core__DOT___065313_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___065419_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064921_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___065314_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___064755_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064751_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064750_)))));
    vlSelf->wasmetal_core__DOT___065078_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063975_))));
    vlSelf->wasmetal_core__DOT___063983_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063975_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063974_)))));
    vlSelf->wasmetal_core__DOT___064924_ = (1U & (0x3aU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064919_)))));
    vlSelf->wasmetal_core__DOT___065420_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064920_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___065195_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064491_))));
    vlSelf->wasmetal_core__DOT___064499_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064491_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064490_)))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030093_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030221_) 
           | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->wasmetal_core__DOT___068963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068962_)))));
    vlSelf->__VdfgTmp_hb27da868__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068790_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068892_))))));
    vlSelf->__VdfgTmp_h280fcf30__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068936_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___069034_))))));
    vlSelf->wasmetal_core__DOT___068791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068697_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068790_)))));
    vlSelf->__VdfgTmp_h10281295__0 = (((IData)(vlSelf->wasmetal_core__DOT___063830_) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___068845_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___068936_))))));
    vlSelf->wasmetal_core__DOT___068698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068599_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068697_)))));
    vlSelf->wasmetal_core__DOT___068846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068746_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068845_)))));
    vlSelf->wasmetal_core__DOT___068747_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068649_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068746_)))));
    vlSelf->wasmetal_core__DOT___068600_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068473_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068599_)))));
    vlSelf->wasmetal_core__DOT___068650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068547_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068649_)))));
    vlSelf->wasmetal_core__DOT___068474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068473_)))));
    vlSelf->wasmetal_core__DOT___068397_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068287_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068396_)))));
    vlSelf->wasmetal_core__DOT___068548_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068420_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068547_)))));
    vlSelf->wasmetal_core__DOT___068288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068149_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068287_)))));
    vlSelf->wasmetal_core__DOT___068421_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068341_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068420_)))));
    vlSelf->wasmetal_core__DOT___068150_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068073_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068149_)))));
    vlSelf->wasmetal_core__DOT___068342_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068341_)))));
    vlSelf->wasmetal_core__DOT___068074_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068073_)))));
    vlSelf->wasmetal_core__DOT___068235_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068098_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068234_)))));
    vlSelf->wasmetal_core__DOT___068099_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068025_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068098_)))));
    vlSelf->wasmetal_core__DOT___067816_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))));
    vlSelf->wasmetal_core__DOT___067969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067815_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067968_)))));
    vlSelf->wasmetal_core__DOT___068026_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068025_)))));
    vlSelf->wasmetal_core__DOT___067755_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))));
    vlSelf->wasmetal_core__DOT___067903_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067754_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067902_)))));
    vlSelf->wasmetal_core__DOT___067731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067592_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h958b2749__0))))))));
    vlSelf->wasmetal_core__DOT___067593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067447_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067592_)))));
    vlSelf->wasmetal_core__DOT___067665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067496_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x35U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___063826_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hd78cc544__0))))))));
    vlSelf->wasmetal_core__DOT___067448_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067300_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067447_)))));
    vlSelf->wasmetal_core__DOT___067301_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067145_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067300_)))));
    vlSelf->wasmetal_core__DOT___067146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067145_)))));
    vlSelf->wasmetal_core__DOT___066963_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066843_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066962_)))));
    vlSelf->wasmetal_core__DOT___066844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066638_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066843_)))));
    vlSelf->wasmetal_core__DOT___066639_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066516_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066638_)))));
    vlSelf->wasmetal_core__DOT___067497_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067496_)))));
    vlSelf->wasmetal_core__DOT___066517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066304_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066516_)))));
    vlSelf->wasmetal_core__DOT___067331_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067186_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067330_)))));
    vlSelf->wasmetal_core__DOT___066305_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066304_)))));
    vlSelf->wasmetal_core__DOT___067187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067067_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067186_)))));
    vlSelf->wasmetal_core__DOT___067068_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066884_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067067_)))));
    vlSelf->wasmetal_core__DOT___066117_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065925_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066116_)))));
    vlSelf->wasmetal_core__DOT___066885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066760_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066884_)))));
    vlSelf->wasmetal_core__DOT___066761_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066593_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066760_)))));
    vlSelf->wasmetal_core__DOT___065926_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065793_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065925_)))));
    vlSelf->wasmetal_core__DOT___066594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066593_)))));
    vlSelf->wasmetal_core__DOT___065794_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065793_)))));
    vlSelf->wasmetal_core__DOT___066391_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066260_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066390_)))));
    vlSelf->wasmetal_core__DOT___066261_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066260_)))));
    vlSelf->wasmetal_core__DOT___065596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065291_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065595_)))));
    vlSelf->wasmetal_core__DOT___065292_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065070_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065291_)))));
    vlSelf->wasmetal_core__DOT___066071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065889_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066070_)))));
    vlSelf->wasmetal_core__DOT___065890_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065691_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065889_)))));
    vlSelf->wasmetal_core__DOT___065692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065404_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065691_)))));
    vlSelf->wasmetal_core__DOT___065405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065175_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065404_)))));
    vlSelf->wasmetal_core__DOT___065071_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064723_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065070_)))));
    vlSelf->wasmetal_core__DOT___065176_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064890_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065175_)))));
    vlSelf->wasmetal_core__DOT___064891_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064482_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064890_)))));
    vlSelf->wasmetal_core__DOT___064483_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064482_))));
    vlSelf->wasmetal_core__DOT___064724_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063827_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064723_)))));
    vlSelf->wasmetal_core__DOT___063829_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063828_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063827_))));
    vlSelf->wasmetal_core__DOT___052843_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052840_))));
    vlSelf->wasmetal_core__DOT___053506_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028307_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028242_));
    vlSelf->wasmetal_core__DOT___049152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___049321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___064478_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001874_))));
    vlSelf->wasmetal_core__DOT___065201_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064470_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065200_)))));
    vlSelf->wasmetal_core__DOT___065426_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064902_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065425_)))));
    vlSelf->wasmetal_core__DOT___064903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064902_))));
    vlSelf->wasmetal_core__DOT___063835_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063834_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84f9890b__0))));
    vlSelf->wasmetal_core__DOT___063968_ = (1U & (IData)(
                                                         (0x40007fffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048304_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063967_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___042174_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___042173_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___042177_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063965_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048368_)))))))));
    if (vlSelf->wasmetal_core__DOT___042095_) {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___134976___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___134940___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___134994___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___134958___DOT__CO__BRA__1__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___042284_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042307_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042072_ = vlSelf->wasmetal_core__DOT___042083_;
        vlSelf->wasmetal_core__DOT___042106_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042403_ = vlSelf->wasmetal_core__DOT___042317_;
        vlSelf->wasmetal_core__DOT___042391_ = vlSelf->wasmetal_core__DOT___042295_;
        vlSelf->wasmetal_core__DOT___042224_ = vlSelf->wasmetal_core__DOT___042116_;
        vlSelf->wasmetal_core__DOT___042212_ = vlSelf->wasmetal_core__DOT___042083_;
    }
    vlSelf->wasmetal_core__DOT___064771_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063872_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063921_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063922_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x4fff00ff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063915_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063901_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063916_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063902_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h61f75715__0))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___064748_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2e505808__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x4fff00ff00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___063878_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063892_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063877_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063891_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0791be06__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063872_)))));
    vlSelf->__VdfgTmp_hbbb75ece__0 = (((IData)(vlSelf->wasmetal_core__DOT___063894_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0791be06__0))));
    vlSelf->__VdfgTmp_h826c8569__0 = ((4U & ((0xe8U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4ea6bbba__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h563f0a85__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h21594217__0)))));
    vlSelf->__VdfgTmp_h2a821aa8__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h21594217__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->__VdfgTmp_h4720a72d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha753d377__0)))));
    vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027355_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127944___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b2__05d));
    vlSelf->__VdfgTmp_hcdf58d3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_hcf2773b3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_hc8e63fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hffde1553__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hcf316312__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O)))))));
    vlSelf->__VdfgTmp_hba4cc4c7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_h9fccfed0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127427___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022537_));
    vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128476___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128141___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031043_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128324___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___050522_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049039_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049032_))));
    vlSelf->wasmetal_core__DOT___049284_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049279_))));
    vlSelf->__VdfgTmp_h249d4881__0 = (((IData)(vlSelf->wasmetal_core__DOT___049351_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049354_));
    vlSelf->wasmetal_core__DOT___049084_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049078_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049077_))));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
    } else if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010091_)));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010173_)));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010113_)));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010152_)));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010132_)));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010142_)));
    } else {
        vlSelf->wasmetal_core__DOT___012294_ = (1U 
                                                & (IData)(
                                                          (0x7000000ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010091_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
        vlSelf->wasmetal_core__DOT___056288_ = (1U 
                                                & (IData)(
                                                          (0x11100000fffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010173_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
        vlSelf->wasmetal_core__DOT___012043_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010113_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8d891945__0))))));
        vlSelf->wasmetal_core__DOT___056286_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010152_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0))))));
        vlSelf->wasmetal_core__DOT___012044_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010132_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h143507db__0))))));
        vlSelf->wasmetal_core__DOT___056285_ = (1U 
                                                & (IData)(
                                                          (0x11010000ff0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010142_) 
                                                                << 4U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h53247725__0))))));
    }
    vlSelf->wasmetal_core__DOT___056191_ = (1U & (IData)(
                                                         (0xfff8ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb57f307c__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_he4fe919e__0)))));
    vlSelf->wasmetal_core__DOT___049041_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049031_))));
    vlSelf->wasmetal_core__DOT___050519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049022_))));
    vlSelf->wasmetal_core__DOT___049451_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049282_))));
    vlSelf->wasmetal_core__DOT___049283_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049282_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049281_))));
    vlSelf->__VdfgTmp_h4d50854c__0 = (((IData)(vlSelf->wasmetal_core__DOT___049354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049353_));
    vlSelf->__VdfgTmp_h45e6cf8e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049353_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049360_));
    vlSelf->wasmetal_core__DOT___049490_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049077_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049082_))));
    vlSelf->wasmetal_core__DOT___049083_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049081_))));
    vlSelf->__VdfgTmp_hf222e899__0 = (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeeeULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hcb043302__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___009782_)));
    vlSelf->__VdfgTmp_h1a6962a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___009783_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfff00000eeeeULL 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcb043302__0)))))));
    if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___056172_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xffff0001U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009782_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009781_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009780_) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (IData)(
                                                                           (0xfff00000eeeeULL 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hcb043302__0)))))))))));
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he6780703__0)))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0xf0f0305U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h02606b30__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___056172_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___009784_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___008974_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009783_)))));
        vlSelf->wasmetal_core__DOT___010412_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009651_))))));
        vlSelf->wasmetal_core__DOT___010221_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008974_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010232_))
                                                    : 
                                                   (0x31U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010232_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010231_))))));
    }
    vlSelf->__VdfgTmp_he13bfe6a__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he89f377b__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010547_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he89f377b__0))))));
    vlSelf->wasmetal_core__DOT___012798_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))))));
    vlSelf->__VdfgTmp_h52f935f8__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d));
    vlSelf->__VdfgTmp_hcf7ded40__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011124_));
    vlSelf->wasmetal_core__DOT___011973_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))));
    vlSelf->wasmetal_core__DOT___050518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049021_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049014_))));
    vlSelf->wasmetal_core__DOT___049251_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049247_))));
    vlSelf->__VdfgTmp_h57526782__0 = (((IData)(vlSelf->wasmetal_core__DOT___049359_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049358_));
    vlSelf->__VdfgTmp_hc0f91dc6__0 = (((IData)(vlSelf->wasmetal_core__DOT___049125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049124_));
    vlSelf->wasmetal_core__DOT___062104_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061705_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062124_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062114_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062090_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xfff05550fff0333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf03fc3ad__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c7215cb__0)))))))))))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048419_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061705_)))))))));
    vlSelf->wasmetal_core__DOT___049023_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049013_))));
    vlSelf->wasmetal_core__DOT___049447_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049247_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049249_))));
    vlSelf->__VdfgTmp_h20ec44fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049358_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049357_));
    vlSelf->__VdfgTmp_h15ceac3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___049357_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049367_));
    vlSelf->wasmetal_core__DOT___049502_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049124_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049131_))));
    vlSelf->wasmetal_core__DOT___049132_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049130_))));
    vlSelf->wasmetal_core__DOT___062171_ = (1U & (IData)(
                                                         (0xb3300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062164_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062163_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))))));
    if (vlSelf->wasmetal_core__DOT___010312_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7ffc48a0__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010302_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
        vlSelf->wasmetal_core__DOT___011666_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h842b3020__0)));
    }
    vlSelf->__VdfgTmp_h362b458b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009653_));
    vlSelf->__VdfgTmp_ha569c0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010044_));
    vlSelf->wasmetal_core__DOT___062045_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061619_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaa33330f0f00ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___062035_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h379220a5__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h90c7fdf4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf20faaf0__0))))))))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xf0f3355U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___061608_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((0xcaU 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___061607_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))) 
                                                                                << 1U)) 
                                                                               | (1U 
                                                                                & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061593_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061594_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hee831718__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062046_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062031_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___062057_ = (1U & (IData)(
                                                         (0x1d1d00000f55ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062054_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061707_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xcaU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x5533fffff0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x53U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057288_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057289_)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057243_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057247_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057286_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057290_)))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___062031_)))))))));
    vlSelf->wasmetal_core__DOT___051706_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051613_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (1U 
                                                          & (0x53U 
                                                             >> (IData)(vlSelf->__VdfgTmp_hb6137419__0))))))));
    vlSelf->wasmetal_core__DOT___051372_ = (1U & (0xc000aU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 3U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((0xacU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049529_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h304fb1ba__0))))));
    vlSelf->__VdfgTmp_h6748fbc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010241_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d 
        = (1U & (IData)((0x11110000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010242_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010241_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb5f0d294__0))))))));
    vlSelf->wasmetal_core__DOT___055271_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc16275c3__0))));
    vlSelf->__VdfgTmp_h2133c371__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hc16275c3__0));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010750_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf96aac0e__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009651_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he6780703__0))))))));
    vlSelf->wasmetal_core__DOT___011197_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d))))));
    vlSelf->__VdfgTmp_ha8f305c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056379_));
    vlSelf->wasmetal_core__DOT___056284_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___057011_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___056205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056196_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056195_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___056925_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___011898_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8472195__0))));
    vlSelf->wasmetal_core__DOT___057557_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hddfbd8d3__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010523_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010092_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010414_)))))))));
    vlSelf->wasmetal_core__DOT___011857_ = (1U & (IData)(
                                                         (0xfeeef000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h499272d1__0))))));
    vlSelf->__VdfgTmp_h88263545__0 = (((IData)(vlSelf->wasmetal_core__DOT___011042_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d));
    vlSelf->__VdfgTmp_hbc86843d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___053096_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xbf00bfbf00000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___053084_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053083_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053082_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050411_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050421_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050410_)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000e0e00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053078_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053064_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053049_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053048_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053064_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053022_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053023_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053021_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053045_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053066_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfff30004000cfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053066_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053060_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053065_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053046_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053047_)))))))))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf0f0fdfU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052732_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (vlSelf->insn_w 
                                                                            >> 1U))))))))))));
    vlSelf->wasmetal_core__DOT___057540_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010722_))));
    vlSelf->wasmetal_core__DOT___011924_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0)))));
    vlSelf->wasmetal_core__DOT___055118_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054771_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054786_)))))))));
    vlSelf->__VdfgTmp_hb67d963d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010102_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010101_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h724ed7d2__0)));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d 
        = (1U & (0xfef0U >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                              << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                         << 3U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010893_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde094a0f__0))))));
    vlSelf->__VdfgTmp_h6a02124a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056427_));
    vlSelf->__VdfgTmp_hcba8f5cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h45be7681__0 = (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010338_));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010338_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hfa355bbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d 
        = (1U & (IData)((0x11110000000fULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))));
    vlSelf->wasmetal_core__DOT___012978_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0))))))));
    vlSelf->__VdfgTmp_hf1841993__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he96324c1__0)));
    vlSelf->wasmetal_core__DOT___056896_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___012183_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x333355550f0f00ffULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))));
    vlSelf->wasmetal_core__DOT___056718_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h18547ac4__0))))))));
    vlSelf->wasmetal_core__DOT___011198_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010194_)) 
                                                  & (IData)(
                                                            (0xffffff11fffffff0ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h1b8b64b8__0))));
    vlSelf->__VdfgTmp_h40926396__0 = (((IData)(vlSelf->wasmetal_core__DOT___049566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049849_));
    vlSelf->__VdfgTmp_hfc74b95b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049089_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049098_));
    vlSelf->wasmetal_core__DOT___049836_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049835_))));
    vlSelf->wasmetal_core__DOT___049459_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049263_))));
    vlSelf->__VdfgTmp_h69fe2c1e__0 = (((IData)(vlSelf->wasmetal_core__DOT___049849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049853_));
    vlSelf->wasmetal_core__DOT___049099_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049097_))));
    vlSelf->wasmetal_core__DOT___050525_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049835_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049839_))));
    vlSelf->wasmetal_core__DOT___049266_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049263_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049262_))));
    vlSelf->wasmetal_core__DOT___061971_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061965_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2a3772ca__0))))))))))))));
    vlSelf->wasmetal_core__DOT___055155_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055153_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054913_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf5533ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4481aac1__0)))))))))))));
    vlSelf->wasmetal_core__DOT___054920_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___009643_)
                                                   ? 
                                                  (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0x3333555500ff0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054919_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054918_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054917_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054916_)))))))) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xff33ff550f0f0f0fULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054896_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc9c602ec__0)))))))))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xc0aU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054914_))))))))))
                                                   : 
                                                  (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xf0f333300ff5555ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___054905_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054904_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054903_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054902_)))))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xff33330f0f5555ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054913_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h4481aac1__0))))))))))));
    vlSelf->__VdfgTmp_h6e22e397__0 = (((IData)(vlSelf->wasmetal_core__DOT___049853_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049852_));
    vlSelf->wasmetal_core__DOT___049483_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049097_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049066_))));
    vlSelf->wasmetal_core__DOT___049843_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049839_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049838_))));
    vlSelf->wasmetal_core__DOT___049458_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049262_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049273_))));
    vlSelf->wasmetal_core__DOT___055981_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055979_))));
    vlSelf->__VdfgTmp_hd957e182__0 = (((IData)(vlSelf->wasmetal_core__DOT___049852_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049854_));
    vlSelf->__VdfgTmp_h9726a7a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049854_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049608_));
    vlSelf->__VdfgTmp_hc8d2269b__0 = (((IData)(vlSelf->wasmetal_core__DOT___049065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049072_));
    vlSelf->wasmetal_core__DOT___049074_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049066_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049065_))));
    vlSelf->wasmetal_core__DOT___049842_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049840_))));
    vlSelf->wasmetal_core__DOT___050524_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049841_))));
    vlSelf->wasmetal_core__DOT___049453_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049276_))));
    vlSelf->wasmetal_core__DOT___049278_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049273_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049272_))));
    vlSelf->__VdfgTmp_h7fb5afda__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h8d891945__0));
    vlSelf->__VdfgTmp_h658ce6a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_ha7c061ef__0));
    vlSelf->wasmetal_core__DOT___012992_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010518_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010553_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25073b9c__0)))))));
    vlSelf->__VdfgTmp_hf8199cb0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h143507db__0));
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___010718_ = (1U 
                                                & (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___010716_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h18547ac4__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___010718_ = (1U 
                                                & (0x53U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010533_))))));
        vlSelf->wasmetal_core__DOT___010716_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009842_))))));
    }
    vlSelf->__VdfgTmp_hb9280dfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h53247725__0));
    if (vlSelf->wasmetal_core__DOT___010323_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010124_)));
    } else if (vlSelf->wasmetal_core__DOT___007693_) {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc2d8d129__0)));
    } else {
        vlSelf->wasmetal_core__DOT___010300_ = (1U 
                                                & (0xeU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
        vlSelf->wasmetal_core__DOT___056553_ = (1U 
                                                & (0xe00U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hb7b9c3d6__0)));
    }
    vlSelf->wasmetal_core__DOT___010187_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))));
    vlSelf->wasmetal_core__DOT___061878_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff44ff00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007399_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055777_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf0f00003355ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___055467_))))))))))));
    vlSelf->wasmetal_core__DOT___054846_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054844_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054843_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010045_)))))))));
    vlSelf->wasmetal_core__DOT___012028_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010495_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010591_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h97dd8594__0)))))));
    vlSelf->wasmetal_core__DOT___019303_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1111f0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054884_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054880_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054879_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054878_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054877_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054873_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1327a702__0)))))))))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054876_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054875_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___012991_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010500_)) 
                                                  & (IData)(
                                                            (0xffffff00ffffff1fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010585_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 4U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc09bd195__0)))))));
    vlSelf->__VdfgTmp_ha4e3e772__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)));
    vlSelf->wasmetal_core__DOT___010770_ = (1U & (0xff00ff1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0))))));
    vlSelf->__VdfgTmp_h39adae05__0 = (((IData)(vlSelf->wasmetal_core__DOT___010122_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h4ec1ed59__0));
    vlSelf->__VdfgTmp_hffef1e62__0 = (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010280_));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d 
        = (1U & (IData)((0xeeee0000fff0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010281_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010280_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010278_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010279_)))))))));
    vlSelf->wasmetal_core__DOT___061795_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061674_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___061796_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061763_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061762_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___061649_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061674_)))))))));
    vlSelf->wasmetal_core__DOT___054799_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054736_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054737_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf6b3ca0e__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfce0919b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054729_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbec427aa__0)) 
                                                                                << 4U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb919cd7__0))))))))))))));
    vlSelf->wasmetal_core__DOT___054798_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f0eeeeff00ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054766_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33ff550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha9869a20__0))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf3f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054758_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054773_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054772_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054771_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054786_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))))))))))))));
    vlSelf->__VdfgTmp_hd5a37d8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___012027_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012029_));
    vlSelf->wasmetal_core__DOT___056721_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010597_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)))))))));
    vlSelf->__VdfgTmp_hda718c9e__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)));
    vlSelf->wasmetal_core__DOT___056898_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056327_)))))))));
    vlSelf->__VdfgTmp_h375c9c07__0 = (((IData)(vlSelf->wasmetal_core__DOT___056376_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056375_));
    vlSelf->wasmetal_core__DOT___057024_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___011728_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010836_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d))))));
    vlSelf->__VdfgTmp_heb18a766__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d));
    vlSelf->wasmetal_core__DOT___056919_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___011194_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d))))));
    vlSelf->__VdfgTmp_h51371d7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011867_));
    vlSelf->wasmetal_core__DOT___055974_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055972_))));
    vlSelf->__VdfgTmp_had4ae229__0 = ((2U & ((IData)(
                                                     (0xf0f0000aaccULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & ((0xbU 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010439_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff4f400000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056308_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010444_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))));
    vlSelf->wasmetal_core__DOT___071992_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xccccaaaaf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056324_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xccccaaaaf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))))))));
    vlSelf->wasmetal_core__DOT___012719_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xccccaaaaf0f0ff00ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0))));
    vlSelf->wasmetal_core__DOT___056723_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff00ffccaaaaf0f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->wasmetal_core__DOT___011919_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xff003355550f0fULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h929b802f__0))));
    vlSelf->__VdfgTmp_hca8ac9e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___056178_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d))));
    vlSelf->wasmetal_core__DOT___056500_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011122_)));
    if (vlSelf->wasmetal_core__DOT___008974_) {
        vlSelf->wasmetal_core__DOT___010209_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010208_)));
        vlSelf->wasmetal_core__DOT___010161_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010159_)));
    } else {
        vlSelf->wasmetal_core__DOT___010209_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010208_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0)))))));
        vlSelf->wasmetal_core__DOT___010161_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010159_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0)))))));
    }
    vlSelf->wasmetal_core__DOT___011020_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf939f2bf__0)))));
    vlSelf->wasmetal_core__DOT___010261_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010273_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hc43f9106__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010271_))))))));
    vlSelf->wasmetal_core__DOT___056437_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011603_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010966_));
    vlSelf->wasmetal_core__DOT___011997_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010166_));
    vlSelf->wasmetal_core__DOT___011119_ = (1U & (IData)(
                                                         (0xffffff11fffffff0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d 
        = (1U & (0xee000fU >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                << 4U) | (IData)(vlSelf->__VdfgTmp_h882f8f15__0))));
    vlSelf->wasmetal_core__DOT___056433_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3820fb89__0))));
    vlSelf->wasmetal_core__DOT___010219_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010254_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h7edccd87__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010252_))))))));
    vlSelf->wasmetal_core__DOT___056594_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011115_)));
    vlSelf->wasmetal_core__DOT___010972_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc63a86c__0)))));
    vlSelf->__VdfgTmp_hb25114eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012131_));
    vlSelf->wasmetal_core__DOT___010391_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x333355550f0f00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053906_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051689_)) 
                                                            << 1U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               >> 1U))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))));
    vlSelf->wasmetal_core__DOT___051690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051581_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051689_))));
    vlSelf->wasmetal_core__DOT___051719_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051630_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051631_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051630_))));
    vlSelf->wasmetal_core__DOT___053910_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053689_))));
    vlSelf->wasmetal_core__DOT___053663_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___051650_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051549_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051650_))));
    vlSelf->wasmetal_core__DOT___050828_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049644_))));
    vlSelf->wasmetal_core__DOT___051354_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x503U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051586_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((4U 
                                                             >> 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                              << 1U)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___057066_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010472_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010467_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0))))))));
    vlSelf->__VdfgTmp_hbe17c4c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hafd3f22a__0)));
    vlSelf->__VdfgTmp_h00b060af__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0)));
    vlSelf->wasmetal_core__DOT___012177_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0xaaaaccccff00fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010534_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0adc7ff6__0))))))));
    vlSelf->wasmetal_core__DOT___061512_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061459_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4dc07bf4__0))))))));
    vlSelf->__VdfgTmp_hf56802d2__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___061504_))) 
                                             << 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___061491_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___061490_)))));
    vlSelf->__VdfgTmp_hb5edd3cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 2U) | ((2U 
                                                  & ((0xfa330000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha587a88f__0)))))))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___019337_)));
    vlSelf->__VdfgTmp_h058d1256__0 = (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___019337_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xfefeff00ff00ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055032_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055031_) 
                                                                          << 3U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha587a88f__0))))))))));
    vlSelf->wasmetal_core__DOT___054972_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019319_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f5U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___054939_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8cc03967__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054966_)))))))));
    vlSelf->wasmetal_core__DOT___059205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___059201_))));
    vlSelf->wasmetal_core__DOT___060006_ = (1U & (IData)(
                                                         (0xf00ff8800000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059202_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005663_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059198_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x4000U 
                                                                            >> 
                                                                            ((8U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051507_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006106_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___059159_)))))))));
    vlSelf->wasmetal_core__DOT___069089_ = (1U & (IData)(
                                                         (0xff0044440000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048851_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048852_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h22ba1a50__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000169_)))))))));
    vlSelf->wasmetal_core__DOT___001947_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002289_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002288_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b64371c__0))))))));
    vlSelf->__VdfgTmp_h85a07a94__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbd418077__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001963_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001964_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h5b64371c__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT___068967_ = (1U & (0xccf000aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002811_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048859_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048860_)))))));
    vlSelf->__VdfgTmp_h07469665__0 = (((IData)(vlSelf->wasmetal_core__DOT___002564_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2ac6c9b8__0));
    vlSelf->wasmetal_core__DOT___002353_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048771_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002851_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002852_)))))))));
    vlSelf->__VdfgTmp_hcbcea2b7__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((~ (IData)(vlSelf->wasmetal_core__DOT___000152_)) 
                                                 & (IData)(
                                                           (0xfff0ffff1111ffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000163_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                               ? (IData)(vlSelf->wasmetal_core__DOT___001727_)
                                                                               : 
                                                                              (0xc0aU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001937_)))))) 
                                                                             << 1U)) 
                                                                         | ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                                            & (IData)(
                                                                                (0xff00ccccf0f0aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001731_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001729_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___001726_))))))))))))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000167_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb4d5b900__0))))))))));
    vlSelf->__VdfgTmp_h91cc03bd__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha720ddd6__0))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h343b1824__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000164_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000163_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb4d5b900__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015651_))));
    vlSelf->wasmetal_core__DOT___011921_ = (1U & (IData)(
                                                         (0xbbf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->__VdfgTmp_hba8ce1a4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010573_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9c14d25f__0)));
    vlSelf->wasmetal_core__DOT___055251_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h2544c7bd__0))))));
    vlSelf->wasmetal_core__DOT___058931_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058693_))));
    vlSelf->wasmetal_core__DOT___068032_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6dac888a__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))))))))))));
    vlSelf->wasmetal_core__DOT___002196_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h6dac888a__0)))))));
    vlSelf->wasmetal_core__DOT___049530_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049528_))));
    vlSelf->wasmetal_core__DOT___051614_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051613_))));
    vlSelf->wasmetal_core__DOT___050254_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050253_))));
    vlSelf->wasmetal_core__DOT___051301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050253_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050176_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050175_))));
    vlSelf->wasmetal_core__DOT___051303_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050175_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050261_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050260_))));
    vlSelf->wasmetal_core__DOT___051309_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050260_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050265_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050138_))));
    vlSelf->wasmetal_core__DOT___050139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050275_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050164_))));
    vlSelf->wasmetal_core__DOT___050165_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050164_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___050277_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050153_))));
    vlSelf->wasmetal_core__DOT___050154_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050153_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051284_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050167_))));
    vlSelf->wasmetal_core__DOT___050168_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050167_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___051281_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050142_))));
    vlSelf->wasmetal_core__DOT___050143_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050142_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___006633_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___006632_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127453___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003805_))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022667_));
    vlSelf->wasmetal_core__DOT___068437_ = (1U & (IData)(
                                                         (0xcc000f000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf11U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h703a7a56__0)) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9934c93f__0)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048729_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048730_)))))))));
    vlSelf->wasmetal_core__DOT___003054_ = (1U & ((1U 
                                                   & (0x10000U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                        << 4U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he03432df__0))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9934c93f__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h162766a7__0)))))));
    vlSelf->wasmetal_core__DOT___066293_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002476_))));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (0xfdfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___002479_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002478_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002476_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002475_)))))));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002115_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002114_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002113_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002112_))))))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002395_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002394_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002393_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002392_))))))));
    } else {
        vlSelf->wasmetal_core__DOT___002468_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___002477_)));
        vlSelf->wasmetal_core__DOT___002029_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002116_))));
        vlSelf->wasmetal_core__DOT___048788_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002396_))));
    }
    vlSelf->wasmetal_core__DOT___009520_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050848_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79a3c79a__0))));
    vlSelf->wasmetal_core__DOT___051582_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051346_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051581_))));
    vlSelf->wasmetal_core__DOT___067822_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf033f0f0ffffff55ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb62f452d__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))))))))))));
    vlSelf->wasmetal_core__DOT___001250_ = (1U & (0xf00011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb62f452d__0)))));
    vlSelf->wasmetal_core__DOT___002719_ = (1U & ((1U 
                                                   & (IData)(
                                                             (0xeULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h22ba1a50__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hdf798121__0)))))));
    vlSelf->wasmetal_core__DOT___002076_ = (1U & (IData)(
                                                         (0xff00ff00ff000eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048832_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h81d9e1ef__0))))))));
    vlSelf->wasmetal_core__DOT___002516_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfd6c95b6__0)))))));
    vlSelf->wasmetal_core__DOT___002431_ = (1U & (IData)(
                                                         (0xff00f000ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h5a517e30__0)))))));
    vlSelf->wasmetal_core__DOT___068486_ = (1U & (IData)(
                                                         (0xf0ccf0f0000000aaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))))))));
    vlSelf->wasmetal_core__DOT___001807_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002069_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002068_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0da24f1d__0))))))));
    vlSelf->__VdfgTmp_hf699b114__0 = ((4U & ((0xc0a0000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))))) 
                                             << 2U)) 
                                      | ((2U & (((IData)(vlSelf->wasmetal_core__DOT___000170_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha952ad99__0))
                                                   : 
                                                  (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___001853_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___001854_))))
                                                  : 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                  | (1U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h0da24f1d__0)))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___000152_)));
    vlSelf->__VdfgTmp_h912dcb78__0 = (((IData)(vlSelf->wasmetal_core__DOT___002894_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002893_));
    vlSelf->__VdfgTmp_he7cac7a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011508_));
    vlSelf->wasmetal_core__DOT___056179_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010022_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010045_))))));
    vlSelf->wasmetal_core__DOT___049926_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049382_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))));
    vlSelf->wasmetal_core__DOT___051550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051549_))));
    vlSelf->wasmetal_core__DOT___049898_ = (1U & (IData)(
                                                         (0x5555ccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049440_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h35851421__0)))));
    vlSelf->wasmetal_core__DOT___051521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051520_))));
    vlSelf->__VdfgTmp_h76242b02__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005823_));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006274_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023480_));
    vlSelf->__VdfgTmp_h54bf9a7e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049815_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049814_))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (IData)(vlSelf->__VdfgTmp_h951148c2__0))));
    vlSelf->wasmetal_core__DOT___051367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051113_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051366_))));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___014037_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023601_));
    vlSelf->wasmetal_core__DOT___049765_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___051347_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051346_))));
    vlSelf->wasmetal_core__DOT___061513_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061507_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061502_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061497_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061489_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___061482_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061475_)))))))));
    vlSelf->wasmetal_core__DOT___061514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061490_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061476_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha1796962__0))))));
    vlSelf->wasmetal_core__DOT___061510_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061477_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___061476_))));
    vlSelf->wasmetal_core__DOT___061663_ = (1U & (IData)(
                                                         (0xf030a020f0300030ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061661_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x5f4c554400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061654_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061637_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061639_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061621_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061620_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27ece1ce__0))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048270_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061637_)))))))));
    vlSelf->wasmetal_core__DOT___056639_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009842_)))))))));
    vlSelf->wasmetal_core__DOT___011936_ = ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                            & (IData)(
                                                      (0x55550f0f00ff0033ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010540_)))))))));
    vlSelf->wasmetal_core__DOT___012042_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___009842_))))));
    vlSelf->__VdfgTmp_ha7112868__0 = (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h3cc7dcfe__0 = (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010231_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h02606b30__0)));
    vlSelf->__VdfgTmp_h4a9b748c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011992_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___049383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047949_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049382_))));
    vlSelf->wasmetal_core__DOT___051327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050692_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051326_))));
    vlSelf->wasmetal_core__DOT___065065_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048345_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063925_))));
    vlSelf->wasmetal_core__DOT___055999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055997_))));
    vlSelf->wasmetal_core__DOT___056005_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055997_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053772_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___060758_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019204_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007059_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___019201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019203_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x53U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___019278_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1b99479d__0))))))))))));
    vlSelf->wasmetal_core__DOT___062129_ = (1U & (IData)(
                                                         (0xf0ff44ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061665_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055047_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052741_)))))))));
    vlSelf->wasmetal_core__DOT___061448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019277_))));
    vlSelf->wasmetal_core__DOT___055874_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019277_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_h84446dc0__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((IData)(
                                                              (0xaaaaf0f0ff00ccccULL 
                                                               >> 
                                                               ((8U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                                    << 3U)) 
                                                                | ((4U 
                                                                    & ((0xacU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                                       << 2U)) 
                                                                   | ((2U 
                                                                       & ((0xacU 
                                                                           >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha0b2e14a__0)))))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hce73595f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4f58838a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb043089c__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hb2b84c00__0))))))))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048673_));
    vlSelf->wasmetal_core__DOT___049527_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___050789_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3d1308f6__0))))));
    vlSelf->wasmetal_core__DOT___047950_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6d3ebca4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce2b20fd__0))))));
    vlSelf->wasmetal_core__DOT___050850_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he957a5af__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049645_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0))))));
    vlSelf->wasmetal_core__DOT___049054_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h77ed0e73__0))))));
    vlSelf->wasmetal_core__DOT___049226_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb4c65051__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_he957a5af__0))))));
    vlSelf->wasmetal_core__DOT___049748_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfbafed17__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049747_))));
    vlSelf->wasmetal_core__DOT___049885_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049884_))));
    vlSelf->wasmetal_core__DOT___049796_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049795_))));
    vlSelf->wasmetal_core__DOT___049699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049498_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049698_))));
    vlSelf->wasmetal_core__DOT___049619_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049615_))));
    vlSelf->wasmetal_core__DOT___055016_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055014_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055013_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033416_)))))))));
    vlSelf->wasmetal_core__DOT___050048_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050046_))));
    vlSelf->wasmetal_core__DOT___049506_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049499_))));
    vlSelf->wasmetal_core__DOT___049146_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049121_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049120_))));
    vlSelf->wasmetal_core__DOT___050694_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048590_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048589_))));
    vlSelf->wasmetal_core__DOT___049887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049616_))));
    vlSelf->wasmetal_core__DOT___050792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050787_))));
    vlSelf->wasmetal_core__DOT___049798_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049500_))));
    vlSelf->wasmetal_core__DOT___049750_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049144_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049121_))));
    vlSelf->wasmetal_core__DOT___049371_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047952_))));
    vlSelf->wasmetal_core__DOT___049702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048590_))));
    vlSelf->__VdfgTmp_h10a668fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___063925_));
    vlSelf->wasmetal_core__DOT___002632_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002761_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002759_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002758_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_))))));
    vlSelf->wasmetal_core__DOT___002634_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002843_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002841_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002840_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002842_))))));
    vlSelf->wasmetal_core__DOT___002630_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002682_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002680_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002679_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002681_))))));
    vlSelf->wasmetal_core__DOT___002629_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002643_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002641_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002640_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002642_))))));
    vlSelf->wasmetal_core__DOT___019808_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((7U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052806_))));
    vlSelf->wasmetal_core__DOT___019809_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071471_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)))))));
    vlSelf->wasmetal_core__DOT___039935_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___128672___DOT__CO__BRA__0__KET__) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039878_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039883_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039882_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039881_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039880_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039871_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039879_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039876_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034698_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039875_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039874_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039873_ = (1U & (0xa2a2a2aeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039998_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039942_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039941_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___039922_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___039917_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT___039937_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___039936_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___039934_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d)))))));
    vlSelf->wasmetal_core__DOT___039933_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d)))))));
    vlSelf->wasmetal_core__DOT___039945_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___039946_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT___039947_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT___039954_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___039970_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___039959_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___039958_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___039957_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___039956_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT___039938_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___039932_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___039952_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___039951_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___039950_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___039949_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT___039960_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___039961_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___039962_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT___039969_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___039985_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___039974_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d)))))));
    vlSelf->wasmetal_core__DOT___039973_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___039972_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT___039971_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT___039953_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___039948_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d)))))));
    vlSelf->wasmetal_core__DOT___039967_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT___039966_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___039965_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT___039964_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT___039975_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___039976_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT___039977_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT___039984_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___040001_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___039989_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT___039988_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___039987_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d)))))));
    vlSelf->wasmetal_core__DOT___039986_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT___039968_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___039963_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT___039982_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT___039981_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___039980_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d)))))));
    vlSelf->wasmetal_core__DOT___039979_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d)))))));
    vlSelf->wasmetal_core__DOT___039990_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___039991_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d)))))));
    vlSelf->wasmetal_core__DOT___039992_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d)))))));
    vlSelf->wasmetal_core__DOT___040000_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___040015_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d)))))));
    vlSelf->wasmetal_core__DOT___040005_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d)))))));
    vlSelf->wasmetal_core__DOT___040004_ = (1U & (0xa2aea2a2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052806_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((7U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h364b73f0__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d)))))));
}
